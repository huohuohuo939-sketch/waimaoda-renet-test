# -*- coding: utf-8 -*-
"""Conservative manufacturer lead classification, contact cleaning and reversible deduplication."""
import re
from urllib.parse import urlparse, parse_qs

EMAIL_RE = re.compile(r'^[A-Z0-9.!#$%&\'*+/=?^_`{|}~-]+@[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?(?:\.[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?)+$', re.I)
NOISE = {
    '招聘/职位': re.compile(r'招聘|职位|job\b|career\b|vacancy|sales manager\s*:|international sales representative|sales representative|export sales manager|business development representative|国际业务员|外贸业务员', re.I),
    '新闻/媒体/文章': re.compile(r'\b(news|times|businessline|blog|press release|history month)\b|高考|出路|women.s history month', re.I),
    '营销/软件/服务商': re.compile(r'\b(digital|marketing|crm|software|agency|consulting|advertising)\b', re.I),
}
# Strong terms indicate a manufacturing candidate; weak terms alone only send a row to review.
MAKER_STRONG = re.compile(r'\b(manufacturer|manufacturers|manufacturing|factory|factories|production plant|producer|oem|odm|machinery manufacturer|equipment manufacturer|mining machinery)\b|制造商|制造厂|生产厂|工厂|生产基地|生产企业', re.I)
MAKER_MEDIUM = re.compile(r'\b(machinery|machine|equipment|industrial|production|plant|crusher|processing|mining)\b|机械|设备|矿山|矿机|加工|制造', re.I)
DISTRIBUTOR = re.compile(r'\b(distributor|dealer|trading company|supplier|reseller)\b|经销商|代理商|贸易公司|供应商', re.I)
FREE_EMAIL = {'gmail.com','yahoo.com','outlook.com','hotmail.com','163.com','126.com','qq.com','foxmail.com','vip.163.com'}


def _list(v):
    if isinstance(v, str): return [v] if v.strip() else []
    return [str(x).strip() for x in (v or []) if str(x).strip()]


def _emails(values):
    out=[]
    for raw in values:
        for item in re.split(r'[;,\s]+', str(raw or '')):
            e=item.strip().strip('<>()[]{}.,;:').lower()
            if e and EMAIL_RE.match(e) and e not in out: out.append(e)
    return out


def _wa(values, allow_number=False):
    """Normalize explicit WhatsApp URLs; allow bare numbers only from an explicitly labelled WA field."""
    out=[]
    for raw in values:
        s=str(raw or '').strip()
        if not s: continue
        candidate=''
        try:
            p=urlparse(s if '://' in s else 'https://' + s)
            host=(p.hostname or '').lower()
            if host == 'wa.me': candidate=p.path.strip('/').split('/')[0]
            elif host in {'whatsapp.com','api.whatsapp.com','web.whatsapp.com'}:
                candidate=(parse_qs(p.query).get('phone') or [''])[0]
        except Exception: pass
        digits=re.sub(r'\D','',candidate)
        if not digits and allow_number and re.fullmatch(r'[+\d() .-]{8,24}',s):
            digits=re.sub(r'\D','',s)
        if 8 <= len(digits) <= 15:
            link='https://wa.me/'+digits
            if link not in out: out.append(link)
    return out


def _clean_phones(values):
    out=[]
    for raw in values:
        for part in re.split(r'[;\n|]+',str(raw or '')):
            value=part.strip()
            if not value or re.search(r'\b20\d{2}[-/.年]\d{1,2}[-/.月]\d{1,2}',value):
                continue
            digits=re.sub(r'\D','',value)
            if 7 <= len(digits) <= 15 and re.fullmatch(r'[+\d() .\-/extEXT分机号#]+',value):
                if value not in out: out.append(value)
    return out


def _domain(row):
    u=str(row.get('company_website') or row.get('website') or '').strip()
    if not u: return ''
    try:
        p=urlparse(u if '://' in u else 'https://'+u)
        host=(p.hostname or '').lower()
        return host[4:] if host.startswith('www.') else host
    except Exception: return ''


def _name_key(name):
    s=str(name or '').lower()
    s=re.sub(r'\b(limited|ltd|co\.?|company|inc\.?|corp\.?|corporation|group)\b',' ',s)
    return re.sub(r'[^a-z0-9\u4e00-\u9fff]+','',s)


def assess(row):
    name=str(row.get('company_name') or row.get('工厂/公司名称') or row.get('name_title') or row.get('page_title') or '').strip()
    industry=str(row.get('industry') or row.get('industry_category') or row.get('行业') or '')
    evidence=' '.join([name, industry, str(row.get('manufacturer_evidence') or ''), str(row.get('notes') or '')])
    for reason, pat in NOISE.items():
        if pat.search(name): return 'excluded', reason
    if MAKER_STRONG.search(evidence): return 'keep', '出现明确制造/工厂/OEM证据，列为制造商候选，仍需官网核实'
    if MAKER_MEDIUM.search(evidence): return 'review', '出现行业或产品词，但尚无明确生产制造证据'
    if DISTRIBUTOR.search(evidence): return 'review', '可能为供应商/经销商/贸易商，需确认是否自有工厂'
    return 'review', '缺少明确制造商证据，暂存待人工复核'


def clean_and_dedupe(rows):
    """Return (accepted, quarantine, stats). Never discard contacts when merging duplicate entities."""
    accepted=[]; quarantine=[]; groups={}
    stats={'input':len(rows),'excluded':0,'review':0,'duplicate_rows_merged':0,'invalid_emails':0,'email_domain_conflicts':0,'mixed_email_domains':0,'phone_values_not_whatsapp':0}
    for index, original in enumerate(rows):
        r=dict(original)
        name=str(r.get('company_name') or r.get('工厂/公司名称') or r.get('name_title') or r.get('page_title') or '').strip()
        status,reason=assess(r)
        if status=='excluded':
            stats['excluded']+=1; quarantine.append({'record':r,'quality_status':'excluded','quality_reason':reason}); continue
        if status=='review': stats['review']+=1
        r['company_name']=name
        # Explicit WA URLs and explicitly labelled WA contact fields only.
        wa_links=_list(r.get('whatsapp_links'))
        wa_contacts=_clean_phones(_list(r.get('whatsapp_contacts')))
        wa_links += _list(r.get('联系方式'))
        r['whatsapp_contacts']=wa_contacts
        r['whatsapp_links']=list(dict.fromkeys(_wa(wa_links)))
        raw_emails=_list(r.get('emails'))+_list(r.get('邮箱'))
        valid=_emails(raw_emails); stats['invalid_emails'] += max(0,len(raw_emails)-len(valid))
        r['emails']=valid
        raw_contact_values=[]
        for contact_value in _list(r.get('联系方式')):
            for contact_part in re.split(r'[;\n|]+',contact_value):
                contact_part=contact_part.strip()
                if contact_part and not re.search(r'(?:wa\.me/|whatsapp\.com/)',contact_part,re.I):
                    raw_contact_values.append(contact_part)
        phones=_clean_phones(_list(r.get('phone_candidates'))+raw_contact_values)
        r['phone_candidates']=phones
        stats['phone_values_not_whatsapp'] += len(phones)
        domain=_domain(r)
        email_domains={e.rsplit('@',1)[1] for e in valid}
        if len(email_domains)>1:
            r['quality_warning']='同一记录含多个邮箱域名，需逐个核验邮箱归属'; stats['mixed_email_domains']+=1
        if domain and any(edomain != domain and not edomain.endswith('.'+domain) and edomain not in FREE_EMAIL for edomain in email_domains):
            r['quality_warning']='邮箱域名与官网域名不一致，需核验归属'; stats['email_domain_conflicts']+=1
        key=('domain:'+domain) if domain else ('name:'+_name_key(name) if len(_name_key(name))>=4 else 'row:'+str(index))
        if key in groups:
            primary=groups[key]
            primary['emails']=list(dict.fromkeys(primary.get('emails',[])+valid))
            primary['whatsapp_links']=list(dict.fromkeys(primary.get('whatsapp_links',[])+r['whatsapp_links']))
            primary['whatsapp_contacts']=list(dict.fromkeys(_list(primary.get('whatsapp_contacts'))+_list(r.get('whatsapp_contacts'))))
            primary['source_urls']=list(dict.fromkeys(_list(primary.get('source_urls'))+_list(r.get('source_urls'))))
            primary['phone_candidates']=list(dict.fromkeys(_list(primary.get('phone_candidates'))+phones))
            primary['linkedin_links']=list(dict.fromkeys(_list(primary.get('linkedin_links'))+_list(r.get('linkedin_links'))))
            # Address is merged only inside the same domain/name dedupe group; never copy
            # an address from a different company record.
            if not primary.get('company_address') and r.get('company_address'):
                primary['company_address']=r.get('company_address')
                primary['address_source_url']=r.get('address_source_url','')
            for field in ('contact_evidence','email_details'):
                left=primary.get(field) or ({} if field=='contact_evidence' else [])
                right=r.get(field) or ({} if field=='contact_evidence' else [])
                if field=='contact_evidence' and isinstance(left,dict) and isinstance(right,dict):
                    for kind,mapping in right.items():
                        if isinstance(mapping,dict): left.setdefault(kind,{}).update({k:v for k,v in mapping.items() if k not in left.get(kind,{})})
                    primary[field]=left
                elif field=='email_details' and isinstance(left,list) and isinstance(right,list):
                    seen_email={str(x.get('email','')).lower() for x in left if isinstance(x,dict)}
                    primary[field]=left+[x for x in right if isinstance(x,dict) and str(x.get('email','')).lower() not in seen_email]
            warnings=list(dict.fromkeys(x for x in [primary.get('quality_warning'),r.get('quality_warning')] if x))
            if warnings: primary['quality_warning']='；'.join(warnings)
            primary['notes']=(str(primary.get('notes') or '')+'；合并重复记录：'+name).strip('；')
            stats['duplicate_rows_merged']+=1
            quarantine.append({'record':r,'quality_status':'duplicate_merged','quality_reason':'已合并到主记录 '+str(primary.get('company_name') or name)})
            continue
        r['quality_status']=status; r['quality_category']='制造商候选' if status=='keep' else '待人工复核'; r['quality_reason']=reason
        groups[key]=r
    accepted=list(groups.values())
    def rank(r):
        status=0 if r.get('quality_status')=='keep' else 1
        contact=int(bool(r.get('emails')))+int(bool(r.get('whatsapp_links')))
        score=int(r.get('factory_authenticity_score') or r.get('manufacturer_score') or 0)
        return (status,-score,-contact,str(r.get('company_name','')).casefold())
    accepted.sort(key=rank)
    stats['accepted']=len(accepted); stats['quarantined']=len(quarantine); stats['manufacturer_candidates']=sum(r.get('quality_status')=='keep' for r in accepted); stats['review_kept']=sum(r.get('quality_status')=='review' for r in accepted)
    return accepted,quarantine,stats
