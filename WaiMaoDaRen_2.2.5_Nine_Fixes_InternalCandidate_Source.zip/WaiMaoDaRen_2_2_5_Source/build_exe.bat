@echo off
setlocal EnableExtensions
set "APP_DIR=%~dp0"
for %%I in ("%APP_DIR%.") do set "APP_DIR=%%~fI\"
set "REQ_FILE=%APP_DIR%requirements.txt"
set "APP_FILE=%APP_DIR%app.py"
set "DIST_DIR=%APP_DIR%dist\WaiMaoDaRen_2_1_9"

title WaiMaoDaRen - Build EXE
if not exist "%REQ_FILE%" (
  echo [ERROR] Cannot find requirements.txt: "%REQ_FILE%"
  pause
  exit /b 2
)
if not exist "%APP_FILE%" (
  echo [ERROR] Cannot find app.py: "%APP_FILE%"
  pause
  exit /b 2
)
set "PYTHON_CMD="
where py >nul 2>nul
if not errorlevel 1 set "PYTHON_CMD=py -3"
if not defined PYTHON_CMD (
  where python >nul 2>nul
  if not errorlevel 1 set "PYTHON_CMD=python"
)
if not defined PYTHON_CMD (
  echo [ERROR] Python 3.10 or newer was not found.
  pause
  exit /b 1
)
%PYTHON_CMD% -m pip install --disable-pip-version-check -r "%REQ_FILE%" pyinstaller
if errorlevel 1 (
  echo [ERROR] Build dependencies failed.
  pause
  exit /b 1
)
pushd "%APP_DIR%"
%PYTHON_CMD% -m PyInstaller --noconfirm --clean --windowed --name WaiMaoDaRen_2_1_9 "%APP_FILE%"
if errorlevel 1 (
  popd
  echo [ERROR] PyInstaller build failed.
  pause
  exit /b 1
)
for %%F in (industry_catalog.csv industry_catalog_supplement.csv) do if exist "%%F" copy /Y "%%F" "dist\WaiMaoDaRen_2_1_9\" >nul
popd
echo Build completed.
pause
endlocal
