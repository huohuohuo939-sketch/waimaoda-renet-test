import csv, re, time, threading, os, html, sqlite3, json, base64, sys, queue, socket, urllib.request, platform, random, shutil, uuid
from urllib.parse import urljoin, urlparse, unquote, parse_qs, urlencode, urlunparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from urllib.robotparser import RobotFileParser
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import requests
from bs4 import BeautifulSoup
from data_quality import clean_and_dedupe, assess
from search_scheduler import (build_rounds, flatten_rounds, plan_signature, load_progress, save_progress,
                               load_performance, record_query_performance, prioritize_rounds)
from api_services import (load_api_keys, save_api_keys, search_providers, init_provider_db, provider_usage,
                          record_provider_call, search_serpapi, search_brave, score_three_dimensions, ProviderError, set_provider_quota, get_provider_quotas, rank_search_engines, record_engine_search, record_engine_qualification, search_engine_performance, paid_monthly_usage, paid_task_usage)
try:
    import truststore
    truststore.inject_into_ssl()
except Exception:
    pass

def resolve_app_dir(is_frozen=False, executable=None, source_file=None):
    if is_frozen and executable:
        return os.path.dirname(os.path.abspath(executable))
    return os.path.dirname(os.path.abspath(source_file or __file__))


APP_DIR = resolve_app_dir(getattr(sys, 'frozen', False), sys.executable, __file__)
CATALOG_FILE = os.path.join(APP_DIR, 'industry_catalog.csv')

def resolve_persistent_db_file(app_dir):
    """Keep the company database across version-folder upgrades on Windows.

    On Windows the canonical database lives under %LOCALAPPDATA%\\WaiMaoDaRen.
    First launch migrates the richest non-empty database from current/sibling
    version folders using SQLite backup (safe with WAL databases).
    """
    if os.name != 'nt':
        return os.path.join(app_dir, 'factorylead.db')
    root = os.environ.get('LOCALAPPDATA') or os.path.join(os.path.expanduser('~'), 'AppData', 'Local')
    data_dir = os.path.join(root, 'WaiMaoDaRen')
    os.makedirs(data_dir, exist_ok=True)
    target = os.path.join(data_dir, 'factorylead.db')
    if os.path.exists(target):
        try:
            check = sqlite3.connect(target, timeout=5)
            try: existing_count = int(check.execute('SELECT COUNT(*) FROM leads').fetchone()[0])
            finally: check.close()
            if existing_count > 0: return target
        except Exception:
            # An empty/invalid first-run shell must not prevent recovery from an older version folder.
            pass
    candidates = [os.path.join(app_dir, 'factorylead.db')]
    # Users commonly extract a ZIP into an outer folder which contains the
    # package's own source folder. Search the current directory and two parents
    # deep so both flat and nested extraction layouts can migrate old data.
    roots = [os.path.abspath(app_dir), os.path.dirname(os.path.abspath(app_dir)),
             os.path.dirname(os.path.dirname(os.path.abspath(app_dir)))]
    for scan_root in dict.fromkeys(roots):
        try:
            for walk_root, dirs, files in os.walk(scan_root):
                depth = os.path.relpath(walk_root, scan_root).count(os.sep)
                if depth >= 2: dirs[:] = []
                if 'factorylead.db' in files:
                    folder = os.path.basename(walk_root).lower()
                    if folder.startswith(('waimaodaren','factorylead')):
                        candidates.append(os.path.join(walk_root,'factorylead.db'))
        except OSError:
            continue
    ranked = []
    for source in dict.fromkeys(candidates):
        if not os.path.isfile(source): continue
        try:
            src = sqlite3.connect(source, timeout=5)
            try: count = int(src.execute('SELECT COUNT(*) FROM leads').fetchone()[0])
            finally: src.close()
            if count > 0: ranked.append((count, os.path.getmtime(source), source))
        except Exception: continue
    if ranked:
        _, _, source = max(ranked)
        src = sqlite3.connect(source, timeout=10); dst = sqlite3.connect(target, timeout=10)
        try: src.backup(dst)
        finally: dst.close(); src.close()
    return target

DB_FILE = resolve_persistent_db_file(APP_DIR)
QUALITY_QUARANTINE_FILE = os.path.join(APP_DIR, 'quality_quarantine.json')
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
TIMEOUT = 15
MAX_SITE_PAGES = 10

WA_RE = re.compile(r'''(?i)(?:https?:)?//(?:www\.)?(?:wa\.me/[+\d]+|(?:api|web)\.whatsapp\.com/send\?[^\s\"'<>\\]+|(?:www\.)?whatsapp\.com/(?:send|channel)/[^\s\"'<>\\]+)''')
EMAIL_RE = re.compile(r'(?i)(?<![\w.+-])([A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,})(?![\w.-])')
PHONE_RE = re.compile(r'(?<![\w@])(?:\+?\d[\d\s().\-]{5,}\d)(?![\w@])')
LINKEDIN_RE = re.compile(r'https?://(?:[a-z]{2,3}\.)?linkedin\.com/(?:company|in|showcase|school)/[^\s"<>?#]+', re.I)
EMAIL_ROLE_RULES = [
    ('sales', ('sales', 'sale', 'businessdevelopment', 'bd', 'commercial'), 95, '销售'),
    ('export', ('export', 'overseas', 'international', 'global'), 95, '外贸/出口'),
    ('inquiry', ('inquiry', 'enquiry', 'rfq', 'quote', 'quotation', 'request'), 90, '询盘/报价'),
    ('purchase', ('purchase', 'purchasing', 'procurement', 'sourcing', 'buying'), 70, '采购'),
    ('marketing', ('marketing', 'market'), 65, '市场'),
    ('info', ('info', 'contact', 'office', 'hello', 'general'), 65, '通用商务'),
    ('service', ('service', 'support', 'after sales', 'aftersales'), 50, '客服/售后'),
    ('hr', ('hr', 'career', 'careers', 'recruit', 'job', 'jobs'), 10, '人力资源'),
    ('finance', ('finance', 'account', 'accounting', 'billing', 'invoice'), 10, '财务'),
]

MANUFACTURER_WORDS = {
    'manufacturer': 7, 'manufacturing': 7, 'factory': 8, 'plant': 6, 'producer': 6,
    'production': 5, 'oem': 5, 'odm': 5, 'exporter': 4, 'supplier': 3,
    'fabricat': 5, 'workshop': 3, 'industrial': 2, 'made in': 4, 'production line': 7,
    'manufacture': 6, 'own factory': 9, 'production facility': 9, 'factory direct': 9,
    '工厂': 8, '厂家': 8, '生产厂家': 10, '制造厂': 10, '制造商': 9, '制造': 5,
    '生产': 6, '源头工厂': 10, '自有工厂': 10, '工厂直销': 8, '生产线': 8,
    '厂房': 5, '车间': 5, '加工厂': 9, '实业': 3, '产业园': 3, '代工': 6,
    '贴牌生产': 7, '研发生产': 7, '生产基地': 8, '生产企业': 8, '厂家直供': 8,
}
NEGATIVE_WORDS = {'distributor': -4, 'trading company': -7, 'trading': -3, 'wholesale': -2, 'agent': -5}
CONTACT_PATHS = ['contact', 'contact-us', 'about', 'about-us', 'company', 'factory', 'products', 'services', 'export', 'oem', 'certification']
SOCIAL_DOMAINS = ['linkedin.com','facebook.com','instagram.com','youtube.com','tiktok.com','x.com','twitter.com','pinterest.com']
DIRECTORY_DOMAINS = ['alibaba.com','made-in-china.com','globalsources.com','indiamart.com','1688.com','amazon.com','aliexpress.com','shunqi.com','gongchang.com']
IGNORED_OUTBOUND_DOMAINS = set(SOCIAL_DOMAINS + DIRECTORY_DOMAINS + ['google.com','baidu.com','qq.com','weixin.qq.com'])


def create_http_session():
    """Create a browser-like HTTP session and honor Windows/Python proxy settings."""
    session = requests.Session()
    # requests honors HTTP_PROXY/HTTPS_PROXY/NO_PROXY by default. On Windows,
    # urllib also reads the user's Internet Settings proxy configuration.
    try:
        system_proxies = urllib.request.getproxies()
        if system_proxies and not any((os.environ.get(k) or os.environ.get(k.upper())) for k in ('http_proxy','https_proxy','all_proxy')):
            if hasattr(session, 'proxies'):
                session.proxies.update({k: v for k, v in system_proxies.items() if k in ('http','https','all') and v})
    except Exception:
        pass
    try:
        session.trust_env = True
    except Exception:
        pass
    default_headers = {
        'User-Agent': USER_AGENT,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9,zh-CN;q=0.7,zh;q=0.6',
        'Upgrade-Insecure-Requests': '1',
    }
    if hasattr(session, 'headers'):
        session.headers.update(default_headers)
    retry = Retry(total=2, connect=2, read=1, backoff_factor=0.5,
                  status_forcelist=(500, 502, 503, 504),
                  allowed_methods=frozenset(['GET', 'HEAD']),
                  raise_on_status=False)
    adapter = HTTPAdapter(max_retries=retry, pool_connections=12, pool_maxsize=12)
    if hasattr(session, 'mount'):
        session.mount('http://', adapter)
        session.mount('https://', adapter)
    return session


def run_network_diagnostics():
    """Check optional API endpoints and API-free public search entry points."""
    targets = [
        ('自主搜索 Bing', 'www.bing.com', 'https://www.bing.com/search?q=export+manager+China'),
        ('自主搜索 DuckDuckGo', 'html.duckduckgo.com', 'https://html.duckduckgo.com/html/?q=export+manager+China'),
        ('自主搜索 Baidu', 'www.baidu.com', 'https://www.baidu.com/s?wd=外贸经理'),
        ('自主搜索 Ecosia', 'www.ecosia.org', 'https://www.ecosia.org/search?q=export+manager+China'),
        ('自主搜索 Yandex', 'yandex.com', 'https://yandex.com/search/?text=export+manager+China'),
        ('SerpApi 搜索 API（可选）', 'serpapi.com', 'https://serpapi.com/search.json'),
        ('Brave Search API（可选）', 'api.search.brave.com', 'https://api.search.brave.com/res/v1/web/search'),
    ]
    session = create_http_session()
    rows = []
    for label, host, url in targets:
        dns_text = 'DNS失败'
        try:
            socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)
            dns_text = 'DNS成功'
        except Exception as exc:
            dns_text = f'DNS失败：{type(exc).__name__}: {str(exc)[:100]}'
        try:
            # No API key is sent. An authentication/parameter response still proves
            # endpoint reachability, not that the account is authenticated.
            response = session.get(url, timeout=(8, 12), allow_redirects=False)
            status = response.status_code
            result = ('公开搜索入口可访问' if status < 400 else '公开搜索入口返回访问限制/错误') if '自主搜索' in label else ('API端点可访问（未验证密钥）' if status < 500 else 'API服务端异常')
            rows.append({'site': label, 'host': host, 'dns': dns_text,
                         'https': f'HTTP {status}', 'final_url': url,
                         'content_type': response.headers.get('Content-Type', ''),
                         'bytes': len(response.content), 'result': result})
        except requests.RequestException as exc:
            rows.append({'site': label, 'host': host, 'dns': dns_text,
                         'https': f'{type(exc).__name__}: {str(exc)[:120]}',
                         'final_url': '', 'content_type': '', 'bytes': 0, 'result': ('公开搜索入口连接失败' if '自主搜索' in label else 'API端点连接失败')})
    try:
        proxy_summary = ', '.join(f'{k}={v}' for k,v in urllib.request.getproxies().items() if k in ('http','https')) or '未检测到系统代理'
    except Exception:
        proxy_summary = '系统代理读取失败'
    return {'platform': platform.platform(), 'proxy': proxy_summary, 'rows': rows}


def load_catalog():
    rows=[]
    try:
        with open(CATALOG_FILE, encoding='utf-8-sig', newline='') as f:
            rows=list(csv.DictReader(f))
    except Exception:
        rows=[]
    # Keep the requested 607-row core taxonomy separate from explicitly marked additions.
    supplement_file=os.path.join(APP_DIR,'industry_catalog_supplement.csv')
    if os.path.isfile(supplement_file):
        try:
            with open(supplement_file,encoding='utf-8-sig',newline='') as f:
                rows.extend(csv.DictReader(f))
        except Exception:
            pass
    return rows


def normalize_company_key(name):
    'Conservative exact-name key; avoids fuzzy merging unrelated subsidiaries.'
    value = html.unescape(re.sub(r'\s+', ' ', str(name or '')).strip()).lower()
    value = re.sub(r'https?://|www\.', ' ', value)
    value = re.sub(r'\b(official website|official site|homepage|官网|官方网站)\b', ' ', value, flags=re.I)
    # Remove English legal suffixes only when they are visibly separate words;
    # never strip a coincidental ending such as the 'co' in a brand name 'Maco'.
    value = re.sub(r'\s+(?:co\.?\s*,?\s*)?(?:ltd\.?|limited|inc\.?|corp\.?|corporation|company)$', '', value, flags=re.I)
    value = re.sub(r'[\s\-_,，。·.()（）\[\]【】]+', '', value)
    suffixes = ('有限责任公司','股份有限公司','有限公司','集团有限公司','集团')
    changed = True
    while changed and value:
        changed = False
        for suffix in suffixes:
            if value.endswith(suffix) and len(value) > len(suffix) + 1:
                value = value[:-len(suffix)]; changed = True; break
    return value


def registry_domain_key(domain):
    host = str(domain or '').lower().strip().split(':')[0].strip('.')
    if host.startswith('www.'): host = host[4:]
    labels = host.split('.')
    if len(labels) < 2: return host
    if labels[0] in {'m','mobile','shop','store','en','cn','global','www'} and len(labels) >= 3:
        labels = labels[1:]
    multi_suffixes = {'com.cn','net.cn','org.cn','gov.cn','com.hk','com.sg','com.au','co.uk','org.uk','co.jp','com.tw','com.my','co.nz'}
    suffix = '.'.join(labels[-2:])
    return '.'.join(labels[-3:]) if suffix in multi_suffixes and len(labels) >= 3 else '.'.join(labels[-2:])


def is_previously_collected(domain, company_name, known_domains, known_company_names):
    domain_key = registry_domain_key(domain)
    name_key = normalize_company_key(company_name)
    return bool((domain_key and domain_key in known_domains) or (name_key and name_key in known_company_names))


def load_collected_registry(db_file=None):
    'Return stable keys for companies already accepted into the permanent lead DB.'
    domains, names = set(), set()
    con = sqlite3.connect(db_file or DB_FILE, timeout=10)
    try:
        for domain, name in con.execute("SELECT domain, company_name FROM leads WHERE quality_status='keep'"):
            if domain: domains.add(registry_domain_key(domain))
            key = normalize_company_key(name)
            if key: names.add(key)
        try:
            for domain, key in con.execute("SELECT domain, normalized_name FROM collection_registry WHERE status='collected'"):
                if domain: domains.add(registry_domain_key(domain))
                if key: names.add(str(key))
        except sqlite3.OperationalError: pass
    finally: con.close()
    return domains, names


def load_recently_seen_registry(db_file=None, days=30):
    """Return unqualified/recently discovered domains to suppress repeat searches temporarily.

    Successfully collected companies remain suppressed permanently through leads/collected registry.
    Unqualified or failed candidates are suppressed for a limited window only, so they can be retried later.
    """
    domains, names = set(), set()
    con = sqlite3.connect(db_file or DB_FILE, timeout=10)
    try:
        rows = con.execute("""SELECT domain, normalized_name FROM collection_registry
            WHERE status IN ('discovered','review','failed','excluded')
              AND last_seen >= datetime('now', ?)""", (f'-{max(1,int(days))} days',)).fetchall()
        for domain, key in rows:
            if domain: domains.add(registry_domain_key(domain))
            if key: names.add(str(key))
    except sqlite3.OperationalError:
        pass
    finally:
        con.close()
    return domains, names


def record_registry_candidate(domain, title='', website='', source_query='', status='discovered'):
    'Remember a seen candidate without treating an unverified candidate as collected.'
    domain = (domain or '').lower().strip()
    if not domain: return
    now = time.strftime('%Y-%m-%d %H:%M:%S'); key = normalize_company_key(title)
    con = sqlite3.connect(DB_FILE, timeout=10)
    try:
        con.execute('''INSERT INTO collection_registry(domain,normalized_name,company_name,website,first_seen,last_seen,seen_count,status,last_query)
          VALUES(?,?,?,?,?,?,1,?,?) ON CONFLICT(domain) DO UPDATE SET
          normalized_name=CASE WHEN excluded.normalized_name!='' THEN excluded.normalized_name ELSE collection_registry.normalized_name END,
          company_name=CASE WHEN excluded.company_name!='' THEN excluded.company_name ELSE collection_registry.company_name END,
          website=CASE WHEN excluded.website!='' THEN excluded.website ELSE collection_registry.website END,
          last_seen=excluded.last_seen, seen_count=collection_registry.seen_count+1,
          status=CASE WHEN collection_registry.status='collected' THEN 'collected' ELSE excluded.status END,
          last_query=excluded.last_query''', (domain,key,title or '',website or '',now,now,status,source_query or ''))
        con.commit()
    finally: con.close()


def init_db():
    con = sqlite3.connect(DB_FILE)
    con.execute('''CREATE TABLE IF NOT EXISTS leads (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        domain TEXT UNIQUE, company_name TEXT, website TEXT, category TEXT, industry TEXT,
        country TEXT, score INTEGER, operation_score INTEGER, evidence TEXT,
        whatsapp TEXT, emails TEXT, phones TEXT, linkedin TEXT, sources TEXT,
        status TEXT, notes TEXT, collected_at TEXT
    )''')
    existing = {row[1] for row in con.execute('PRAGMA table_info(leads)')}
    for name, decl in [('email_details', "TEXT DEFAULT '[]'"), ('whatsapp_contacts', "TEXT DEFAULT '[]'"), ('contact_evidence', "TEXT DEFAULT '{}'"), ('decision_maker_evidence', "TEXT DEFAULT ''"), ('gender_status', "TEXT DEFAULT '未知/未核实'"), ('company_address', "TEXT DEFAULT ''"), ('address_source_url', "TEXT DEFAULT ''"), ('quality_status', "TEXT DEFAULT 'review'"), ('quality_reason', "TEXT DEFAULT ''")]:
        if name not in existing:
            con.execute(f'ALTER TABLE leads ADD COLUMN {name} {decl}')
    existing = {row[1] for row in con.execute('PRAGMA table_info(leads)')}
    for name in ('factory_authenticity_score','export_capability_score','contact_evidence_score'):
        if name not in existing:
            con.execute(f'ALTER TABLE leads ADD COLUMN {name} INTEGER NOT NULL DEFAULT 0')
    con.commit(); con.close()
    init_provider_db(DB_FILE)
    # Additive migration; legacy company/evidence rows are preserved.
    con = sqlite3.connect(DB_FILE)
    con.execute('CREATE INDEX IF NOT EXISTS idx_lead_evidence_dedupe ON lead_evidence(domain,evidence_type,evidence_text,source_url,observed_at)')
    con.execute('''CREATE TABLE IF NOT EXISTS collection_registry (
        domain TEXT PRIMARY KEY, normalized_name TEXT NOT NULL DEFAULT '', company_name TEXT NOT NULL DEFAULT '',
        website TEXT NOT NULL DEFAULT '', first_seen TEXT NOT NULL, last_seen TEXT NOT NULL,
        seen_count INTEGER NOT NULL DEFAULT 1, status TEXT NOT NULL DEFAULT 'discovered',
        last_query TEXT NOT NULL DEFAULT '', collected_at TEXT NOT NULL DEFAULT '')''')
    con.execute('CREATE INDEX IF NOT EXISTS idx_collection_registry_name ON collection_registry(normalized_name,status)')
    con.execute('''CREATE TABLE IF NOT EXISTS contact_registry (
        domain TEXT NOT NULL, contact_type TEXT NOT NULL, normalized_value TEXT NOT NULL,
        raw_value TEXT NOT NULL DEFAULT '', first_seen TEXT NOT NULL, last_seen TEXT NOT NULL,
        source_url TEXT NOT NULL DEFAULT '', evidence_count INTEGER NOT NULL DEFAULT 1,
        status TEXT NOT NULL DEFAULT '未核实', PRIMARY KEY(domain,contact_type,normalized_value))''')
    con.execute('CREATE INDEX IF NOT EXISTS idx_contact_registry_value ON contact_registry(contact_type,normalized_value)')
    # Backfill legacy leads with conservative quality labels. Only confirmed
    # manufacturer candidates become permanent skips; review rows stay in the
    # 30-day candidate registry so a later run can retry them.
    legacy_rows=con.execute('SELECT domain,company_name,website,industry,evidence,notes,collected_at,quality_status,quality_reason FROM leads').fetchall()
    for domain, name, website, industry, evidence, notes, collected_at, qstatus, qreason in legacy_rows:
        if not qreason:
            qstatus,qreason=assess({'company_name':name or '', 'industry':industry or '', 'manufacturer_evidence':evidence or '', 'notes':notes or ''})
            con.execute('UPDATE leads SET quality_status=?,quality_reason=? WHERE domain=?',(qstatus,qreason,domain))
        registry_status='collected' if qstatus=='keep' else ('excluded' if qstatus=='excluded' else 'review')
        key = normalize_company_key(name); stamp = collected_at or time.strftime('%Y-%m-%d %H:%M:%S')
        con.execute('''INSERT INTO collection_registry(domain,normalized_name,company_name,website,first_seen,last_seen,seen_count,status,last_query,collected_at)
          VALUES(?,?,?,?,?,?,1,?,'',?) ON CONFLICT(domain) DO UPDATE SET
          normalized_name=CASE WHEN excluded.normalized_name!='' THEN excluded.normalized_name ELSE collection_registry.normalized_name END,
          company_name=CASE WHEN excluded.company_name!='' THEN excluded.company_name ELSE collection_registry.company_name END,
          website=CASE WHEN excluded.website!='' THEN excluded.website ELSE collection_registry.website END,
          status=CASE WHEN collection_registry.status='collected' THEN 'collected' ELSE excluded.status END,
          collected_at=CASE WHEN excluded.collected_at!='' THEN excluded.collected_at ELSE collection_registry.collected_at END''',
          (domain,key,name or '',website or '',stamp,stamp,registry_status,stamp))
    con.commit(); con.close()


CATALOG = load_catalog(); init_db()


def normalize_url(s):
    s = (s or '').strip()
    if not s: return ''
    if not s.startswith(('http://','https://')): s = 'https://' + s
    return s


def site_root_url(url):
    """Return the website origin root while keeping actual page URLs separately as evidence."""
    try:
        p=urlparse(normalize_url(url))
        if p.scheme and p.netloc:
            return urlunparse((p.scheme,p.netloc,'/','','',''))
    except Exception:
        pass
    return normalize_url(url)


def root_domain(url):
    try:
        host = urlparse(url).netloc.lower().split(':')[0]
        if host.startswith('www.'): host = host[4:]
        return host
    except Exception: return ''


def same_domain(a, b): return root_domain(a) == root_domain(b) and bool(root_domain(a))


def clean_text(s): return re.sub(r'\s+', ' ', html.unescape(s or '')).strip()


def canonicalize_contact(url):
    try:
        p = urlparse(url)
        return p._replace(fragment='', query='').geturl().rstrip('/')
    except Exception: return url


def is_eligible_whatsapp_number(value, allow_compact_international=False):
    """Reject service/fax/landline numbers; labelled mainland numbers must be explicitly +86 mobile."""
    raw = str(value or '').strip()
    digits = re.sub(r'\D', '', raw)
    if not 9 <= len(digits) <= 15:
        return False
    # China mainland: country code +86 followed by an 11-digit mobile beginning 13-19.
    if digits.startswith('86'):
        national = digits[2:]
        explicit_prefix = raw.startswith('+86') or raw.startswith('0086') or allow_compact_international
        return explicit_prefix and len(digits) == 13 and len(national) == 11 and national.startswith('1') and national[1] in '3456789'
    # Explicit service numbers are never WhatsApp mobile contacts.
    if digits.startswith(('400', '800')):
        return False
    return True


def whatsapp_url_has_eligible_number(url):
    """Check a WhatsApp contact URL's embedded phone number without inventing one."""
    try:
        parsed = urlparse(html.unescape((url or '').strip()))
        host = (parsed.hostname or '').lower()
        digits = ''
        if host == 'wa.me':
            first_path = parsed.path.strip('/').split('/')[0]
            # Preserve explicit non-number WhatsApp short links (e.g. message/invite);
            # they remain links, not extracted phone numbers.
            if first_path.lower() in {'message', 'invite'}:
                return True
            digits = re.sub(r'\D', '', first_path)
        elif host == 'whatsapp.com' or host.endswith('.whatsapp.com'):
            values = parse_qs(parsed.query).get('phone', [])
            digits = re.sub(r'\D', '', values[0]) if values else ''
        else:
            return False
        # Number-bearing contact links must pass the same mobile/service-number filter.
        return is_eligible_whatsapp_number(digits, allow_compact_international=True) if digits else False
    except Exception:
        return False


def normalize_whatsapp_url(url):
    """Normalize an explicitly published WhatsApp URL; never create one from a phone number."""
    try:
        p = urlparse(html.unescape((url or '').strip()))
        if p.scheme.lower() not in ('http', 'https'):
            return ''
        host = (p.hostname or '').lower().rstrip('.')
        if host == 'wa.me':
            # wa.me links identify WhatsApp by domain; preserve the path, discard tracking.
            return p._replace(fragment='', query='').geturl().rstrip('/')
        if host == 'whatsapp.com' or host.endswith('.whatsapp.com'):
            q = parse_qs(p.query)
            kept = {}
            if q.get('phone'):
                phone = re.sub(r'\D', '', q['phone'][0])
                if 8 <= len(phone) <= 15:
                    kept['phone'] = phone
            if q.get('app_absent'):
                kept['app_absent'] = q['app_absent'][0]
            return p._replace(fragment='', query=urlencode(kept)).geturl().rstrip('?')
        return ''
    except Exception:
        return ''


def classify_email(email, page_url):
    """Classify only from the public email string; never infer a person's gender."""
    email = (email or '').strip().lower()
    if not EMAIL_RE.fullmatch(email):
        return {'email': email, 'role': 'unknown', 'role_label': '未分类', 'email_score': 20,
                'email_type': '格式待核验', 'domain_match': False, 'public_source_url': page_url}
    local, domain = email.rsplit('@', 1)
    role, label, base = 'general', '通用/未分类', 55
    normalized = re.sub(r'[._+\-]+', '', local)
    for key, tokens, score, cn_label in EMAIL_ROLE_RULES:
        if any(t.replace(' ', '') in normalized for t in tokens):
            role, label, base = key, cn_label, score
            break
    role_mailboxes = {'sales','export','inquiry','purchase','marketing','info','service','hr','finance'}
    generic = role in role_mailboxes or local in {'admin','administrator','webmaster','noreply','no-reply','postmaster'}
    personal_like = not generic and bool(re.fullmatch(r'[a-z][a-z0-9._+-]{1,30}', local))
    if personal_like:
        role, label, base = 'person_or_team', '个人/团队邮箱（身份未核实）', 82
    site_domain = root_domain(page_url)
    email_domain_match = bool(site_domain and (domain == site_domain or domain.endswith('.' + site_domain)))
    score = base + (10 if email_domain_match else 0)
    if domain in {'gmail.com','outlook.com','hotmail.com','yahoo.com','163.com','126.com','qq.com'}:
        score -= 12
    score = max(0, min(100, score))
    return {'email': email, 'role': role, 'role_label': label, 'email_score': score,
            'email_type': '角色邮箱' if generic else '个人/团队邮箱候选',
            'domain_match': email_domain_match, 'public_source_url': page_url}


def enrich_emails(emails, page_urls):
    """Attach public page evidence and priority; no SMTP probing or email sending."""
    details = []
    for email in sorted(set(x.strip().lower() for x in emails if x and '@' in x)):
        sources = [u for u in page_urls if email in u.lower()]  # fallback only; page text evidence is added by caller below
        detail = classify_email(email, page_urls[0] if page_urls else '')
        detail['public_source_url'] = sources[0] if sources else (page_urls[0] if page_urls else '')
        details.append(detail)
    return sorted(details, key=lambda x: (-x['email_score'], x['email']))


PLACEHOLDER_EMAIL_DOMAINS = {
    'example.com', 'example.org', 'example.net', 'test.com', 'invalid',
    'email.com', 'domain.com', 'yourdomain.com', 'company.com'
}

def clean_email_candidate(value):
    """Return a plausible email address or an empty string; never invent addresses."""
    value = html.unescape(unquote((value or '').strip())).strip('\t\r\n <>()[]{}\"\'.,;:')
    value = value.lower()
    if not EMAIL_RE.fullmatch(value):
        return ''
    local, domain = value.rsplit('@', 1)
    if len(value) > 254 or len(local) > 64 or '..' in value:
        return ''
    if domain in PLACEHOLDER_EMAIL_DOMAINS or domain.endswith(('.example', '.test', '.invalid', '.localhost')):
        return ''
    if domain in {'sentry.io','wixpress.com','sentry-next.wixpress.com'} or domain.endswith(('.sentry.io','.wixpress.com')):
        return ''
    if domain.rsplit('.',1)[-1] in {'png','jpg','jpeg','gif','svg','webp','pdf'}:
        return ''
    if domain.startswith('.') or domain.endswith('.') or '..' in domain:
        return ''
    # Reject obvious file/document artefacts sometimes mistaken for email text.
    if local.endswith(('.png', '.jpg', '.jpeg', '.gif', '.svg', '.webp', '.pdf')):
        return ''
    return value


def clean_phone_candidate(value, context=''):
    """Conservative phone cleanup: exclude dates, IPs, identifiers and implausible lengths."""
    value = html.unescape(unquote((value or '').strip()))
    context = (context or '').lower()
    if any(marker in context for marker in ('isbn', 'orcid', 'doi:', 'doi.org', 'ip address', 'copyright', 'order id', 'tracking number', 'publication date')):
        return '' 
    value = re.sub(r'^(?:tel:)', '', value, flags=re.I).strip().strip('.,;:()[]{}')
    if not value:
        return ''
    digits = re.sub(r'\D', '', value)
    if not 9 <= len(digits) <= 15:
        return ''
    # A visible IPv4 address is not a phone number.
    if re.fullmatch(r'\d{1,3}(?:\.\d{1,3}){3}', value):
        return ''
    # Reject common date forms and ISBN-shaped identifiers even in legacy exports.
    if re.fullmatch(r'97[89][-\s]?\d[-\s]?\d{2,5}[-\s]?\d{2,7}[-\s]?[\dX]', value, re.I):
        return ''
    if re.fullmatch(r'(?:19|20)\d{2}[-/.年](?:0?[1-9]|1[0-2])[-/.月](?:0?[1-9]|[12]\d|3[01])日?', value):
        return ''
    if re.fullmatch(r'\d{4}[-/]\d{2}[-/]\d{2}', value):
        return ''
    if len(set(digits)) <= 2 and len(digits) >= 10:
        return ''
    # Plain numeric identifiers without formatting are risky; require contact-label context.
    contact_context=any(k in context for k in ('phone','mobile','telephone','tel:','contact','whatsapp','call us','电话','手机','联系','联络','热线','传真'))
    formatted=any(c in value for c in ' ()-') or value.lstrip().startswith('+')
    if not formatted and not contact_context and len(digits) >= 8:
        return ''
    if len(digits) >= 12 and not formatted and not contact_context:
        return ''
    return value


def deduplicate_phone_formats(values, evidence=None):
    """Collapse formatting variants of the same public phone number without guessing country codes."""
    chosen = {}
    source_map = {}
    for value in values or []:
        raw = str(value or '').strip()
        digits = re.sub(r'\D', '', raw)
        if not 9 <= len(digits) <= 15:
            continue
        current = chosen.get(digits)
        # Prefer an explicit international '+' form, then a human-readable formatted value.
        rank = (raw.startswith('+'), any(ch in raw for ch in ' -()'), len(raw))
        current_rank = (current.startswith('+'), any(ch in current for ch in ' -()'), len(current)) if current else None
        if current is None or rank > current_rank:
            chosen[digits] = raw
        if evidence and raw in evidence:
            source_map.setdefault(digits, evidence[raw])
    output = sorted(chosen.values())
    normalized_sources = {chosen[d]: source_map[d] for d in chosen if d in source_map}
    return output, normalized_sources


def _decode_cloudflare_email(encoded):
    """Decode Cloudflare's public email-protection markup when it is present in page HTML."""
    try:
        data = bytes.fromhex(encoded.strip())
        if len(data) < 2:
            return ''
        key = data[0]
        decoded = ''.join(chr(b ^ key) for b in data[1:])
        return clean_email_candidate(decoded)
    except (ValueError, TypeError):
        return ''


def extract_obfuscated_emails(text):
    """Recover common human-readable email obfuscations without guessing missing text."""
    value = html.unescape(text or '')
    found = set()
    patterns = [
        r'(?i)([A-Z0-9._%+-]+)\s*\[\s*at\s*\]\s*([A-Z0-9.-]+)\s*\[\s*dot\s*\]\s*([A-Z]{2,}(?:\s*\[\s*dot\s*\]\s*[A-Z]{2,})*)',
        r'(?i)([A-Z0-9._%+-]+)\s*\(\s*at\s*\)\s*([A-Z0-9.-]+)\s*\(\s*dot\s*\)\s*([A-Z]{2,}(?:\s*\(\s*dot\s*\)\s*[A-Z]{2,})*)',
        r'(?i)([A-Z0-9._%+-]+)\s+at\s+([A-Z0-9.-]+)\s+dot\s+([A-Z]{2,}(?:\s+dot\s+[A-Z]{2,})*)',
    ]
    for pattern in patterns:
        for match in re.finditer(pattern, value):
            candidate = match.group(1) + '@' + match.group(2) + '.' + re.sub(r'(?i)\s*(?:\[\s*dot\s*\]|\(\s*dot\s*\)|\bdot\b)\s*', '.', match.group(3))
            candidate = clean_email_candidate(candidate)
            if candidate:
                found.add(candidate)
    # Common JS-style forms: name [at] domain (dot) tld, with spaces around separators.
    loose = re.compile(r'(?i)([A-Z0-9._%+-]+)\s*(?:\[at\]|\(at\)|\bat\b)\s*([A-Z0-9.-]+)\s*(?:\[dot\]|\(dot\)|\bdot\b)\s*([A-Z]{2,})')
    for match in loose.finditer(value):
        candidate = clean_email_candidate(f'{match.group(1)}@{match.group(2)}.{match.group(3)}')
        if candidate:
            found.add(candidate)
    # Emails sometimes render across adjacent HTML spans as visible text with whitespace around @.
    spaced_at = re.compile(r'(?i)([A-Z0-9._%+-]+)\s*@\s*([A-Z0-9.-]+\.[A-Z]{2,})')
    for match in spaced_at.finditer(value):
        candidate = clean_email_candidate(match.group(1) + '@' + match.group(2))
        if candidate:
            found.add(candidate)
    # Cloudflare protected email payloads are embedded in public HTML attributes.
    for encoded in re.findall(r'data-cfemail=[\"\']([0-9a-fA-F]+)[\"\']', value, re.I):
        decoded = _decode_cloudflare_email(encoded)
        if decoded:
            found.add(decoded)
    return found




def iter_jsonld_objects(soup):
    """Yield dictionaries embedded in public schema.org JSON-LD blocks."""
    def walk(value):
        if isinstance(value, dict):
            yield value
            for child in value.values():
                yield from walk(child)
        elif isinstance(value, list):
            for child in value:
                yield from walk(child)
    for script in soup.find_all('script', attrs={'type': re.compile(r'application/ld\+json', re.I)}):
        raw=script.string or script.get_text(' ',strip=True)
        if not raw:
            continue
        try:
            data=json.loads(raw.strip())
        except (ValueError, TypeError):
            continue
        yield from walk(data)


def structured_company_name(soup):
    preferred=('organization','localbusiness','corporation','store','manufacturer','professionalservice')
    for obj in iter_jsonld_objects(soup):
        types=obj.get('@type', [])
        if isinstance(types,str): types=[types]
        normalized=[str(x).lower().replace('schema:','') for x in types]
        if any(any(t in typ for t in preferred) for typ in normalized):
            name=clean_text(str(obj.get('name','')))
            if 2 <= len(name) <= 180:
                return name
    return ''


def extract_company_address(soup):
    """Extract a conservative company address; reject contact blocks polluted by phones/emails."""
    def format_address(value):
        if isinstance(value, str):
            return clean_text(value)
        if isinstance(value, dict):
            keys=('streetAddress','addressLocality','addressRegion','postalCode','addressCountry')
            parts=[]
            for key in keys:
                item=value.get(key)
                if isinstance(item,dict): item=item.get('name') or item.get('@id')
                if item:
                    if isinstance(item,dict): item=item.get('name','')
                    parts.append(clean_text(str(item)))
            return ', '.join(dict.fromkeys(x for x in parts if x))
        return ''
    def plausible(value, structured=False):
        value=clean_text(value)
        if not (8 <= len(value) <= 400): return False
        if re.search(r'(?i)privacy|terms|copyright|cookie|sales service|tel(?:ephone)?\s*[:：]|phone\s*[:：]|fax\s*[:：]|whats\s*app|e-?mail\s*[:：]|www\.|https?://',value): return False
        if len(re.findall(r'\+?\d[\d ()-]{6,}\d',value)) >= 2: return False
        if structured: return True
        address_cues=r'(?i)\b(road|rd\.?|street|st\.?|avenue|ave\.?|industrial park|building|floor|district|city|province|county|zone|postal|zip|china|ningbo|shenzhen|guangzhou|shanghai|dongguan)\b|地址|路|街|工业园|产业园|大厦|楼|区|市|省|县|镇|邮编'
        return bool(re.search(address_cues,value))
    for obj in iter_jsonld_objects(soup):
        addr=obj.get('address')
        if addr:
            value=format_address(addr)
            if plausible(value, structured=True): return value
    candidates=[]
    for node in soup.find_all(['address']):
        value=clean_text(node.get_text(' ',strip=True))
        if plausible(value): candidates.append(value)
    for node in soup.find_all(True, attrs={'class': re.compile(r'address|location|company-info',re.I)}):
        value=clean_text(node.get_text(' ',strip=True))
        if plausible(value) and re.search(r'(?i)address|地址|location|所在地|street|road|路|街|区|市|省|邮编',value): candidates.append(value)
    for value in candidates:
        value=re.sub(r'(?i)^.*?(?:company\s+address|office\s+address|address|地址|公司地址|联系地址)\s*[:：]?\s*','',value)
        if plausible(value): return value[:400]
    return ''


def phone_context_for_match(block, start, end):
    """Use nearby labels and separators so unrelated identifiers do not contaminate phone context."""
    # Restrict context to the current clause; semicolons and vertical bars commonly separate contact fields.
    left = max(block.rfind(';', 0, start), block.rfind('|', 0, start), block.rfind('；', 0, start), block.rfind('｜', 0, start), block.rfind('\n', 0, start)) + 1
    right_candidates = [x for x in (block.find(';', end), block.find('|', end), block.find('；', end), block.find('｜', end), block.find('\n', end)) if x >= 0]
    right = min(right_candidates) if right_candidates else len(block)
    clause = block[left:right]
    rel_start = start - left
    prefix = clause[:rel_start]
    labels = list(re.finditer(r'(?i)(whats\s*app|whatsapp|wa\.me|\bwa\b|telephone|phone|mobile|tel|fax|电话|手机|热线|联系号码|联系方式|联系|isbn|orcid|doi(?:\.org)?|ip address|publication date|copyright|tracking number|order id)\s*[:：-]?', prefix))
    label = labels[-1].group(0) if labels else ''
    # The current clause is still useful for formatting and the candidate itself, but use the nearest label
    # as the context anchor so a preceding WhatsApp label cannot classify a later ordinary phone as WhatsApp.
    return (label + ' ' + block[start:end] + ' ' + clause[rel_start + (end-start):]).strip()


def extract_contact_evidence(soup, page_url):
    """Extract public contacts with per-field evidence; WhatsApp numbers require an explicit label/link."""
    raw = html.unescape(str(soup))
    text = clean_text(soup.get_text(' ', strip=True))
    # Many sites keep WhatsApp CTA URLs in inline JS/JSON rather than visible anchors.
    # Decode common escaped URL forms, but never synthesize a link from a plain phone number.
    script_text = ' '.join(x.get_text(' ', strip=True) for x in soup.find_all('script'))
    wa_scan_text = html.unescape(raw + ' ' + script_text).replace('\\/', '/')
    wa_scan_text = re.sub(r'\\u002[fF]', '/', wa_scan_text)
    wa_links = set()
    whatsapp_contacts = set()
    linkedin = set()
    email_candidates = set(EMAIL_RE.findall(html.unescape(text)))
    email_candidates.update(extract_obfuscated_emails(text))
    email_candidates.update(EMAIL_RE.findall(raw))
    email_candidates.update(extract_obfuscated_emails(raw))
    phone_candidates = []  # Keep context alongside each candidate to avoid losing tel/schema evidence.
    email_evidence = {}
    phone_evidence = {}
    wa_evidence = {}

    def add_whatsapp_url(candidate, source=page_url):
        candidate = html.unescape(unquote(str(candidate or '').strip().strip('\"\'`.,);]')))
        if candidate.startswith('//'):
            candidate = 'https:' + candidate
        if not candidate.lower().startswith(('http://', 'https://')):
            return
        normalized = normalize_whatsapp_url(candidate)
        if normalized and whatsapp_url_has_eligible_number(normalized):
            wa_links.add(normalized)
            wa_evidence.setdefault(normalized, source)
            # A phone-bearing WhatsApp URL is direct evidence for its embedded number.
            # Previously we retained the link but did not populate the separate number field.
            parsed = urlparse(normalized)
            embedded = ''
            if (parsed.hostname or '').lower() == 'wa.me':
                embedded = parsed.path.strip('/').split('/')[0]
            elif (parsed.hostname or '').lower().endswith('whatsapp.com'):
                values = parse_qs(parsed.query).get('phone', [])
                embedded = values[0] if values else ''
            digits = re.sub(r'\D','',embedded)
            if digits and is_eligible_whatsapp_number(digits,allow_compact_international=True):
                display_number = '+' + digits
                cleaned_number = clean_phone_candidate(display_number,'WhatsApp URL')
                if cleaned_number:
                    whatsapp_contacts.add(cleaned_number)
                    wa_evidence.setdefault(cleaned_number,source)

    for match in WA_RE.finditer(wa_scan_text):
        add_whatsapp_url(match.group(0))

    def add_email(value, source=page_url):
        for candidate in EMAIL_RE.findall(html.unescape(unquote(str(value or '')))):
            cleaned = clean_email_candidate(candidate)
            if cleaned:
                email_candidates.add(cleaned)
                email_evidence.setdefault(cleaned, source)
        for candidate in extract_obfuscated_emails(str(value or '')):
            email_candidates.add(candidate)
            email_evidence.setdefault(candidate, source)

    def add_phone(value, context='', source=page_url):
        cleaned = clean_phone_candidate(str(value or ''), context)
        if cleaned:
            phone_candidates.append((cleaned, context, source))
            phone_evidence.setdefault(cleaned, source)
            if re.search(r'(?i)whats\s*app|whatsapp|wa\.me|whats-app|chat\s+on\s+wa|contact\s+via\s+wa|wa\s+contact|聊\s*天\s*whatsapp|whatsapp\s*联系|通过\s*whatsapp| واتساب|whatsapp\s*销售|contato\s+whatsapp|contacto\s+whatsapp', context) and is_eligible_whatsapp_number(cleaned):
                # Store only eligible mobile-style contacts; this is not proof of WhatsApp registration.
                whatsapp_contacts.add(cleaned)
                wa_evidence.setdefault(cleaned, source)

    # Schema.org structured public business information.
    for obj in iter_jsonld_objects(soup):
        for key in ('email', 'emailAddress'):
            value = obj.get(key)
            if isinstance(value, str):
                add_email(value)
        for key in ('telephone', 'phone', 'faxNumber'):
            value = obj.get(key)
            if isinstance(value, str):
                add_phone(value, f'{key} telephone contact')
        for key in ('url', 'sameAs'):
            value = obj.get(key)
            vals = value if isinstance(value, list) else [value]
            for link in vals:
                if isinstance(link, str) and re.match(r'https?://', link, re.I):
                    if re.search(r'(?:wa\.me/|(?:api\.)?whatsapp\.com/)', link, re.I):
                        add_whatsapp_url(link)
                    if 'linkedin.com/' in link.lower():
                        linkedin.add(link.split('?')[0].rstrip('/'))

    # Parse explicit anchors. tel: links retain phone context even when the number is digits-only.
    for a in soup.find_all('a', href=True):
        href_raw = html.unescape(a['href'].strip())
        href = urljoin(page_url, href_raw)
        host = (urlparse(href).hostname or '').lower()
        label = clean_text(' '.join([a.get_text(' ', strip=True), a.get('aria-label', ''), a.get('title', '')]))
        low = href.lower()
        if host == 'wa.me' or host == 'whatsapp.com' or host.endswith('.whatsapp.com'):
            add_whatsapp_url(href)
        if 'linkedin.com/' in low:
            linkedin.add(href.split('?')[0].rstrip('/'))
        if href_raw.lower().startswith('mailto:'):
            address = unquote(href_raw[7:].split('?')[0]).strip()
            add_email(address)
        if href_raw.lower().startswith('tel:'):
            add_phone(unquote(href_raw[4:]), 'tel link telephone contact ' + label)
        # If a phone number appears in a clearly labelled WhatsApp link's text, record it as a labelled contact.
        if re.search(r'(?i)whats\s*app|whatsapp|wa\.me|chat\s+on\s+wa|contact\s+via\s+wa|wa\s+contact|whatsapp\s*联系|通过\s*whatsapp|contato\s+whatsapp|contacto\s+whatsapp', label):
            for match in PHONE_RE.finditer(label):
                add_phone(match.group(0), 'WhatsApp label ' + label)

    # Look only at attributes likely to carry contact details; ignore arbitrary IDs and tracking values.
    for tag in soup.find_all(True):
        for attr, value in tag.attrs.items():
            values = value if isinstance(value, list) else [value]
            attr_low = attr.lower()
            for item in values:
                if not isinstance(item, str):
                    continue
                if attr_low in {'data-email', 'email', 'content', 'aria-label', 'title', 'alt', 'href'}:
                    add_email(item)
                if attr_low in {'href', 'data-href', 'data-url', 'data-link', 'onclick', 'data-whatsapp', 'data-whatsapp-url'} or 'whatsapp' in attr_low:
                    for wa_match in WA_RE.finditer(item.replace('\\/', '/')):
                        add_whatsapp_url(wa_match.group(0))
                if any(k in attr_low for k in ('phone', 'telephone', 'mobile', 'whatsapp', 'fax', 'tel')):
                    add_phone(item, f'{attr_low} contact attribute')
                if 'whatsapp' in attr_low or 'whatsapp' in item.lower() or 'wa.me/' in item.lower():
                    for match in PHONE_RE.finditer(item):
                        add_phone(match.group(0), f'WhatsApp {attr_low} attribute')

    # Prefer paragraph/list/address blocks so an ISBN or ORCID elsewhere on the page does not
    # poison a legitimate nearby phone number's context.
    text_blocks = []
    for node in soup.find_all(['p', 'li', 'address', 'footer', 'header', 'td', 'dd']):
        block = clean_text(node.get_text(' ', strip=True))
        if block and block not in text_blocks:
            text_blocks.append(block)
    if not text_blocks:
        text_blocks = [text]
    for block in text_blocks:
        for match in PHONE_RE.finditer(block):
            context = phone_context_for_match(block, match.start(), match.end())
            add_phone(match.group(0), context)

    emails = {e for candidate in email_candidates if (e := clean_email_candidate(candidate))}
    for email in emails:
        email_evidence.setdefault(email, page_url)
    phones = set()
    for candidate, context, source in phone_candidates:
        cleaned = clean_phone_candidate(candidate, context)
        if cleaned:
            phones.add(cleaned)
            phone_evidence.setdefault(cleaned, source)
    phones, phone_evidence = deduplicate_phone_formats(phones, phone_evidence)
    whatsapp_contacts, normalized_wa_sources = deduplicate_phone_formats(whatsapp_contacts, wa_evidence)
    # Preserve explicit WhatsApp URL evidence while collapsing duplicate number formats.
    wa_evidence = {k: v for k, v in wa_evidence.items() if str(k).startswith(('http://', 'https://'))}
    wa_evidence.update(normalized_wa_sources)
    # Do not claim WhatsApp registration; these are only numbers explicitly labelled as WhatsApp.
    return {
        'whatsapp_links': sorted(wa_links),
        'whatsapp_contacts': whatsapp_contacts,
        'emails': sorted(emails),
        'phones': phones,
        'linkedin': sorted(linkedin),
        'email_evidence': email_evidence,
        'phone_evidence': phone_evidence,
        'whatsapp_evidence': wa_evidence,
    }


def extract_contacts(soup, page_url):
    """Compatibility wrapper: return the historical four contact lists."""
    details = extract_contact_evidence(soup, page_url)
    return details['whatsapp_links'], details['emails'], details['phones'], details['linkedin']


def load_robots_parser(session, base_url):
    """Read public robots.txt once for a site; if unavailable, do not bypass other access controls."""
    parsed_base=urlparse(normalize_url(base_url))
    robots_url=urlunparse((parsed_base.scheme, parsed_base.netloc, '/robots.txt', '', '', ''))
    try:
        response=session.get(robots_url,headers={'User-Agent':USER_AGENT},timeout=8,allow_redirects=True)
        if response.status_code >= 400 or len(response.text or '') > 1_000_000:
            return None
        parser=RobotFileParser()
        parser.set_url(robots_url)
        parser.parse((response.text or '').splitlines())
        return parser
    except requests.RequestException:
        return None
    except Exception:
        return None


def robots_allows(parser, url):
    if parser is None:
        return True
    try:
        return bool(parser.can_fetch(USER_AGENT, url))
    except Exception:
        return True


def fetch_page(session, url, timeout=None):
    """Fetch a public page and return (soup, response, diagnostic). Never bypass access controls."""
    try:
        r = session.get(
            normalize_url(url),
            headers={
                'User-Agent': USER_AGENT,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.8,zh-CN;q=0.6',
                'Cache-Control': 'no-cache',
            },
            timeout=(timeout or TIMEOUT), allow_redirects=True, stream=True
        )
        max_page_bytes=3*1024*1024
        content_length=r.headers.get('Content-Length')
        if content_length and str(content_length).isdigit() and int(content_length)>max_page_bytes:
            r.close()
            return None,r,'网页超过3 MB安全读取上限，已停止下载。'
        if isinstance(r, requests.Response):
            chunks=[]; total=0
            for chunk in r.iter_content(chunk_size=65536):
                if not chunk: continue
                total+=len(chunk)
                if total>max_page_bytes:
                    r.close()
                    return None,r,'网页超过3 MB安全读取上限，已停止下载。'
                chunks.append(chunk)
            r._content=b''.join(chunks); r._content_consumed=True
        ct = (r.headers.get('Content-Type') or '').lower()
        current_encoding=getattr(r, 'encoding', None)
        if not current_encoding or str(current_encoding).lower() in ('iso-8859-1', 'ascii'):
            try:
                r.encoding = getattr(r, 'apparent_encoding', None) or 'utf-8'
            except Exception:
                pass
        body = (r.text or '').lstrip().lower()
        looks_html = ('html' in ct or body.startswith(('<!doctype html', '<html', '<?xml', '<!--')) or '<html' in body[:1200])
        restriction_markers = ('captcha', 'anomaly', 'verify you are human', 'unusual traffic', '机器人验证', '人机验证', '安全验证')
        if any(marker in body[:50000] for marker in restriction_markers):
            return None, r, '检测到验证码/异常访问验证页面；已停止解析，不尝试绕过访问控制。'
        if r.status_code in (401, 403, 407, 429):
            return None, r, f'HTTP {r.status_code}：网站要求登录、拒绝访问、代理认证或触发访问频率限制。'
        if r.status_code >= 400:
            return None, r, f'HTTP {r.status_code}：服务器返回错误。'
        if not looks_html:
            preview = re.sub(r'\s+', ' ', (r.text or '')[:180]).strip()
            return None, r, f'响应不是可识别的 HTML；Content-Type={ct or "（未提供）"}；响应片段={preview or "（空响应）"}'
        return BeautifulSoup(r.text, 'html.parser'), r, ''
    except requests.RequestException as e:
        return None, None, f'{type(e).__name__}: {str(e)[:220]}'
    except Exception as e:
        return None, None, f'{type(e).__name__}: {str(e)[:220]}'


def score_site(pages, industry='', keywords=''):
    combined = ' '.join(clean_text(s.get_text(' ', strip=True)).lower() for _,s in pages)
    page_meta = ' '.join((url + ' ' + (s.title.get_text(' ', strip=True) if s.title else '')) for url, s in pages).lower()
    score = 0; hits=[]
    # Generic legal, publishing and identifier pages should not qualify as manufacturers.
    irrelevant_markers = {
        'privacy statement': -45, 'privacy policy': -45, 'cookie policy': -35,
        'terms of use': -35, 'terms and conditions': -30, 'isbn': -20,
        'orcid': -25, 'doi.org': -30, 'journal article': -30,
        'academic publisher': -30, 'book publisher': -30, 'elgaronline': -45,
    }
    for marker, penalty in irrelevant_markers.items():
        if marker in page_meta or (marker in combined and marker in {'privacy statement','privacy policy','cookie policy','terms of use','elgaronline'}):
            score += penalty; hits.append(f'无关页面信号:{marker}')
    for word, weight in MANUFACTURER_WORDS.items():
        n = combined.count(word)
        if n:
            score += min(weight*2, n*weight); hits.append(f'{word}×{n}')
    for word, weight in NEGATIVE_WORDS.items():
        n = combined.count(word)
        if n:
            score += max(-12, n*weight); hits.append(f'{word}×{n}')
    industry_l = (industry or '').lower().strip()
    if industry_l and industry_l in combined: score += 8; hits.append('行业名称命中')
    keyword_phrases = [x.strip().lower() for x in (keywords or '').split(';') if x.strip()]
    for kw in keyword_phrases:
        if len(kw) >= 4 and kw in combined:
            score += 3; hits.append(f'关键词:{kw}')
    # Product relevance is more important than generic words such as factory/OEM/export.
    stop = {'manufacturer','manufacturers','manufacturing','factory','factories','china','supplier','suppliers',
            'exporter','exporters','export','oem','odm','production','plant','plants','made','direct','company',
            'industrial','industry','products','product','and','for','with','the','from','parts','components',
            'small','home','supplier','wholesale','manufacturer china'}
    product_terms = set()
    for phrase in keyword_phrases + [industry_l]:
        for token in re.findall(r'[a-z]{3,}', phrase):
            if token not in stop and len(token) >= 4:
                product_terms.add(token.rstrip('s'))
        # Chinese industry/product phrases are meaningful without whitespace tokenization.
        for token in re.findall(r'[\u4e00-\u9fff]{2,}', phrase):
            if token not in {'中国', '工厂', '厂家', '制造商', '生产厂家', '供应商', '出口商'}:
                product_terms.add(token)
    matched_terms = sorted(t for t in product_terms if t in combined or (t + 's') in combined)
    if matched_terms:
        bonus = min(18, 6 + 3 * len(matched_terms))
        score += bonus; hits.append('产品相关词命中:' + ', '.join(matched_terms[:8]))
    elif product_terms:
        # A generic company page with no product-specific evidence must not pass the normal threshold.
        score = min(score, 22); hits.append('未找到明确产品相关词，降低候选评分')
    if len(pages) >= 3: score += 5; hits.append('官网多页面可访问')
    if any(marker in page_meta for marker in ('privacy statement', 'privacy policy', 'terms of use', 'elgaronline', 'doi.org', 'journal article')):
        score = min(score, 12)
    return max(0, min(100, score)), '；'.join(dict.fromkeys(hits))[:900]


def operation_signals(pages):
    combined = ' '.join(clean_text(s.get_text(' ', strip=True)).lower() for _,s in pages)
    positive = {
        'products': 8, 'product catalog': 8, 'factory': 6, 'production': 5,
        'capacity': 5, 'quality control': 4, 'certification': 4, 'oem': 5,
        'odm': 5, 'export': 12, 'exporter': 12, 'export sales': 12,
        'international sales': 12, 'foreign trade': 14, 'international trade': 12,
        'import and export': 12, 'overseas business': 10, 'global business': 8,
        'trading company': 10, 'trade company': 10, 'sourcing': 6,
        'contact': 3, 'inquiry': 3, 'get a quote': 3,
        '外贸': 14, '出口': 12, '进出口': 14, '国际贸易': 12,
        '国际销售': 12, '海外业务': 10, '外贸公司': 14, '进出口公司': 14,
        '出口贸易': 14, '出口业务': 12, '国际业务': 10, '供应链': 7,
        '商务合作': 5, '海外市场': 8, '外贸经理': 10, '外贸业务': 10
    }
    score=0; hits=[]
    for k,w in positive.items():
        if k in combined: score += w; hits.append(k)
    score = min(100, score)
    if score >= 45: status='运营信号较强'
    elif score >= 25: status='存在运营信号，建议人工复核'
    else: status='运营信号不足，建议人工复核'
    return score, status, ', '.join(hits)


def is_trade_contact_candidate(result, min_manufacturer_score=25):
    """A lead must expose at least one public business contact; factory status is optional."""
    has_contact=bool(result.get('emails') or result.get('whatsapp_links') or result.get('whatsapp_contacts'))
    if not has_contact:
        return False
    export_signal=int(result.get('operation_score') or 0)>=8
    manufacturer_score=int(result.get('manufacturer_score') or 0)
    manufacturer_signal=manufacturer_score>0 and manufacturer_score>=max(1,int(min_manufacturer_score))
    return export_signal or manufacturer_signal


def scan_site(url, industry='', keywords='', country='', timeout=None):
    url=normalize_url(url)
    result={'company_name':'','company_website':url,'industry_category':'','industry':industry,'keywords':keywords,'country':country,
            'page_title':'','company_address':'','address_source_url':'','manufacturer_score':0,'operation_score':0,'manufacturer_evidence':'','operation_evidence':'','factory_authenticity_score':0,'export_capability_score':0,'contact_evidence_score':0,'factory_evidence_items':[],'export_evidence_items':[],'contact_evidence_items':[],
            'whatsapp_links':[],'whatsapp_contacts':[],'emails':[],'email_details':[],'contact_evidence':{},'email_priority':'','decision_maker_evidence':'未发现可确认的公开负责人身份信息','gender_status':'未知/未核实','phone_candidates':[],'linkedin_links':[],'source_urls':[],'status':'','notes':'',
            'collected_at':time.strftime('%Y-%m-%d %H:%M:%S')}
    session=create_http_session()
    soup,r,diagnostic=fetch_page(session,url,timeout=timeout)
    if not soup:
        if r is not None:
            result['company_website']=r.url or url
            ct=(r.headers.get('Content-Type') or '（未提供）')
            restricted = (r.status_code in (401,403,407,429) or '验证码' in diagnostic or '异常访问验证' in diagnostic)
            result['status']=(f'访问受限 HTTP {r.status_code}' if restricted else f'访问失败 HTTP {r.status_code}')
            result['notes']=f'原始网址：{url}；最终网址：{r.url}；Content-Type：{ct}；诊断：{diagnostic}。未绕过验证码、登录、付费墙或访问限制。'
        else:
            result['status']='访问失败/连接异常'
            result['notes']=f'网址：{url}；诊断：{diagnostic or "未获取到 HTTP 响应"}。请检查网络、代理、DNS、证书或防火墙。'
        return result
    result['status']=f'HTTP {r.status_code}'; result['company_website']=site_root_url(r.url); result['source_urls']=[r.url]
    result['page_title']=clean_text(soup.title.get_text(' ',strip=True) if soup.title else '')[:300]
    result['company_name']=(soup.find('meta',property='og:site_name') or {}).get('content','').strip() if soup.find('meta',property='og:site_name') else ''
    if not result['company_name']:
        result['company_name']=structured_company_name(soup)
    if not result['company_name']:
        title_parts=[clean_text(x) for x in re.split(r'\s*[|·–—]\s*|\s+-\s+',result['page_title']) if clean_text(x)]
        generic_titles={'home','homepage','welcome','welcome to our website','contact','contact us','about','about us','products','official website','index'}
        meaningful=[x for x in title_parts if x.lower() not in generic_titles]
        result['company_name']=(meaningful[0] if meaningful else (title_parts[0] if title_parts else ''))[:180]
    pages=[(r.url,soup)]; result['company_address']=extract_company_address(soup); result['address_source_url']=r.url if result['company_address'] else ''; wa=[]; wa_contacts=[]; emails=[]; phones=[]; linkedin=[]; email_sources={}; phone_sources={}; wa_sources={}
    robots_parser=load_robots_parser(session,r.url)
    contact=extract_contact_evidence(soup,r.url)
    wa+=contact['whatsapp_links']; wa_contacts+=contact['whatsapp_contacts']; emails+=contact['emails']; phones+=contact['phones']; linkedin+=contact['linkedin']
    email_sources.update(contact['email_evidence']); phone_sources.update(contact['phone_evidence']); wa_sources.update(contact['whatsapp_evidence'])
    links=[]
    for a in soup.find_all('a',href=True):
        href=urljoin(r.url,a['href']); label=clean_text(a.get_text(' ',strip=True)).lower()
        aria=clean_text(a.get('aria-label','')).lower()
        key=(href.lower()+' '+label+' '+aria)
        if same_domain(r.url,href) and (any(k in key for k in CONTACT_PATHS) or re.search(r'whats\s*app|wa\.me|chat on wa|contact via wa', key, re.I)):
            links.append(href.split('#')[0])
    # Also look for sitemap.xml as a low-cost source of relevant internal pages.
    for href in [urljoin(r.url,'/sitemap.xml')]:
        if not robots_allows(robots_parser,href):
            continue
        try:
            rr=session.get(href,headers={'User-Agent':USER_AGENT},timeout=8,stream=True)
            sitemap_limit=2*1024*1024
            if rr.headers.get('Content-Length','').isdigit() and int(rr.headers['Content-Length'])>sitemap_limit:
                rr.close(); continue
            if isinstance(rr, requests.Response):
                data=bytearray()
                for chunk in rr.iter_content(chunk_size=65536):
                    if chunk:
                        data.extend(chunk)
                        if len(data)>sitemap_limit: break
                sitemap_text=data.decode(rr.encoding or 'utf-8',errors='replace')
            else: sitemap_text=rr.text or ''
            if rr.status_code < 400 and 'sitemap' in href and len(sitemap_text.encode('utf-8',errors='ignore'))<=sitemap_limit:
                for loc in re.findall(r'<loc>(.*?)</loc>', sitemap_text, re.I):
                    if same_domain(r.url,loc) and any(k in loc.lower() for k in CONTACT_PATHS): links.append(loc)
        except requests.RequestException: pass
    def contact_priority(href):
        low=href.lower()
        if any(k in low for k in ('whatsapp','wa.me','chat-on-wa','contact-via-wa')): return -1
        if 'contact' in low: return 0
        if 'about' in low or 'company' in low: return 1
        if 'factory' in low or 'oem' in low or 'export' in low: return 2
        if 'products' in low: return 4
        return 3
    ordered_links=sorted(dict.fromkeys(links), key=contact_priority)
    for href in ordered_links[:MAX_SITE_PAGES-1]:
        if same_domain(r.url,href) and href != r.url and robots_allows(robots_parser,href):
            s2,r2,diag2=fetch_page(session,href,timeout=timeout)
            if s2:
                pages.append((r2.url,s2));
                if not result.get('company_address'):
                    address_value=extract_company_address(s2)
                    if address_value: result['company_address']=address_value; result['address_source_url']=r2.url
                contact=extract_contact_evidence(s2,r2.url)
                wa+=contact['whatsapp_links']; wa_contacts+=contact['whatsapp_contacts']; emails+=contact['emails']; phones+=contact['phones']; linkedin+=contact['linkedin']
                for k,v in contact['email_evidence'].items(): email_sources.setdefault(k,v)
                for k,v in contact['phone_evidence'].items(): phone_sources.setdefault(k,v)
                for k,v in contact['whatsapp_evidence'].items(): wa_sources.setdefault(k,v)
                # Continue through the bounded page budget: WhatsApp buttons are often placed
                # on About/product pages even when Contact already yielded an email or phone.
    result['manufacturer_score'],result['manufacturer_evidence']=score_site(pages,industry,keywords)
    result['operation_score'],op_status,result['operation_evidence']=operation_signals(pages)
    result['whatsapp_links']=sorted(set(x for x in wa if normalize_whatsapp_url(x))); result['whatsapp_contacts']=sorted(set(wa_contacts)); result['emails']=sorted(set(x.lower() for x in emails if clean_email_candidate(x)))[:50]
    result['source_urls']=list(dict.fromkeys([u for u,_ in pages]))
    # Exact page evidence is collected during extraction, including mailto/data attributes.
    result['email_details'] = []
    for email in result['emails']:
        d = classify_email(email, email_sources.get(email, result['company_website']))
        d['public_source_url'] = email_sources.get(email, result['company_website'])
        result['email_details'].append(d)
    result['email_details'].sort(key=lambda x: (-x['email_score'], x['email']))
    result['phone_candidates']=sorted(set(phones))[:40]; result['linkedin_links']=sorted(set(linkedin))[:10]
    result['contact_evidence'] = {
        'emails': {e: email_sources.get(e, result['company_website']) for e in result['emails']},
        'phones': {p: phone_sources.get(p, result['company_website']) for p in result['phone_candidates']},
        'whatsapp_links': {w: wa_sources.get(w, result['company_website']) for w in result['whatsapp_links']},
        'whatsapp_contacts': {w: wa_sources.get(w, result['company_website']) for w in result['whatsapp_contacts']},
    }
    # Store independent evidence records with the exact public page URL that supports each score.
    combined_pages=[(u, clean_text(ps.get_text(' ', strip=True))) for u,ps in pages]
    factory_terms=('manufacturer','factory','production facility','production line','工厂','生产厂家','制造商','生产线','自有工厂','源头工厂')
    export_terms=('export','exporter','export sales','foreign trade','international trade','import and export','trading company','overseas business','international sales','global sales','出口','外贸','海外市场','出口业务','进出口','国际贸易','国际销售','外贸公司','进出口公司')
    result['factory_evidence_items']=[{'type':'factory','text':term,'source_url':u} for u,txt in combined_pages for term in factory_terms if term.lower() in txt.lower()][:80]
    result['export_evidence_items']=[{'type':'export','text':term,'source_url':u} for u,txt in combined_pages for term in export_terms if term.lower() in txt.lower()][:80]
    result['contact_evidence_items']=[{'type':'contact','text':kind+': '+value,'source_url':source}
        for kind,mapping in [('email',email_sources),('phone',phone_sources),('whatsapp',wa_sources)]
        for value,source in mapping.items() if source.startswith(('http://','https://'))][:120]
    scores=score_three_dimensions(result['factory_evidence_items'],result['export_evidence_items'],result['contact_evidence_items'])
    result.update(scores)
    result['score_evidence_sources']={
        'factory':sorted({x['source_url'] for x in result['factory_evidence_items']}),
        'export':sorted({x['source_url'] for x in result['export_evidence_items']}),
        'contact':sorted({x['source_url'] for x in result['contact_evidence_items']}),
    }
    result['email_priority'] = '；'.join(f"{d['email']}（{d['role_label']}，{d['email_score']}分）" for d in result['email_details'][:5])
    # Decision-maker evidence is evidence-only. Gender remains unknown unless an explicit, attributable public source supports it.
    combined_text = ' '.join(clean_text(ps.get_text(' ', strip=True)) for _, ps in pages)
    leadership_terms = ['founder', 'co-founder', 'chief executive officer', 'ceo', 'president', 'owner', 'executive director', 'managing director', 'general manager', 'export manager', 'foreign trade manager', 'international sales', 'overseas sales', 'sales director', 'sales manager', 'business development', 'sourcing manager', 'supply chain manager', 'export sales', 'foreign trade', '外贸经理', '出口经理', '国际销售', '海外业务', '销售总监', '业务经理', '供应链经理', '董事长', '总经理', '创始人']
    role_evidence=[]
    for page_url,page_soup in pages:
        page_text=clean_text(page_soup.get_text(' ',strip=True))
        page_low=page_text.lower()
        for term in leadership_terms:
            pos=page_low.find(term.lower())
            if pos>=0:
                excerpt=page_text[max(0,pos-65):min(len(page_text),pos+115)]
                role_evidence.append(f'{term}：{excerpt[:180]}（{page_url}）')
    if role_evidence:
        result['decision_maker_evidence'] = '公开网页职位/外贸业务证据：' + '；'.join(dict.fromkeys(role_evidence))[:1200] + '；姓名、职位归属及女性身份需人工核验。'
        result['notes']=(result.get('notes','')+' '+result['decision_maker_evidence']).strip()
    if result['whatsapp_links'] or result['whatsapp_contacts']: note='发现明确公开的 WhatsApp 链接或带 WhatsApp 标签的号码；标签号码不代表已验证 WhatsApp 注册状态。'
    else: note='未发现明确 WhatsApp 链接或带标签号码；普通电话不会被推断为 WhatsApp。'
    note += ' 邮箱按公开页面证据提取并分类；未进行 SMTP 探测或发送测试邮件。性别默认未知，不根据姓名/邮箱前缀推断。'
    result['notes']=note+' '+op_status+'。'
    src=result['score_evidence_sources']
    result['notes'] += ' 评分证据来源网址：工厂真实性=' + ('; '.join(src['factory']) or '无') + '；出口能力=' + ('; '.join(src['export']) or '无') + '；联系人证据=' + ('; '.join(src['contact']) or '无')
    return result




def balance_candidate_items(items, query_context, limit=None):
    """Round-robin candidates by subindustry so early search results do not crowd out later industries."""
    groups={}
    for item in items:
        query=item[2] if len(item)>2 else ''
        context=(query_context or {}).get(query,{})
        group_key=context.get('industry') or query or 'unknown'
        groups.setdefault(group_key,[]).append(item)
    balanced=[]
    while any(groups.values()):
        for group in groups.values():
            if group:
                balanced.append(group.pop(0))
                if limit is not None and len(balanced)>=limit:
                    return balanced
    return balanced


def _parse_public_engine_results(provider, response):
    """Parse ordinary public search result pages; no CAPTCHA or access-control bypass."""
    soup=BeautifulSoup(response.text or '', 'html.parser')
    selectors={
        'Bing':'li.b_algo h2 a, h2 a',
        'DuckDuckGo':'a.result__a, a[data-testid="result-title-a"]',
        'Baidu':'.result h3 a, .c-container h3 a, h3 a',
        'Ecosia':'a.result-title, a[data-test-id="result-title-link"], .result h2 a',
        'Yandex':'a.OrganicTitle-Link, .serp-item h2 a, h2 a',
    }
    anchors=soup.select(selectors.get(provider,'')) if provider in selectors else []
    rows=[]
    for a in anchors:
        href=(a.get('href') or '').strip(); title=a.get_text(' ',strip=True)
        if 'duckduckgo.com/l/?' in href:
            target=parse_qs(urlparse(href).query).get('uddg',[''])[0]
            href=unquote(target) if target else href
        if provider=='Baidu' and 'baidu.com/link?' in href:
            continue
        if not href.startswith(('http://','https://')) or len(title)<2:
            continue
        host=(urlparse(href).hostname or '').lower()
        if not host or any(host==d or host.endswith('.'+d) for d in ('bing.com','duckduckgo.com','baidu.com','ecosia.org','yandex.com','google.com')):
            continue
        rows.append((href,title))
    # SearXNG is an optional self-hosted metasearch endpoint returning JSON.
    if provider=='SearXNG':
        try:
            payload=response.json()
            for item in payload.get('results',[]):
                href=str(item.get('url') or '').strip(); title=str(item.get('title') or '').strip()
                if href.startswith(('http://','https://')) and len(title)>=2:
                    rows.append((href,title))
        except Exception:
            pass
    if provider=='OpenSERP':
        try:
            payload=response.json(); items=payload.get('results') or payload.get('organic_results') or []
            for item in items:
                href=str(item.get('url') or item.get('link') or '').strip(); title=str(item.get('title') or '').strip()
                if href.startswith(('http://','https://')) and len(title)>=2:
                    rows.append((href,title))
        except Exception:
            pass
    return rows


def search_public_web(query, max_results=20, diagnostics=None, session=None):
    """Dynamic free-first engine rotation; engine rank improves from qualified-lead outcomes."""
    diagnostics=diagnostics if diagnostics is not None else {}
    session=session or create_http_session()
    merged=[]; seen=set(); engine_map=diagnostics.setdefault('result_engine_map',{}); domain_engine_map=diagnostics.setdefault('domain_engine_map',{})
    default_order=['Bing','DuckDuckGo','Baidu','Ecosia','Yandex']
    if os.environ.get('FACTORYLEAD_SEARXNG_URL','').strip(): default_order.append('SearXNG')
    if os.environ.get('FACTORYLEAD_OPENSERP_URL','').strip(): default_order.append('OpenSERP')
    try: engine_order=rank_search_engines(DB_FILE,default_order)
    except Exception: engine_order=default_order
    diagnostics.setdefault('public_search',{})['engine_order']=engine_order
    endpoints={
        'Bing':('https://www.bing.com/search',{'q':query,'count':min(max_results,20)}),
        'DuckDuckGo':('https://html.duckduckgo.com/html/',{'q':query}),
        'Baidu':('https://www.baidu.com/s',{'wd':query}),
        'Ecosia':('https://www.ecosia.org/search',{'q':query}),
        'Yandex':('https://yandex.com/search/',{'text':query}),
    }
    if 'SearXNG' in engine_order:
        base=os.environ.get('FACTORYLEAD_SEARXNG_URL','').strip().rstrip('/')
        endpoints['SearXNG']=(base+'/search',{'q':query,'format':'json'})
    if 'OpenSERP' in engine_order:
        base=os.environ.get('FACTORYLEAD_OPENSERP_URL','').strip().rstrip('/')
        endpoints['OpenSERP']=(base,{'q':query})
    # Rotate the first-choice free engine across successive queries. Fall
    # through only when the current engine does not fill the requested quota.
    # This avoids up to five sequential network requests for every keyword.
    rotation_index=int(diagnostics.get('_free_engine_rotation_index',0) or 0)
    diagnostics['_free_engine_rotation_index']=rotation_index+1
    if engine_order:
        offset=rotation_index % len(engine_order)
        engine_order=engine_order[offset:]+engine_order[:offset]
    diagnostics.setdefault('public_search',{})['engine_order_for_query']=engine_order
    tried_engines=[]
    for provider in engine_order:
        if len(merged)>=max_results:
            break
        tried_engines.append(provider)
        endpoint,params=endpoints[provider]
        state=diagnostics.setdefault('public_search',{}).setdefault(provider,{'status':'未尝试','results':0})
        try:
            response=session.get(endpoint,params=params,timeout=(5,10),headers={'Referer':'https://www.google.com/'})
            state['http_status']=getattr(response,'status_code',None)
            if response.status_code in (401,403,429):
                state['status']=f'访问受限 HTTP {response.status_code}'
                record_engine_search(DB_FILE,provider,0,True,state['status'])
                continue
            response.raise_for_status()
            parsed=_parse_public_engine_results(provider,response)
            state['sample_results']=[{'title':title,'url':href} for href,title in parsed[:5]]
            added=0
            for href,title in parsed:
                host=(urlparse(href).hostname or '').lower()
                host=host[4:] if host.startswith('www.') else host
                if not host: continue
                domain_engine_map.setdefault(host,[])
                if provider not in domain_engine_map[host]: domain_engine_map[host].append(provider)
                if host in seen: continue
                seen.add(host); merged.append((href,title)); engine_map[href]=provider; added+=1
                if added>=max_results: break
            state['results']=added
            state['status']='成功' if added else '页面可访问但未解析到自然搜索结果'
            record_engine_search(DB_FILE,provider,added,False,state['status'])
        except Exception as exc:
            state['status']=f'请求失败：{type(exc).__name__}'
            record_engine_search(DB_FILE,provider,0,True,state['status'])
    diagnostics.setdefault('public_search',{})['returned_results']=len(merged)
    diagnostics.setdefault('public_search',{})['engines_tried_this_query']=tried_engines
    diagnostics.setdefault('public_search',{})['rotation_exhausted']=len(merged)<max_results
    return merged[:max_results*max(1,len(engine_order))]


def search_web(query, max_results=20, diagnostics=None, include_directories=False, session=None, search_mode='免费优先（付费补漏）', exclude_domains=None, exclude_company_names=None, paid_call_limit=20):
    """Three explicit strategies: free-only, free-first, and paid-first.

    Historical company/domain exclusions are applied to both result streams before
    they are merged, so known companies never trigger a paid fallback request.
    """
    diagnostics = diagnostics if diagnostics is not None else {}
    session = session or create_http_session()
    mode = str(search_mode or '免费优先（付费补漏）').strip()
    if mode not in ('仅免费搜索（不调用API）', '免费优先（付费补漏）', '付费优先（免费补充）'):
        mode = '免费优先（付费补漏）'
    orchestration = diagnostics.setdefault('provider_orchestration', {})
    orchestration['strategy'] = mode
    excluded = set(SOCIAL_DOMAINS + DIRECTORY_DOMAINS + ['google.com','baidu.com','bing.com','duckduckgo.com'])
    prior_domains={registry_domain_key(x) for x in (exclude_domains or set()) if x}
    prior_names={normalize_company_key(x) for x in (exclude_company_names or set()) if x}
    raw_candidate_cap=max_results*max(1,len(diagnostics.get('public_search',{}).get('engine_order',[])))
    def eligible(source_rows):
        accepted=[]; seen=set()
        for href,title in source_rows:
            domain=root_domain(href); domain_key=registry_domain_key(domain)
            name_key=normalize_company_key(title)
            if not domain or domain_key in seen or domain_key in prior_domains: continue
            if name_key and name_key in prior_names: continue
            if any(domain == d or domain.endswith('.' + d) for d in excluded): continue
            seen.add(domain_key); accepted.append((href,title))
            if len(accepted)>=raw_candidate_cap: break
        return accepted
    def paid_search(needed):
        if needed <= 0: return []
        keys=load_api_keys()
        if not (keys.get('serpapi') or keys.get('brave')):
            orchestration['status']='未配置付费 API；没有产生付费请求'
            return []
        engine='baidu' if re.search(r'[\u4e00-\u9fff]', query) else 'google'
        return eligible(search_providers(query, needed, diagnostics, DB_FILE, keys,
                         session=session, serpapi_engine=engine, paid_call_limit=paid_call_limit))
    rows=[]
    if mode == '付费优先（免费补充）':
        try: rows.extend(paid_search(max_results))
        except Exception as exc: orchestration['paid_error']=type(exc).__name__
        if len(rows)<max_results:
            rows.extend(x for x in eligible(search_public_web(query,max_results-len(rows),diagnostics,session=session)) if registry_domain_key(root_domain(x[0])) not in {registry_domain_key(root_domain(y[0])) for y in rows})
    else:
        rows=eligible(search_public_web(query,max_results,diagnostics,session=session))
        orchestration['free_results']=orchestration.get('free_results',0)+len(rows)
        if mode == '免费优先（付费补漏）' and len(rows)<max_results:
            try:
                existing={registry_domain_key(root_domain(url)) for url,_ in rows}
                for url,title in paid_search(max_results-len(rows)):
                    key=registry_domain_key(root_domain(url))
                    if key and key not in existing:
                        existing.add(key); rows.append((url,title))
                        if len(rows)>=max_results: break
                orchestration['paid_top_up_results']=orchestration.get('paid_top_up_results',0)+max(0,len(rows)-orchestration.get('free_results',0))
            except Exception as exc: orchestration['last_error']=type(exc).__name__
        elif mode == '仅免费搜索（不调用API）':
            orchestration['status']='仅免费搜索模式：已禁止调用 SerpApi 和 Brave'
        else:
            orchestration['status']='免费搜索已满足本次候选数量；未调用付费 API'
    budget=diagnostics.get('_paid_search_budget',{})
    orchestration['paid_search_budget']={'limit':min(20,int(budget.get('limit',paid_call_limit))), 'used':int(budget.get('used',0)), 'remaining':max(0,min(20,int(budget.get('limit',paid_call_limit)))-int(budget.get('used',0)))}
    return rows[:raw_candidate_cap]


def search_linkedin_companies(query, max_results=12, diagnostics=None, session=None, search_mode='免费优先（付费补漏）', paid_call_limit=20):
    """Discover public LinkedIn company pages with the same explicit paid strategy."""
    diagnostics = diagnostics if diagnostics is not None else {}
    q = query if 'site:linkedin.com/company' in query.lower() else f'site:linkedin.com/company {query}'
    session = session or create_http_session()
    mode=str(search_mode or '免费优先（付费补漏）')
    if mode not in ('仅免费搜索（不调用API）','免费优先（付费补漏）','付费优先（免费补充）'):
        mode='免费优先（付费补漏）'
    def only_company_pages(rows):
        out=[]; seen=set()
        for url,title in rows:
            parsed=urlparse(url)
            if ((parsed.hostname or '').lower() == 'linkedin.com' or (parsed.hostname or '').lower().endswith('.linkedin.com')) and '/company/' in parsed.path.lower():
                clean=url.split('?')[0].rstrip('/')
                if clean not in seen: seen.add(clean); out.append((clean,title))
                if len(out)>=max_results: break
        return out
    rows=[]
    if mode=='付费优先（免费补充）':
        keys=load_api_keys()
        if keys.get('serpapi') or keys.get('brave'):
            engine='baidu' if re.search(r'[\u4e00-\u9fff]',q) else 'google'
            rows=only_company_pages(search_providers(q,max_results,diagnostics,DB_FILE,keys,session=session,serpapi_engine=engine,paid_call_limit=paid_call_limit))
        if len(rows)<max_results:
            existing={x[0] for x in rows}
            rows += [x for x in only_company_pages(search_public_web(q,max_results,diagnostics,session=session)) if x[0] not in existing]
    else:
        rows=only_company_pages(search_public_web(q,max_results,diagnostics,session=session))
        if mode=='免费优先（付费补漏）' and len(rows)<max_results:
            keys=load_api_keys()
            if keys.get('serpapi') or keys.get('brave'):
                engine='baidu' if re.search(r'[\u4e00-\u9fff]',q) else 'google'
                existing={x[0] for x in rows}
                rows += [x for x in only_company_pages(search_providers(q,max_results-len(rows),diagnostics,DB_FILE,keys,session=session,serpapi_engine=engine,paid_call_limit=paid_call_limit)) if x[0] not in existing]
    diag=diagnostics.setdefault('linkedin_company_search',{})
    diag['queries'] = diag.get('queries',0)+1
    diag['results'] = diag.get('results',0)+len(rows[:max_results])
    diag['last_query'] = q[:180]
    diag['last_status'] = '命中公开公司主页' if rows else '未命中可识别的公开公司主页（个人页/其他页面已过滤）'
    return [(title,url) for url,title in rows[:max_results]]


def search_linkedin_for_company_candidates(items, diagnostics=None, session=None, limit=20):
    """Search public index for LinkedIn company pages using each candidate's company title."""
    diagnostics = diagnostics if diagnostics is not None else {}
    session = session or create_http_session()
    found=[]; seen_urls=set(); seen_names=set()
    for item in list(items or [])[:max(0,int(limit))]:
        if not item: continue
        candidate_url=item[0] if len(item)>0 else ''
        candidate_title=clean_text(item[1] if len(item)>1 else '')
        if len(candidate_title)<3: continue
        normalized=re.sub(r'[^a-z0-9\u4e00-\u9fff ]+',' ',candidate_title.lower()).strip()
        if not normalized or normalized in seen_names: continue
        seen_names.add(normalized)
        domain=root_domain(candidate_url)
        query=f'site:linkedin.com/company "{candidate_title[:90]}"'
        if domain: query += f' "{domain}"'
        try:
            hits=search_public_web(query,max_results=4,diagnostics=diagnostics,session=session)
            for url,title in hits:
                parsed=urlparse(url)
                if ((parsed.hostname or '').lower() == 'linkedin.com' or (parsed.hostname or '').lower().endswith('.linkedin.com')) and '/company/' in parsed.path.lower():
                    clean=url.split('?')[0].rstrip('/')
                    if clean not in seen_urls:
                        seen_urls.add(clean); found.append((clean_text(title),clean))
        except Exception as exc:
            diagnostics.setdefault('linkedin_company_search_errors',[]).append(type(exc).__name__)
    return found


def build_people_queries(keywords, country='China'):
    products=[x.strip() for x in (keywords or '').split(';') if x.strip()] or ['export supply']
    queries=[]
    female='"female" OR "woman" OR "women" OR "woman owner" OR "female owner" OR "she/her"'
    roles='"export manager" OR "foreign trade manager" OR "international sales" OR "overseas sales" OR "business development" OR founder OR "woman owner" OR CEO OR "general manager" OR director OR manager OR "sales representative"'
    # Broad cross-industry searches: job seniority and manufacturer status are deliberately not required.
    queries.extend([
        f'China ({female}) ({roles}) (export OR exporter OR "foreign trade" OR "international trade") (WhatsApp OR email)',
        f'中国 女性 外贸经理 OR 国际销售 OR 出口业务 OR 海外业务 (WhatsApp OR 邮箱)',
        f'China female export sales contact WhatsApp email supplier',
    ])
    for product in products[:3]:
        queries.append(f'site:linkedin.com/in ({female}) ({roles}) "{product}" {country}')
    return list(dict.fromkeys(queries))[:8]


def build_trade_contact_queries(country='China'):
    """Cross-industry searches for women working in export/trade, not just factory owners."""
    return [
        f'(female OR woman OR women OR "she/her") ("export manager" OR "export sales" OR "foreign trade" OR "international sales" OR "overseas sales") {country} (WhatsApp OR email)',
        f'女性 ("外贸经理" OR "外贸业务" OR "国际销售" OR "出口业务" OR "海外业务") {country} (WhatsApp OR 邮箱)',
        f'(female OR woman OR women) ("international trade" OR "import export" OR exporter) ("sales manager" OR "export sales") China (WhatsApp OR email)',
        f'(female OR woman OR women) ("foreign trade company" OR "export company") China ("sales manager" OR "export sales") (contact OR email)',
        f'(female OR woman OR women) ("overseas business" OR "global sales") China (manager OR director) (contact OR email)',
    ]

def search_people_web(query, max_results=8, diagnostics=None, session=None):
    """Find publicly indexed LinkedIn profiles free-first; no login or access-control bypass."""
    diagnostics=diagnostics if diagnostics is not None else {}
    session=session or create_http_session()

    def only_profiles(rows):
        out=[]; seen=set()
        for url,title in rows:
            if root_domain(url)!='linkedin.com' or '/in/' not in url.lower(): continue
            clean=url.split('?')[0].rstrip('/')
            if clean not in seen: seen.add(clean); out.append((clean,title))
            if len(out)>=max_results: break
        return out

    rows=only_profiles(search_public_web(query,max_results,diagnostics,session=session))
    if len(rows)<max_results:
        try:
            keys=load_api_keys()
            if keys.get('serpapi') or keys.get('brave'):
                engine='baidu' if re.search(r'[\u4e00-\u9fff]',query) else 'google'
                rows += only_profiles(search_providers(query,max_results-len(rows),diagnostics,DB_FILE,keys,session=session,serpapi_engine=engine))
        except Exception as exc:
            diagnostics.setdefault('provider_orchestration',{})['people_error']=type(exc).__name__
    return [(title,url) for url,title in rows[:max_results]]


def save_lead(r):
    """Atomically upsert one company and append evidence without deleting history."""
    if not r.get('quality_status'):
        qstatus,qreason=assess(r)
        r['quality_status']=qstatus; r['quality_reason']=qreason
        r['quality_category']='制造商候选' if qstatus=='keep' else ('无关/隔离' if qstatus=='excluded' else '待人工复核')
    domain = root_domain(r.get('company_website', ''))
    if not domain:
        raise ValueError('企业官网域名为空，拒绝保存无稳定匹配键的企业记录')
    now = time.strftime('%Y-%m-%d %H:%M:%S')
    con = sqlite3.connect(DB_FILE, timeout=20)
    try:
        con.execute('BEGIN IMMEDIATE')
        # Merge historical contacts/evidence before upsert; a later crawl must never erase older contacts.
        previous = con.execute('SELECT whatsapp,emails,phones,linkedin,sources,email_details,whatsapp_contacts,contact_evidence FROM leads WHERE domain=?', (domain,)).fetchone()
        if previous:
            for field, old_json in zip(('whatsapp_links','emails','phone_candidates','linkedin_links','source_urls','email_details','whatsapp_contacts'), previous[:7]):
                try: old_values = json.loads(old_json or '[]')
                except (TypeError, ValueError): old_values = []
                new_values = r.get(field, []) or []
                if field == 'email_details':
                    by_email = {str(x.get('email','')).lower(): x for x in old_values + new_values if isinstance(x,dict) and x.get('email')}
                    r[field] = list(by_email.values())
                else:
                    r[field] = list(dict.fromkeys(old_values + new_values))
            try: old_evidence = json.loads(previous[7] or '{}')
            except (TypeError, ValueError): old_evidence = {}
            merged_evidence = dict(old_evidence) if isinstance(old_evidence,dict) else {}
            for evidence_type, mapping in (r.get('contact_evidence',{}) or {}).items():
                if isinstance(mapping,dict):
                    combined = dict(merged_evidence.get(evidence_type,{}) or {})
                    combined.update(mapping); merged_evidence[evidence_type] = combined
            r['contact_evidence'] = merged_evidence
        con.execute('''INSERT INTO leads(domain,company_name,website,category,industry,country,score,operation_score,evidence,whatsapp,emails,phones,linkedin,sources,status,notes,collected_at,email_details,whatsapp_contacts,contact_evidence,decision_maker_evidence,gender_status,company_address,address_source_url,quality_status,quality_reason)
          VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
          ON CONFLICT(domain) DO UPDATE SET company_name=excluded.company_name,website=excluded.website,category=excluded.category,
          industry=excluded.industry,country=excluded.country,score=excluded.score,operation_score=excluded.operation_score,
          evidence=excluded.evidence,whatsapp=CASE WHEN excluded.whatsapp NOT IN ('','[]','null') THEN excluded.whatsapp ELSE leads.whatsapp END,emails=CASE WHEN excluded.emails NOT IN ('','[]','null') THEN excluded.emails ELSE leads.emails END,phones=CASE WHEN excluded.phones NOT IN ('','[]','null') THEN excluded.phones ELSE leads.phones END,linkedin=CASE WHEN excluded.linkedin NOT IN ('','[]','null') THEN excluded.linkedin ELSE leads.linkedin END,
          sources=excluded.sources,status=excluded.status,notes=excluded.notes,collected_at=excluded.collected_at,email_details=CASE WHEN excluded.email_details NOT IN ('','[]','null') THEN excluded.email_details ELSE leads.email_details END,
          whatsapp_contacts=CASE WHEN excluded.whatsapp_contacts NOT IN ('','[]','null') THEN excluded.whatsapp_contacts ELSE leads.whatsapp_contacts END,contact_evidence=CASE WHEN excluded.contact_evidence NOT IN ('','{}','null') THEN excluded.contact_evidence ELSE leads.contact_evidence END,
          decision_maker_evidence=excluded.decision_maker_evidence,gender_status=excluded.gender_status,company_address=CASE WHEN excluded.company_address!='' THEN excluded.company_address ELSE leads.company_address END,address_source_url=CASE WHEN excluded.address_source_url!='' THEN excluded.address_source_url ELSE leads.address_source_url END,quality_status=excluded.quality_status,quality_reason=excluded.quality_reason''',
          (domain,r.get('company_name',''),r.get('company_website',''),r.get('industry_category',''),r.get('industry',''),r.get('country',''),
           r.get('manufacturer_score',0),r.get('operation_score',0),r.get('manufacturer_evidence',''),json.dumps(r.get('whatsapp_links',[]),ensure_ascii=False),
           json.dumps(r.get('emails',[]),ensure_ascii=False),json.dumps(r.get('phone_candidates',[]),ensure_ascii=False),json.dumps(r.get('linkedin_links',[]),ensure_ascii=False),
           json.dumps(r.get('source_urls',[]),ensure_ascii=False),r.get('status',''),r.get('notes',''),r.get('collected_at',now),
           json.dumps(r.get('email_details',[]),ensure_ascii=False),json.dumps(r.get('whatsapp_contacts',[]),ensure_ascii=False),
           json.dumps(r.get('contact_evidence',{}),ensure_ascii=False),r.get('decision_maker_evidence',''),r.get('gender_status','未知/未核实'),r.get('company_address',''),r.get('address_source_url',''),r.get('quality_status','review'),r.get('quality_reason','')))
        registry_now = time.strftime('%Y-%m-%d %H:%M:%S')
        company_key = normalize_company_key(r.get('company_name',''))
        registry_status='collected' if r.get('quality_status')=='keep' else ('excluded' if r.get('quality_status')=='excluded' else 'review')
        con.execute('''INSERT INTO collection_registry(domain,normalized_name,company_name,website,first_seen,last_seen,seen_count,status,last_query,collected_at)
          VALUES(?,?,?,?,?,?,1,?,'',?) ON CONFLICT(domain) DO UPDATE SET
          normalized_name=CASE WHEN excluded.normalized_name!='' THEN excluded.normalized_name ELSE collection_registry.normalized_name END,
          company_name=CASE WHEN excluded.company_name!='' THEN excluded.company_name ELSE collection_registry.company_name END,
          website=CASE WHEN excluded.website!='' THEN excluded.website ELSE collection_registry.website END,
          last_seen=excluded.last_seen,status=CASE WHEN collection_registry.status='collected' THEN 'collected' ELSE excluded.status END,collected_at=excluded.collected_at''',
          (domain,company_key,r.get('company_name',''),r.get('company_website',''),registry_now,registry_now,registry_status,registry_now))
        scores=score_three_dimensions(r.get('factory_evidence_items',[]),r.get('export_evidence_items',[]),r.get('contact_evidence_items',[]))
        con.execute('UPDATE leads SET factory_authenticity_score=?,export_capability_score=?,contact_evidence_score=? WHERE domain=?',
          (scores['factory_authenticity_score'],scores['export_capability_score'],scores['contact_evidence_score'],domain))
        for kind,items in [('factory',r.get('factory_evidence_items',[])),('export',r.get('export_evidence_items',[])),('contact',r.get('contact_evidence_items',[]))]:
            for item in items or []:
                source=str(item.get('source_url','')).strip()
                if source.startswith(('http://','https://')):
                    observed=str(item.get('observed_at') or now); body=str(item.get('text',''))[:300]
                    con.execute('''INSERT INTO lead_evidence(domain,evidence_type,evidence_text,source_url,observed_at)
                      SELECT ?,?,?,?,? WHERE NOT EXISTS (SELECT 1 FROM lead_evidence WHERE domain=? AND evidence_type=? AND evidence_text=? AND source_url=? AND observed_at=?)''',
                      (domain,kind,body,source,observed,domain,kind,body,source,observed))
        ce=r.get('contact_evidence',{}) or {}; observed=str(r.get('collected_at') or now); contacts=[]
        for email in r.get('emails',[]) or []:
            source=(ce.get('emails',{}) or {}).get(email,'')
            detail=next((x for x in r.get('email_details',[]) if x.get('email')==email),{})
            validation={'format_valid':bool(EMAIL_RE.fullmatch(str(email))),'domain_match':detail.get('domain_match'),
              'mx_status':'未检查','third_party_status':'未检查','overall_status':'未核实','role':detail.get('role','unknown')}
            contacts.append(('email',email,email,source,'公开网页',observed,'未核实',validation))
        for link in r.get('whatsapp_links',[]) or []:
            source=(ce.get('whatsapp_links',{}) or {}).get(link,'')
            contacts.append(('whatsapp_link',link,link,source,'官网',observed,'官网明确展示 WhatsApp 链接',{}))
        for number in r.get('whatsapp_contacts',[]) or []:
            source=(ce.get('whatsapp_contacts',{}) or {}).get(number,'')
            contacts.append(('whatsapp_labelled_number',number,number,source,'官网',observed,'官网有 WhatsApp 标签；注册状态未确认',{}))
        for number in r.get('phone_candidates',[]) or []:
            if number not in (r.get('whatsapp_contacts',[]) or []):
                source=(ce.get('phones',{}) or {}).get(number,'')
                contacts.append(('phone',number,number,source,'官网',observed,'仅普通电话号码',{}))
        for ctype,value,raw,source,channel,seen,status,validation in contacts:
            if ctype == 'email': normalized_value = str(value).strip().lower()
            elif ctype in ('phone','whatsapp_labelled_number'): normalized_value = re.sub(r'\D','',str(value))
            else: normalized_value = str(value).strip().lower().rstrip('/')
            if normalized_value:
                con.execute("""INSERT INTO contact_registry(domain,contact_type,normalized_value,raw_value,first_seen,last_seen,source_url,evidence_count,status)
                    VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(domain,contact_type,normalized_value) DO UPDATE SET
                    raw_value=CASE WHEN excluded.raw_value!='' THEN excluded.raw_value ELSE contact_registry.raw_value END,
                    last_seen=excluded.last_seen,source_url=CASE WHEN excluded.source_url!='' THEN excluded.source_url ELSE contact_registry.source_url END,
                    evidence_count=contact_registry.evidence_count+1,status=excluded.status""",
                    (domain,ctype,normalized_value,str(raw),seen,seen,str(source or ''),1,str(status)))
            if str(source).startswith(('http://','https://')):
                con.execute("""INSERT INTO lead_contact_evidence(domain,contact_type,contact_value,raw_value,source_url,source_channel,observed_at,status,validation_json)
                  SELECT ?,?,?,?,?,?,?,?,? WHERE NOT EXISTS (SELECT 1 FROM lead_contact_evidence WHERE domain=? AND contact_type=? AND contact_value=? AND source_url=? AND observed_at=?)""",
                  (domain,ctype,str(value),str(raw),str(source),channel,seen,status,json.dumps(validation,ensure_ascii=False),domain,ctype,str(value),str(source),seen))
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()



def load_saved_leads():
    rows=[]
    try:
        con=sqlite3.connect(DB_FILE)
        cur=con.execute('SELECT company_name,website,category,industry,country,score,operation_score,evidence,whatsapp,emails,phones,linkedin,sources,status,notes,collected_at,email_details,whatsapp_contacts,contact_evidence,decision_maker_evidence,gender_status,company_address,address_source_url,quality_status,quality_reason FROM leads ORDER BY id DESC')
        for rec in cur.fetchall():
            (company,website,category,industry,country,score,op,evidence,wa,emails,phones,linkedin,sources,status,notes,collected,email_details,wa_contacts,contact_evidence,dm,gender,company_address,address_source_url,quality_status,quality_reason)=rec
            def parsed_json(v, expected_type, fallback):
                """Parse one stored JSON field without letting a malformed legacy value hide every lead."""
                if not v:
                    return fallback
                try:
                    value = json.loads(v)
                    return value if isinstance(value, expected_type) else fallback
                except (TypeError, ValueError, json.JSONDecodeError):
                    return fallback
            rows.append({'company_name':company or '', 'company_website':website or '', 'industry_category':category or '', 'industry':industry or '', 'keywords':'', 'country':country or '',
                         'manufacturer_score':score or 0,'operation_score':op or 0,'manufacturer_evidence':evidence or '','operation_evidence':'',
                         'whatsapp_links':parsed_json(wa, list, []),'whatsapp_contacts':parsed_json(wa_contacts, list, []),'contact_evidence':parsed_json(contact_evidence, dict, {}),'emails':parsed_json(emails, list, []),'phone_candidates':parsed_json(phones, list, []),'linkedin_links':parsed_json(linkedin, list, []),'source_urls':parsed_json(sources, list, []),
                         'status':status or '','notes':notes or '','collected_at':collected or '', 'email_details':parsed_json(email_details, list, []),
                         'email_priority':'','decision_maker_evidence':dm or '','gender_status':gender or '未知/未核实','company_address':company_address or '', 'address_source_url':address_source_url or '', 'quality_status':quality_status or 'review', 'quality_reason':quality_reason or ''})
        cur=con.execute('SELECT domain,factory_authenticity_score,export_capability_score,contact_evidence_score FROM leads')
        score_map={row[0]:row[1:] for row in cur.fetchall()}
        evidence_by_domain={}
        try:
            for erow in con.execute('SELECT domain,evidence_type,evidence_text,source_url FROM lead_evidence').fetchall():
                evidence_by_domain.setdefault(erow[0],[]).append(erow[1:])
        except sqlite3.Error:
            evidence_by_domain={}
        for item in rows:
            domain=root_domain(item.get('company_website',''))
            vals=score_map.get(domain,(0,0,0))
            item['factory_authenticity_score'],item['export_capability_score'],item['contact_evidence_score']=vals
            evidence_rows=evidence_by_domain.get(domain,[])
            item['factory_evidence_items']=[{'type':'factory','text':t,'source_url':u} for k,t,u in evidence_rows if k=='factory']
            item['export_evidence_items']=[{'type':'export','text':t,'source_url':u} for k,t,u in evidence_rows if k=='export']
            item['contact_evidence_items']=[{'type':'contact','text':t,'source_url':u} for k,t,u in evidence_rows if k=='contact']
            item['score_evidence_sources']={
                'factory':sorted({u for k,t,u in evidence_rows if k=='factory'}),
                'export':sorted({u for k,t,u in evidence_rows if k=='export'}),
                'contact':sorted({u for k,t,u in evidence_rows if k=='contact'}),
            }
            if any(item['score_evidence_sources'].values()):
                src=item['score_evidence_sources']
                if '评分证据来源网址：' not in item['notes']:
                    item['notes'] += ' 评分证据来源网址：工厂真实性=' + ('; '.join(src['factory']) or '无') + '；出口能力=' + ('; '.join(src['export']) or '无') + '；联系人证据=' + ('; '.join(src['contact']) or '无')
        con.close()
    except Exception:
        return []
    return rows


def _split_import_values(value):
    return list(dict.fromkeys(x.strip() for x in re.split(r"[;\n；、]+", str(value or "")) if x.strip()))


def import_legacy_xlsx_to_database(file_path):
    """Import a prior WaiMaoDaRen export into the persistent DB without inventing evidence."""
    try:
        from openpyxl import load_workbook
    except ImportError as exc:
        raise RuntimeError("缺少 openpyxl，无法导入 Excel") from exc
    wb = load_workbook(file_path, read_only=True, data_only=True)
    ws = wb.active
    headers = [str(c.value or "").strip() for c in ws[1]]
    index = {name: i for i, name in enumerate(headers)}
    aliases = {
        "company": ("公司名称", "工厂/公司名称", "企业名称"),
        "website": ("官方网站", "官网", "公司网站"),
        "address": ("公司地址", "地址"),
        "address_source": ("地址来源网址", "地址来源"),
        "wa_number": ("WhatsApp号码（明确标注）", "WhatsApp号码", "WhatsApp号码（明确信息）"),
        "wa_number_source": ("WhatsApp号码证据网址", "WhatsApp号码来源网址"),
        "wa_link": ("WhatsApp联系链接", "WhatsApp链接"),
        "wa_link_source": ("WhatsApp链接证据网址", "WhatsApp联系链接来源"),
        "email": ("公开邮箱", "邮箱"),
        "phone": ("公开电话（非WhatsApp）", "公开电话", "普通电话"),
        "linkedin": ("LinkedIn企业主页", "LinkedIn"),
        "source": ("采集来源网址", "来源网址"),
        "status": ("访问/核验状态", "核验状态", "状态"),
        "category": ("制造商分类", "企业分类"),
        "notes": ("核验说明", "备注"),
        "collected": ("采集时间", "发现时间"),
    }
    col = {key: next((index[n] for n in names if n in index), None) for key, names in aliases.items()}
    def get(row, key):
        i = col.get(key)
        return row[i] if i is not None and i < len(row) else ""
    imported = updated = skipped = 0
    try:
        for values in ws.iter_rows(min_row=2, values_only=True):
            company = str(get(values, "company") or "").strip()
            website = normalize_url(str(get(values, "website") or "").strip())
            if not company or not root_domain(website):
                skipped += 1
                continue
            wa_numbers = list(dict.fromkeys(
                cleaned for raw_number in _split_import_values(get(values, "wa_number"))
                if (cleaned := clean_phone_candidate(raw_number, "WhatsApp")) and
                   is_eligible_whatsapp_number(cleaned, allow_compact_international=True)
            ))
            wa_links = [x for x in _split_import_values(get(values, "wa_link")) if normalize_whatsapp_url(x)]
            emails = [x.lower() for x in _split_import_values(get(values, "email")) if clean_email_candidate(x)]
            phones = _split_import_values(get(values, "phone"))
            linkedin = [x for x in _split_import_values(get(values, "linkedin")) if 'linkedin.com/' in x.lower()]
            address = str(get(values, "address") or "").strip()
            address_source = str(get(values, "address_source") or "").strip()
            wa_num_source = str(get(values, "wa_number_source") or "").strip()
            wa_link_source = str(get(values, "wa_link_source") or "").strip()
            contact_evidence = {
                "emails": {x: "" for x in emails}, "phones": {x: "" for x in phones},
                "whatsapp_contacts": {x: wa_num_source for x in wa_numbers},
                "whatsapp_links": {x: wa_link_source for x in wa_links},
            }
            row = {
                "company_name": company, "company_website": website,
                "industry_category": str(get(values, "category") or "历史导入"),
                "industry": "", "country": "China", "manufacturer_score": 0,
                "operation_score": 0, "manufacturer_evidence": "",
                "whatsapp_links": wa_links, "whatsapp_contacts": wa_numbers,
                "emails": emails, "phone_candidates": phones, "linkedin_links": linkedin,
                "source_urls": _split_import_values(get(values, "source")),
                "status": str(get(values, "status") or "历史资料导入，待复核"),
                "notes": (str(get(values, "notes") or "") + "；历史 Excel 导入；原文件未提供的单项证据网址不会自动补造").strip("；"),
                "collected_at": str(get(values, "collected") or time.strftime("%Y-%m-%d")),
                "email_details": [], "contact_evidence": contact_evidence,
                "decision_maker_evidence": "", "gender_status": "未知/未核实",
                "company_address": address, "address_source_url": address_source,
            }
            con = sqlite3.connect(DB_FILE, timeout=10)
            try:
                existed = con.execute("SELECT 1 FROM leads WHERE domain=?", (root_domain(website),)).fetchone() is not None
            finally:
                con.close()
            save_lead(row)
            if existed: updated += 1
            else: imported += 1
    finally:
        wb.close()
    return {"imported": imported, "updated": updated, "skipped": skipped}


def safe_spreadsheet_cell(value):
    """Neutralize spreadsheet formula prefixes in untrusted scraped text."""
    text_value=str(value or '')
    if text_value[:1] in ('=','+','-','@','\t','\r'):
        return "'" + text_value
    return text_value


class App(tk.Tk):
    def __init__(self):
        super().__init__(); self.title('外贸达人 2.2.5 - 中国制造商采集工作台'); self.geometry('1520x900'); self.minsize(1150,700)
        self._ui_events=queue.Queue()
        # A set pause event means the worker may run; clearing it requests a pause.
        self._pause_event=threading.Event(); self._pause_event.set()
        self._stop_event=threading.Event(); self._task_active=False
        self.rows=load_saved_leads(); self.people_rows=[]; self.quality_quarantine=self._load_quality_quarantine(); self.quality_review=[]; self.catalog=CATALOG; self._last_raw_candidates=0; self._last_excluded_count=0; self._last_duplicates_skipped=0; self._last_linkedin_hits=0; self._ui()
        self.after(100,self._process_ui_events)

    def _ui(self):
        """Chinese blue-white desktop layout based on the user's reference screenshot."""
        self.configure(bg='#edf4ff')
        style=ttk.Style(self)
        try: style.theme_use('clam')
        except Exception: pass
        bg='#edf4ff'; blue='#1677e8'; navy='#173f73'; border='#cbdcf5'
        style.configure('TFrame',background=bg)
        style.configure('Card.TFrame',background='#ffffff')
        style.configure('TLabel',background=bg,foreground='#142d52',font=('Microsoft YaHei UI',10))
        style.configure('Title.TLabel',background='#ffffff',foreground='#173b68',font=('Microsoft YaHei UI',14,'bold'))
        style.configure('Sub.TLabel',background='#ffffff',foreground='#71839b',font=('Microsoft YaHei UI',9))
        style.configure('TLabelframe',background='#ffffff',bordercolor=border,relief='solid')
        style.configure('TLabelframe.Label',background='#ffffff',foreground='#173b68',font=('Microsoft YaHei UI',10,'bold'))
        style.configure('TButton',font=('Microsoft YaHei UI',10),padding=(11,7),background='#f7faff',foreground='#173b68')
        style.map('TButton',background=[('active','#e5f0ff')])
        style.configure('Accent.TButton',background='#16b879',foreground='#ffffff',font=('Microsoft YaHei UI',10,'bold'),padding=(16,8))
        style.map('Accent.TButton',background=[('active','#0f9e67'),('disabled','#aabbd0')],foreground=[('disabled','#edf2f7')])
        style.configure('Treeview',background='#ffffff',fieldbackground='#ffffff',foreground='#26364a',rowheight=31,font=('Microsoft YaHei UI',9))
        style.configure('Treeview.Heading',background='#e8f1ff',foreground='#173b68',font=('Microsoft YaHei UI',9,'bold'),padding=8)
        style.map('Treeview',background=[('selected','#d8e9fb')],foreground=[('selected','#173b68')])
        style.configure('TNotebook',background='#ffffff',borderwidth=0)
        style.configure('TNotebook.Tab',padding=(15,8),font=('Microsoft YaHei UI',9,'bold'))

        shell=tk.Frame(self,bg=bg); shell.pack(fill='both',expand=True)
        header=tk.Frame(shell,bg='#ffffff',height=78,highlightbackground='#d8e5f7',highlightthickness=1); header.pack(fill='x'); header.pack_propagate(False)
        brand=tk.Frame(header,bg='#ffffff'); brand.pack(side='left',fill='y',padx=22,pady=8)
        tk.Label(brand,text='🌐 外贸达人',bg='#ffffff',fg='#1255a0',font=('Microsoft YaHei UI',23,'bold')).pack(side='left')
        tk.Label(brand,text='  2.2.5',bg='#ffffff',fg='#f28a28',font=('Microsoft YaHei UI',17,'bold')).pack(side='left',pady=(7,0))
        tk.Label(brand,text='  │  专业的中国制造商采集工具',bg='#ffffff',fg='#647b9c',font=('Microsoft YaHei UI',11)).pack(side='left',pady=(10,0))
        quick=tk.Frame(header,bg='#ffffff'); quick.pack(side='right',padx=22)
        tk.Button(quick,text='▥ 采集统计',command=lambda:messagebox.showinfo('采集统计',f'当前载入记录：{len(self.rows)} 条'),relief='flat',bg='#ffffff',fg=navy,font=('Microsoft YaHei UI',10,'bold')).pack(side='left',padx=8,pady=22)
        tk.Button(quick,text='⚙ 设置',command=self.api_settings,relief='flat',bg='#ffffff',fg=navy,font=('Microsoft YaHei UI',10,'bold')).pack(side='left',padx=8,pady=22)
        tk.Button(quick,text='ⓘ 帮助',command=lambda:messagebox.showinfo('使用帮助','选择行业、细分行业、国家和目标数量后，点击“开始采集”。'),relief='flat',bg='#ffffff',fg=navy,font=('Microsoft YaHei UI',10,'bold')).pack(side='left',padx=8,pady=22)

        body=tk.Frame(shell,bg=bg); body.pack(fill='both',expand=True)
        sidebar=tk.Frame(body,bg='#214d80',width=190); sidebar.pack(side='left',fill='y'); sidebar.pack_propagate(False)
        tk.Label(sidebar,text='工作空间',bg='#214d80',fg='#bcd5f4',font=('Microsoft YaHei UI',10,'bold')).pack(anchor='w',padx=20,pady=(22,12))
        content=tk.Frame(body,bg=bg); content.pack(side='left',fill='both',expand=True,padx=15,pady=12)
        pages=[]
        page_host=tk.Frame(content,bg=bg); page_host.pack(fill='both',expand=True)
        for _ in range(5):
            p=tk.Frame(page_host,bg=bg); pages.append(p)
        def show_page(index):
            for p in pages: p.pack_forget()
            pages[index].pack(fill='both',expand=True)
            for j,b in enumerate(nav_buttons):
                b.configure(bg=('#3488ef' if j==index else '#214d80'))
        nav_buttons=[]
        for i,label in enumerate(('⌕  开始采集','▦  数据管理','⇩  导出结果','⚙  系统设置','ⓘ  使用帮助')):
            b=tk.Button(sidebar,text=label,anchor='w',relief='flat',bd=0,bg=('#3488ef' if i==0 else '#214d80'),fg='#ffffff',activebackground='#347ac0',activeforeground='#ffffff',font=('Microsoft YaHei UI',11),padx=18,pady=13,command=lambda n=i:show_page(n))
            b.pack(fill='x',padx=8,pady=3); nav_buttons.append(b)
        tk.Frame(sidebar,bg='#214d80').pack(fill='both',expand=True)
        promo=tk.Frame(sidebar,bg='#dceaff',highlightbackground='#a8c7ef',highlightthickness=1); promo.pack(fill='x',padx=12,pady=16)
        tk.Label(promo,text='👑 专业工作台',bg='#dceaff',fg='#173b68',font=('Microsoft YaHei UI',11,'bold')).pack(pady=(12,4))
        tk.Label(promo,text='本地保存 · 证据可追溯',bg='#dceaff',fg='#42658e',font=('Microsoft YaHei UI',9)).pack(pady=(0,12))

        # Collection task page
        task=pages[0]
        intro=tk.Frame(task,bg='#ffffff',highlightbackground=border,highlightthickness=1); intro.pack(fill='x',pady=(0,9))
        lf=ttk.LabelFrame(intro,text=' ① 采集任务设置 ',padding=(12,9)); lf.pack(fill='x',padx=8,pady=7)
        line=tk.Frame(lf,bg='#ffffff'); line.pack(fill='x',pady=4)
        tk.Label(line,text='行业分类：',bg='#ffffff',font=('Microsoft YaHei UI',10)).pack(side='left')
        self.cat_var=tk.StringVar(); cats=sorted(set(x.get('大类','') for x in self.catalog if x.get('大类')))
        self.cat=ttk.Combobox(line,textvariable=self.cat_var,values=cats,state='readonly',width=22); self.cat.pack(side='left',padx=(4,14)); self.cat.bind('<<ComboboxSelected>>',self.cat_changed)
        tk.Label(line,text='细分行业：',bg='#ffffff',font=('Microsoft YaHei UI',10)).pack(side='left')
        self.sub_var=tk.StringVar(); self.sub=ttk.Combobox(line,textvariable=self.sub_var,state='readonly',width=30); self.sub.pack(side='left',padx=(4,14)); self.sub.bind('<<ComboboxSelected>>',self.sub_changed)
        tk.Label(line,text='目标国家：',bg='#ffffff',font=('Microsoft YaHei UI',10)).pack(side='left')
        self.country=ttk.Combobox(line,values=('中国','China','美国','United States','德国','Germany','英国','United Kingdom','全球','Worldwide'),width=17); self.country.pack(side='left',padx=4); self.country.set('中国')
        tk.Label(line,text='采集数量：',bg='#ffffff',font=('Microsoft YaHei UI',10)).pack(side='left',padx=(12,2))
        self.target=ttk.Spinbox(line,from_=5,to=300,width=8); self.target.pack(side='left'); self.target.set('100')
        line2=tk.Frame(lf,bg='#ffffff'); line2.pack(fill='x',pady=(8,3))
        tk.Label(line2,text='关键词：',bg='#ffffff',font=('Microsoft YaHei UI',10)).pack(side='left')
        self.kw=tk.StringVar(); ttk.Entry(line2,textvariable=self.kw).pack(side='left',fill='x',expand=True,padx=5)
        ttk.Button(line2,text='导入/更新行业目录',command=self.import_catalog).pack(side='right',padx=(8,0))
        self.search_all=tk.BooleanVar(value=False); ttk.Checkbutton(lf,text='搜索当前大类下全部细分行业',variable=self.search_all).pack(anchor='w',pady=(4,0))

        opts=ttk.LabelFrame(intro,text=' ② 采集选项 ',padding=(12,7)); opts.pack(fill='x',padx=8,pady=(0,8))
        optrow=tk.Frame(opts,bg='#ffffff'); optrow.pack(fill='x')
        self.search_mode=tk.StringVar(value='免费优先（付费补漏）')
        tk.Label(optrow,text='搜索策略：',bg='#ffffff',font=('Microsoft YaHei UI',10)).pack(side='left')
        self.search_mode_box=ttk.Combobox(optrow,textvariable=self.search_mode,values=('仅免费搜索（不调用API）','免费优先（付费补漏）','付费优先（免费补充）'),state='readonly',width=22); self.search_mode_box.pack(side='left',padx=(4,15))
        self.parallel=tk.IntVar(value=4); tk.Label(optrow,text='并发核验：',bg='#ffffff').pack(side='left'); ttk.Spinbox(optrow,from_=1,to=8,textvariable=self.parallel,width=5).pack(side='left',padx=4)
        self.min_score=ttk.Entry(optrow,width=6); self.min_score.pack(side='left',padx=(12,4)); self.min_score.insert(0,'25'); tk.Label(optrow,text='制造商参考分',bg='#ffffff').pack(side='left')
        self.women_mode=tk.BooleanVar(value=False); ttk.Checkbutton(optrow,text='附加发现公开女性商务联系人（可选）',variable=self.women_mode).pack(side='left',padx=14)
        ttk.Button(optrow,text='高级设置 / API 配置',command=self.api_settings).pack(side='right')

        controls=tk.Frame(task,bg=bg); controls.pack(fill='x',pady=(2,9))
        self.run_btn=ttk.Button(controls,text='▶  开始采集',style='Accent.TButton',command=self.start); self.run_btn.pack(side='left',padx=(0,8))
        self.pause_btn=ttk.Button(controls,text='Ⅱ  暂停任务',command=self.pause_task,state='disabled'); self.pause_btn.pack(side='left',padx=4)
        self.resume_btn=ttk.Button(controls,text='▶  继续采集',command=self.resume_task,state='disabled'); self.resume_btn.pack(side='left',padx=4)
        self.stop_btn=ttk.Button(controls,text='■  停止任务',command=self.stop_task,state='disabled'); self.stop_btn.pack(side='left',padx=4)
        ttk.Button(controls,text='仅核验网址',command=self.verify_urls).pack(side='left',padx=4)
        ttk.Button(controls,text='自动筛选 / 去重',command=self.apply_quality_filter).pack(side='left',padx=4)
        ttk.Button(controls,text='查看隔离记录',command=self.show_quality_quarantine).pack(side='left',padx=4)
        ttk.Button(controls,text='清空结果',command=self.clear).pack(side='left',padx=4)
        ttk.Button(controls,text='查看日志',command=lambda:results_tabs.select(log_page)).pack(side='left',padx=4)

        resultbox=tk.Frame(task,bg='#ffffff',highlightbackground=border,highlightthickness=1); resultbox.pack(fill='both',expand=True)
        self.results_tabs=ttk.Notebook(resultbox); results_tabs=self.results_tabs; results_tabs.pack(fill='both',expand=True,padx=8,pady=7)
        result_page=tk.Frame(results_tabs,bg='#ffffff'); log_page=tk.Frame(results_tabs,bg='#ffffff'); stats_page=tk.Frame(results_tabs,bg='#ffffff')
        results_tabs.add(result_page,text='采集结果（0）'); results_tabs.add(log_page,text='任务日志'); results_tabs.add(stats_page,text='统计信息')
        searchbar=tk.Frame(result_page,bg='#ffffff'); searchbar.pack(fill='x',pady=(4,6))
        tk.Label(searchbar,text='制造商采集结果',bg='#ffffff',fg=navy,font=('Microsoft YaHei UI',11,'bold')).pack(side='left',padx=5)
        self.filter_var=tk.StringVar(); ttk.Entry(searchbar,textvariable=self.filter_var,width=30).pack(side='right',padx=5); tk.Label(searchbar,text='搜索公司名称或邮箱',bg='#ffffff',fg='#71839b').pack(side='right')
        cols=('company','website','address','industry','factory_score','export_score','contact_score','wa_number','wa_link','email','email_score','phone','linkedin','gender','status','notes')
        self.tree=ttk.Treeview(result_page,columns=cols,displaycolumns=('company','website','address','wa_number','wa_link','email','phone','linkedin','status','notes'),show='headings')
        labels={'company':'公司名称','website':'官方网站','address':'公司地址','industry':'行业','factory_score':'工厂分','export_score':'出口分','contact_score':'联系人分','wa_number':'WhatsApp号码（明确标注）','wa_link':'WhatsApp联系链接','email':'公开邮箱','email_score':'邮箱角色/评分','phone':'公开电话（非WA）','linkedin':'LinkedIn','gender':'身份核验','status':'状态','notes':'来源 / 核验说明'}
        widths={'company':170,'website':190,'address':240,'industry':100,'factory_score':70,'export_score':70,'contact_score':70,'wa_number':165,'wa_link':180,'email':210,'email_score':120,'phone':135,'linkedin':160,'gender':100,'status':100,'notes':230}
        for c in cols: self.tree.heading(c,text=labels[c]); self.tree.column(c,width=widths[c],minwidth=75,stretch=True)
        ys=ttk.Scrollbar(result_page,orient='vertical',command=self.tree.yview); xs=ttk.Scrollbar(result_page,orient='horizontal',command=self.tree.xview); self.tree.configure(yscrollcommand=ys.set,xscrollcommand=xs.set)
        self.tree.pack(side='left',fill='both',expand=True); ys.pack(side='right',fill='y'); xs.pack(side='bottom',fill='x')
        self.filter_var.trace_add('write',lambda *_:self._filter_visible_results())
        self.status=tk.StringVar(value='就绪 · 等待开始采集')
        self.log_text=tk.Text(log_page,height=10,wrap='word',font=('Microsoft YaHei UI',9),bg='#fbfdff',fg='#42566f',relief='flat',state='disabled'); self.log_text.pack(fill='both',expand=True,padx=8,pady=8)
        self.stats_text=tk.StringVar(value=f'当前数据库已载入 {len(self.rows)} 条企业记录。采集完成后可在此查看统计。')
        tk.Label(stats_page,textvariable=self.stats_text,bg='#ffffff',fg=navy,font=('Microsoft YaHei UI',12),justify='left').pack(anchor='nw',padx=18,pady=18)
        self._append_log('程序已启动。采集结果会保存在本地数据库中。')

        # Other navigation pages
        data_page=pages[1]; tk.Label(data_page,text='数据管理',bg=bg,fg=navy,font=('Microsoft YaHei UI',17,'bold')).pack(anchor='w',pady=(5,12))
        tk.Label(data_page,text='管理制造商候选、待人工复核和隔离记录；完整来源证据保存在本地数据库。',bg=bg,fg='#5c7190',font=('Microsoft YaHei UI',10)).pack(anchor='w',pady=5)
        ttk.Button(data_page,text='自动筛选与去重',command=self.apply_quality_filter).pack(anchor='w',pady=6); ttk.Button(data_page,text='查看隔离记录 / 恢复',command=self.show_quality_quarantine).pack(anchor='w',pady=6); ttk.Button(data_page,text='仅核验已保存官网',command=self.verify_urls).pack(anchor='w',pady=6)
        ttk.Button(data_page,text='导入历史采集 Excel 到永久数据库',command=self.import_history_xlsx).pack(anchor='w',pady=6)
        export_page=pages[2]; tk.Label(export_page,text='导出结果',bg=bg,fg=navy,font=('Microsoft YaHei UI',17,'bold')).pack(anchor='w',pady=(5,12))
        tk.Label(export_page,text='完整导出包含公司名称、官网、官网公开地址及地址来源、WhatsApp号码/链接、公开邮箱、普通电话、LinkedIn、采集来源和核验状态；按官网域名优先去重。地址无法从公开页面核实时留空，不会猜测。',bg=bg,fg='#5c7190',font=('Microsoft YaHei UI',10),wraplength=850).pack(anchor='w',pady=5)
        ttk.Button(export_page,text='导出完整资料 CSV',command=self.export_csv).pack(anchor='w',pady=7); ttk.Button(export_page,text='导出完整资料 Excel',command=self.export_xlsx).pack(anchor='w',pady=7); ttk.Button(export_page,text='查看公开个人线索',command=self.show_people).pack(anchor='w',pady=7); ttk.Button(export_page,text='导出个人线索 CSV',command=self.export_people_csv).pack(anchor='w',pady=7)
        settings_page=pages[3]; tk.Label(settings_page,text='系统设置',bg=bg,fg=navy,font=('Microsoft YaHei UI',17,'bold')).pack(anchor='w',pady=(5,12))
        tk.Label(settings_page,text='搜索 API 密钥保存在当前 Windows 用户的本地配置中。SerpApi 与 Brave 每任务默认最多 20 次，并增加跨任务每月合计 100 次的本地费用保护。',bg=bg,fg='#5c7190',font=('Microsoft YaHei UI',10),wraplength=850).pack(anchor='w',pady=5)
        ttk.Button(settings_page,text='搜索 API 配置 / 用量',command=self.api_settings).pack(anchor='w',pady=7); ttk.Button(settings_page,text='搜索引擎表现',command=self.show_engine_performance).pack(anchor='w',pady=7); ttk.Button(settings_page,text='搜索引擎实测（标题 / 网址）',command=self.live_engine_test).pack(anchor='w',pady=7); ttk.Button(settings_page,text='网络诊断',command=self.network_diagnostics).pack(anchor='w',pady=7)
        help_page=pages[4]; tk.Label(help_page,text='使用帮助',bg=bg,fg=navy,font=('Microsoft YaHei UI',17,'bold')).pack(anchor='w',pady=(5,12))
        help_text='1. 选择行业大类、细分行业、目标国家和采集数量。\n2. 可在关键词框补充产品名称或制造工艺。\n3. 点击“开始采集”，实时状态和运行日志会显示在底部和任务日志页。\n4. 采集后可执行质量筛选、去重和官网核验。\n5. WhatsApp号码、WhatsApp联系链接和普通公开电话分列显示、分别统计；普通电话不会自动认定为 WhatsApp。\n6. 导出前请人工核验企业身份及联系方式。'
        tk.Label(help_page,text=help_text,bg=bg,fg='#42566f',font=('Microsoft YaHei UI',11),justify='left',wraplength=900).pack(anchor='w',pady=5)

        footer=tk.Frame(shell,bg='#ffffff',height=48,highlightbackground='#d8e5f7',highlightthickness=1); footer.pack(fill='x',side='bottom'); footer.pack_propagate(False)
        self.status_label=tk.Label(footer,textvariable=self.status,bg='#ffffff',fg='#315b86',font=('Microsoft YaHei UI',9,'bold')); self.status_label.pack(side='left',padx=18,pady=13)
        self.count_label=tk.Label(footer,text=f'今日已采集：{len(self.rows)} 条   |   成功：{len(self.rows)} 条   |   失败：0 条',bg='#ffffff',fg='#315b86',font=('Microsoft YaHei UI',9)); self.count_label.pack(side='left',padx=16)
        self.progress=ttk.Progressbar(footer,mode='indeterminate',length=210); self.progress.pack(side='right',padx=18,pady=12)
        self.status.trace_add('write',self._status_changed)
        if cats: self.cat.current(0); self.cat_changed()
        show_page(0)
        for i,r in enumerate(reversed(self.rows),1): self.add_result(r,i,len(self.rows))

    def _filter_visible_results(self):
        """Filter the visible result table without changing saved records."""
        if not hasattr(self, 'tree'):
            return
        needle=(self.filter_var.get() if hasattr(self, 'filter_var') else '').strip().lower()
        for iid in self.tree.get_children(''):
            values=self.tree.item(iid, 'values')
            haystack=' '.join(str(v) for v in values).lower()
            if not needle or needle in haystack:
                self.tree.reattach(iid, '', 'end')
            else:
                self.tree.detach(iid)

    def _append_log(self, message):
        if not hasattr(self,'log_text'): return
        stamp=time.strftime('%H:%M:%S')
        try:
            self.log_text.configure(state='normal'); self.log_text.insert('end',f'[{stamp}] {message}\n'); self.log_text.see('end')
            # Keep the UI log bounded; the full diagnostic history remains in application/database logs.
            lines=int(self.log_text.index('end-1c').split('.')[0])
            if lines>180: self.log_text.delete('1.0',f'{lines-150}.0')
            self.log_text.configure(state='disabled')
        except tk.TclError: pass

    def _status_changed(self, *_):
        try:
            value=self.status.get()
            self._append_log(value)
            active=any(word in value for word in ('正在','第 ','核验候选','发现公开','搜索进度'))
            if active and str(self.progress.cget('mode'))=='indeterminate': self.progress.start(12)
            elif not active: self.progress.stop()
        except Exception: pass

    def api_settings(self):
        win=tk.Toplevel(self); win.title('搜索 API 本地配置与用量'); win.geometry('760x570'); win.transient(self)
        keys=load_api_keys(); frame=ttk.Frame(win,padding=14); frame.pack(fill='both',expand=True)
        ttk.Label(frame,text='API Key 为可选补充项，不是启动采集的前提。搜索策略可选：仅免费搜索、免费优先付费补漏、付费优先免费补充。SerpApi 与 Brave 合计每个任务默认最多 20 次请求，并且跨任务每月合计最多 100 次（失败请求也计数）；达到任一上限立即停止付费调用。7 天缓存命中不产生新付费请求。密钥仅保存在本 Windows 用户配置下并使用 DPAPI 加密。',wraplength=710).pack(anchor='w',pady=(0,10))
        serp_var=tk.StringVar(); brave_var=tk.StringVar()
        ttk.Label(frame,text='SerpApi API Key').pack(anchor='w'); ttk.Entry(frame,textvariable=serp_var,show='*',width=86).pack(fill='x',pady=(2,8))
        ttk.Label(frame,text='Brave Search API Key').pack(anchor='w'); ttk.Entry(frame,textvariable=brave_var,show='*',width=86).pack(fill='x',pady=(2,8))
        ttk.Label(frame,text='输入新的密钥后点击保存；留空表示不修改现有密钥。清除密钥请使用下方清除按钮。',foreground='#666').pack(anchor='w')
        status=tk.StringVar(value=f"SerpApi：{'已配置' if keys.get('serpapi') else '未配置'}；Brave：{'已配置' if keys.get('brave') else '未配置'}")
        ttk.Label(frame,textvariable=status).pack(anchor='w',pady=8)
        quota_frame=ttk.Frame(frame); quota_frame.pack(fill='x',pady=4)
        quotas=get_provider_quotas(DB_FILE)
        ttk.Label(quota_frame,text='SerpApi 月免费额度（按账户套餐填写，0=未设置）').pack(side='left')
        serp_quota=tk.StringVar(value=str(quotas.get('serpapi',0))); ttk.Entry(quota_frame,textvariable=serp_quota,width=8).pack(side='left',padx=4)
        ttk.Label(quota_frame,text='Brave 月免费额度').pack(side='left',padx=(10,0))
        brave_quota=tk.StringVar(value=str(quotas.get('brave',0))); ttk.Entry(quota_frame,textvariable=brave_quota,width=8).pack(side='left',padx=4)
        usage_box=tk.Text(frame,height=12,wrap='word'); usage_box.pack(fill='both',expand=True,pady=6)
        def refresh_usage():
            usage_box.delete('1.0','end')
            usage_box.insert('end',f'月度调用统计：SerpApi + Brave 跨任务保护上限 100 次；本月已预留 {paid_monthly_usage(DB_FILE)} 次，剩余 {max(0,100-paid_monthly_usage(DB_FILE))} 次。失败请求也计入，缓存命中不计费。\n免费额度由账户套餐决定，请按供应商控制台填写。\n')
            try:
                set_provider_quota(DB_FILE,'serpapi',int(serp_quota.get() or 0)); set_provider_quota(DB_FILE,'brave',int(brave_quota.get() or 0))
            except ValueError:
                usage_box.insert('end','额度必须为非负整数。\n')
            rows=provider_usage(DB_FILE)
            qmap=get_provider_quotas(DB_FILE)
            if not rows: usage_box.insert('end','暂无 API 调用记录。\n')
            for row in rows[:20]:
                quota=qmap.get(row['provider'],0); pct=(row['calls']/quota*100) if quota else None
                qtext=f'额度 {quota} / 使用 {pct:.1f}%' if quota else '额度未设置'
                usage_box.insert('end',f"{row['month']} | {row['provider']} | 调用 {row['calls']} | 成功 {row['successes']} | 失败 {row['errors']} | 结果 {row['results']} | {qtext} | 最近状态 {row['last_status']} | {row['last_error'] or '无错误'}\n")
            usage_box.insert('end','\n最近错误（不含 API Key）：\n')
            con=sqlite3.connect(DB_FILE)
            for provider,st,code,msg,when in con.execute('SELECT provider,status,error_code,error_message,created_at FROM provider_errors ORDER BY id DESC LIMIT 20'):
                usage_box.insert('end',f'{when} | {provider} | HTTP {st} | {code} | {msg}\n')
            con.close()
        def save():
            new={"serpapi":serp_var.get().strip() or keys.get('serpapi',''),"brave":brave_var.get().strip() or keys.get('brave','')}
            try:
                save_api_keys(new); keys.update(new); serp_var.set(''); brave_var.set('')
                status.set(f"SerpApi：{'已配置' if new['serpapi'] else '未配置'}；Brave：{'已配置' if new['brave'] else '未配置'}")
                messagebox.showinfo('保存成功','API Key 已在本机加密保存。',parent=win)
            except Exception as exc: messagebox.showerror('保存失败',str(exc),parent=win)
        def clear_keys():
            if not messagebox.askyesno('确认清除','确定清除本机保存的两个 API Key？',parent=win): return
            try:
                save_api_keys({}); keys.update({"serpapi":"","brave":""}); status.set('SerpApi：未配置；Brave：未配置')
                messagebox.showinfo('已清除','本机 API Key 已清除。',parent=win)
            except Exception as exc: messagebox.showerror('清除失败',str(exc),parent=win)
        def test_one(provider):
            active=(serp_var.get().strip() if provider=='serpapi' else brave_var.get().strip()) or keys.get(provider,'')
            if not active:
                messagebox.showwarning('未配置','请先输入并保存对应 API Key。',parent=win); return
            status.set(f'{provider} 正在执行真实连接测试…')
            def worker():
                try:
                    fn=search_serpapi if provider=='serpapi' else search_brave
                    rows,http=fn('China manufacturer official website',active,max_results=1)
                    record_provider_call(DB_FILE,provider,True,len(rows),http)
                    self._post_ui(lambda:status.set(f'{provider} 真实连接成功：HTTP {http}，返回 {len(rows)} 条自然搜索结果'))
                    self._post_ui(refresh_usage)
                except Exception as exc:
                    record_provider_call(DB_FILE,provider,False,0,getattr(exc,'status',None),getattr(exc,'code',type(exc).__name__),str(exc)[:180] if isinstance(exc,ProviderError) else type(exc).__name__)
                    err_type=type(exc).__name__
                    self._post_ui(lambda e=err_type:status.set(f'{provider} 真实连接失败：{e}'))
                    self._post_ui(refresh_usage)
            threading.Thread(target=worker,daemon=True).start()
        btn=ttk.Frame(frame); btn.pack(fill='x',pady=5)
        ttk.Button(btn,text='安全保存',command=save).pack(side='left',padx=3)
        ttk.Button(btn,text='清除密钥',command=clear_keys).pack(side='left',padx=3)
        ttk.Button(btn,text='测试 SerpApi 真实连接',command=lambda:test_one('serpapi')).pack(side='left',padx=3)
        ttk.Button(btn,text='测试 Brave 真实连接',command=lambda:test_one('brave')).pack(side='left',padx=3)
        ttk.Button(btn,text='刷新用量/错误',command=refresh_usage).pack(side='left',padx=3)
        refresh_usage()

    def live_engine_test(self):
        keyword=(self.kw.get() or '').strip()
        query=(f'({keyword}) China (female OR women OR export OR foreign trade) (WhatsApp OR email)' if keyword else 'China female export sales manager WhatsApp email')
        self.status.set('正在逐个测试可用搜索引擎并读取真实标题/网址…')
        def worker():
            diagnostics={}
            try:
                rows=search_public_web(query,max_results=5,diagnostics=diagnostics,session=create_http_session())
                self._post_ui(self._show_engine_test,query,diagnostics,rows)
            except Exception as exc:
                self._post_ui(self.status.set,f'引擎实测失败：{type(exc).__name__}')
        threading.Thread(target=worker,daemon=True).start()

    def _show_engine_test(self,query,diagnostics,rows):
        win=tk.Toplevel(self); win.title('搜索引擎实测：真实标题与网址'); win.geometry('1180x650')
        ttk.Label(win,text='测试关键词：'+query,wraplength=1140).pack(anchor='w',padx=12,pady=8)
        ttk.Label(win,text='以下为当前 Windows 网络实际返回的搜索结果样本；HTTP 可访问但没有标题/网址，不算搜索成功。',foreground='#8a5a00',wraplength=1140).pack(anchor='w',padx=12,pady=(0,8))
        cols=('engine','status','count','samples')
        tree=ttk.Treeview(win,columns=cols,show='headings',height=18)
        labels={'engine':'搜索引擎','status':'本次状态','count':'有效解析数','samples':'真实标题 / 网址样本'}
        widths={'engine':130,'status':220,'count':90,'samples':700}
        for col in cols: tree.heading(col,text=labels[col]); tree.column(col,width=widths[col],stretch=True)
        for engine in diagnostics.get('public_search',{}).get('engine_order',[]):
            state=diagnostics.get('public_search',{}).get(engine,{})
            examples='\n'.join(f"{x.get('title','')} — {x.get('url','')}" for x in state.get('sample_results',[]))
            tree.insert('','end',values=(engine,state.get('status','未尝试'),state.get('results',0),examples or '未解析到真实搜索结果'))
        tree.pack(fill='both',expand=True,padx=12,pady=8)
        ttk.Label(win,text=f'合并后候选网址：{len(rows)} 条。只有后续网站核验并找到公开商务联系方式及外贸/出口业务信号，才会计入有效线索。',wraplength=1140).pack(anchor='w',padx=12,pady=4)
        ttk.Button(win,text='关闭',command=win.destroy).pack(anchor='e',padx=12,pady=10)
        self.status.set(f'引擎实测结束：合并得到 {len(rows)} 条候选网址；请查看每个引擎的标题/网址样本。')

    def show_engine_performance(self):
        rows=search_engine_performance(DB_FILE)
        win=tk.Toplevel(self); win.title('搜索引擎表现与自动排序依据'); win.geometry('850x430')
        ttk.Label(win,text='系统根据每个引擎实际带来的合格线索、解析结果和错误率调整后续搜索优先级。冷启动时采用默认候选顺序。',wraplength=810).pack(anchor='w',padx=12,pady=10)
        cols=('engine','calls','parsed','qualified','errors','last')
        tree=ttk.Treeview(win,columns=cols,show='headings',height=12)
        labels={'engine':'引擎','calls':'搜索次数','parsed':'解析结果数','qualified':'合格线索数','errors':'错误次数','last':'最近状态'}
        widths={'engine':140,'calls':90,'parsed':110,'qualified':110,'errors':90,'last':260}
        for col in cols: tree.heading(col,text=labels[col]); tree.column(col,width=widths[col],stretch=True)
        for row in rows: tree.insert('','end',values=(row['engine'],row['calls'],row['parsed_results'],row['qualified_leads'],row['errors'],row['last_status']))
        tree.pack(fill='both',expand=True,padx=12,pady=8)
        if not rows: ttk.Label(win,text='尚无联网搜索记录；首次运行后会自动开始积累各引擎表现。',foreground='#777').pack(anchor='w',padx=12)
        ttk.Button(win,text='关闭',command=win.destroy).pack(anchor='e',padx=12,pady=10)

    def network_diagnostics(self):
        self.status.set('正在检测 SerpApi / Brave API 网络端点…')
        def worker():
            try:
                report = run_network_diagnostics()
                self._post_ui(self._show_network_report, report)
            except Exception as exc:
                self._post_ui(messagebox.showerror, '网络诊断失败', f'{type(exc).__name__}: {exc}')
                self._post_ui(self.status.set, '网络诊断失败')
        threading.Thread(target=worker, daemon=True).start()

    def _show_network_report(self, report):
        win = tk.Toplevel(self); win.title('外贸达人本机网络诊断'); win.geometry('980x440')
        ttk.Label(win, text='检测 Bing / DuckDuckGo 自主搜索入口，以及 SerpApi / Brave 可选 API 端点；不会发送 API Key。API 端点可访问不代表账户认证成功。', wraplength=930).pack(anchor='w', padx=12, pady=(12,6))
        ttk.Label(win, text=f"系统：{report['platform']}\n代理：{report['proxy']}", wraplength=930).pack(anchor='w', padx=12, pady=4)
        cols=('site','host','dns','https','result','bytes')
        tree=ttk.Treeview(win, columns=cols, show='headings', height=10)
        labels={'site':'搜索入口','host':'主机','dns':'DNS解析','https':'HTTPS结果','result':'连接状态','bytes':'响应字节数'}
        widths={'site':125,'host':175,'dns':230,'https':250,'result':100,'bytes':70}
        for col in cols:
            tree.heading(col,text=labels[col]); tree.column(col,width=widths[col],stretch=True)
        for row in report['rows']:
            tree.insert('', 'end', values=(row['site'],row['host'],row['dns'],row['https'],row['result'],row['bytes']))
        tree.pack(fill='both',expand=True,padx=12,pady=8)
        ttk.Button(win,text='关闭',command=win.destroy).pack(anchor='e',padx=12,pady=(0,10))
        self.status.set('搜索 API 端点诊断完成')

    def _post_ui(self, callback, *args, **kwargs):
        """Thread-safe UI dispatch: workers enqueue updates; Tk widgets are touched on the main thread."""
        self._ui_events.put((callback,args,kwargs))

    def _update_query_progress(self, done, total, candidates, new_domains, engine_note='', duplicates_skipped=0):
        try:
            self.progress.stop()
            self.progress.configure(mode='determinate', maximum=max(1,int(total)), value=max(0,min(int(done),int(total))))
        except Exception:
            pass
        suffix=f'；本次新增域名 {new_domains} 个；累计候选网站 {candidates} 个；历史重复跳过 {duplicates_skipped} 个'
        if engine_note:
            suffix += f'；引擎：{engine_note}'
        self.status.set(f'搜索进度 {done}/{total}{suffix}')

    def _process_ui_events(self):
        try:
            while True:
                callback,args,kwargs=self._ui_events.get_nowait()
                try:
                    callback(*args,**kwargs)
                except Exception as exc:
                    # Keep the event loop alive; errors from UI callbacks should be visible in status.
                    try: self.status.set(f'界面更新异常：{type(exc).__name__}: {exc}')
                    except Exception: pass
        except queue.Empty:
            pass
        try:
            if self.winfo_exists(): self.after(100,self._process_ui_events)
        except tk.TclError:
            pass

    def cat_changed(self,event=None):
        cat=self.cat_var.get()
        rows=[x for x in self.catalog if x.get('大类')==cat]
        # Include the official sub-industry code in the display label so repeated Chinese names remain selectable.
        labels=[f"{x.get('细分行业','')}（{x.get('细分行业代码','')}）" for x in rows]
        self.sub['values']=labels
        if labels: self.sub.current(0); self.sub_changed()
    def selected_catalog_row(self):
        selected=(self.sub_var.get() or '').strip()
        code_match=re.search(r'（(\d{4})）$',selected)
        if code_match:
            return next((x for x in self.catalog if x.get('细分行业代码')==code_match.group(1)),{})
        # Backward-compatible fallback for tests and older UI state containing only the industry name.
        return next((x for x in self.catalog if x.get('细分行业')==selected and (not self.cat_var.get() or x.get('大类')==self.cat_var.get())),{})
    def sub_changed(self,event=None):
        row=self.selected_catalog_row()
        # The keyword box is intentionally concise: the uploaded new English core terms.
        # Users may append concrete product names separated by semicolons.
        terms=[x.strip() for x in (row.get('英文核心词') or '').split(';') if x.strip()]
        if not terms:
            terms=[x.strip() for x in (row.get('英文搜索关键词') or '').split(';')[:1] if x.strip()]
        self.kw.set('; '.join(dict.fromkeys(terms)))

    def import_catalog(self):
        path=filedialog.askopenfilename(title='选择行业目录 CSV',filetypes=[('CSV','*.csv')]);
        if not path:return
        try:
            with open(path,encoding='utf-8-sig',newline='') as f:
                reader=csv.DictReader(f); data=list(reader); fieldnames=list(reader.fieldnames or [])
            if not data or not {'大类','细分行业','英文搜索关键词'}.issubset(data[0].keys()): raise ValueError('CSV 必须包含：大类、细分行业、英文搜索关键词')
            imported_codes={str(x.get('细分行业代码','')).strip() for x in data if x.get('细分行业代码')}
            supplements=[x for x in self.catalog if str(x.get('目录类型','')).startswith('补充-') and str(x.get('细分行业代码','')).strip() not in imported_codes]
            self.catalog=data+supplements
            # Preserve the built-in supplemental rows and every imported keyword column.
            all_fields=list(dict.fromkeys((fieldnames or list(data[0].keys())) + [k for row in supplements for k in row.keys()]))
            with open(CATALOG_FILE,'w',encoding='utf-8-sig',newline='') as f:
                w=csv.DictWriter(f,fieldnames=all_fields,extrasaction='ignore'); w.writeheader(); w.writerows(self.catalog)
            cats=sorted(set(x.get('大类','') for x in data if x.get('大类'))); self.cat['values']=cats
            if cats:self.cat.current(0); self.cat_changed()
            messagebox.showinfo('已更新',f'已载入 {len(data)} 条细分行业，保留全部关键词字段。')
        except Exception as e: messagebox.showerror('导入失败',str(e))

    def make_queries(self):
        """Build one complete English-keyword pass and resume/rotate it persistently."""
        country={'中国':'China','美国':'United States','德国':'Germany','英国':'United Kingdom','全球':'Worldwide'}.get(self.country.get().strip(), self.country.get().strip() or 'China')
        selected_row=self.selected_catalog_row()
        selected_code=str(selected_row.get('细分行业代码','')).strip()
        selected_category=self.cat_var.get().strip() if 'cat_var' in self.__dict__ else ''
        all_categories=bool(self.__dict__.get('search_all_categories',False))
        common={
            'selected_category': selected_category if (self.search_all.get() or not selected_code) else None,
            'selected_code': (selected_code or None) if not self.search_all.get() else None,
            'all_categories': all_categories,
            'extra_terms': self.kw.get() or '',
        }
        saved_progress=load_progress()
        baseline=build_rounds(self.catalog,country,keyword_cycle=0,**common)
        rotation_signature=plan_signature(baseline,country)
        if saved_progress.get('rotation_signature')==rotation_signature:
            if not saved_progress.get('completed',False):
                keyword_cycle=max(0,int(saved_progress.get('keyword_cycle',0) or 0))
            else:
                keyword_cycle=max(0,int(saved_progress.get('next_keyword_cycle',int(saved_progress.get('keyword_cycle',0) or 0)+1)))
        else:
            keyword_cycle=0
        rounds=build_rounds(self.catalog,country,keyword_cycle=keyword_cycle,**common)
        actual_signature=plan_signature(rounds,country)
        if (saved_progress.get('rotation_signature')==rotation_signature and
                saved_progress.get('signature')==actual_signature and
                not saved_progress.get('completed') and saved_progress.get('plan_queries')):
            canonical=flatten_rounds(rounds)
            by_query={item['query']:item for item in canonical}
            restored=[by_query[q] for q in saved_progress['plan_queries'] if q in by_query]
            restored.extend(item for item in canonical if item['query'] not in set(saved_progress['plan_queries']))
            flat=restored
            rank={item['query']:i for i,item in enumerate(flat)}
            for round_info in rounds:
                round_info['queries'].sort(key=lambda x:rank.get(x['query'],10**9))
        else:
            rounds=prioritize_rounds(rounds,load_performance())
            flat=flatten_rounds(rounds)
        self._base_signature=rotation_signature
        self._rotation_signature=rotation_signature
        self._keyword_cycle=keyword_cycle
        context={item['query']:{**{k:v for k,v in item.items() if k!='query'},'search_intent':item['intent']} for item in flat}
        self._search_rounds=rounds
        self._query_context=context
        return [item['query'] for item in flat]

    def _wait_for_task_permission(self):
        """Block the worker while paused; return False when a stop was requested."""
        while not self._pause_event.wait(0.2):
            if self._stop_event.is_set():
                return False
        return not self._stop_event.is_set()

    def pause_task(self):
        if self._task_active:
            self._pause_event.clear()
            self.pause_btn.config(state='disabled')
            self.resume_btn.config(state='normal')
            self.status.set('已请求暂停 · 当前正在执行的网络请求/小批次结束后暂停，进度会保留')

    def resume_task(self):
        if self._task_active:
            self._pause_event.set()
            self.pause_btn.config(state='normal')
            self.resume_btn.config(state='disabled')
            self.status.set('正在继续采集 · 从当前任务位置接着执行')

    def stop_task(self):
        if self._task_active and messagebox.askyesno('停止采集','确定停止当前任务吗？已保存的数据会保留；停止后如需继续，请重新开始任务并从保存的搜索进度恢复。'):
            self._stop_event.set()
            self._pause_event.set()  # release a paused worker so it can exit
            self.pause_btn.config(state='disabled'); self.resume_btn.config(state='disabled'); self.stop_btn.config(state='disabled')
            self.status.set('正在安全停止 · 保存当前已完成的数据与搜索进度…')

    def start(self):
        # Snapshot all Tk variables on the UI thread; workers must not read Tk widgets.
        try: target=max(5,min(300,int(self.target.get().strip())))
        except (ValueError, TypeError): target=30
        try: min_score=max(0,min(100,int(self.min_score.get().strip())))
        except (ValueError, TypeError): min_score=25
        try: workers=max(1,min(8,int(self.parallel.get())))
        except (ValueError, TypeError): workers=4
        selected_row=self.selected_catalog_row()
        selected_industry=selected_row.get('细分行业',self.sub_var.get())
        queries=self.make_queries()
        query_context=dict(getattr(self, '_query_context', {}))
        if self.women_mode.get():
            for trade_query in build_trade_contact_queries({'中国':'China','美国':'United States','德国':'Germany','英国':'United Kingdom','全球':'Worldwide'}.get(self.country.get().strip(), self.country.get().strip() or 'China')):
                if trade_query not in query_context:
                    queries.append(trade_query)
                    query_context[trade_query]={'industry':'综合外贸','keywords':'出口; 外贸; 国际销售; 供应链','category':'综合外贸','search_intent':'women_trade_contacts'}
        if not queries:
            messagebox.showwarning('没有可执行查询','请先选择行业大类/细分行业，并填写有效的英文核心词或产品关键词。')
            return
        rounds=list(self.__dict__.get('_search_rounds',[]))
        country_value={'中国':'China','美国':'United States','德国':'Germany','英国':'United Kingdom','全球':'Worldwide'}.get(self.country.get().strip(), self.country.get().strip() or 'China')
        signature=plan_signature(rounds,country_value)
        config={
            'queries': queries,
            'query_context': query_context,
            'search_rounds': rounds,
            'progress_signature': signature,
            'base_signature': self.__dict__.get('_base_signature',signature),
            'rotation_signature': self.__dict__.get('_rotation_signature',signature),
            'keyword_cycle': int(self.__dict__.get('_keyword_cycle',0)),
            'all_industry': bool(self.search_all.get()),
            'industry': selected_industry,
            'keywords': self.kw.get().strip(),
            'country': country_value,
            'category': self.cat_var.get(),
            'min_score': min_score,
            'workers': workers,
            'women_mode': bool(self.women_mode.get()),
            'search_mode': (self.__dict__.get('search_mode').get() if self.__dict__.get('search_mode') is not None else '自主搜索（免API）'),
        }
        self._stop_event.clear(); self._pause_event.set(); self._task_active=True
        self.run_btn.config(state='disabled'); self.pause_btn.config(state='normal'); self.resume_btn.config(state='disabled'); self.stop_btn.config(state='normal')
        try:
            self.progress.stop(); self.progress.configure(mode='determinate',maximum=max(1,len(queries)),value=0)
        except Exception: pass
        self.status.set(f'正在发现公开网页 · 共 {len(queries)} 条搜索查询')
        threading.Thread(target=self.worker_discover,args=(target,config),daemon=True).start()

    @staticmethod
    def _name_tokens(text):
        raw=(text or '').lower()
        raw=re.sub(r'(有限责任公司|有限公司|股份有限公司|集团公司|集团|公司)$','',raw)
        text=re.sub(r'[^a-z0-9\u4e00-\u9fff]+',' ',raw)
        stop={'company','limited','ltd','co','corp','inc','the','china','plastic','products','manufacturer','factory','group','technology'}
        tokens={x for x in text.split() if len(x)>=3 and x not in stop}
        # Chinese names are not whitespace-delimited; compare character bigrams
        # so a Chinese official name can match a public LinkedIn page title.
        for run in re.findall(r'[\u4e00-\u9fff]{2,}', raw):
            tokens.update(run[i:i+2] for i in range(len(run)-1))
        return tokens

    def _match_linkedin_company(self, company_name, linkedin_candidates):
        base=self._name_tokens(company_name)
        if not base: return ''
        best=''; best_score=0
        for title,url in linkedin_candidates:
            cand=self._name_tokens(title)
            if not cand: continue
            score=len(base & cand)/max(1,len(base|cand))
            if score>best_score: best_score=score; best=url
        return best if best_score>=0.34 else ''

    def worker_discover(self,target,config):
        candidates={}; queries=config['queries']; diagnostics={'_paid_search_budget': {'limit': 20, 'used': 0, 'monthly_used': paid_monthly_usage(DB_FILE), 'monthly_limit': 100}}; found=[]; scanned=0; errors=0; below=0; excluded=0; pending_no_contact=0; failed_sites=[]; net_fail=0; restricted_sites=0
        try:
            search_session=create_http_session()
            linkedin_candidates=[]
            people_found=[]
            flat_queries=flatten_rounds(config.get('search_rounds',[]))
            signature=config.get('progress_signature','')
            saved=load_progress()
            if saved.get('signature')==signature and not saved.get('completed',False):
                resume_at=max(0,min(len(flat_queries),int(saved.get('next_query_index',0))))
            else:
                resume_at=0
            task_id=str(saved.get('task_id') or uuid.uuid4().hex) if resume_at else uuid.uuid4().hex
            diagnostics['_task_id']=task_id
            if resume_at:
                diagnostics['_paid_search_budget']['used']=max(0,min(20,max(int(saved.get('paid_calls_used',0)),paid_task_usage(DB_FILE,task_id))))
            diagnostics['scheduler']={'rounds_total':len(config.get('search_rounds',[])),
                                     'queries_total':len(flat_queries),'resumed_from':resume_at,
                                     'round_metrics':saved.get('round_metrics',{}) if resume_at else {}}
            round_metrics=diagnostics['scheduler']['round_metrics']
            # Persist the stable task id before the first search/API request. If the
            # process exits mid-request, the reservation ledger can still enforce
            # the same per-task cap after restart.
            save_progress({'signature':signature,'base_signature':config.get('base_signature',signature),
                           'rotation_signature':config.get('rotation_signature',config.get('base_signature',signature)),
                           'keyword_cycle':int(config.get('keyword_cycle',0)),
                           'next_keyword_cycle':int(config.get('keyword_cycle',0)),
                           'plan_queries':[x['query'] for x in flat_queries],
                           'next_query_index':resume_at,'completed':False,
                           'round_metrics':round_metrics,'candidate_snapshot':saved.get('candidate_snapshot',[]) if resume_at else [],
                           'paid_calls_used':int(diagnostics.get('_paid_search_budget',{}).get('used',0)), 'task_id':task_id,
                           'updated_at':time.strftime('%Y-%m-%dT%H:%M:%S')})
            known_domains, known_company_names = load_collected_registry()
            recent_domains, recent_company_names = load_recently_seen_registry(days=30)
            known_domains.update(recent_domains); known_company_names.update(recent_company_names)
            duplicates_skipped = 0
            if resume_at and saved.get('candidate_snapshot'):
                for entry in saved.get('candidate_snapshot',[]):
                    if isinstance(entry,list) and len(entry)==4:
                        domain,href,title,source_query=entry
                        if domain and href: candidates[domain]=(href,title,source_query)
            for flat_index in range(resume_at,len(flat_queries)):
                if not self._wait_for_task_permission():
                    break
                item=flat_queries[flat_index]
                q=item['query']; qi=flat_index+1
                round_no=item['round_index']+1; intent_no=item['intent_index']+1
                self._post_ui(lambda qi=qi,n=len(flat_queries),rn=round_no,rt=len(config.get('search_rounds',[])),it=intent_no,q=q,term=item.get('active_english_term',''),cycle=int(item.get('keyword_cycle',0))+1: self.status.set(f'关键词轮换第 {cycle} 组 · {term} · 行业轮次 {rn}/{rt} · 意图 {it}/8 · 查询 {qi}/{n}'))
                per_query_limit=10 if config.get('all_industry') else min(30,max(10,target*2))
                query_added=0
                before_domains=set(candidates)
                interrupted_query=False
                active_excluded_domains=set(known_domains) | {registry_domain_key(x) for x in candidates}
                active_excluded_names=set(known_company_names) | {normalize_company_key(v[1]) for v in candidates.values() if len(v)>1}
                for href,title in search_web(q,max_results=per_query_limit,diagnostics=diagnostics,session=search_session,search_mode=config.get('search_mode','免费优先（付费补漏）'),exclude_domains=active_excluded_domains,exclude_company_names=active_excluded_names,paid_call_limit=20):
                    if self._stop_event.is_set():
                        interrupted_query=True
                        break
                    domain=root_domain(href)
                    if not domain: continue
                    if is_previously_collected(domain,title,known_domains,known_company_names):
                        duplicates_skipped += 1
                        record_registry_candidate(domain,title,href,q,status='previously_collected')
                        continue
                    if domain not in candidates:
                        candidates[domain]=(href,title,q); query_added+=1
                        record_registry_candidate(domain,title,href,q,status='discovered')
                metric_key=item['industry_code']
                metric=round_metrics.setdefault(metric_key,{'industry':item['industry'],'queries_done':0,'results_seen':0,'new_domains':0,'intent_results':{}})
                metric['queries_done']+=1
                metric['results_seen']+=query_added
                metric['new_domains']+=len(set(candidates)-before_domains)
                metric['intent_results'][item['intent']]=query_added
                record_query_performance(q,query_added)
                # Atomic checkpoint after every query: a crash may replay at most the current query.
                candidate_snapshot=[[domain,*value] for domain,value in candidates.items()]
                save_progress({'signature':signature,'base_signature':config.get('base_signature',signature),
                               'rotation_signature':config.get('rotation_signature',config.get('base_signature',signature)),
                               'keyword_cycle':int(config.get('keyword_cycle',0)),
                               'next_keyword_cycle':int(config.get('keyword_cycle',0)),
                               'plan_queries':[x['query'] for x in flat_queries],
                               'next_query_index':qi,'completed':False,
                               'round_metrics':round_metrics,'candidate_snapshot':candidate_snapshot,
                               'paid_calls_used':int(diagnostics.get('_paid_search_budget',{}).get('used',0)), 'task_id':task_id,
                               'updated_at':time.strftime('%Y-%m-%dT%H:%M:%S')})
                public_diag=diagnostics.get('public_search',{})
                tried=public_diag.get('engines_tried_this_query',[])
                engine_note='、'.join(tried[-3:]) if tried else '暂无引擎返回'
                self._post_ui(self._update_query_progress,qi,len(flat_queries),len(candidates),query_added,engine_note,duplicates_skipped)
                if interrupted_query or self._stop_event.is_set():
                    # Replay the current query on next launch if it was interrupted mid-stream.
                    save_progress({'signature':signature,'base_signature':config.get('base_signature',signature),
                                   'rotation_signature':config.get('rotation_signature',config.get('base_signature',signature)),
                                   'keyword_cycle':int(config.get('keyword_cycle',0)),
                                   'next_keyword_cycle':int(config.get('keyword_cycle',0)),
                                   'plan_queries':[x['query'] for x in flat_queries],
                                   'next_query_index':flat_index if interrupted_query else qi-1,'completed':False,
                                   'round_metrics':round_metrics,'candidate_snapshot':[[domain,*value] for domain,value in candidates.items()],
                                   'paid_calls_used':int(diagnostics.get('_paid_search_budget',{}).get('used',0)), 'task_id':task_id,
                                   'updated_at':time.strftime('%Y-%m-%dT%H:%M:%S')})
                    self._post_ui(lambda:self.status.set('任务已停止 · 搜索进度已保存；已采集企业数据不会丢失'))
                    return
            if self._stop_event.is_set():
                self._post_ui(lambda:self.status.set('任务已停止 · 已保存当前进度和数据'))
                return
            save_progress({'signature':signature,'base_signature':config.get('base_signature',signature),
                           'rotation_signature':config.get('rotation_signature',config.get('base_signature',signature)),
                           'keyword_cycle':int(config.get('keyword_cycle',0)),
                           'next_keyword_cycle':int(config.get('keyword_cycle',0))+1,
                           'plan_queries':[x['query'] for x in flat_queries],
                           'next_query_index':len(flat_queries),'completed':True,
                           'round_metrics':round_metrics,'candidate_snapshot':[[domain,*value] for domain,value in candidates.items()],
                           'paid_calls_used':int(diagnostics.get('_paid_search_budget',{}).get('used',0)), 'task_id':task_id,
                           'updated_at':time.strftime('%Y-%m-%dT%H:%M:%S')})
            # Optional LinkedIn public-index enrichment runs only after core manufacturer discovery.
            # It is supplementary and must never consume the initial search budget.
            if config.get('women_mode'):
                people_queries = build_people_queries(config.get('keywords',''), config.get('country','China'))
                for pq in people_queries:
                    if not self._wait_for_task_permission(): return
                    self._post_ui(lambda q=pq: self.status.set(f'发现女性外贸联系人职业线索：{q[:75]}'))
                    for title, profile_url in search_people_web(pq, max_results=8, diagnostics=diagnostics, session=search_session):
                        key=profile_url.rstrip('/').lower()
                        email_match=EMAIL_RE.search(title)
                        wa_link_match=WA_RE.search(title)
                        wa_number_match=re.search(r'(?i)(?:whatsapp|wa\.me)[^0-9+]{0,12}(\+?\d[\d ()-]{7,}\d)',title)
                        title_has_contact=bool(email_match or wa_link_match or wa_number_match)
                        if title_has_contact and not any(x.get('profile_url','').rstrip('/').lower()==key for x in self.people_rows+people_found):
                            people_found.append({'name_title':title,'profile_url':profile_url,'search_query':pq,'identity_status':'女性身份/职位待人工核验','whatsapp':wa_link_match.group(0) if wa_link_match else (wa_number_match.group(1) if wa_number_match else ''),'email':email_match.group(0) if email_match else '','official_company_url':'待匹配','notes':'搜索结果标题公开显示联系方式线索；不访问或绕过 LinkedIn 登录限制，WhatsApp 注册状态仍未核实。'})
                self.people_rows.extend(people_found)
            # Company-page matching is also supplementary and runs after manufacturer queries.
            for q in queries[:min(6,len(queries))]:
                if not self._wait_for_task_permission(): return
                lq=f'site:linkedin.com/company {q}'
                self._post_ui(lambda q=lq: self.status.set(f'LinkedIn企业主页公开索引搜索：{q[:80]}'))
                for title,url in search_linkedin_companies(lq,max_results=min(8,max(4,target)),diagnostics=diagnostics,session=search_session,search_mode=config.get('search_mode','免费优先（付费补漏）'),paid_call_limit=20):
                    if url not in [x[1] for x in linkedin_candidates]: linkedin_candidates.append((title,url))
            candidate_limit=max(400,target*8)
            items=balance_candidate_items(list(candidates.values()),config.get('query_context',{}),candidate_limit)
            self._post_ui(lambda n=len(items),q=len(flat_queries): self.status.set(f'搜索阶段完成：{q} 条查询；发现 {n} 个候选网站，开始核验官网与公开联系方式'))
            # Company-specific LinkedIn discovery supplements homepage social-link extraction.
            # It uses public search only, is bounded to 20 companies, and does not spend paid API quota.
            linkedin_candidates.extend(search_linkedin_for_company_candidates(items,diagnostics,search_session,limit=20))
            total=len(items)
            def job(item,retry=False):
                # Match the website against the industry/product terms that produced its search result.
                source_query=item[2] if len(item)>2 else ''
                ctx=config.get('query_context',{}).get(source_query,{})
                return scan_site(item[0],ctx.get('industry',config['industry']),ctx.get('keywords',config['keywords']),config['country'],timeout=30 if retry else None)
            if items:
                inspected=0; stop_scanning=False
                with ThreadPoolExecutor(max_workers=config['workers']) as ex:
                    # Submit in small batches; once target is met, do not queue hundreds of unnecessary site requests.
                    for batch_start in range(0,len(items),config['workers']):
                        if not self._wait_for_task_permission(): return
                        batch=items[batch_start:batch_start+config['workers']]
                        futures={ex.submit(job,item):item for item in batch}
                        for f in as_completed(futures):
                            if not self._wait_for_task_permission(): return
                            item=futures[f]; inspected+=1
                            try:
                                r=f.result(); scanned+=1
                                if len(item)>3 and item[3]:
                                    r['source_urls']=list(dict.fromkeys(r.get('source_urls',[])+[item[3]]))
                                    r['notes']=(r.get('notes','')+' 该官网候选由公开企业目录页面发现；目录来源已保留，官网对应关系仍建议核对。').strip()
                            except Exception:
                                errors+=1; continue
                            if str(r.get('status','')).startswith('访问受限'):
                                restricted_sites+=1
                                continue
                            if str(r.get('status','')).startswith('访问失败'):
                                failed_sites.append(item); net_fail+=1
                                self._post_ui(lambda i=inspected,n=total: self.status.set(f'官网访问失败 {i}/{n}；已加入低并发重试队列'))
                                continue
                            ctx=config.get('query_context',{}).get(item[2],{})
                            r['industry_category']=ctx.get('category',config['category'])
                            li=self._match_linkedin_company(r.get('company_name',''), linkedin_candidates)
                            if li:
                                r['linkedin_links']=list(dict.fromkeys(r.get('linkedin_links',[])+[li]))[:10]
                                r['notes']=(r.get('notes','')+' LinkedIn公开公司页已按名称相似度匹配；仍需人工核对公司对应关系。').strip()
                            has_public_contact=bool(r.get('emails') or r.get('whatsapp_links') or r.get('whatsapp_contacts'))
                            export_signal=int(r.get('operation_score') or 0)>=8
                            women_query=(ctx.get('search_intent')=='women_trade_contacts')
                            broad_trade_candidate=has_public_contact and export_signal
                            manufacturer_candidate=has_public_contact and int(r.get('manufacturer_score') or 0)>=config['min_score']
                            quality_status, quality_reason=assess(r)
                            if quality_status == 'excluded':
                                excluded += 1
                                record_registry_candidate(root_domain(item[0]),r.get('company_name',''),item[0],item[2],status='excluded')
                                continue
                            if not has_public_contact and quality_status in ('keep','review'):
                                pending_no_contact += 1
                            if is_trade_contact_candidate(r,config['min_score']):
                                if broad_trade_candidate and not manufacturer_candidate:
                                    quality_status='review'; quality_reason='存在外贸/出口信号及公开联系方式，但官网未能证明其为制造商'
                                r['quality_status']=quality_status; r['quality_reason']=quality_reason
                                r['quality_category']='制造商候选' if quality_status=='keep' else '待人工复核'
                                if women_query:
                                    r['gender_status']='女性外贸联系人候选（待人工核验）'
                                    r['decision_maker_evidence']=(r.get('decision_maker_evidence','')+'；由女性外贸职位搜索词发现，女性身份及个人联系方式归属必须人工核验').strip('；')
                                if broad_trade_candidate and not manufacturer_candidate:
                                    r['notes']=(r.get('notes','')+'；按新规则：有公开商务联系方式且存在外贸/出口业务信号，已保留为人工审核候选，不要求是制造商。').strip()
                                domain=root_domain(item[0])
                                engines=diagnostics.get('domain_engine_map',{}).get(domain,[]) or [diagnostics.get('result_engine_map',{}).get(item[0],'')]
                                engines=[x for x in engines if x]
                                if engines:
                                    for engine in engines:
                                        try: record_engine_qualification(DB_FILE,engine,True)
                                        except Exception: pass
                                    r['notes']=(r.get('notes','')+f'；搜索来源引擎：{", ".join(engines)}；原始搜索词：{item[2]}').strip()
                                found.append(r)
                                try: save_lead(r)
                                except Exception as db_exc:
                                    errors+=1; r['notes']=(r.get('notes','')+f' 数据库保存失败：{type(db_exc).__name__}').strip()
                                self._post_ui(self.add_result,r,len(found),target)
                                if len(found)>=target:
                                    stop_scanning=True
                                    for pending in futures:
                                        if pending is not f and not pending.done(): pending.cancel()
                                    break
                            else: below+=1
                            self._post_ui(lambda i=inspected,n=total,f=len(found): self.status.set(f'核验候选官网 {i}/{n}；已通过 {f}'))
                        if stop_scanning:
                            break
            # Retry network failures once with lower concurrency and a longer timeout.
            if failed_sites and len(found) < target:
                try:
                    retry_items=failed_sites[:min(len(failed_sites), max(10, target-len(found)))]
                    with ThreadPoolExecutor(max_workers=2) as retry_ex:
                        retry_futures={retry_ex.submit(job,item,True):item for item in retry_items}
                        for f in as_completed(retry_futures):
                            if not self._wait_for_task_permission(): return
                            item=retry_futures[f]
                            try: r=f.result(); scanned+=1
                            except Exception: errors+=1; continue
                            if str(r.get('status','')).startswith(('访问失败','访问受限')):
                                errors+=1; continue
                            r['industry_category']=config.get('query_context',{}).get(item[2],{}).get('category',config['category'])
                            has_public_contact=bool(r.get('emails') or r.get('whatsapp_links') or r.get('whatsapp_contacts'))
                            export_signal=int(r.get('operation_score') or 0)>=8
                            ctx=config.get('query_context',{}).get(item[2],{})
                            women_query=(ctx.get('search_intent')=='women_trade_contacts')
                            broad_trade_candidate=has_public_contact and export_signal
                            manufacturer_candidate=has_public_contact and int(r.get('manufacturer_score') or 0)>=config['min_score']
                            quality_status, quality_reason=assess(r)
                            if quality_status == 'excluded':
                                excluded += 1
                                record_registry_candidate(root_domain(item[0]),r.get('company_name',''),item[0],item[2],status='excluded')
                                continue
                            if not has_public_contact and quality_status in ('keep','review'):
                                pending_no_contact += 1
                            if is_trade_contact_candidate(r,config['min_score']):
                                if broad_trade_candidate and not manufacturer_candidate:
                                    quality_status='review'; quality_reason='存在外贸/出口信号及公开联系方式，但官网未能证明其为制造商'
                                r['quality_status']=quality_status; r['quality_reason']=quality_reason
                                r['quality_category']='制造商候选' if quality_status=='keep' else '待人工复核'
                                if women_query:
                                    r['gender_status']='女性外贸联系人候选（待人工核验）'
                                    r['decision_maker_evidence']=(r.get('decision_maker_evidence','')+'；由女性外贸职位搜索词发现，女性身份及个人联系方式归属必须人工核验').strip('；')
                                if broad_trade_candidate and not manufacturer_candidate:
                                    r['notes']=(r.get('notes','')+'；按新规则：有公开商务联系方式且存在外贸/出口业务信号，已保留为人工审核候选，不要求是制造商。').strip()
                                domain=root_domain(item[0])
                                engines=diagnostics.get('domain_engine_map',{}).get(domain,[]) or [diagnostics.get('result_engine_map',{}).get(item[0],'')]
                                engines=[x for x in engines if x]
                                if engines:
                                    for engine in engines:
                                        try: record_engine_qualification(DB_FILE,engine,True)
                                        except Exception: pass
                                    r['notes']=(r.get('notes','')+f'；搜索来源引擎：{", ".join(engines)}；原始搜索词：{item[2]}').strip()
                                found.append(r)
                                try: save_lead(r)
                                except Exception as db_exc:
                                    errors+=1; r['notes']=(r.get('notes','')+f' 数据库保存失败：{type(db_exc).__name__}').strip()
                                self._post_ui(self.add_result,r,len(found),target)
                            else: below+=1
                finally:
                    pass
            by_domain={root_domain(x.get('company_website','')):x for x in self.rows if root_domain(x.get('company_website',''))}
            for item in found:
                domain=root_domain(item.get('company_website',''))
                if domain: by_domain[domain]=item
            self.rows=list(by_domain.values())
            valid_manufacturers=sum(1 for x in found if x.get('quality_status')=='keep')
            pending_review=sum(1 for x in found if x.get('quality_status')=='review')+pending_no_contact
            self._post_ui(self._update_summary_stats,len(candidates),valid_manufacturers,pending_review,excluded,duplicates_skipped,len(linkedin_candidates))
            if not candidates:
                provider_status=diagnostics.get('provider_orchestration',{}).get('status','')
                serp=diagnostics.get('serpapi',{}); brave=diagnostics.get('brave',{})
                detail='；'.join(x for x in [f"SerpApi：{serp.get('last_error','')}",f"Brave：{brave.get('last_error','')}"] if x and not x.endswith('：'))
                free_status=diagnostics.get('public_search',{})
                free_detail='；'.join(f"{name}：{state.get('status','未知')}" for name,state in free_status.items() if isinstance(state,dict) and name in ('Bing','DuckDuckGo','Baidu','Ecosia','Yandex'))
                msg='未发现官网候选：'+(provider_status or '搜索引擎未返回可用候选。')
                if free_detail: msg+='；免费搜索诊断：'+free_detail
                if detail: msg+=' '+detail
                msg+=' 可查看网络诊断；免费搜索优先运行，付费 API 仅在配置后补足结果缺口。'
            elif not found: msg=f'搜索候选 {len(candidates)} 家；已核验 {scanned} 家；有效制造商 0 家；待复核（缺少公开联系方式）{pending_no_contact} 家；排除无关 {excluded} 家；其他未达到收录条件 {below} 家；异常 {errors} 个。当前没有可用的商务联系线索，请检查关键词或稍后重试。'
            else:
                msg=f'完成：原始去重后搜索候选 {len(candidates)} 家；核验 {scanned} 家；有效制造商 {valid_manufacturers} 家；待人工复核 {pending_review} 家（其中无公开联系方式 {pending_no_contact} 家）；排除无关 {excluded} 家；本次新增企业 {len(found)} 家；历史重复跳过 {duplicates_skipped} 次。LinkedIn公开公司页候选 {len(linkedin_candidates)} 个；低分 {below} 个，网络失败 {net_fail} 个，访问受限 {restricted_sites} 个，异常 {errors} 个。历史数据已保存。'
            if config.get('women_mode'):
                msg += f'；公开个人职业资料候选累计 {len(self.people_rows)} 条（身份与 WhatsApp 均需按来源核实）'
            msg += f'；历史已采集企业/官网自动跳过 {duplicates_skipped} 次'
            paid_used=int(diagnostics.get('_paid_search_budget',{}).get('used',0))
            paid_month=diagnostics.get('_paid_search_budget',{}).get('monthly_used','未知')
            msg += f'；本任务付费搜索 {paid_used}/20 次（SerpApi + Brave 合计）；本月累计 {paid_month}/100 次'
            li_diag=diagnostics.get('linkedin_company_search',{})
            msg += f"；LinkedIn企业主页搜索 {li_diag.get('queries',0)} 次，命中 {li_diag.get('results',len(linkedin_candidates))} 条；{li_diag.get('last_status','未执行')}"
            self._post_ui(lambda msg=msg:self.status.set(msg))
        except Exception as e:
            msg=f'采集异常：{type(e).__name__}: {e}'
            paid_used=int(diagnostics.get('_paid_search_budget',{}).get('used',0))
            paid_month=diagnostics.get('_paid_search_budget',{}).get('monthly_used','未知')
            msg += f'；本任务付费搜索 {paid_used}/20 次（SerpApi + Brave 合计）；本月累计 {paid_month}/100 次'
            li_diag=diagnostics.get('linkedin_company_search',{})
            msg += f"；LinkedIn企业主页搜索 {li_diag.get('queries',0)} 次，命中 {li_diag.get('results',len(linkedin_candidates))} 条；{li_diag.get('last_status','未执行')}"
            self._post_ui(lambda msg=msg:self.status.set(msg))
            self._post_ui(lambda msg=msg:messagebox.showerror('采集失败',msg))
        finally:
            self._post_ui(self._finish_task_ui)

    def _finish_task_ui(self):
        self._task_active=False
        for name,state in (('run_btn','normal'),('pause_btn','disabled'),('resume_btn','disabled'),('stop_btn','disabled')):
            widget=self.__dict__.get(name)
            if widget is not None: widget.config(state=state)

    def import_history_xlsx(self):
        path = filedialog.askopenfilename(title='选择历史采集 Excel', filetypes=[('Excel 文件','*.xlsx')])
        if not path:
            return
        try:
            result = import_legacy_xlsx_to_database(path)
            self.rows = load_saved_leads()
            for item in self.tree.get_children(''):
                self.tree.delete(item)
            for i, row in enumerate(reversed(self.rows), 1):
                self.add_result(row, i, len(self.rows))
            messagebox.showinfo('历史资料导入完成',
                f"新增企业：{result['imported']} 家\n更新已有企业：{result['updated']} 家\n跳过（缺少公司名称或官网）：{result['skipped']} 条\n\n原始联系方式已进入联系人库；没有单独证据网址的字段会标记为待核验，不会伪造来源。")
            self.stats_text.set(f"永久数据库现有 {len(self.rows)} 家企业。历史 Excel 新增 {result['imported']} 家，更新 {result['updated']} 家。")
        except Exception as exc:
            messagebox.showerror('导入失败', f'{type(exc).__name__}: {exc}')

    def verify_urls(self):
        win=tk.Toplevel(self); win.title('批量核验官网'); win.geometry('760x500')
        txt=tk.Text(win,wrap='word'); txt.pack(fill='both',expand=True,padx=10,pady=10); txt.insert('1.0','# 每行一个官网 URL\n')
        def go():
            urls=[normalize_url(x.strip()) for x in txt.get('1.0','end').splitlines() if x.strip() and not x.strip().startswith('#')]
            if not urls:
                messagebox.showwarning('没有网址','请每行粘贴一个官网网址，例如 https://example.com')
                return
            # Read every widget value before starting the worker thread.
            config={'industry':self.sub_var.get(),'keywords':self.kw.get().strip(),'country':{'中国':'China','美国':'United States','德国':'Germany','英国':'United Kingdom','全球':'Worldwide'}.get(self.country.get().strip(),self.country.get().strip()),'category':self.cat_var.get()}
            try: config['workers']=max(1,min(8,int(self.parallel.get())))
            except (ValueError,TypeError): config['workers']=4
            win.destroy(); self.run_btn.config(state='disabled'); self.status.set('正在核验粘贴的网址...')
            threading.Thread(target=self.worker_verify,args=(urls,config),daemon=True).start()
        ttk.Button(win,text='开始核验',command=go).pack(pady=8)

    def worker_verify(self,urls,config):
        new=[]; urls=list(dict.fromkeys(urls)); errors=0
        try:
            with ThreadPoolExecutor(max_workers=config['workers']) as ex:
                futures={ex.submit(scan_site,u,config['industry'],config['keywords'],config['country']):u for u in urls}
                for i,f in enumerate(as_completed(futures),1):
                    try:
                        r=f.result()
                    except Exception:
                        errors+=1; continue
                    r['industry_category']=config['category']
                    status=str(r.get('status',''))
                    if not status.startswith(('访问失败','访问受限')):
                        new.append(r)
                        try: save_lead(r)
                        except Exception as db_exc:
                            errors+=1; r['notes']=(r.get('notes','')+f' 数据库保存失败：{type(db_exc).__name__}').strip()
                    self._post_ui(self.add_result,r,i,len(urls))
                    self._post_ui(lambda i=i,n=len(urls):self.status.set(f'核验 {i}/{n}'))
            by_domain={root_domain(x.get('company_website','')):x for x in self.rows if root_domain(x.get('company_website',''))}
            for item in new:
                domain=root_domain(item.get('company_website',''))
                if domain: by_domain[domain]=item
            self.rows=list(by_domain.values())
            msg=f'完成：核验 {len(new)} 条；异常 {errors} 条。'
            self._post_ui(lambda msg=msg:self.status.set(msg))
        except Exception as e:
            msg=f'网址核验异常：{type(e).__name__}: {e}'
            self._post_ui(lambda msg=msg:self.status.set(msg))
            self._post_ui(lambda msg=msg:messagebox.showerror('核验失败',msg))
        finally:
            self._post_ui(self._finish_task_ui)

    def _update_summary_stats(self, raw_candidates=0, valid=0, pending=0, excluded=0, duplicates=0, linkedin_hits=0):
        self._last_raw_candidates=int(raw_candidates or 0)
        self._last_excluded_count=int(excluded or 0)
        self._last_duplicates_skipped=int(duplicates or 0)
        self._last_linkedin_hits=int(linkedin_hits or 0)
        wa_numbers=sum(len(r.get('whatsapp_contacts',[]) or []) for r in self.rows)
        wa_links=sum(len(r.get('whatsapp_links',[]) or []) for r in self.rows)
        public_phones=sum(len(r.get('phone_candidates',[]) or []) for r in self.rows)
        self.stats_text.set(
            f'本次去重后搜索候选：{self._last_raw_candidates} 家\n'
            f'企业数据库当前记录：{len(self.rows)} 家\n'
            f'有效制造商：{int(valid)} 家；待人工复核：{int(pending)} 家；排除无关：{self._last_excluded_count} 家\n'
            f'历史重复跳过：{self._last_duplicates_skipped} 次；LinkedIn公开企业主页命中：{self._last_linkedin_hits} 条\n'
            f'明确标注的 WhatsApp 号码：{wa_numbers} 个；WhatsApp 链接：{wa_links} 条；普通电话：{public_phones} 个'
        )

    def add_result(self,r,i,total):
        # Classify each newly acquired or restored row immediately for visible feedback.
        if not r.get('quality_status'):
            quality_status, quality_reason=assess(r)
            r['quality_status']=quality_status
            r['quality_category']=('制造商候选' if quality_status=='keep' else ('无关/隔离' if quality_status=='excluded' else '待人工复核'))
            r['quality_reason']=quality_reason
        elif r.get('quality_status')=='excluded':
            r['quality_category']='无关/隔离'
        display_status=r.get('quality_category') or r.get('status','')
        display_notes=r.get('notes','')
        if r.get('quality_warning'):
            display_notes=(display_notes+'；数据质量提醒：'+r['quality_warning']).strip('；')
        values=(r.get('company_name',''),r.get('company_website',''),r.get('company_address','') or '未获取',r.get('industry',''),r.get('factory_authenticity_score',0),r.get('export_capability_score',0),r.get('contact_evidence_score',0),'\n'.join(r.get('whatsapp_contacts',[])[:6]) or '未发现','\n'.join(r.get('whatsapp_links',[])[:6]) or '未发现','\n'.join(r.get('emails',[])[:5]) or '未发现','\n'.join(f"{d.get('role_label','')} / {d.get('email_score',0)}分" for d in r.get('email_details',[])[:5]) or '未发现','\n'.join(r.get('phone_candidates',[])[:6]) or '未发现','\n'.join(r.get('linkedin_links',[])[:4]) or '未发现',r.get('gender_status','未知/未核实'),display_status,display_notes)
        iid=root_domain(r.get('company_website','')) or str(i)
        if self.tree.exists(iid):
            self.tree.item(iid,values=values)
        else:
            self.tree.insert('','end',iid=iid,values=values)
        if hasattr(self, 'results_tabs'):
            self.results_tabs.tab(0, text=f'采集结果（{len(self.tree.get_children(""))}）')
        if hasattr(self, 'count_label'):
            self.count_label.configure(text=f'企业总记录：{len(self.rows)} 家   |   有效制造商：{sum(1 for x in self.rows if x.get("quality_status") == "keep")} 家   |   待复核：{sum(1 for x in self.rows if x.get("quality_status") == "review")} 家')
        if hasattr(self, 'stats_text'):
            wa_numbers=sum(len(r.get('whatsapp_contacts',[]) or []) for r in self.rows)
            wa_links=sum(len(r.get('whatsapp_links',[]) or []) for r in self.rows)
            public_phones=sum(len(r.get('phone_candidates',[]) or []) for r in self.rows)
            self.stats_text.set(
                f'本次去重后搜索候选：{self._last_raw_candidates} 家\n'
                f'企业数据库当前记录：{len(self.rows)} 家\n'
                f'有效制造商：{sum(1 for x in self.rows if x.get("quality_status") == "keep")} 家；待人工复核：{sum(1 for x in self.rows if x.get("quality_status") == "review")} 家；排除无关：{self._last_excluded_count} 家\n'
                f'历史重复跳过：{self._last_duplicates_skipped} 次；LinkedIn公开企业主页命中：{self._last_linkedin_hits} 条\n'
                f'明确标注的 WhatsApp 号码：{wa_numbers} 个；WhatsApp 链接：{wa_links} 条；普通电话：{public_phones} 个\n'
                '说明：普通电话不会自动认定为 WhatsApp。'
            )

    def show_people(self):
        win=tk.Toplevel(self); win.title('女性外贸商务人员公开职业资料候选'); win.geometry('1120x560')
        ttk.Label(win,text='此列表仅保留搜索结果标题中明确出现邮箱或 WhatsApp 联系方式的公开职业资料候选；女性身份、职位和联系方式归属仍需人工核验。',wraplength=1080).pack(anchor='w',padx=10,pady=8)
        cols=('title','profile','query','identity','wa','email','company','notes')
        tree=ttk.Treeview(win,columns=cols,show='headings')
        labels={'title':'搜索结果标题','profile':'LinkedIn 公开资料链接','query':'搜索依据','identity':'身份核验状态','wa':'WhatsApp','email':'公开邮箱','company':'企业官网匹配','notes':'说明'}
        widths={'title':210,'profile':230,'query':230,'identity':160,'wa':150,'email':190,'company':130,'notes':240}
        for c in cols: tree.heading(c,text=labels[c]); tree.column(c,width=widths[c],stretch=True)
        ys=ttk.Scrollbar(win,orient='vertical',command=tree.yview); tree.configure(yscrollcommand=ys.set)
        tree.pack(side='left',fill='both',expand=True,padx=(10,0),pady=(0,10)); ys.pack(side='right',fill='y',padx=(0,10),pady=(0,10))
        for r in self.people_rows:
            tree.insert('','end',values=(r.get('name_title',''),r.get('profile_url',''),r.get('search_query',''),r.get('identity_status','待核实'),r.get('whatsapp',''),r.get('email',''),r.get('official_company_url','待匹配'),r.get('notes','')))
        if not self.people_rows: self.status.set('尚无公开个人职业线索；请启用女性外贸联系人搜索后开始采集。')

    def export_people_csv(self):
        if not self.people_rows: messagebox.showinfo('暂无个人线索','请启用女性外贸联系人搜索并运行自动采集。'); return
        path=filedialog.asksaveasfilename(title='导出公开个人职业线索 CSV',defaultextension='.csv',filetypes=[('CSV','*.csv')],initialfile='外贸达人_公开个人职业线索.csv')
        if not path:return
        fields=['搜索结果标题','公开职业资料链接','公开WhatsApp','公开邮箱','来源搜索词','身份核验状态']
        try:
            with open(path,'w',encoding='utf-8-sig',newline='') as f:
                w=csv.writer(f); w.writerow(fields)
                for r in self.people_rows:
                    wa=r.get('whatsapp','')
                    email=r.get('email','')
                    if not isinstance(email,str) or not clean_email_candidate(email): email=''
                    w.writerow([r.get('name_title',''),r.get('profile_url',''),wa,email,r.get('search_query',''),r.get('identity_status','待人工核验')])
            messagebox.showinfo('导出成功','公开个人职业资料候选及来源已保存：\n'+path)
        except Exception as e: messagebox.showerror('导出失败',str(e))

    @staticmethod
    def _simple_export_row(r):
        """Export complete, company-bound business contact and provenance fields."""
        company = r.get('company_name') or r.get('name_title') or r.get('page_title') or ''
        wa_links=[]
        for link in r.get('whatsapp_links',[]) or []:
            link=str(link).strip()
            if re.search(r'(?:wa\.me/|whatsapp\.com/)',link,re.I):
                normalized=normalize_whatsapp_url(link)
                if normalized and normalized not in wa_links: wa_links.append(normalized)
        wa_numbers=[]
        for number in r.get('whatsapp_contacts',[]) or []:
            value=clean_phone_candidate(str(number),'WhatsApp label')
            if value and value not in wa_numbers: wa_numbers.append(value)
        phones=[]
        wa_digits={re.sub(r'\D','',x) for x in wa_numbers}
        for link in wa_links:
            match=re.search(r'(?:wa\.me/|[?&]phone=)([+\d]+)',link,re.I)
            if match: wa_digits.add(re.sub(r'\D','',match.group(1)))
        for number in r.get('phone_candidates',[]) or []:
            value=clean_phone_candidate(str(number),'')
            digits=re.sub(r'\D','',str(number))
            if value and digits not in wa_digits and value not in phones: phones.append(value)
        emails=[]
        for item in r.get('emails',[]) or []:
            value=clean_email_candidate(str(item))
            if value and value not in emails: emails.append(value)
        sources=list(dict.fromkeys(str(x) for x in (r.get('source_urls') or []) if str(x).startswith(('http://','https://'))))
        linkedin=list(dict.fromkeys(str(x) for x in (r.get('linkedin_links') or []) if str(x).startswith(('http://','https://'))))
        evidence=r.get('contact_evidence') or {}
        wa_number_sources=list(dict.fromkeys(str((evidence.get('whatsapp_contacts') or {}).get(x,'')) for x in wa_numbers if (evidence.get('whatsapp_contacts') or {}).get(x,'')))
        wa_link_sources=list(dict.fromkeys(str((evidence.get('whatsapp_links') or {}).get(x,'')) for x in wa_links if (evidence.get('whatsapp_links') or {}).get(x,'')))
        return [safe_spreadsheet_cell(x) for x in [
            company, r.get('company_website',''), r.get('company_address',''), r.get('address_source_url',''),
            '; '.join(wa_numbers), '; '.join(wa_number_sources), '; '.join(wa_links), '; '.join(wa_link_sources),
            '; '.join(emails), '; '.join(phones), '; '.join(linkedin), '; '.join(sources),
            r.get('status',''), r.get('quality_category') or r.get('quality_status',''), r.get('notes',''), r.get('collected_at','')]]

    @staticmethod
    def _load_quality_quarantine():
        try:
            with open(QUALITY_QUARANTINE_FILE,encoding='utf-8') as f:
                value=json.load(f)
            return value if isinstance(value,list) else []
        except Exception:
            return []

    def _save_quality_quarantine(self):
        temp=QUALITY_QUARANTINE_FILE+'.tmp'
        with open(temp,'w',encoding='utf-8') as f:
            json.dump(self.quality_quarantine,f,ensure_ascii=False,indent=2)
        os.replace(temp,QUALITY_QUARANTINE_FILE)

    def _append_quality_quarantine(self, items):
        # Use the complete record fingerprint, not only company name/domain;
        # otherwise multiple distinct duplicate rows from one company would be lost.
        known={json.dumps(x,ensure_ascii=False,sort_keys=True,default=str) for x in self.quality_quarantine}
        for item in items:
            fingerprint=json.dumps(item,ensure_ascii=False,sort_keys=True,default=str)
            if fingerprint not in known:
                self.quality_quarantine.append(item); known.add(fingerprint)
        self._save_quality_quarantine()

    def apply_quality_filter(self):
        if not self.rows:
            messagebox.showinfo('暂无结果','请先采集或核验。'); return
        self._quality_original_rows=list(self.rows)
        accepted, quarantine, stats=clean_and_dedupe(self.rows)
        self.rows=accepted
        self._append_quality_quarantine(quarantine)
        self.quality_review=[r for r in accepted if r.get('quality_status')=='review']
        for item in self.tree.get_children(): self.tree.delete(item)
        for i,r in enumerate(reversed(self.rows),1): self.add_result(r,i,len(self.rows))
        self.status.set(f"筛选完成：保留 {stats['accepted']} 条（其中待复核 {stats['review']}），排除/重复隔离 {stats['quarantined']} 条")
        messagebox.showinfo('自动筛选与去重完成',
            f"原始记录：{stats['input']} 条\n可保留候选：{stats['accepted']} 条\n待人工复核：{stats['review']} 条\n排除/重复隔离：{stats['quarantined']} 条\n合并重复企业：{stats['duplicate_rows_merged']} 条\n邮箱格式异常：{stats['invalid_emails']} 个\n邮箱域名不匹配提醒：{stats['email_domain_conflicts']} 条\n\n原始数据未删除，可在‘查看隔离/恢复’中恢复。")

    def show_quality_quarantine(self):
        win=tk.Toplevel(self); win.title('隔离记录 / 重复记录（可恢复）'); win.geometry('900x520'); win.transient(self)
        ttk.Label(win,text=f'隔离记录：{len(self.quality_quarantine)} 条。这里只做隔离，不永久删除。').pack(anchor='w',padx=12,pady=8)
        cols=('name','status','reason'); tree=ttk.Treeview(win,columns=cols,show='headings')
        for c,t,w in [('name','企业/记录名称',360),('status','处理状态',130),('reason','隔离原因',360)]: tree.heading(c,text=t); tree.column(c,width=w)
        tree.pack(fill='both',expand=True,padx=12,pady=6)
        for i,item in enumerate(self.quality_quarantine):
            r=item.get('record',{}); name=r.get('company_name') or r.get('工厂/公司名称') or r.get('name_title') or ''
            tree.insert('','end',iid=str(i),values=(name,item.get('quality_status',''),item.get('quality_reason','')))
        def restore_selected():
            chosen=tree.selection()
            if not chosen: messagebox.showinfo('请选择记录','先选择需要恢复的记录。',parent=win); return
            indexes=sorted((int(x) for x in chosen),reverse=True)
            for idx in indexes:
                item=self.quality_quarantine.pop(idx); self.rows.append(item.get('record',{}))
            self._save_quality_quarantine()
            for item in tree.get_children(): tree.delete(item)
            for i,item in enumerate(self.quality_quarantine):
                r=item.get('record',{}); tree.insert('','end',iid=str(i),values=(r.get('company_name') or r.get('工厂/公司名称') or r.get('name_title') or '',item.get('quality_status',''),item.get('quality_reason','')))
            for item in self.tree.get_children(): self.tree.delete(item)
            for i,r in enumerate(reversed(self.rows),1): self.add_result(r,i,len(self.rows))
            self.status.set(f'已恢复 {len(indexes)} 条记录；恢复的数据仍可再次筛选')
        ttk.Button(win,text='恢复选中记录',command=restore_selected).pack(anchor='e',padx=12,pady=8)

    def export_rows(self):
        fields=['公司名称','官方网站','公司地址','地址来源网址','WhatsApp号码（明确标注）','WhatsApp号码证据网址','WhatsApp联系链接','WhatsApp链接证据网址','公开邮箱','公开电话（非WhatsApp）','LinkedIn企业主页','采集来源网址','访问/核验状态','制造商分类','核验说明','采集时间']
        # Only records with positive manufacturer signals enter the simple export.
        # Review/excluded/duplicate records remain in the app for later restoration.
        if not self.rows:
            return fields, []
        accepted, quarantine, stats=clean_and_dedupe(self.rows)
        if self.__dict__.get('quality_quarantine') is not None and quarantine:
            self._append_quality_quarantine(quarantine)
        exportable=[r for r in accepted if r.get('quality_status') in ('keep','review')]
        self.quality_review=[r for r in accepted if r.get('quality_status')=='review']
        return fields, [self._simple_export_row(r) for r in exportable]

    def export_csv(self):
        if not self.rows: messagebox.showinfo('暂无结果','请先采集或核验。'); return
        path=filedialog.asksaveasfilename(title='导出完整公司与商务联系资料 CSV',defaultextension='.csv',filetypes=[('CSV','*.csv')],initialfile='外贸达人_完整公司与联系人.csv')
        if not path:return
        fields,rows=self.export_rows()
        if not rows:
            messagebox.showinfo('暂无合格制造商','当前没有可导出的企业记录。请先采集或查看隔离记录。'); return
        try:
            with open(path,'w',encoding='utf-8-sig',newline='') as f:
                w=csv.writer(f); w.writerow(fields); w.writerows(rows)
            messagebox.showinfo('导出成功','完整公司与商务联系资料已保存，包含官网、地址、WhatsApp、邮箱、电话及来源：\n'+path)
        except Exception as e: messagebox.showerror('导出失败',str(e))

    def export_xlsx(self):
        if not self.rows: messagebox.showinfo('暂无结果','请先采集或核验。'); return
        try: import openpyxl
        except ImportError: messagebox.showerror('缺少依赖','请运行启动文件自动安装依赖。'); return
        path=filedialog.asksaveasfilename(title='导出完整公司与商务联系资料 Excel',defaultextension='.xlsx',filetypes=[('Excel','*.xlsx')],initialfile='外贸达人_完整公司与联系人.xlsx')
        if not path:return
        fields,rows=self.export_rows()
        if not rows:
            messagebox.showinfo('暂无合格制造商','当前没有可导出的企业记录。请先采集或查看隔离记录。'); return
        wb=openpyxl.Workbook(); ws=wb.active; ws.title='公司与商务联系资料'; ws.append(fields)
        for r in rows: ws.append(r)
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
        from openpyxl.utils import get_column_letter
        header_fill=PatternFill('solid',fgColor='1F4E78')
        header_font=Font(name='Microsoft YaHei',bold=True,color='FFFFFF',size=10)
        body_font=Font(name='Microsoft YaHei',size=10,color='1F2937')
        thin=Side(style='hair',color='D9E2F3')
        for cell in ws[1]:
            cell.fill=header_fill; cell.font=header_font
            cell.alignment=Alignment(horizontal='center',vertical='center',wrap_text=True)
            cell.border=Border(bottom=Side(style='medium',color='5B9BD5'))
        ws.row_dimensions[1].height=32
        for row_idx in range(2,ws.max_row+1):
            ws.row_dimensions[row_idx].height=48
            for cell in ws[row_idx]:
                cell.font=body_font; cell.alignment=Alignment(vertical='top',wrap_text=True)
                cell.border=Border(bottom=thin)
                if isinstance(cell.value,str) and cell.value.startswith(('https://','http://')):
                    cell.hyperlink=cell.value; cell.style='Hyperlink'
        ws.freeze_panes='A2'; ws.auto_filter.ref=ws.dimensions
        ws.sheet_view.showGridLines=False
        widths={'A':30,'B':38,'C':38,'D':38,'E':24,'F':42,'G':38,'H':42,'I':32,'J':23,'K':36,'L':48,'M':22,'N':18,'O':48,'P':22}
        for col,width in widths.items(): ws.column_dimensions[col].width=width
        ws.sheet_properties.pageSetUpPr.fitToPage=True
        ws.page_setup.fitToWidth=1; ws.page_setup.fitToHeight=0; ws.page_setup.orientation='landscape'
        ws.print_title_rows='1:1'
        wb.save(path); messagebox.showinfo('导出成功','Excel 已按公司资料列宽、自动换行、筛选、冻结表头和超链接格式导出：\n'+path)

    def clear(self):
        if messagebox.askyesno('确认','清空当前结果？'):
            self.rows=[]; self.people_rows=[]
            for item in self.tree.get_children(): self.tree.delete(item)
            self.status.set('已清空')

def run_application():
    try:
        App().mainloop()
    except Exception:
        import traceback
        log_path=os.path.join(APP_DIR, 'factorylead_error.log')
        detail=traceback.format_exc()
        try:
            from pathlib import Path
            Path(log_path).write_text(detail,encoding='utf-8')
        except Exception: pass
        try:
            import tkinter.messagebox as _mb
            _mb.showerror('外贸达人启动失败',f'程序启动失败，详细错误已写入：\n{log_path}\n\n{detail[-1800:]}')
        except Exception: pass
        raise

if __name__=='__main__': run_application()
