# FactoryLead 2.0.3 无 API 自主搜索修复内部测试报告

日期：2026-11-06

## 本轮修复目标
在不配置 SerpApi / Brave API Key 的情况下，主采集流程可以直接启动；同时保留两个 API 的本地配置、真实连接测试、调用统计和额度管理。

## 代码变更
- 主窗口新增搜索模式选择，默认“自主搜索（免API）”。
- 默认模式不读取 API Key、不调用 SerpApi/Brave，直接请求 Bing 与 DuckDuckGo HTML 公共搜索结果页。
- 解析两种公开搜索页的自然结果链接与标题，去重后交给现有官网核验和制造商评分流程。
- 新增“API优先（失败自动自主搜索）”模式；API未配置、调用异常或返回空结果时自动回退公开搜索。
- SerpApi 中文 Baidu / 英文 Google 逻辑保留；Brave API逻辑保留。
- API设置窗口明确说明 API Key 是可选增强项；密钥 DPAPI 本地加密保存逻辑保留。
- 网络诊断增加 Bing / DuckDuckGo 入口检测，同时保留 SerpApi / Brave 端点检测。
- 公开搜索入口返回 401/403/429 时记录受限状态，不尝试绕过验证码、访问控制或配额。
- 修复启动异常日志路径使用字符串拼接的问题。

## 自动化测试
- `python -m py_compile app.py api_services.py tests/test_factorylead.py tests/test_api_services.py`：通过。
- `python -m unittest discover -s tests -v`：**73/73 通过**。
- 新增测试：无 API 默认路径不会读取 API Key；API优先模式失败后回退公开搜索；中文 API 优先仍选 Baidu；Bing/DDG HTML解析；403访问限制处理；网络诊断检查四个入口。
- 行业目录：31/176/607 核心目录及2条补充目录保持原样。

## 在线验证边界
- 当前开发容器对 Bing / DuckDuckGo 的 DNS 解析失败，无法执行真实在线请求。因此只完成代码路径与模拟 HTML 响应测试，不能声称真实公开搜索已在此环境成功。
- SerpApi / Brave 真实账户认证未执行，也不是自主模式启动的前置条件。
- Windows 10 用户实机仍需验证公开搜索是否可达；如网络入口返回 403/429 或验证码，软件会显示受限，不会绕过限制。

## 验收结论
**无 API 启动逻辑已在代码和自动化测试中修复；真实在线搜索及 Windows 10 实机尚未验收。** 当前包为 2.0.3 Windows 内部测试候选，不是正式稳定版。
