@echo off
setlocal EnableExtensions
set "APP_DIR=%~dp0"
for %%I in ("%APP_DIR%.") do set "APP_DIR=%%~fI\"
set "REQ_FILE=%APP_DIR%requirements.txt"
set "APP_FILE=%APP_DIR%app.py"
set "VENV_DIR=%APP_DIR%.venv"
set "VENV_PY=%VENV_DIR%\Scripts\python.exe"

 title WaiMaoDaRen - Startup
 echo [INFO] Application folder: "%APP_DIR%"
 echo [INFO] Checking required files...
 if not exist "%REQ_FILE%" (
   echo [ERROR] Cannot find requirements.txt in the application folder.
   echo [INFO] Expected: "%REQ_FILE%"
   echo Please extract the COMPLETE ZIP folder before starting.
   pause
   exit /b 2
 )
 if not exist "%APP_FILE%" (
   echo [ERROR] Cannot find app.py in the application folder.
   echo [INFO] Expected: "%APP_FILE%"
   pause
   exit /b 2
 )

 echo [INFO] Checking Python...
 set "PYTHON_CMD="
 where py >nul 2>nul
 if not errorlevel 1 set "PYTHON_CMD=py -3"
 if not defined PYTHON_CMD (
   where python >nul 2>nul
   if not errorlevel 1 set "PYTHON_CMD=python"
 )
 if not defined PYTHON_CMD (
   echo [ERROR] Python 3.10 or newer was not found.
   echo Install Python 3.11 or 3.12 and enable "Add Python to PATH".
   pause
   exit /b 1
 )
 %PYTHON_CMD% -c "import sys; print('Python:',sys.version); raise SystemExit(0 if sys.version_info >= (3,10) else 1)"
 if errorlevel 1 (
   echo [ERROR] WaiMaoDaRen requires Python 3.10 or newer.
   pause
   exit /b 1
 )

 if not exist "%VENV_PY%" (
   echo [INFO] Creating virtual environment at "%VENV_DIR%"...
   %PYTHON_CMD% -m venv "%VENV_DIR%"
   if errorlevel 1 (
     echo [ERROR] Could not create virtual environment.
     pause
     exit /b 1
   )
 )
 echo [INFO] Installing/checking dependencies from:
 echo "%REQ_FILE%"
 "%VENV_PY%" -m pip install --disable-pip-version-check -r "%REQ_FILE%"
 if errorlevel 1 (
   echo [ERROR] Dependency installation failed. Check network access and requirements.txt.
   pause
   exit /b 1
 )
 echo [INFO] Starting WaiMaoDaRen...
 "%VENV_PY%" "%APP_FILE%"
 set "RC=%ERRORLEVEL%"
 if not "%RC%"=="0" echo [ERROR] Application exited with code %RC%.
 pause
 exit /b %RC%
