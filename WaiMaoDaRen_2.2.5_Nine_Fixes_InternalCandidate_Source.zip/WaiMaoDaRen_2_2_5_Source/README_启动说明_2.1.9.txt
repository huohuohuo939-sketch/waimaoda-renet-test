外贸达人 2.1.9 启动说明

1. 先将 ZIP 完整解压到一个普通文件夹，例如桌面\外贸达人2.1.9。
2. 打开解压后的 WaiMaoDaRen_2_1_9_Source 文件夹。
3. 确认能看到 requirements.txt、app.py、run_factorylead.bat。
4. 双击 run_factorylead.bat 启动。

请勿在 ZIP 压缩包预览窗口内直接运行，也不要单独移动 run_factorylead.bat。
首次启动会创建 .venv 并安装依赖，需要网络连接；以后启动会复用该虚拟环境。
如果依赖安装失败，新启动器会显示它实际查找 requirements.txt 的完整路径，方便定位。
