# 外贸达人 2.1.6 — 中文桌面界面升级

## 界面按用户参考截图重构
- 使用浅蓝白色主工作区、深蓝左侧导航和白色顶部品牌栏。
- 主页面按截图流程排列：采集任务设置、采集选项、任务操作按钮、结果/日志/统计标签页、底部状态栏。
- 全部主要操作、导航、表格字段和提示统一为简体中文；搜索引擎/WhatsApp/LinkedIn 等专有名称保留原文。
- 行业、细分行业、目标国家、数量和关键词集中在任务设置区。
- 结果表采用截图式简洁列展示，同时保留内部评分、身份核验等原始数据字段，避免影响既有保存和导出逻辑。
- 结果搜索框支持即时筛选；结果数量随列表更新。
- 中国、美国、德国、英国、全球等界面国家名称在搜索请求中映射为规范英文国家名，避免把中文显示标签直接传入搜索查询。
- 左侧导航切换数据管理、导出结果、系统设置和帮助页面；原采集、数据库、API 配置、WhatsApp 提取、去重和导出逻辑继续沿用。

## 开发端验证
- `python -m py_compile app.py api_services.py data_quality.py search_scheduler.py tests/test_factorylead.py tests/test_api_services.py tests/test_data_quality.py`：通过。
- `python -m unittest discover -s tests -v`：93/93 通过。
- Tkinter GUI 冒烟测试：通过；窗口创建、页面刷新、结果表列配置和窗口正常销毁均通过。

## 验证边界
- 当前为开发容器/Linux 虚拟显示环境验证，不能代替 Windows 10 真机显示与交互验收。
- 尚未执行真实互联网批量采集，也未验证用户自己的 SerpApi / Brave API Key。
- 不宣称已完成 Windows 安装程序或正式稳定版验收。
