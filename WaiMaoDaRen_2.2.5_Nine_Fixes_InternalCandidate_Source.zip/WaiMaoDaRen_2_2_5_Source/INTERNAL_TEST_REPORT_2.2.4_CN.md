# 外贸达人 2.2.4 内部测试报告

日期：2026-11-10

## 自动化回归
- `python -m py_compile app.py api_services.py search_scheduler.py data_quality.py tests/test_factorylead.py tests/test_api_services.py`：通过
- `python -m unittest discover -s tests`：114/114 通过

## 新增验证覆盖
- 已采集官网在付费 API 调用前过滤。
- 最近 30 天未核验候选在新任务中暂缓重复搜索。
- 跨任务月度付费预算原子预留。
- 旧版 provider_usage 当月调用数迁移到月度保护账本。
- 联系人按 WhatsApp 链接、WhatsApp 标记号码、普通电话、邮箱分别持久化。
- 后续重复采集时历史邮箱/电话/WhatsApp 和证据合并保留。
- 历史 Excel 导入、官网域名合并和缺少证据网址时不伪造来源。

## 上传 Excel 离线导入实测
文件：外贸达人_完整公司与联系人2.xlsx
- 数据行：62
- 新增公司：61
- 跳过：1（缺少公司名称或有效官网）
- 联系人库去重记录：WhatsApp 标记号码 64、WhatsApp 链接 28、邮箱 210、普通电话 145
- 联系人证据行：81（仅对提供有效证据 URL 的项目保存）

## 未完成项目
- 未在用户 Windows 10 电脑上实测。
- 未做新一轮真实网络搜索和 SerpApi/Brave 实际扣费验证。
- LinkedIn/WhatsApp 实际命中率需要在后续小额度网络试采中测量。
