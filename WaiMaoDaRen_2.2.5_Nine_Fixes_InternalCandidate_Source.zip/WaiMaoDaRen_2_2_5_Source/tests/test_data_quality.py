import sys, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from data_quality import clean_and_dedupe, assess

class DataQualityTests(unittest.TestCase):
    def test_job_and_media_titles_are_quarantined(self):
        for title in ['Export Sales Manager: 1 Post (Male/Female)','Los Angeles Times','外贸业务经理职位招聘']:
            self.assertEqual(assess({'company_name':title})[0],'excluded')
    def test_manufacturer_titles_are_kept(self):
        self.assertEqual(assess({'company_name':'SHANDONG MINING MACHINERY GROUP CO.,LTD'})[0],'keep')
    def test_duplicate_domain_merges_contacts(self):
        rows=[
          {'company_name':'Example Machinery Ltd','company_website':'https://www.example.com','industry':'Mining machinery manufacturing','emails':['sales@example.com'],'whatsapp_links':['https://wa.me/8613800000000']},
          {'company_name':'Example Machinery','company_website':'https://example.com/contact','industry':'Mining equipment factory','emails':['info@example.com'],'whatsapp_links':['https://api.whatsapp.com/send?phone=8613900000000']},
        ]
        accepted,quarantine,stats=clean_and_dedupe(rows)
        self.assertEqual(len(accepted),1)
        self.assertEqual(set(accepted[0]['emails']),{'sales@example.com','info@example.com'})
        self.assertEqual(len(accepted[0]['whatsapp_links']),2)
        self.assertEqual(stats['duplicate_rows_merged'],1)
        self.assertEqual(quarantine[0]['quality_status'],'duplicate_merged')
    def test_duplicate_merge_preserves_company_address_and_separate_contacts(self):
        rows=[
          {'company_name':'Example Machinery Ltd','company_website':'https://www.example.com','industry':'Mining machinery manufacturing','company_address':'88 Industrial Road, Ningbo','address_source_url':'https://www.example.com/contact','whatsapp_contacts':['+8613800000000'],'phone_candidates':['+8657488888888']},
          {'company_name':'Example Machinery','company_website':'https://example.com/contact','industry':'Mining equipment factory','emails':['info@example.com'],'company_address':'','whatsapp_links':['https://wa.me/8613900000000']},
        ]
        accepted,_,_=clean_and_dedupe(rows)
        self.assertEqual(accepted[0]['company_address'],'88 Industrial Road, Ningbo')
        self.assertEqual(accepted[0]['address_source_url'],'https://www.example.com/contact')
        self.assertEqual(accepted[0]['whatsapp_contacts'],['+8613800000000'])
        self.assertEqual(accepted[0]['phone_candidates'],['+8657488888888'])
        self.assertEqual(len(accepted[0]['whatsapp_links']),1)

    def test_ordinary_phone_is_not_promoted_to_whatsapp(self):
        rows=[{'company_name':'Mining Equipment Factory','industry':'Mining machinery','phone_candidates':['+8613800000000'],'emails':['Sales@Example.com']}]
        accepted,_,_=clean_and_dedupe(rows)
        self.assertEqual(accepted[0]['whatsapp_links'],[])
        self.assertEqual(accepted[0]['emails'],['sales@example.com'])

    def test_uploaded_real_export_sample_quarantines_noise_without_claiming_missing_site_dedup(self):
        import csv
        fixture=Path(__file__).parent/'fixtures'/'real_export_sample.csv'
        with fixture.open(encoding='utf-8-sig',newline='') as f:
            rows=[{'company_name':r['工厂/公司名称'], 'whatsapp_links':(r['联系方式'] or '').split(';'), 'emails':(r['邮箱'] or '').split(';')} for r in csv.DictReader(f)]
        accepted,quarantine,stats=clean_and_dedupe(rows)
        self.assertEqual(stats['input'],30)
        self.assertEqual(stats['excluded'],13)
        self.assertEqual(stats['review'],8)
        self.assertEqual(stats['accepted'],17)
        self.assertEqual(stats['manufacturer_candidates'],9)
        self.assertTrue(any('Los Angeles Times' in q['record']['company_name'] for q in quarantine))
        self.assertTrue(any('SHANDONG MINING MACHINERY' in r['company_name'] for r in accepted))


    def test_full_export_includes_manufacturer_and_review_rows_but_not_excluded(self):
        import app
        ui=object.__new__(app.App)
        ui.rows=[
          {'company_name':'SHANDONG MINING MACHINERY GROUP CO.,LTD','emails':['sales@example.com'],'whatsapp_links':['https://wa.me/8613800000000']},
          {'company_name':'Los Angeles Times','emails':['news@latimes.com']},
          {'company_name':'Unknown Company','emails':['info@example.com']},
        ]
        fields,exported=ui.export_rows()
        self.assertEqual(fields[0:4],['公司名称','官方网站','公司地址','地址来源网址'])
        self.assertIn('WhatsApp号码（明确标注）',fields)
        self.assertIn('公开电话（非WhatsApp）',fields)
        self.assertEqual(len(exported),2)
        self.assertIn('SHANDONG MINING MACHINERY',exported[0][0])
        self.assertIn('Unknown Company',exported[1][0])

    def test_unknown_record_goes_to_review_not_delete(self):
        accepted,quarantine,stats=clean_and_dedupe([{'company_name':'Example Trading Ltd'}])
        self.assertEqual(len(accepted),1)
        self.assertEqual(accepted[0]['quality_status'],'review')
        self.assertEqual(len(quarantine),0)


    def test_whatsapp_url_host_must_be_exact_and_not_lookalike(self):
        from data_quality import _wa
        self.assertEqual(_wa(['https://wa.me/8613800000000']), ['https://wa.me/8613800000000'])
        self.assertEqual(_wa(['https://evilwa.me/8613800000000', 'https://whatsapp.com.evil.test/send?phone=8613800000000']), [])

    def test_quarantine_persistence_keeps_distinct_duplicate_rows_same_company(self):
        import json, tempfile
        from unittest.mock import patch
        import app
        ui=object.__new__(app.App)
        ui.quality_quarantine=[]
        items=[
            {'record':{'company_name':'Same Factory','emails':['a@example.com']},'quality_status':'duplicate_merged','quality_reason':'merged'},
            {'record':{'company_name':'Same Factory','emails':['b@example.com']},'quality_status':'duplicate_merged','quality_reason':'merged'},
        ]
        with tempfile.TemporaryDirectory() as d:
            with patch.object(app,'QUALITY_QUARANTINE_FILE',str(Path(d)/'q.json')):
                app.App._append_quality_quarantine(ui,items)
                with open(Path(d)/'q.json',encoding='utf-8') as f: saved=json.load(f)
        self.assertEqual(len(saved),2)

    def test_blank_company_names_do_not_merge_unrelated_rows(self):
        accepted, quarantine, stats=clean_and_dedupe([
            {'emails':['one@example.com']}, {'emails':['two@example.com']}
        ])
        self.assertEqual(len(accepted),2)
        self.assertEqual(stats['duplicate_rows_merged'],0)

    def test_multiple_email_domains_are_flagged_but_not_deleted(self):
        accepted, _, stats=clean_and_dedupe([{
            'company_name':'Example Machinery Manufacturer',
            'emails':['sales@example.com','person@gmail.com','other@unrelated.test']
        }])
        self.assertEqual(len(accepted[0]['emails']),3)
        self.assertIn('多个邮箱域名',accepted[0]['quality_warning'])
        self.assertEqual(stats['mixed_email_domains'],1)

    def test_date_values_in_contact_field_are_not_kept_as_phones(self):
        accepted, _, _=clean_and_dedupe([{
            'company_name':'Example Machinery Manufacturer',
            '联系方式':'2025-12-01 20; +86 138 0000 0000'
        }])
        self.assertEqual(accepted[0]['phone_candidates'],['+86 138 0000 0000'])
        self.assertEqual(accepted[0]['whatsapp_links'],[])

    def test_phone_column_is_not_treated_as_whatsapp_without_explicit_label(self):
        accepted, _, _=clean_and_dedupe([{
            'company_name':'Example Machinery Manufacturer',
            'phone_candidates':['+8613800000000']
        }])
        self.assertEqual(accepted[0]['whatsapp_links'],[])

if __name__=='__main__': unittest.main()
