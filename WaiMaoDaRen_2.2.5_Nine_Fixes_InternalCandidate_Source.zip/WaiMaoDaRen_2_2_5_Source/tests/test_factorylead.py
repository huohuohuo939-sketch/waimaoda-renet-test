"""Offline regression tests for FactoryLead internal candidate; no live scraping."""
import os, sys, tempfile, unittest, base64, csv, sqlite3, types, threading, time, json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import app

class Var:
    def __init__(self, value): self.value=value
    def get(self): return self.value

class QueryPlanTests(unittest.TestCase):
    def setUp(self):
        self.ui=object.__new__(app.App)
        self.ui.catalog=app.load_catalog()
        self.ui.country=Var('China')
        self.ui.search_all=Var(True)
        self.ui.kw=Var('wiper blade manufacturer; windshield wiper factory')
        self.ui.sub_var=Var(self.ui.catalog[0]['细分行业'])
        self.ui.cat_var=Var(self.ui.catalog[0]['大类'])

    def test_each_subindustry_is_a_complete_eight_intent_round(self):
        qs=self.ui.make_queries(); contexts=self.ui._query_context
        expected=[r for r in self.ui.catalog if r.get('大类')==self.ui.cat_var.get()]
        self.assertEqual(len(qs),len(expected)*8)
        self.assertEqual({v['industry_code'] for v in contexts.values()}, {r['细分行业代码'] for r in expected})
        for row in expected:
            intents={v['search_intent'] for v in contexts.values() if v['industry_code']==row['细分行业代码']}
            self.assertEqual(intents,{'manufacturer','production','oem_odm','export','whatsapp_link','whatsapp_cta','whatsapp_contact','contact'})

    def test_cleaned_english_vocabulary_csv_has_exactly_607_core_rows(self):
        import csv
        path=Path(app.APP_DIR)/'source_vocabulary'/'FactoryLead_English_Search_Terms_v1_20261106.csv'
        with path.open(encoding='utf-8-sig',newline='') as f:
            rows=list(csv.DictReader(f))
        self.assertEqual(len(rows),607)
        self.assertEqual({int(r['序号']) for r in rows},set(range(1,608)))
        self.assertTrue(all(r['新英文核心词'].strip() for r in rows))

    def test_catalog_core_remains_exact_31_176_607(self):
        rows=app.load_catalog(); core=[r for r in rows if r.get('目录类型')=='核心31/176/607']
        supplements=[r for r in rows if r.get('目录类型','').startswith('补充-')]
        self.assertEqual(len(core),607)
        self.assertEqual(len({r.get('大类代码') for r in core}),31)
        self.assertEqual(len({r.get('中类代码') for r in core}),176)
        self.assertEqual(len({r.get('细分行业代码') for r in core}),607)
        self.assertEqual(len(supplements),2)

    def test_duplicate_chinese_industry_names_resolve_by_code(self):
        self.ui.sub_var=Var('建筑陶瓷制品制造（3032）')
        row=self.ui.selected_catalog_row(); self.assertEqual(row.get('细分行业代码'),'3032')
        self.ui.sub_var=Var('建筑陶瓷制品制造（3071）')
        row=self.ui.selected_catalog_row(); self.assertEqual(row.get('细分行业代码'),'3071')

    def test_all_categories_plan_covers_607_core_plus_two_supplements(self):
        from search_scheduler import build_rounds, flatten_rounds
        rounds=build_rounds(self.ui.catalog,'China',all_categories=True)
        flat=flatten_rounds(rounds)
        codes={x['industry_code'] for x in flat}
        self.assertEqual(len(rounds),609)
        self.assertEqual(len(flat),609*8)
        self.assertEqual(len(codes),609)

    def test_single_industry_plan_has_eight_queries_and_three_whatsapp_intents_first(self):
        self.ui.search_all=Var(False)
        qs=self.ui.make_queries()
        self.assertEqual(len(qs),8)
        self.assertEqual({self.ui._query_context[q]['search_intent'] for q in qs[:8]},
                         {'manufacturer','production','oem_odm','export','whatsapp_link','whatsapp_cta','whatsapp_contact','contact'})

    def test_custom_terms_are_added_to_all_six_queries(self):
        self.ui.kw=Var('rice cooker; air fryer')
        qs=self.ui.make_queries()
        self.assertTrue(all('rice cooker' in q and 'air fryer' in q for q in qs))

    def test_start_builds_config_with_selected_industry_without_name_error(self):
        from unittest.mock import patch
        class Widget:
            def config(self,**kwargs): self.state=kwargs
            def set(self,value): self.value=value
        class FakeThread:
            captured=None
            def __init__(self,**kwargs): FakeThread.captured=kwargs
            def start(self): pass
        ui=object.__new__(app.App)
        ui.target=Var('10'); ui.min_score=Var('25'); ui.parallel=Var('3')
        ui.search_all=Var(False); ui.sub_var=Var('Rice processing'); ui.cat_var=Var('Food processing')
        ui.kw=Var('rice'); ui.country=Var('China'); ui.women_mode=Var(False)
        ui.run_btn=Widget(); ui.pause_btn=Widget(); ui.resume_btn=Widget(); ui.stop_btn=Widget(); ui.status=Widget(); ui._query_context={'q':{'industry':'Rice processing'}}
        ui._pause_event=threading.Event(); ui._pause_event.set(); ui._stop_event=threading.Event(); ui._task_active=False
        ui.selected_catalog_row=lambda:{'细分行业':'Rice processing','细分行业代码':'1311','英文核心词':'rice mill'}
        ui.catalog=[{'细分行业':'Rice processing','细分行业代码':'1311','大类':'Food processing','英文核心词':'rice mill'}]
        ui.make_queries=lambda:['rice manufacturer China']
        with patch.object(app.threading,'Thread',FakeThread):
            app.App.start(ui)
        args=FakeThread.captured['args']
        self.assertEqual(args[1]['industry'],'Rice processing')
        self.assertEqual(args[1]['queries'],['rice manufacturer China'])


    def test_english_synonyms_rotate_in_separate_keyword_cycles(self):
        from search_scheduler import build_rounds
        rows=[{'大类':'食品','细分行业':'宠物食品','细分行业代码':'A1','新英文核心词':'pet food / pet food production / animal feed'}]
        first=build_rounds(rows,'China',all_categories=True,keyword_cycle=0)
        second=build_rounds(rows,'China',all_categories=True,keyword_cycle=1)
        third=build_rounds(rows,'China',all_categories=True,keyword_cycle=2)
        self.assertEqual(first[0]['active_english_term'],'pet food')
        self.assertEqual(second[0]['active_english_term'],'pet food production')
        self.assertEqual(third[0]['active_english_term'],'animal feed')
        self.assertEqual([first[0]['keyword_cycle'],second[0]['keyword_cycle'],third[0]['keyword_cycle']],[0,1,2])
        self.assertTrue(all(len(x[0]['queries'])==8 for x in (first,second,third)))
        self.assertIn('pet food production',second[0]['queries'][0]['query'])

    def test_completed_task_advances_persistent_keyword_cycle(self):
        from unittest.mock import patch
        from search_scheduler import build_rounds, plan_signature
        baseline=build_rounds(self.ui.catalog,'China',selected_category=self.ui.cat_var.get(),extra_terms=self.ui.kw.get())
        rotation=plan_signature(baseline,'China')
        progress={'rotation_signature':rotation,'completed':True,'keyword_cycle':0,'next_keyword_cycle':1}
        with patch.object(app,'load_progress',return_value=progress):
            queries=self.ui.make_queries()
        self.assertEqual(self.ui._keyword_cycle,1)
        self.assertTrue(queries)
        self.assertTrue(all(v['keyword_cycle']==1 for v in self.ui._query_context.values()))

    def test_low_yield_queries_are_deprioritized_but_never_removed(self):
        from search_scheduler import build_rounds, prioritize_rounds
        rounds=build_rounds(self.ui.catalog[:1],'China',all_categories=True)
        queries=rounds[0]['queries']
        history={queries[0]['query']:{'calls':4,'new_domains':0},
                 queries[1]['query']:{'calls':4,'new_domains':12}}
        ordered=prioritize_rounds(rounds,history)[0]['queries']
        self.assertEqual(len(ordered),8)
        self.assertEqual([x['intent'] for x in ordered[:3]],['whatsapp_link','whatsapp_cta','whatsapp_contact'])
        non_wa=[x for x in ordered if not x['intent'].startswith('whatsapp')]
        self.assertEqual(non_wa[0]['query'],queries[1]['query'])
        self.assertEqual({x['query'] for x in ordered},{x['query'] for x in queries})

    def test_search_progress_checkpoint_resumes_and_writes_atomically(self):
        from search_scheduler import load_progress, save_progress
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'state'/'progress.json'
            state={'signature':'abc','base_signature':'base','task_id':'persisted-task-123','plan_queries':['q1','q2'],'next_query_index':7,'completed':False,'round_metrics':{'1311':{'new_domains':3}},'candidate_snapshot':[['example.com','https://example.com','Example','q1']]}
            save_progress(state,path)
            self.assertEqual(load_progress(path),state)
            self.assertFalse(list(path.parent.glob('*.tmp')))

class ProviderMainFlowTests(unittest.TestCase):
    def test_linkedin_discovery_is_free_first_and_uses_api_only_for_gap(self):
        from unittest.mock import patch
        with patch.object(app, 'search_public_web', return_value=[] ) as public, \
             patch.object(app, 'load_api_keys', return_value={'serpapi':'configured','brave':''}), \
             patch.object(app, 'search_providers', return_value=[('https://www.linkedin.com/company/acme-factory/','Acme Factory')]) as provider:
            got=app.search_linkedin_companies('Acme Factory')
        self.assertEqual(got,[('Acme Factory','https://www.linkedin.com/company/acme-factory')])
        public.assert_called_once()
        provider.assert_called_once()

    def test_linkedin_company_name_matching_supports_chinese_names(self):
        ui=object.__new__(app.App)
        url='https://www.linkedin.com/company/zhongshan-xingye/'
        self.assertEqual(ui._match_linkedin_company('中山兴业电器有限公司', [('中山兴业电器 | LinkedIn',url)]),url)

    def test_linkedin_free_only_mode_reports_company_page_hits_without_paid_api(self):
        from unittest.mock import patch
        diag={}
        with patch.object(app,'search_public_web',return_value=[
            ('https://www.linkedin.com/company/acme-tools/','Acme Tools | LinkedIn'),
            ('https://www.linkedin.com/in/person/','Person | LinkedIn'),
            ('https://example.com/company/acme','Other')]), \
             patch.object(app,'load_api_keys',side_effect=AssertionError('free-only LinkedIn search must not read keys')), \
             patch.object(app,'search_providers',side_effect=AssertionError('free-only LinkedIn search must not call paid API')):
            got=app.search_linkedin_companies('Acme Tools',max_results=5,diagnostics=diag,search_mode='仅免费搜索（不调用API）')
        self.assertEqual(got,[('Acme Tools | LinkedIn','https://www.linkedin.com/company/acme-tools')])
        self.assertEqual(diag['linkedin_company_search']['results'],1)
        self.assertIn('命中',diag['linkedin_company_search']['last_status'])

    def test_linkedin_search_is_company_specific_and_rejects_person_or_non_linkedin_pages(self):
        from unittest.mock import patch
        def fake_search(query, **kwargs):
            self.assertIn('site:linkedin.com/company',query)
            self.assertIn('Acme Industrial Pumps',query)
            self.assertIn('acmepumps.example',query)
            return [('https://www.linkedin.com/company/acme-industrial-pumps/','Acme Industrial Pumps | LinkedIn'),
                    ('https://www.linkedin.com/in/some-person/','Person'),
                    ('https://example.com/company/acme','Other')]
        with patch.object(app,'search_public_web',side_effect=fake_search):
            got=app.search_linkedin_for_company_candidates([
                ('https://acmepumps.example/','Acme Industrial Pumps')],diagnostics={},session=object(),limit=5)
        self.assertEqual(got,[('Acme Industrial Pumps | LinkedIn','https://www.linkedin.com/company/acme-industrial-pumps')])

    def test_default_search_web_uses_public_search_without_loading_api_keys(self):
        from unittest.mock import patch
        with patch.object(app, 'load_api_keys', side_effect=AssertionError('API keys must not be needed')), \
             patch.object(app, 'search_public_web', return_value=[('https://newfactory.example/','New Factory')]) as public_search:
            got=app.search_web('industrial factory China',max_results=5,diagnostics={})
        self.assertEqual(got,[('https://newfactory.example/','New Factory')])
        public_search.assert_called_once()

    def test_free_search_runs_before_paid_api_top_up(self):
        from unittest.mock import patch
        with patch.object(app, 'load_api_keys', return_value={'serpapi':'configured','brave':''}), \
             patch.object(app, 'search_public_web', return_value=[('https://public.example/','Public Factory')]) as public_search, \
             patch.object(app, 'search_providers', return_value=[('https://paid.example/','Paid Factory')]) as provider:
            got=app.search_web('industrial factory China',max_results=5,diagnostics={})
        self.assertEqual(got,[('https://public.example/','Public Factory'),('https://paid.example/','Paid Factory')])
        public_search.assert_called_once()
        provider.assert_called_once()
        self.assertEqual(provider.call_args.args[1],4)

    def test_free_only_mode_never_loads_or_calls_paid_api(self):
        from unittest.mock import patch
        with patch.object(app, 'load_api_keys', side_effect=AssertionError('free-only mode must not read API keys')), \
             patch.object(app, 'search_providers', side_effect=AssertionError('free-only mode must not call paid API')), \
             patch.object(app, 'search_public_web', return_value=[('https://free.example/','Free Factory')]):
            diag={}
            got=app.search_web('factory China',max_results=5,diagnostics=diag,search_mode='仅免费搜索（不调用API）')
        self.assertEqual(got,[('https://free.example/','Free Factory')])
        self.assertIn('仅免费搜索模式',diag['provider_orchestration']['status'])

    def test_paid_first_mode_calls_paid_provider_before_free_search(self):
        from unittest.mock import patch
        calls=[]
        def paid(*args,**kwargs):
            calls.append('paid'); return [('https://paid.example/','Paid Factory')]
        def free(*args,**kwargs):
            calls.append('free'); return [('https://free.example/','Free Factory')]
        with patch.object(app,'load_api_keys',return_value={'serpapi':'configured','brave':''}), \
             patch.object(app,'search_providers',side_effect=paid), \
             patch.object(app,'search_public_web',side_effect=free):
            got=app.search_web('factory China',max_results=2,diagnostics={},search_mode='付费优先（免费补充）')
        self.assertEqual(calls,['paid','free'])
        self.assertEqual({x[0] for x in got},{'https://paid.example/','https://free.example/'})

    def test_default_paid_budget_is_20_per_task(self):
        from unittest.mock import patch
        diag={}
        with patch.object(app,'search_public_web',return_value=[]), \
             patch.object(app,'load_api_keys',return_value={'serpapi':'configured','brave':''}), \
             patch.object(app,'search_providers',return_value=[]) as provider:
            app.search_web('factory China',max_results=5,diagnostics=diag)
        self.assertEqual(provider.call_args.kwargs['paid_call_limit'],20)

    def test_historical_domains_are_filtered_before_paid_api_top_up(self):
        from unittest.mock import patch
        public=[('https://www.oldfactory.example/','Old Factory'),('https://newfactory.example/','New Factory')]
        with patch.object(app, 'load_api_keys', side_effect=AssertionError('known duplicates must not trigger paid API')), \
             patch.object(app, 'search_public_web', return_value=public), \
             patch.object(app, 'search_providers', side_effect=AssertionError('paid API must be skipped')):
            got=app.search_web('factory China',max_results=1,diagnostics={},exclude_domains={'oldfactory.example'})
        self.assertEqual(got,[('https://newfactory.example/','New Factory')])

    def test_recent_unqualified_registry_entries_are_suppressed_temporarily(self):
        old=app.DB_FILE
        with tempfile.TemporaryDirectory() as td:
            app.DB_FILE=os.path.join(td,'recent.db'); app.init_db()
            app.record_registry_candidate('recentfactory.example','Recent Factory','https://recentfactory.example/','factory China','discovered')
            domains,names=app.load_recently_seen_registry(days=30)
            self.assertIn('recentfactory.example',domains)
            self.assertIn(app.normalize_company_key('Recent Factory'),names)
        app.DB_FILE=old

    def test_import_legacy_xlsx_adds_companies_and_contact_records_to_database(self):
        from openpyxl import Workbook
        old=app.DB_FILE
        with tempfile.TemporaryDirectory() as td:
            app.DB_FILE=os.path.join(td,'import.db'); app.init_db()
            path=os.path.join(td,'legacy.xlsx')
            wb=Workbook(); ws=wb.active
            ws.append(['公司名称','官方网站','WhatsApp号码（明确标注）','WhatsApp号码证据网址','WhatsApp联系链接','WhatsApp链接证据网址','公开邮箱','公开电话（非WhatsApp）','采集来源网址'])
            ws.append(['Import Factory Ltd','https://import-factory.com/','+8613812345678','https://import-factory.com/contact','https://wa.me/8613812345678','https://import-factory.com/contact','sales@import-factory.com','+86 010 12345678','https://import-factory.com/contact'])
            ws.append(['Missing Website Factory','','+8613812345679','','','','','',''])
            wb.save(path); wb.close()
            result=app.import_legacy_xlsx_to_database(path)
            self.assertEqual(result,{'imported':1,'updated':0,'skipped':1})
            con=sqlite3.connect(app.DB_FILE)
            company_count=con.execute('SELECT COUNT(*) FROM leads').fetchone()[0]
            contact_types={r[0] for r in con.execute('SELECT DISTINCT contact_type FROM contact_registry')}
            evidence_count=con.execute('SELECT COUNT(*) FROM lead_contact_evidence').fetchone()[0]
            con.close()
            self.assertEqual(company_count,1)
            self.assertTrue({'whatsapp_labelled_number','whatsapp_link','email','phone'}.issubset(contact_types))
            self.assertGreater(evidence_count,0)
        app.DB_FILE=old

    def test_contact_registry_persists_distinct_contact_types(self):
        old=app.DB_FILE
        with tempfile.TemporaryDirectory() as td:
            app.DB_FILE=os.path.join(td,'contacts.db'); app.init_db()
            row={'company_name':'Contact Registry Factory','company_website':'https://contact-registry.example/','industry_category':'test','industry':'test','country':'China','manufacturer_score':70,'operation_score':10,'manufacturer_evidence':'factory','whatsapp_links':['https://wa.me/8613812345678'],'whatsapp_contacts':['+8613812345678'],'emails':['sales@contact-registry.example'],'phone_candidates':['+86 010 12345678'],'linkedin_links':[],'source_urls':['https://contact-registry.example/contact'],'status':'HTTP 200','notes':'','collected_at':'2026-11-10','email_details':[],'contact_evidence':{'whatsapp_links':{'https://wa.me/8613812345678':'https://contact-registry.example/contact'},'whatsapp_contacts':{'+8613812345678':'https://contact-registry.example/contact'},'emails':{'sales@contact-registry.example':'https://contact-registry.example/contact'},'phones':{'+86 010 12345678':'https://contact-registry.example/contact'}},'decision_maker_evidence':'','gender_status':'未知/未核实'}
            app.save_lead(row)
            con=sqlite3.connect(app.DB_FILE)
            types={x[0] for x in con.execute('SELECT DISTINCT contact_type FROM contact_registry')}
            count=con.execute('SELECT COUNT(*) FROM contact_registry').fetchone()[0]
            con.close()
            self.assertTrue({'whatsapp_link','whatsapp_labelled_number','email','phone'}.issubset(types))
            self.assertEqual(count,4)
        app.DB_FILE=old

    def test_free_search_satisfying_target_skips_paid_api(self):
        from unittest.mock import patch
        with patch.object(app, 'load_api_keys', side_effect=AssertionError('paid keys must not be loaded')), \
             patch.object(app, 'search_public_web', return_value=[(f'https://factory{i}.example/','Factory '+str(i)) for i in range(5)]), \
             patch.object(app, 'search_providers', side_effect=AssertionError('paid search must be skipped')):
            got=app.search_web('industrial factory China',max_results=5,diagnostics={})
        self.assertEqual(len(got),5)

    def test_chinese_free_search_gap_uses_baidu_engine_for_paid_top_up(self):
        from unittest.mock import patch
        with patch.object(app, 'load_api_keys', return_value={'serpapi':'configured','brave':''}), \
             patch.object(app, 'search_public_web', return_value=[]), \
             patch.object(app, 'search_providers', return_value=[('https://factory.example/','工厂')]) as provider:
            got=app.search_web('家用电器制造商 中国',max_results=5,diagnostics={})
        self.assertEqual(got,[('https://factory.example/','工厂')])
        self.assertEqual(provider.call_args.kwargs['serpapi_engine'],'baidu')

    def test_public_search_parses_bing_and_duckduckgo_html(self):
        from unittest.mock import Mock
        class Session:
            def __init__(self): self.calls=[]
            def get(self,url,**kwargs):
                self.calls.append(url)
                response=Mock(status_code=200)
                if 'bing.com' in url:
                    response.text='<li class="b_algo"><h2><a href="https://factory-one.example/about">Factory One</a></h2></li>'
                else:
                    response.text='<a class="result__a" href="https://factory-two.example">Factory Two</a>'
                response.raise_for_status.return_value=None
                return response
        session=Session()
        rows=app.search_public_web('factory China',2,{},session=session)
        self.assertEqual(rows,[('https://factory-one.example/about','Factory One'),('https://factory-two.example','Factory Two')])
        self.assertGreaterEqual(len(session.calls),2)
        self.assertEqual(set(app.search_public_web.__name__ for _ in [0]), {'search_public_web'})

    def test_public_search_collects_candidates_from_each_free_engine_before_scan(self):
        from unittest.mock import Mock, patch
        class MultiSession:
            def get(self,url,**kwargs):
                host=app.urlparse(url).hostname or ''
                mapping={
                    'www.bing.com':'<li class="b_algo"><h2><a href="https://bing-lead.example/">Bing Lead</a></h2></li>',
                    'html.duckduckgo.com':'<a class="result__a" href="https://ddg-lead.example/">DDG Lead</a>',
                    'www.baidu.com':'<div class="result"><h3><a href="https://baidu-lead.example/">Baidu Lead</a></h3></div>',
                    'www.ecosia.org':'<a class="result-title" href="https://ecosia-lead.example/">Ecosia Lead</a>',
                    'yandex.com':'<a class="OrganicTitle-Link" href="https://yandex-lead.example/">Yandex Lead</a>',
                }
                response=Mock(status_code=200,text=mapping[host]); response.raise_for_status.return_value=None; return response
        diagnostics={}
        with patch.object(app,'rank_search_engines',return_value=['Bing','DuckDuckGo','Baidu','Ecosia','Yandex']), patch.object(app,'record_engine_search'):
            for index in range(5):
                app.search_public_web(f'female export manager China {index}',1,diagnostics,session=MultiSession())
        self.assertEqual(set(diagnostics['domain_engine_map'].keys()),{'bing-lead.example','ddg-lead.example','baidu-lead.example','ecosia-lead.example','yandex-lead.example'})

    def test_public_search_keeps_per_engine_title_and_url_samples(self):
        from unittest.mock import Mock, patch
        class SampleSession:
            def get(self,url,**kwargs):
                host=app.urlparse(url).hostname or ''
                html_by_host={
                    'www.bing.com':'<li class="b_algo"><h2><a href="https://sample-bing.example/">Bing sample</a></h2></li>',
                    'html.duckduckgo.com':'<a class="result__a" href="https://sample-ddg.example/">DDG sample</a>',
                    'www.baidu.com':'<div class="result"><h3><a href="https://sample-baidu.example/">Baidu sample</a></h3></div>',
                    'www.ecosia.org':'<a class="result-title" href="https://sample-ecosia.example/">Ecosia sample</a>',
                    'yandex.com':'<a class="OrganicTitle-Link" href="https://sample-yandex.example/">Yandex sample</a>',
                }
                response=Mock(status_code=200,text=html_by_host[host]); response.raise_for_status.return_value=None; return response
        diagnostics={}
        with patch.object(app,'rank_search_engines',return_value=['Bing','DuckDuckGo','Baidu','Ecosia','Yandex']), patch.object(app,'record_engine_search'):
            for index in range(5):
                app.search_public_web(f'China female export manager {index}',1,diagnostics,session=SampleSession())
        for engine in ('Bing','DuckDuckGo','Baidu','Ecosia','Yandex'):
            self.assertTrue(diagnostics['public_search'][engine]['sample_results'])
            self.assertTrue(diagnostics['public_search'][engine]['sample_results'][0]['url'].startswith('https://'))


    def test_free_search_rotates_preferred_engine_across_queries_and_stops_when_quota_met(self):
        from unittest.mock import Mock, patch
        class RotatingSession:
            def __init__(self): self.calls=[]
            def get(self,url,**kwargs):
                self.calls.append(url)
                response=Mock(status_code=200)
                if 'bing.com' in url:
                    response.text='<li class="b_algo"><h2><a href="https://one-result.example/">One Result</a></h2></li>'
                else:
                    response.text='<a class="result__a" href="https://one-result.example/">One Result</a>'
                response.raise_for_status.return_value=None
                return response
        session=RotatingSession(); diagnostics={}
        with patch.object(app,'rank_search_engines',return_value=['Bing','DuckDuckGo','Baidu','Ecosia','Yandex']), patch.object(app,'record_engine_search'):
            first=app.search_public_web('manufacturer query one',1,diagnostics,session=session)
            first_calls=len(session.calls)
            second=app.search_public_web('manufacturer query two',1,diagnostics,session=session)
        self.assertEqual(len(first),1)
        self.assertEqual(len(second),1)
        self.assertEqual(first_calls,1)
        self.assertEqual(len(session.calls),2)
        self.assertIn('bing.com',session.calls[0])
        self.assertIn('html.duckduckgo.com',session.calls[1])

    def test_public_search_rotates_through_free_engines_when_no_results(self):
        from unittest.mock import Mock, patch
        class EmptySession:
            def __init__(self): self.calls=[]
            def get(self,url,**kwargs):
                self.calls.append(url)
                response=Mock(status_code=200,text='<html><body>no parsed results</body></html>')
                response.raise_for_status.return_value=None
                return response
        session=EmptySession(); diagnostics={}
        with patch.object(app,'rank_search_engines',return_value=['Bing','DuckDuckGo','Baidu','Ecosia','Yandex']), \
             patch.object(app,'record_engine_search') as record:
            self.assertEqual(app.search_public_web('female export manager China',10,diagnostics,session=session),[])
        self.assertEqual(len(session.calls),5)
        self.assertEqual(record.call_count,5)
        self.assertEqual(diagnostics['public_search']['returned_results'],0)

    def test_public_search_restrictions_are_reported_without_captcha_bypass(self):
        from unittest.mock import Mock
        class Session:
            def get(self,url,**kwargs):
                response=Mock(status_code=403,text='blocked')
                response.raise_for_status.return_value=None
                return response
        diag={}
        self.assertEqual(app.search_public_web('factory China',5,diag,session=Session()),[])
        self.assertIn('访问受限',diag['public_search']['Bing']['status'])


class DataTests(unittest.TestCase):
    def test_http_session_uses_browser_headers_and_retry_adapter(self):
        session = app.create_http_session()
        self.assertIn('Mozilla/5.0', session.headers.get('User-Agent', ''))
        self.assertIn('text/html', session.headers.get('Accept', ''))
        self.assertIsNotNone(session.get_adapter('https://'))

    def test_catalog_has_industry_and_keyword_fields(self):
        rows=app.load_catalog()
        self.assertGreaterEqual(len(rows),180)
        self.assertTrue(all(r.get('中文搜索关键词') for r in rows))
        self.assertGreaterEqual(len(set(r.get('大类','') for r in rows)),10)

    def test_trade_contact_candidate_requires_public_contact_but_not_factory_status(self):
        trade={'emails':['sales@example.com'],'whatsapp_links':[],'whatsapp_contacts':[],'operation_score':12,'manufacturer_score':0}
        self.assertTrue(app.is_trade_contact_candidate(trade,25))
        no_contact={'emails':[],'whatsapp_links':[],'whatsapp_contacts':[],'operation_score':99,'manufacturer_score':99}
        self.assertFalse(app.is_trade_contact_candidate(no_contact,25))
        factory={'emails':[],'whatsapp_links':['https://wa.me/8613800000000'],'whatsapp_contacts':[],'operation_score':0,'manufacturer_score':30}
        self.assertTrue(app.is_trade_contact_candidate(factory,25))

    def test_operation_signals_cover_non_manufacturer_export_business(self):
        from bs4 import BeautifulSoup
        pages=[('https://trade.example/about',BeautifulSoup('<p>International trade, export sales, foreign trade company, overseas business and sourcing.</p><p>外贸公司 出口业务 国际销售</p>','html.parser'))]
        score,status,evidence=app.operation_signals(pages)
        self.assertGreaterEqual(score,8)
        self.assertIn('foreign trade',evidence)

    def test_public_contact_extraction(self):
        from bs4 import BeautifulSoup
        html='''<html><head><title>Example Factory</title></head><body>
        <p>Contact sales@example-factory.com</p>
        <a href="mailto:export@example-factory.com">Export sales</a>
        <a href="https://wa.me/8613800000000">WhatsApp</a>
        <a href="https://www.linkedin.com/company/example-factory/">LinkedIn</a>
        <a href="tel:+86-138-0000-0000">Phone</a>
        </body></html>'''
        wa, emails, phones, linkedin=app.extract_contacts(BeautifulSoup(html,'html.parser'),'https://example-factory.com/contact')
        self.assertTrue(any('wa.me/8613800000000' in x for x in wa))
        self.assertIn('sales@example-factory.com',emails)
        self.assertIn('export@example-factory.com',emails)
        self.assertTrue(any('linkedin.com/company/example-factory' in x for x in linkedin))
        self.assertTrue(phones)

    def test_whatsapp_extraction_from_inline_script_and_data_attributes(self):
        from bs4 import BeautifulSoup
        url='https://factory.example/contact'
        html='''<html><body>
        <button data-whatsapp-url="https://api.whatsapp.com/send?phone=8613800000000">Chat now</button>
        <div onclick="window.open('https://wa.me/8613900000000')">Contact</div>
        <script>const waLink = "https:\\/\\/wa.me\\/8613700000000";</script>
        <p>Telephone: +86 10 8888 9999</p>
        </body></html>'''
        found=app.extract_contact_evidence(BeautifulSoup(html,'html.parser'),url)
        links=' '.join(found['whatsapp_links'])
        self.assertIn('8613800000000',links)
        self.assertIn('8613900000000',links)
        self.assertIn('8613700000000',links)
        self.assertFalse(any('861088889999' in x for x in found['whatsapp_contacts']))
        self.assertTrue(all(source == url for source in found['whatsapp_evidence'].values()))

    def test_cross_industry_public_whatsapp_and_email_extraction(self):
        from bs4 import BeautifulSoup
        cases = [
            ('https://yugongcompany.com/contact-us/', '<p>WhatsApp/Tel: +86 1971292 7484</p><p>TEL/WhatsApp: +86 15937192512</p><a href="https://api.whatsapp.com/send?phone=8615937192512">WhatsApp: +86 15937192512</a><p>factory@yugongmachine.com</p>'),
            ('https://www.cnwhmachine.com/contact-us', '<p>Whatsapp: +8613652558716</p><a href="https://api.whatsapp.com/send?phone=8613652558716">WhatsApp</a><p>info@cnwhmachine.com</p>'),
            ('https://www.chinashoefactory.com/contact-us/', '<p>Whatsapp: +86 13950003760</p><a href="https://wa.me/8613950003760">Chat on WhatsApp</a><p>andy@chinashoefactory.com</p>'),
            ('https://www.chengfei-appliance.com/contact-us', '<p>Email david@chengfei-appliance.com</p><p>WhatsApp +86 18688802903</p>'),
            ('https://witymachinery.com/contact.html', '<p>Whatsapp: +86-13958862336</p><p>E-mail: wity@witymachine.com</p>'),
            ('https://en.xintelectric.com/contact.html', '<p>WeChat/WhatsApp:86-17596985166</p><p>Email: wilson.wong@xintelectric.com</p>'),
            ('https://www.xresin.cn/en/contact.html', '<p>Email info@xresin.cn</p><p>WhatsApp +86 189 1262 5533</p>'),
        ]
        for url, body in cases:
            with self.subTest(url=url):
                found = app.extract_contact_evidence(BeautifulSoup('<html><body>'+body+'</body></html>', 'html.parser'), url)
                self.assertTrue(found['emails'])
                if 'xintelectric.com' in url:
                    self.assertFalse(found['whatsapp_contacts'] or found['whatsapp_links'])  # no explicit +86 prefix: reject as requested
                else:
                    self.assertTrue(found['whatsapp_contacts'] or found['whatsapp_links'])
                self.assertTrue(all(src == url for src in found['email_evidence'].values()))
                self.assertTrue(all(src == url for src in found['whatsapp_evidence'].values()))
        # Link and text versions of the same international number must not become duplicate contacts.
        footwear = app.extract_contact_evidence(BeautifulSoup('<html><body><p>WhatsApp +86 13950003760</p><a href="https://wa.me/8613950003760">WhatsApp</a></body></html>', 'html.parser'), cases[2][0])
        self.assertEqual(len(footwear['whatsapp_contacts']), 1)
        self.assertEqual(len(footwear['phones']), 1)

    def test_whatsapp_search_plan_prioritizes_three_separate_whatsapp_queries(self):
        from search_scheduler import build_rounds, prioritize_rounds
        rounds=build_rounds([{'大类':'食品','细分行业':'宠物食品','细分行业代码':'A1','英文核心词':'pet food'}])
        ordered=prioritize_rounds(rounds,{})[0]['queries']
        self.assertEqual([x['intent'] for x in ordered[:3]],['whatsapp_link','whatsapp_cta','whatsapp_contact'])
        self.assertEqual(len(ordered),8)

    def test_whatsapp_filter_accepts_cn_mobile_and_rejects_service_landline_fax(self):
        from bs4 import BeautifulSoup
        url='https://factory.example/contact'
        html='''<html><body>
        <p>WhatsApp: +86 138 0000 0000</p>
        <p>WhatsApp: +86 400 123 4567</p>
        <p>WhatsApp: +86 010 8888 9999</p>
        <p>Fax: +86 020 8888 7777</p>
        <a href="https://wa.me/8613900000000">WhatsApp mobile</a>
        <a href="https://wa.me/864001234567">WhatsApp service</a>
        <a href="https://api.whatsapp.com/send?phone=8610123456789">WhatsApp landline-like</a>
        <p>WhatsApp: +1 202 555 0147</p>
        </body></html>'''
        found=app.extract_contact_evidence(BeautifulSoup(html,'html.parser'),url)
        self.assertIn('+86 138 0000 0000', found['whatsapp_contacts'])
        self.assertIn('+1 202 555 0147', found['whatsapp_contacts'])
        self.assertNotIn('+86 400 123 4567', found['whatsapp_contacts'])
        self.assertNotIn('+86 010 8888 9999', found['whatsapp_contacts'])
        self.assertNotIn('+86 020 8888 7777', found['whatsapp_contacts'])
        self.assertFalse(app.whatsapp_url_has_eligible_number('https://wa.me/11611447'))
        self.assertEqual(len(found['whatsapp_links']),1)
        self.assertIn('8613900000000', found['whatsapp_links'][0])

    def test_contact_extraction_rejects_identifier_garbage(self):
        from bs4 import BeautifulSoup
        html = """<html><head><title>Company contact</title></head><body>
        <p>ISBN: 978-1-4028-9462-6</p>
        <p>ORCID: 0000-0002-1825-0097</p>
        <p>IP address: 192.168.1.1</p>
        <p>Publication date: 2025-01-01</p>
        <p>Contact phone: +86 138 0000 0000</p>
        <p>Sales: sales@example-factory.com</p>
        <p>Placeholder: test@example.com</p>
        </body></html>"""
        wa, emails, phones, linkedin = app.extract_contacts(BeautifulSoup(html, 'html.parser'), 'https://factory.example/contact')
        self.assertIn('sales@example-factory.com', emails)
        self.assertNotIn('test@example.com', emails)
        self.assertTrue(any('138 0000 0000' in x for x in phones))
        self.assertFalse(any('978' in x or '192.168' in x or '2025' in x or '0000-0002' in x for x in phones))

    def test_whatsapp_url_number_is_also_populated_in_number_field(self):
        from bs4 import BeautifulSoup
        html='''<html><body><a href="https://api.whatsapp.com/send?phone=8613767906454">WhatsApp</a></body></html>'''
        details=app.extract_contact_evidence(BeautifulSoup(html,'html.parser'),'https://factory.example/contact')
        self.assertIn('https://api.whatsapp.com/send?phone=8613767906454',details['whatsapp_links'])
        self.assertIn('+8613767906454',details['whatsapp_contacts'])
        self.assertEqual(details['whatsapp_evidence']['+8613767906454'],'https://factory.example/contact')

    def test_whatsapp_api_link_preserves_phone_parameter(self):
        from bs4 import BeautifulSoup
        html = '<html><body><a href="https://api.whatsapp.com/send?phone=8613800000000&amp;text=Hello">WhatsApp</a></body></html>'
        wa, emails, phones, linkedin = app.extract_contacts(BeautifulSoup(html, 'html.parser'), 'https://factory.example/contact')
        self.assertTrue(any('phone=8613800000000' in x for x in wa))
        self.assertFalse(any('text=Hello' in x for x in wa))

    def test_unrelated_generic_manufacturer_page_is_downranked(self):
        from bs4 import BeautifulSoup
        page = BeautifulSoup('<html><head><title>General Business Services</title></head><body>Factory manufacturer production export OEM supplier contact us. We help businesses.</body></html>', 'html.parser')
        score, evidence = app.score_site([('https://example.org/', page)], 'wiper blades', 'wiper blade manufacturer; windshield wiper factory')
        self.assertLessEqual(score, 22)
        self.assertIn('未找到明确产品相关词', evidence)

    def test_chinese_factory_terms_raise_manufacturer_score(self):
        from bs4 import BeautifulSoup
        page=BeautifulSoup('<html><head><title>五金制品生产厂家</title></head><body>我们是源头工厂，拥有自有工厂、生产线和加工车间，提供五金配件生产制造。</body></html>','html.parser')
        score,evidence=app.score_site([('https://factory.example.cn',page)], '五金制品', '五金配件;生产厂家')
        self.assertGreaterEqual(score,25)
        self.assertIn('生产厂家', evidence)

    def test_generic_privacy_page_does_not_score_as_manufacturer(self):
        from bs4 import BeautifulSoup
        page = BeautifulSoup('<html><head><title>Microsoft Privacy Statement</title></head><body>Manufacturer factory production export OEM contact privacy policy</body></html>', 'html.parser')
        score, evidence = app.score_site([('https://example.com/privacy-statement', page)], 'small home appliances', 'appliance factory; manufacturer')
        self.assertLessEqual(score, 12)
        self.assertIn('无关页面信号', evidence)

    def test_export_filters_legacy_garbage_contacts(self):
        row = {
            'company_name': 'Test Factory',
            'whatsapp_links': ['not-a-whatsapp-link', 'https://api.whatsapp.com/send?phone=8613800000000&text=hello'],
            'phone_candidates': ['192.168.1.1', '2025-01-01', '978-1-4028-9462-6', '+86 138 0000 0000'],
            'emails': ['sales@test-factory.com', 'test@example.com']
        }
        result = app.App._simple_export_row(row)
        self.assertEqual(result[0], 'Test Factory')
        self.assertIn('phone=8613800000000', result[6])
        self.assertNotIn('+86 138 0000 0000', result[9])
        self.assertNotIn('192.168.1.1', result[1])
        self.assertNotIn('2025-01-01', result[1])
        self.assertNotIn('978-1-4028-9462-6', result[1])
        self.assertEqual(result[8], 'sales@test-factory.com')

    def test_csv_and_xlsx_exports(self):
        with tempfile.TemporaryDirectory() as td:
            row={'company_name':'Example Factory','industry_category':'Industrial','industry':'Wiper blades','keywords':'wiper blade manufacturer','country':'China','manufacturer_score':88,'operation_score':12,'manufacturer_evidence':'factory×2','operation_evidence':'public contact','company_website':'https://example-factory.com','page_title':'Example Factory','whatsapp_links':['https://wa.me/8613800000000'],'emails':['sales@example-factory.com'],'email_details':[{'email':'sales@example-factory.com','role_label':'销售','email_score':95,'domain_match':True,'public_source_url':'https://example-factory.com/contact'}],'email_priority':'sales@example-factory.com','phone_candidates':['+86 13800000000'],'linkedin_links':['https://linkedin.com/company/example-factory'],'decision_maker_evidence':'not verified','gender_status':'未知/未核实','source_urls':['https://example-factory.com/contact'],'status':'HTTP 200','notes':'fixture','collected_at':'2026-10-29'}
            fake=object.__new__(app.App); fake.rows=[row]; fake.people_rows=[]
            csv_path=os.path.join(td,'leads.csv'); xlsx_path=os.path.join(td,'leads.xlsx')
            old_csv=app.filedialog.asksaveasfilename; old_info=app.messagebox.showinfo
            try:
                app.filedialog.asksaveasfilename=lambda **kwargs: csv_path
                app.messagebox.showinfo=lambda *args,**kwargs: None
                fake.export_csv()
                with open(csv_path,encoding='utf-8-sig',newline='') as f: parsed=list(csv.DictReader(f))
                self.assertEqual(len(parsed),1)
                self.assertEqual(list(parsed[0].keys())[0:4],['公司名称','官方网站','公司地址','地址来源网址'])
                self.assertEqual(parsed[0]['公司名称'],'Example Factory')
                self.assertEqual(parsed[0]['官方网站'],'https://example-factory.com')
                self.assertIn('sales@example-factory.com',parsed[0]['公开邮箱'])
                self.assertIn('https://wa.me/8613800000000',parsed[0]['WhatsApp联系链接'])
                self.assertNotIn('+86 13800000000',parsed[0]['公开电话（非WhatsApp）'])
                app.filedialog.asksaveasfilename=lambda **kwargs: xlsx_path
                fake.export_xlsx()
                import openpyxl
                wb=openpyxl.load_workbook(xlsx_path,read_only=False)
                self.assertEqual(wb.sheetnames,['公司与商务联系资料'])
                ws=wb['公司与商务联系资料']
                self.assertEqual(ws.max_row,2)
                self.assertEqual([c.value for c in ws[1]][:4],['公司名称','官方网站','公司地址','地址来源网址'])
                self.assertIn('WhatsApp号码证据网址',[c.value for c in ws[1]])
                self.assertTrue(ws['A1'].fill.fgColor.rgb.endswith('1F4E78'))
                self.assertTrue(ws['A2'].alignment.wrap_text)
                self.assertEqual(ws.freeze_panes,'A2')
                self.assertEqual(ws.auto_filter.ref,ws.dimensions)
                wb.close()
            finally:
                app.filedialog.asksaveasfilename=old_csv; app.messagebox.showinfo=old_info

    def test_scan_site_end_to_end_with_offline_fixture(self):
        from unittest.mock import patch
        class Response:
            def __init__(self, url, text, status=200, content_type='text/html'):
                self.url=url; self.text=text; self.status_code=status; self.headers={'Content-Type':content_type}
        class FakeSession:
            def get(self, url, **kwargs):
                if url.endswith('/sitemap.xml'):
                    return Response(url, '<urlset><loc>https://wiper.example.com/contact</loc></urlset>', 200, 'application/xml')
                if url.endswith('/robots.txt'):
                    return Response(url, 'User-agent: *', 200, 'text/plain')
                if url.rstrip('/').endswith('/contact'):
                    return Response(url, """<html><head><title>Contact Wiper Blade Factory</title></head><body>
                    Wiper blades manufacturer. Contact export@wiper.example.com and WhatsApp.
                    <a href=\"mailto:sales@wiper.example.com\">Sales</a>
                    <a href=\"https://wa.me/8613800000000\">WhatsApp</a>
                    <a href=\"tel:+86-138-0000-0000\">Phone</a></body></html>""")
                return Response(url, """<html><head><title>Wiper Blade Factory</title><meta property=\"og:site_name\" content=\"Wiper Blade Factory\"></head>
                <body>We are a wiper blades manufacturer and production factory. OEM ODM export products contact us.
                <a href=\"/contact\">Contact</a></body></html>""")
        with patch.object(app.requests, 'Session', return_value=FakeSession()):
            row=app.scan_site('https://wiper.example.com', 'wiper blades', 'wiper blade manufacturer; windshield wiper factory', 'China')
        self.assertEqual(row['company_name'], 'Wiper Blade Factory')
        self.assertIn('sales@wiper.example.com', row['emails'])
        self.assertIn('export@wiper.example.com', row['emails'])
        self.assertTrue(any('wa.me/8613800000000' in x for x in row['whatsapp_links']))
        self.assertTrue(row['source_urls'])
        self.assertEqual(row['contact_evidence']['emails']['sales@wiper.example.com'], 'https://wiper.example.com/contact')
        self.assertEqual(row['contact_evidence']['whatsapp_links']['https://wa.me/8613800000000'], 'https://wiper.example.com/contact')
        self.assertGreater(row['manufacturer_score'], 0)
        self.assertTrue(row['contact_evidence']['phones'])

    def test_obfuscated_public_emails_are_extracted(self):
        from bs4 import BeautifulSoup
        html = '<html><body><p>Sales: sales [at] factory-example.com [dot] cn</p><p>Export: export (at) factory-example.com (dot) com</p></body></html>'
        wa, emails, phones, linkedin = app.extract_contacts(BeautifulSoup(html, 'html.parser'), 'https://factory-example.com/contact')
        self.assertIn('sales@factory-example.com.cn', emails)
        self.assertIn('export@factory-example.com.com', emails)



    def test_digits_only_tel_link_keeps_phone_context(self):
        from bs4 import BeautifulSoup
        soup = BeautifulSoup('<html><body><a href="tel:8613800000000">Call sales</a></body></html>', 'html.parser')
        details = app.extract_contact_evidence(soup, 'https://factory.example/contact')
        self.assertIn('8613800000000', details['phones'])

    def test_explicit_whatsapp_label_captures_number_without_inventing_link(self):
        from bs4 import BeautifulSoup
        soup = BeautifulSoup('<html><body><p>WhatsApp: +86 138 0000 0000</p><p>Phone: +86 139 1111 2222</p></body></html>', 'html.parser')
        details = app.extract_contact_evidence(soup, 'https://factory.example/contact')
        self.assertIn('+86 138 0000 0000', details['whatsapp_contacts'])
        self.assertNotIn('+86 139 1111 2222', details['whatsapp_contacts'])
        self.assertEqual(details['whatsapp_links'], [])

    def test_cloudflare_email_protection_is_decoded(self):
        from bs4 import BeautifulSoup
        address = 'sales@factory-example.cn'
        key = 0x42
        encoded = bytes([key]) + bytes([ord(c) ^ key for c in address])
        payload = encoded.hex()
        soup = BeautifulSoup(f'<html><body><span class="__cf_email__" data-cfemail="{payload}">[email protected]</span></body></html>', 'html.parser')
        details = app.extract_contact_evidence(soup, 'https://factory-example.cn/contact')
        self.assertIn(address, details['emails'])

    def test_whatsapp_normalizer_rejects_lookalike_domain(self):
        self.assertEqual(app.normalize_whatsapp_url('https://fakewa.me/8613800000000'), '')
        self.assertEqual(app.normalize_whatsapp_url('https://wa.me/8613800000000?text=hello'), 'https://wa.me/8613800000000')

    def test_multilevel_obfuscated_email(self):
        from bs4 import BeautifulSoup
        soup = BeautifulSoup('<html><body><p>Export: sales [at] factory-example [dot] co [dot] uk</p></body></html>', 'html.parser')
        details = app.extract_contact_evidence(soup, 'https://factory-example.co.uk/contact')
        self.assertIn('sales@factory-example.co.uk', details['emails'])


    def test_explicit_whatsapp_contact_survives_database_roundtrip(self):
        old = app.DB_FILE
        with tempfile.TemporaryDirectory() as td:
            app.DB_FILE = os.path.join(td, 'contacts.db')
            app.init_db()
            row = {'company_name':'Roundtrip Factory','company_website':'https://roundtrip.example/','industry_category':'test','industry':'test','country':'China','manufacturer_score':60,'operation_score':10,'manufacturer_evidence':'fixture','whatsapp_links':[],'whatsapp_contacts':['+86 138 0000 0000'],'emails':['sales@roundtrip.example'],'phone_candidates':['+86 138 0000 0000'],'linkedin_links':[],'source_urls':['https://roundtrip.example/contact'],'status':'HTTP 200','notes':'fixture','collected_at':'2026-10-29','email_details':[],'contact_evidence':{'emails':{'sales@roundtrip.example':'https://roundtrip.example/contact'}},'decision_maker_evidence':'','gender_status':'未知/未核实','company_address':'88 Industrial Road, Ningbo, Zhejiang, China','address_source_url':'https://roundtrip.example/contact'}
            app.save_lead(row)
            saved = app.load_saved_leads()
            self.assertEqual(len(saved), 1)
            self.assertIn('+86 138 0000 0000', saved[0]['whatsapp_contacts'])
            self.assertEqual(saved[0]['company_address'],'88 Industrial Road, Ningbo, Zhejiang, China')
            self.assertEqual(saved[0]['address_source_url'],'https://roundtrip.example/contact')
            self.assertEqual(saved[0]['contact_evidence']['emails']['sales@roundtrip.example'], 'https://roundtrip.example/contact')
        app.DB_FILE = old

    def test_malformed_contact_evidence_does_not_hide_saved_leads(self):
        old = app.DB_FILE
        with tempfile.TemporaryDirectory() as td:
            app.DB_FILE = os.path.join(td, 'malformed.db')
            app.init_db()
            row = {'company_name':'Still Visible Factory','company_website':'https://still-visible.example/','industry_category':'test','industry':'test','country':'China','manufacturer_score':60,'operation_score':10,'manufacturer_evidence':'fixture','whatsapp_links':[],'whatsapp_contacts':[],'emails':['sales@still-visible.example'],'phone_candidates':[],'linkedin_links':[],'source_urls':['https://still-visible.example/contact'],'status':'HTTP 200','notes':'fixture','collected_at':'2026-10-29','email_details':[],'contact_evidence':{'emails':{'sales@still-visible.example':'https://still-visible.example/contact'}},'decision_maker_evidence':'','gender_status':'未知/未核实'}
            app.save_lead(row)
            con = sqlite3.connect(app.DB_FILE)
            con.execute("UPDATE leads SET contact_evidence = ?, emails = ? WHERE domain = ?", ('{broken json', '{not a list}', 'still-visible.example'))
            con.commit(); con.close()
            saved = app.load_saved_leads()
            self.assertEqual(len(saved), 1)
            self.assertEqual(saved[0]['company_name'], 'Still Visible Factory')
            self.assertEqual(saved[0]['contact_evidence'], {})
            self.assertEqual(saved[0]['emails'], [])
        app.DB_FILE = old

    def test_export_keeps_explicit_whatsapp_number_without_inventing_url(self):
        row = {'company_name':'WhatsApp Label Factory','whatsapp_links':[],'whatsapp_contacts':['+86 138 0000 0000'],'phone_candidates':[],'emails':['sales@factory.cn']}
        fields, values = app.App.export_rows if False else (None, None)
        got = app.App._simple_export_row(row)
        self.assertEqual(got[4], "'+86 138 0000 0000")
        self.assertEqual(got[5], '')
        self.assertNotIn('wa.me', got[5])


    def test_whatsapp_and_ordinary_phone_in_same_paragraph_are_separated(self):
        from bs4 import BeautifulSoup
        soup = BeautifulSoup('<html><body><p>WhatsApp: +86 138 0000 0000; Tel: +86 139 1111 2222</p></body></html>', 'html.parser')
        details = app.extract_contact_evidence(soup, 'https://factory.example/contact')
        self.assertIn('+86 138 0000 0000', details['whatsapp_contacts'])
        self.assertNotIn('+86 139 1111 2222', details['whatsapp_contacts'])
        self.assertIn('+86 139 1111 2222', details['phones'])

    def test_email_split_across_visible_spans_is_recovered(self):
        from bs4 import BeautifulSoup
        soup = BeautifulSoup('<html><body><p>Email: <span>sales</span><span> @ </span><span>factory-example.cn</span></p></body></html>', 'html.parser')
        details = app.extract_contact_evidence(soup, 'https://factory-example.cn/contact')
        self.assertIn('sales@factory-example.cn', details['emails'])

    def test_unformatted_number_requires_phone_context(self):
        self.assertEqual(app.clean_phone_candidate('1234567890'), '')
        self.assertEqual(app.clean_phone_candidate('1234567890', 'Contact phone: 1234567890'), '1234567890')

    def test_robots_rules_are_respected_for_internal_pages(self):
        from urllib.robotparser import RobotFileParser
        parser=RobotFileParser()
        parser.set_url('https://factory.example/robots.txt')
        parser.parse(['User-agent: *', 'Disallow: /private/', 'Allow: /contact'])
        self.assertFalse(app.robots_allows(parser, 'https://factory.example/private/profile'))
        self.assertTrue(app.robots_allows(parser, 'https://factory.example/contact'))

    def test_app_directory_uses_executable_folder_when_frozen(self):
        self.assertEqual(app.resolve_app_dir(True, '/portable/FactoryLead_MVP.exe', '/bundle/_internal/app.py'), '/portable')
        self.assertEqual(app.resolve_app_dir(False, '/portable/python.exe', '/project/app.py'), '/project')

    def test_company_address_is_extracted_from_jsonld_postal_address(self):
        from bs4 import BeautifulSoup
        html='''<script type="application/ld+json">{"@context":"https://schema.org","@type":"Organization","name":"Address Factory","address":{"@type":"PostalAddress","streetAddress":"88 Industrial Road","addressLocality":"Ningbo","addressRegion":"Zhejiang","postalCode":"315000","addressCountry":"CN"}}</script>'''
        soup=BeautifulSoup(html,'html.parser')
        address=app.extract_company_address(soup)
        self.assertIn('88 Industrial Road',address)
        self.assertIn('Ningbo',address)
        self.assertIn('Zhejiang',address)

    def test_company_address_rejects_mixed_contact_and_phone_blocks(self):
        from bs4 import BeautifulSoup
        html='''<html><body><div class="company-address">7/24 sales service Tel: 0086-18880887440 sales@example.com</div><div class="address">Building 3, No. 88 Industrial Road, Ningbo, Zhejiang, China</div></body></html>'''
        address=app.extract_company_address(BeautifulSoup(html,'html.parser'))
        self.assertIn('Industrial Road',address)
        self.assertNotIn('sales service',address)
        self.assertNotIn('18880887440',address)

    def test_jsonld_public_business_contacts_and_name(self):
        from bs4 import BeautifulSoup
        html = '''<html><head><script type="application/ld+json">{"@context":"https://schema.org","@type":"Organization","name":"Structured Factory Ltd","email":"sales@structured-factory.com","telephone":"+86 138 0000 0000","sameAs":["https://www.linkedin.com/company/structured-factory"]}</script></head><body>Manufacturer</body></html>'''
        soup=BeautifulSoup(html,'html.parser')
        wa,emails,phones,linkedin=app.extract_contacts(soup,'https://structured-factory.com')
        self.assertIn('sales@structured-factory.com',emails)
        self.assertTrue(any('138 0000 0000' in x for x in phones))
        self.assertTrue(any('linkedin.com/company/structured-factory' in x for x in linkedin))
        self.assertEqual(app.structured_company_name(soup),'Structured Factory Ltd')

    def test_trade_contact_queries_cover_cross_industry_women_export_roles(self):
        queries=app.build_trade_contact_queries('China')
        combined=' '.join(queries).lower()
        for term in ('female','export manager','international sales','whatsapp','email','外贸经理','国际销售'):
            self.assertIn(term,combined)
        self.assertNotIn('manufacturer only',combined)

    def test_people_queries_include_owner_roles_and_multiple_products(self):
        queries=app.build_people_queries('wiper blades; small appliances; footwear','China')
        self.assertTrue(any('woman owner' in q for q in queries))
        self.assertTrue(any('general manager' in q for q in queries))
        self.assertTrue(any('small appliances' in q for q in queries))
        self.assertTrue(any('footwear' in q for q in queries))

    def test_legacy_database_schema_migrates_without_dropping_leads(self):
        old=app.DB_FILE
        with tempfile.TemporaryDirectory() as td:
            path=os.path.join(td,'legacy.db')
            con=sqlite3.connect(path)
            con.execute('CREATE TABLE leads (id INTEGER PRIMARY KEY AUTOINCREMENT, domain TEXT UNIQUE, company_name TEXT, website TEXT, category TEXT, industry TEXT, country TEXT, score INTEGER, operation_score INTEGER, evidence TEXT, whatsapp TEXT, emails TEXT, phones TEXT, linkedin TEXT, sources TEXT, status TEXT, notes TEXT, collected_at TEXT)')
            con.execute("INSERT INTO leads(domain,company_name,website) VALUES('legacy.example','Legacy Factory','https://legacy.example')")
            con.commit(); con.close()
            app.DB_FILE=path
            app.init_db()
            con=sqlite3.connect(path)
            cols={r[1] for r in con.execute('PRAGMA table_info(leads)')}
            name=con.execute("SELECT company_name FROM leads WHERE domain='legacy.example'").fetchone()[0]
            con.close()
            self.assertIn('email_details',cols); self.assertIn('decision_maker_evidence',cols); self.assertIn('gender_status',cols)
            self.assertEqual(name,'Legacy Factory')
        app.DB_FILE=old

    def test_company_website_is_root_but_source_keeps_contact_page(self):
        self.assertEqual(app.site_root_url('https://www.example-factory.com/contact-us?ref=directory'), 'https://www.example-factory.com/')


    def test_whatsapp_short_link_is_preserved_as_explicit_link(self):
        from bs4 import BeautifulSoup
        html='<html><body><a href="https://wa.me/message/ABC123">WhatsApp business chat</a></body></html>'
        wa,emails,phones,linkedin=app.extract_contacts(BeautifulSoup(html,'html.parser'),'https://factory.example/contact')
        self.assertTrue(any('wa.me/message/ABC123' in x for x in wa))


    def test_candidate_balancing_preserves_later_industries(self):
        items=[('https://a.example','A','query-a'),('https://a2.example','A2','query-a'),('https://b.example','B','query-b'),('https://c.example','C','query-c')]
        context={'query-a':{'industry':'Industry A'},'query-b':{'industry':'Industry B'},'query-c':{'industry':'Industry C'}}
        got=app.balance_candidate_items(items,context,3)
        self.assertEqual([x[2] for x in got],['query-a','query-b','query-c'])

    def test_three_evidence_scores_persist_with_source_urls(self):
        old=app.DB_FILE
        with tempfile.TemporaryDirectory() as td:
            app.DB_FILE=os.path.join(td,'evidence.db'); app.init_db()
            row={'company_name':'Evidence Factory','company_website':'https://evidence.example/','industry_category':'test','industry':'test','country':'China',
                 'manufacturer_score':75,'operation_score':12,'manufacturer_evidence':'factory production','whatsapp_links':[],'emails':['sales@evidence.example'],
                 'phone_candidates':[],'linkedin_links':[],'source_urls':['https://evidence.example/'],'status':'HTTP 200','notes':'fixture',
                 'collected_at':'2026-11-04','email_details':[],'whatsapp_contacts':[],'contact_evidence':{},'decision_maker_evidence':'','gender_status':'未知/未核实',
                 'factory_evidence_items':[{'type':'factory','text':'factory','source_url':'https://evidence.example/about'}],
                 'export_evidence_items':[{'type':'export','text':'export','source_url':'https://evidence.example/export'}],
                 'contact_evidence_items':[{'type':'contact','text':'sales email','source_url':'https://evidence.example/contact'}]}
            app.save_lead(row)
            con=sqlite3.connect(app.DB_FILE)
            vals=con.execute('SELECT factory_authenticity_score,export_capability_score,contact_evidence_score FROM leads').fetchone()
            evidence=con.execute('SELECT COUNT(*),COUNT(DISTINCT source_url) FROM lead_evidence').fetchone()
            con.close()
            self.assertEqual(vals,(35,35,30)); self.assertEqual(evidence,(3,3))
            loaded=app.load_saved_leads()[0]
            self.assertEqual((loaded['factory_authenticity_score'],loaded['export_capability_score'],loaded['contact_evidence_score']),(35,35,30))
            self.assertIn('https://evidence.example/export',loaded['notes'])
        app.DB_FILE=old

    def test_collected_registry_persists_and_matches_domain_or_exact_company_name(self):
        old=app.DB_FILE
        with tempfile.TemporaryDirectory() as td:
            app.DB_FILE=os.path.join(td,'registry.db'); app.init_db()
            row={'company_name':'Shenzhen Bright Tools Co., Ltd.','company_website':'https://www.brighttools.example/','industry_category':'test','industry':'test','country':'China','manufacturer_score':70,'operation_score':10,'manufacturer_evidence':'factory','whatsapp_links':[],'emails':['sales@brighttools.example'],'phone_candidates':[],'linkedin_links':[],'source_urls':[],'status':'HTTP 200','notes':'','collected_at':'2026-11-10','email_details':[],'whatsapp_contacts':[],'contact_evidence':{},'decision_maker_evidence':'','gender_status':'未知/未核实'}
            app.save_lead(row)
            domains,names=app.load_collected_registry()
            self.assertIn('brighttools.example',domains)
            self.assertIn(app.normalize_company_key('Shenzhen Bright Tools Limited'),names)
            con=sqlite3.connect(app.DB_FILE)
            saved=con.execute("SELECT status,seen_count FROM collection_registry WHERE domain='brighttools.example'").fetchone()
            con.close()
            self.assertEqual(saved[0],'collected')
        app.DB_FILE=old

    def test_pending_review_is_not_permanent_skip_but_is_recently_suppressed(self):
        old=app.DB_FILE
        with tempfile.TemporaryDirectory() as td:
            app.DB_FILE=os.path.join(td,'pending.db'); app.init_db()
            row={'company_name':'Possible Supplier Ltd','company_website':'https://possible-supplier.example/','industry_category':'test','industry':'Industrial equipment','country':'China','manufacturer_score':12,'operation_score':18,'manufacturer_evidence':'supplier export sales','whatsapp_links':[],'emails':['sales@possible-supplier.example'],'phone_candidates':[],'linkedin_links':[],'source_urls':[],'status':'HTTP 200','notes':'','collected_at':'2026-11-11','email_details':[],'whatsapp_contacts':[],'contact_evidence':{},'decision_maker_evidence':'','gender_status':'未知/未核实'}
            app.save_lead(row)
            domains,names=app.load_collected_registry()
            recent_domains,recent_names=app.load_recently_seen_registry(days=30)
            self.assertNotIn('possible-supplier.example',domains)
            self.assertIn('possible-supplier.example',recent_domains)
            con=sqlite3.connect(app.DB_FILE)
            status=con.execute("SELECT status FROM collection_registry WHERE domain='possible-supplier.example'").fetchone()[0]
            con.close()
            self.assertEqual(status,'review')
        app.DB_FILE=old

    def test_previous_collection_filter_matches_domain_or_exact_normalized_name(self):
        domains={'knownfactory.example'}
        names={app.normalize_company_key('Shenzhen Bright Tools Co., Ltd.')}
        self.assertTrue(app.is_previously_collected('knownfactory.example','Other title',domains,names))
        self.assertTrue(app.is_previously_collected('newdomain.example','Shenzhen Bright Tools Limited',domains,names))
        self.assertTrue(app.is_previously_collected('www.knownfactory.example','Other title',domains,names))
        self.assertTrue(app.is_previously_collected('shop.knownfactory.example','Other title',domains,names))
        self.assertFalse(app.is_previously_collected('newdomain.example','Maco Industrial',domains,names))

    def test_windows_database_migration_prefers_nonempty_previous_version_db(self):
        from unittest.mock import patch
        with tempfile.TemporaryDirectory() as td:
            old_outer=Path(td)/'WaiMaoDaRen_2.2.1_Extracted'; old_dir=old_outer/'WaiMaoDaRen_2_2_1_Source'
            new_dir=Path(td)/'WaiMaoDaRen_2.2.3_Extracted'/'WaiMaoDaRen_2_2_3_Source'
            old_dir.mkdir(parents=True); new_dir.mkdir(parents=True)
            old_db=old_dir/'factorylead.db'; con=sqlite3.connect(old_db)
            con.execute('CREATE TABLE leads(domain TEXT, company_name TEXT)')
            con.execute("INSERT INTO leads VALUES('migrated.example','Migrated Factory')")
            con.commit(); con.close()
            env={'LOCALAPPDATA':str(Path(td)/'LocalAppData')}
            with patch.object(app.os,'name','nt'), patch.dict(os.environ,env,clear=False):
                target=app.resolve_persistent_db_file(str(new_dir))
            con=sqlite3.connect(target)
            row=con.execute('SELECT domain,company_name FROM leads').fetchone(); con.close()
            self.assertEqual(row,('migrated.example','Migrated Factory'))

    def test_legacy_leads_are_backfilled_into_collection_registry(self):
        old=app.DB_FILE
        with tempfile.TemporaryDirectory() as td:
            app.DB_FILE=os.path.join(td,'legacy-registry.db')
            con=sqlite3.connect(app.DB_FILE)
            con.execute('CREATE TABLE leads (id INTEGER PRIMARY KEY, domain TEXT UNIQUE, company_name TEXT, website TEXT, category TEXT, industry TEXT, country TEXT, score INTEGER, operation_score INTEGER, evidence TEXT, whatsapp TEXT, emails TEXT, phones TEXT, linkedin TEXT, sources TEXT, status TEXT, notes TEXT, collected_at TEXT)')
            con.execute("INSERT INTO leads(domain,company_name,website,collected_at) VALUES('oldfactory.example','Old Factory Limited','https://oldfactory.example/','2026-11-01')")
            con.commit(); con.close()
            app.init_db()
            domains,names=app.load_collected_registry()
            self.assertIn('oldfactory.example',domains)
            self.assertIn(app.normalize_company_key('Old Factory'),names)
        app.DB_FILE=old

    def test_sqlite_upsert_deduplicates_domain(self):
        old=app.DB_FILE
        with tempfile.TemporaryDirectory() as td:
            app.DB_FILE=os.path.join(td,'test.db'); app.init_db()
            row={'company_name':'Test Factory','company_website':'https://testfactory.example/','industry_category':'test','industry':'test','country':'China','manufacturer_score':70,'operation_score':10,'manufacturer_evidence':'factory','whatsapp_links':[],'emails':['sales@testfactory.example'],'phone_candidates':[],'linkedin_links':[],'source_urls':['https://testfactory.example/'],'status':'HTTP 200','notes':'fixture','collected_at':'2026-10-29','email_details':[],'contact_evidence':{'emails':{'sales@roundtrip.example':'https://roundtrip.example/contact'}},'decision_maker_evidence':'','gender_status':'未知/未核实'}
            app.save_lead(row)
            row['manufacturer_score']=80; row['emails']=['new@roundtrip.example']; row['phone_candidates']=['+8613812345678']
            app.save_lead(row)
            con=sqlite3.connect(app.DB_FILE)
            count=con.execute('select count(*) from leads').fetchone()[0]
            score=con.execute('select score from leads').fetchone()[0]
            emails=json.loads(con.execute('select emails from leads').fetchone()[0])
            phones=json.loads(con.execute('select phones from leads').fetchone()[0])
            con.close()
            self.assertEqual(count,1); self.assertEqual(score,80)
            self.assertEqual(set(emails),{'sales@testfactory.example','new@roundtrip.example'})
            self.assertEqual(phones,['+8613812345678'])
        app.DB_FILE=old

    def test_evidence_is_appended_and_exact_repeat_is_deduplicated(self):
        old=app.DB_FILE
        with tempfile.TemporaryDirectory() as td:
            app.DB_FILE=os.path.join(td,'append.db'); app.init_db()
            base={'company_name':'Append Factory','company_website':'https://append.example/','industry_category':'test','industry':'test','country':'China','manufacturer_score':60,'operation_score':10,'manufacturer_evidence':'factory','whatsapp_links':[],'emails':[],'phone_candidates':[],'linkedin_links':[],'source_urls':[],'status':'HTTP 200','notes':'','collected_at':'2026-11-04 10:00:00','email_details':[],'whatsapp_contacts':[],'contact_evidence':{},'decision_maker_evidence':'','gender_status':'未知/未核实'}
            base['factory_evidence_items']=[{'text':'factory','source_url':'https://append.example/about'}]
            app.save_lead(base); app.save_lead(base)
            second=dict(base); second['collected_at']='2026-11-04 11:00:00'; second['factory_evidence_items']=[{'text':'factory','source_url':'https://append.example/factory'}]
            app.save_lead(second)
            con=sqlite3.connect(app.DB_FILE); rows=con.execute('SELECT source_url,observed_at FROM lead_evidence ORDER BY id').fetchall(); con.close()
            self.assertEqual(len(rows),2)
            self.assertEqual({x[0] for x in rows},{'https://append.example/about','https://append.example/factory'})
        app.DB_FILE=old

    def test_multiple_contact_evidence_persists_separately_and_unverified(self):
        old=app.DB_FILE
        with tempfile.TemporaryDirectory() as td:
            app.DB_FILE=os.path.join(td,'contacts.db'); app.init_db()
            row={'company_name':'Contacts Factory','company_website':'https://contacts.example/','industry_category':'test','industry':'test','country':'China','manufacturer_score':60,'operation_score':10,'manufacturer_evidence':'factory','whatsapp_links':['https://wa.me/8613800000000'],'emails':['sales@contacts.example','export@contacts.example'],'phone_candidates':['+86 139 0000 0000'],'whatsapp_contacts':['+86 138 0000 0000'],'linkedin_links':[],'source_urls':[],'status':'HTTP 200','notes':'','collected_at':'2026-11-04 12:00:00','email_details':[{'email':'sales@contacts.example','role':'sales','domain_match':True},{'email':'export@contacts.example','role':'export','domain_match':True}],'whatsapp_contacts':['+86 138 0000 0000'],'contact_evidence':{'emails':{'sales@contacts.example':'https://contacts.example/contact','export@contacts.example':'https://contacts.example/export'},'whatsapp_links':{'https://wa.me/8613800000000':'https://contacts.example/contact'},'whatsapp_contacts':{'+86 138 0000 0000':'https://contacts.example/contact'},'phones':{'+86 139 0000 0000':'https://contacts.example/contact'}},'decision_maker_evidence':'','gender_status':'未知/未核实'}
            app.save_lead(row)
            con=sqlite3.connect(app.DB_FILE); rows=con.execute('SELECT contact_type,contact_value,status,validation_json FROM lead_contact_evidence ORDER BY id').fetchall(); con.close()
            self.assertEqual(sum(1 for x in rows if x[0]=='email'),2)
            email=next(x for x in rows if x[0]=='email')
            self.assertIn('未核实',email[2]); self.assertIn('未检查',email[3])
            self.assertTrue(any(x[0]=='whatsapp_link' for x in rows))
            self.assertTrue(any(x[0]=='whatsapp_labelled_number' for x in rows))
            self.assertTrue(any(x[0]=='phone' and x[2]=='仅普通电话号码' for x in rows))
        app.DB_FILE=old

    def test_quality_classification_persists_across_database_reload(self):
        old=app.DB_FILE
        with tempfile.TemporaryDirectory() as td:
            app.DB_FILE=os.path.join(td,'quality.db'); app.init_db()
            row={'company_name':'Quality Factory Ltd','company_website':'https://quality-factory.example/','industry_category':'test','industry':'Industrial machinery','country':'China','manufacturer_score':70,'operation_score':15,'manufacturer_evidence':'factory manufacturer production','whatsapp_links':[],'whatsapp_contacts':[],'emails':['sales@quality-factory.example'],'phone_candidates':[],'linkedin_links':[],'source_urls':['https://quality-factory.example/about'],'status':'HTTP 200','notes':'','collected_at':'2026-11-11','email_details':[],'contact_evidence':{},'decision_maker_evidence':'','gender_status':'未知/未核实','quality_status':'keep','quality_reason':'官网有明确制造商证据'}
            app.save_lead(row)
            loaded=app.load_saved_leads()
            self.assertEqual(len(loaded),1)
            self.assertEqual(loaded[0]['quality_status'],'keep')
            self.assertEqual(loaded[0]['quality_reason'],'官网有明确制造商证据')
        app.DB_FILE=old

    def test_save_failure_rolls_back_company_and_evidence(self):
        old=app.DB_FILE
        with tempfile.TemporaryDirectory() as td:
            app.DB_FILE=os.path.join(td,'rollback.db'); app.init_db()
            con=sqlite3.connect(app.DB_FILE)
            con.execute("CREATE TRIGGER fail_evidence BEFORE INSERT ON lead_evidence BEGIN SELECT RAISE(ABORT,'forced test failure'); END")
            con.commit(); con.close()
            row={'company_name':'Rollback Factory','company_website':'https://rollback.example/','industry_category':'test','industry':'test','country':'China','manufacturer_score':60,'operation_score':10,'manufacturer_evidence':'factory','whatsapp_links':[],'emails':[],'phone_candidates':[],'linkedin_links':[],'source_urls':[],'status':'HTTP 200','notes':'','collected_at':'2026-11-04','email_details':[],'whatsapp_contacts':[],'contact_evidence':{},'decision_maker_evidence':'','gender_status':'未知/未核实','factory_evidence_items':[{'text':'factory','source_url':'https://rollback.example/about'}]}
            with self.assertRaises(sqlite3.IntegrityError): app.save_lead(row)
            con=sqlite3.connect(app.DB_FILE); count=con.execute('SELECT COUNT(*) FROM leads').fetchone()[0]; ev=con.execute('SELECT COUNT(*) FROM lead_evidence').fetchone()[0]; con.close()
            self.assertEqual((count,ev),(0,0))
        app.DB_FILE=old


class RuntimeRegressionTests(unittest.TestCase):
    def test_worker_verify_finishes_without_undefined_search_diagnostics(self):
        from unittest.mock import patch
        class Status:
            value = ''
            def set(self, value): self.value=value
        class Button:
            def config(self, **kwargs): self.state=kwargs.get('state')
        ui=object.__new__(app.App)
        ui.rows=[]; ui.status=Status(); ui.run_btn=Button(); ui.pause_btn=Button(); ui.resume_btn=Button(); ui.stop_btn=Button()
        ui._post_ui=lambda callback,*args,**kwargs: callback(*args,**kwargs)
        ui.add_result=lambda *args,**kwargs: None
        result={'company_name':'Fixture Factory','company_website':'https://fixture.example/',
                'status':'HTTP 200','industry':'Fixture','emails':['sales@fixture.example'],
                'whatsapp_links':[],'whatsapp_contacts':[],'phone_candidates':[]}
        with patch.object(app,'scan_site',return_value=result), patch.object(app,'save_lead'):
            app.App.worker_verify(ui,['https://fixture.example/'],{'workers':1,'industry':'Fixture','keywords':'test','country':'China','category':'Test'})
        self.assertEqual(len(ui.rows),1)
        self.assertIn('完成：核验 1 条',ui.status.value)
        self.assertEqual(ui.run_btn.state,'normal')

if __name__=='__main__': unittest.main(verbosity=2)


class PauseResumeControlTests(unittest.TestCase):
    def _bare_app(self):
        instance=app.App.__new__(app.App)
        instance._pause_event=threading.Event(); instance._pause_event.set()
        instance._stop_event=threading.Event()
        return instance

    def test_worker_waits_while_paused_and_resumes(self):
        instance=self._bare_app()
        instance._pause_event.clear()
        result=[]
        worker=threading.Thread(target=lambda: result.append(instance._wait_for_task_permission()))
        worker.start()
        time.sleep(0.08)
        self.assertTrue(worker.is_alive(), 'worker should remain parked while paused')
        instance._pause_event.set()
        worker.join(1)
        self.assertFalse(worker.is_alive())
        self.assertEqual(result,[True])

    def test_stop_releases_paused_worker_and_returns_false(self):
        instance=self._bare_app()
        instance._pause_event.clear(); instance._stop_event.set()
        self.assertFalse(instance._wait_for_task_permission())
