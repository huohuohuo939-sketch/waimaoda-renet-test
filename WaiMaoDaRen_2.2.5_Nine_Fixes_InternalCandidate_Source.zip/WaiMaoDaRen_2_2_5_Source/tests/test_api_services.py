import json, os, sqlite3, tempfile, unittest
from pathlib import Path
from unittest.mock import Mock, patch
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import api_services as api

class ProviderTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.db=str(Path(self.tmp.name)/'usage.db'); api.init_provider_db(self.db)
    def tearDown(self): self.tmp.cleanup()
    def test_serpapi_parses_organic_results_and_region(self):
        session=Mock(); response=Mock(status_code=200); response.json.return_value={'organic_results':[{'title':'Factory A','link':'https://a.example/'}]}; session.get.return_value=response
        rows,status=api.search_serpapi('factory China','secret-test-key',5,session)
        self.assertEqual(rows,[('https://a.example/','Factory A')]); self.assertEqual(status,200)
        args=session.get.call_args.kwargs['params']; self.assertEqual(args['gl'],'cn'); self.assertEqual(args['hl'],'zh-cn')
    def test_serpapi_can_select_baidu_engine(self):
        session=Mock(); response=Mock(status_code=200); response.json.return_value={'organic_results':[{'title':'工厂','link':'https://factory.example/'}]}; session.get.return_value=response
        api.search_serpapi('工厂制造商 China','secret-test-key',5,session,engine='baidu')
        self.assertEqual(session.get.call_args.kwargs['params']['engine'],'baidu')

    def test_brave_uses_subscription_header_and_normalizes(self):
        session=Mock(); response=Mock(status_code=200); response.json.return_value={'web':{'results':[{'title':'Factory B','url':'https://b.example'}]}}; session.get.return_value=response
        rows,_=api.search_brave('factory China','brave-secret',5,session)
        self.assertEqual(rows,[('https://b.example','Factory B')]); self.assertEqual(session.get.call_args.kwargs['headers']['X-Subscription-Token'],'brave-secret')
    def test_missing_keys_do_not_make_real_calls(self):
        with patch.object(api.requests.Session,'get',side_effect=AssertionError('network must not be called')):
            rows=api.search_providers('factory',5,{},self.db,{'serpapi':'','brave':''})
        self.assertEqual(rows,[]); self.assertEqual(api.provider_usage(self.db),[])
    def test_provider_usage_counts_success_and_error(self):
        api.record_provider_call(self.db,'serpapi',True,3,200)
        api.record_provider_call(self.db,'serpapi',False,0,429,'HTTP_ERROR','rate limited')
        row=api.provider_usage(self.db,'serpapi')[0]
        self.assertEqual((row['calls'],row['successes'],row['errors'],row['results']),(2,1,1,3))
    def test_error_log_never_persists_api_key(self):
        api.record_provider_call(self.db,'brave',False,0,401,'AUTH','Unauthorized')
        con=sqlite3.connect(self.db); raw=' '.join(str(x) for x in con.execute('SELECT * FROM provider_errors').fetchone()); con.close()
        self.assertNotIn('secret',raw); self.assertIn('Unauthorized',raw)
    def test_quota_is_editable_and_monthly_calls_reported(self):
        api.set_provider_quota(self.db,'brave',2000)
        self.assertEqual(api.get_provider_quotas(self.db)['brave'],2000)
    def test_shared_task_budget_caps_serpapi_and_brave_combined(self):
        diag={"_paid_search_budget":{"limit":1,"used":0}}
        with patch.object(api,'search_serpapi',return_value=([],200)) as serp, \
             patch.object(api,'search_brave',return_value=([],200)) as brave:
            api.search_providers('first query',5,diag,self.db,{'serpapi':'configured','brave':'configured'})
            api.search_providers('second query',5,diag,self.db,{'serpapi':'configured','brave':'configured'})
        self.assertEqual(serp.call_count + brave.call_count,1)
        self.assertEqual(diag['_paid_search_budget']['used'],1)
        self.assertTrue(diag['_paid_search_budget']['blocked'])

    def test_failed_paid_request_still_consumes_task_budget(self):
        diag={"_paid_search_budget":{"limit":2,"used":0}}
        with patch.object(api,'search_serpapi',side_effect=api.ProviderError('serpapi',429,'HTTP_ERROR','rate limited')), \
             patch.object(api,'search_brave',return_value=([],200)) as brave:
            api.search_providers('first query',5,diag,self.db,{'serpapi':'configured','brave':'configured'})
        self.assertEqual(diag['_paid_search_budget']['used'],2)
        brave.assert_called_once()

    def test_persistent_monthly_shared_cap_blocks_paid_calls_across_tasks(self):
        from unittest.mock import patch
        diag1={'_paid_search_budget':{'limit':100,'used':0}}
        diag2={'_paid_search_budget':{'limit':100,'used':0}}
        with patch.object(api,'PAID_MONTHLY_HARD_CAP',1), \
             patch.object(api,'search_serpapi',return_value=([],200)) as serp, \
             patch.object(api,'search_brave',return_value=([],200)) as brave:
            api.search_providers('first query',5,diag1,self.db,{'serpapi':'configured','brave':''})
            api.search_providers('second query',5,diag2,self.db,{'serpapi':'configured','brave':''})
        self.assertEqual(serp.call_count+brave.call_count,1)
        self.assertTrue(diag2.get('_paid_search_budget',{}).get('monthly_used',0) >= 1)
        self.assertTrue(diag2.get('serpapi',{}).get('monthly_budget_blocked'))

    def test_legacy_provider_usage_is_migrated_into_monthly_guard(self):
        month=api._dt.datetime.now().strftime('%Y-%m')
        api.record_provider_call(self.db,'serpapi',True,1,200)
        # Re-initialization seeds the new reservation ledger from old usage records.
        api.init_provider_db(self.db)
        self.assertEqual(api.paid_monthly_usage(self.db),1)

    def test_persistent_task_budget_survives_process_restart(self):
        task_id='same-resumed-task'
        diag1={'_task_id':task_id,'_paid_search_budget':{'limit':20,'used':0}}
        diag2={'_task_id':task_id,'_paid_search_budget':{'limit':20,'used':0}}
        with patch.object(api,'PAID_TASK_DEFAULT_CAP',1), \
             patch.object(api,'search_serpapi',return_value=([],200)) as serp:
            api.search_providers('query one',5,diag1,self.db,{'serpapi':'configured','brave':''})
            # Simulate a fresh process: only the stable task_id is restored.
            diag2={'_task_id':task_id,'_paid_search_budget':{'limit':20,'used':0}}
            api.search_providers('query two',5,diag2,self.db,{'serpapi':'configured','brave':''})
        self.assertEqual(serp.call_count,1)
        self.assertTrue(diag2.get('serpapi',{}).get('task_budget_blocked'))
        self.assertEqual(api.paid_task_usage(self.db,task_id),1)

    def test_existing_reservation_schema_migrates_task_id_column(self):
        old_db=str(Path(self.tmp.name)/'old-schema.db')
        con=sqlite3.connect(old_db)
        con.execute("CREATE TABLE paid_search_reservations (id INTEGER PRIMARY KEY, provider TEXT NOT NULL, month TEXT NOT NULL, query_hash TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'reserved', created_at TEXT NOT NULL, completed_at TEXT NOT NULL DEFAULT '')")
        con.commit(); con.close()
        api.init_provider_db(old_db)
        con=sqlite3.connect(old_db)
        cols={r[1] for r in con.execute('PRAGMA table_info(paid_search_reservations)')}
        con.close()
        self.assertIn('task_id',cols)

    def test_task_budget_hard_ceiling_cannot_be_raised_above_20(self):
        diag={"_paid_search_budget":{"limit":9999,"used":19}}
        with patch.object(api,'search_serpapi',return_value=([],200)) as serp, \
             patch.object(api,'search_brave',return_value=([],200)) as brave:
            api.search_providers('last allowed query',5,diag,self.db,{'serpapi':'configured','brave':'configured'})
            api.search_providers('over limit query',5,diag,self.db,{'serpapi':'configured','brave':'configured'})
        self.assertEqual(diag['_paid_search_budget']['limit'],20)
        self.assertEqual(diag['_paid_search_budget']['used'],20)
        self.assertEqual(serp.call_count+brave.call_count,1)

    def test_scores_require_source_urls_and_are_independent(self):
        factory=[{'type':'factory','text':'factory','source_url':'https://f.example/about'}]
        export=[{'type':'export','text':'export','source_url':'https://f.example/export'}]
        contact=[{'type':'contact','text':'sales@example.com','source_url':'https://f.example/contact'}]
        scores=api.score_three_dimensions(factory,export,contact)
        self.assertEqual(scores,{'factory_authenticity_score':35,'export_capability_score':35,'contact_evidence_score':30})
        no_url=api.score_three_dimensions([{'type':'factory','text':'factory','source_url':''}],[],[])
        self.assertEqual(no_url['factory_authenticity_score'],0)
    def test_dedupes_search_results_by_domain(self):
        got=api._normalize([{'title':'One','link':'https://a.example/1'},{'title':'Duplicate','link':'https://www.a.example/2'},{'title':'Two','link':'https://b.example'}],'mock')
        self.assertEqual(len(got),2)
    def test_provider_orchestration_uses_brave_as_api_backup_and_counts_calls(self):
        with patch.object(api, 'search_serpapi', side_effect=api.ProviderError('serpapi',429,'HTTP_ERROR','rate limited')), \
             patch.object(api, 'search_brave', return_value=([('https://brave.example','Brave Factory')],200)):
            diag={}; rows=api.search_providers('factory',5,diag,self.db,{'serpapi':'configured','brave':'configured'})
        self.assertEqual(rows,[('https://brave.example','Brave Factory')])
        self.assertTrue(diag['serpapi']['blocked']); self.assertEqual(diag['brave']['results'],1)
        usage={x['provider']:x for x in api.provider_usage(self.db)}
        self.assertEqual(usage['serpapi']['errors'],1); self.assertEqual(usage['brave']['successes'],1)
        with patch.object(api, 'search_serpapi', side_effect=AssertionError('blocked provider must not be called')), \
             patch.object(api, 'search_brave', return_value=([],200)):
            api.search_providers('factory again',5,diag,self.db,{'serpapi':'configured','brave':'configured'})
    def test_search_results_are_cached_for_seven_days(self):
        with patch.object(api,'search_serpapi',return_value=([('https://cached.example','Cached')],200)) as serp, \
             patch.object(api,'search_brave',return_value=([],200)):
            first=api.search_providers('cache this query',5,{'_task_id':'cache-task'},self.db,{'serpapi':'configured','brave':''})
            diag={'_task_id':'cache-task'}
            second=api.search_providers('cache this query',5,diag,self.db,{'serpapi':'configured','brave':''})
        self.assertEqual(first,second)
        self.assertEqual(serp.call_count,1)
        self.assertEqual(diag['serpapi']['cache_hits'],1)
        self.assertEqual(api.paid_task_usage(self.db,'cache-task'),1)

    def test_local_monthly_quota_blocks_additional_provider_calls(self):
        api.set_provider_quota(self.db,'serpapi',1)
        api.record_provider_call(self.db,'serpapi',True,1,200)
        with patch.object(api,'search_serpapi',side_effect=AssertionError('quota should block call')):
            diag={}
            rows=api.search_providers('uncached quota query',5,diag,self.db,{'serpapi':'configured','brave':''})
        self.assertEqual(rows,[])
        self.assertTrue(diag['serpapi']['quota_blocked'])

    def test_engine_ranking_improves_after_qualified_lead_feedback(self):
        order=['Bing','DuckDuckGo','Baidu']
        api.record_engine_search(self.db,'Bing',4,False,'成功')
        api.record_engine_search(self.db,'DuckDuckGo',2,False,'成功')
        api.record_engine_search(self.db,'Baidu',3,False,'成功')
        api.record_engine_qualification(self.db,'Baidu',True)
        api.record_engine_qualification(self.db,'Baidu',True)
        self.assertEqual(api.rank_search_engines(self.db,order)[0],'Baidu')
        rows={x['engine']:x for x in api.search_engine_performance(self.db)}
        self.assertEqual(rows['Baidu']['qualified_leads'],2)

    def test_windows_dpapi_is_not_claimed_on_non_windows(self):
        if os.name!='nt':
            with self.assertRaises(OSError): api.save_api_keys({'serpapi':'do-not-store'})

if __name__=='__main__': unittest.main()
