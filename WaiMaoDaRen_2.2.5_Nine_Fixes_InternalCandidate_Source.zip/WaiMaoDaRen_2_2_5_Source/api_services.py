"""FactoryLead 2.0 search providers, DPAPI credential storage and evidence scoring.
API keys are never included in diagnostics, exceptions, SQLite records or source files.
"""
from __future__ import annotations
import base64, ctypes, datetime as _dt, hashlib, json, os, sqlite3, time
from ctypes import wintypes
from pathlib import Path
from urllib.parse import urlparse
import requests

APP_NAME = "FactoryLead"
PAID_MONTHLY_HARD_CAP = 100  # Shared SerpApi + Brave safety cap across tasks in one calendar month.
PAID_TASK_DEFAULT_CAP = 20  # Shared SerpApi + Brave default cap for one collection task.


def _credential_path() -> Path:
    root = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
    return Path(root) / APP_NAME / "api_keys.dpapi"


def _dpapi(data: bytes, protect: bool) -> bytes:
    if os.name != "nt":
        raise OSError("API 密钥安全存储仅在 Windows 本机启用")
    class DATA_BLOB(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]
    crypt = ctypes.windll.crypt32
    kernel = ctypes.windll.kernel32
    raw = (ctypes.c_byte * len(data)).from_buffer_copy(data)
    inp = DATA_BLOB(len(data), raw)
    out = DATA_BLOB()
    if protect:
        ok = crypt.CryptProtectData(ctypes.byref(inp), ctypes.c_wchar_p("FactoryLead API credentials"), None, None, None, 0x1, ctypes.byref(out))
    else:
        ok = crypt.CryptUnprotectData(ctypes.byref(inp), None, None, None, None, 0, ctypes.byref(out))
    if not ok:
        raise OSError("Windows DPAPI 操作失败")
    try:
        return ctypes.string_at(out.pbData, out.cbData)
    finally:
        kernel.LocalFree(out.pbData)


def save_api_keys(keys: dict, path: Path | None = None) -> None:
    clean = {k: str(keys.get(k, "")).strip() for k in ("serpapi", "brave")}
    payload = json.dumps(clean, ensure_ascii=False).encode("utf-8")
    encrypted = _dpapi(payload, True)
    target = path or _credential_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_suffix(target.suffix + ".tmp")
    tmp.write_bytes(encrypted)
    os.replace(tmp, target)


def load_api_keys(path: Path | None = None) -> dict:
    target = path or _credential_path()
    if not target.exists():
        return {"serpapi": "", "brave": ""}
    try:
        data = _dpapi(target.read_bytes(), False)
        value = json.loads(data.decode("utf-8"))
        return {k: str(value.get(k, "")) for k in ("serpapi", "brave")}
    except Exception:
        return {"serpapi": "", "brave": ""}


def init_provider_db(db_path: str) -> None:
    con = sqlite3.connect(db_path)
    con.executescript("""
    CREATE TABLE IF NOT EXISTS provider_usage (
      id INTEGER PRIMARY KEY AUTOINCREMENT, provider TEXT NOT NULL, month TEXT NOT NULL,
      calls INTEGER NOT NULL DEFAULT 0, successes INTEGER NOT NULL DEFAULT 0,
      errors INTEGER NOT NULL DEFAULT 0, results INTEGER NOT NULL DEFAULT 0,
      last_status INTEGER, last_error TEXT, updated_at TEXT,
      UNIQUE(provider, month));
    CREATE TABLE IF NOT EXISTS provider_errors (
      id INTEGER PRIMARY KEY AUTOINCREMENT, provider TEXT NOT NULL, status INTEGER,
      error_code TEXT, error_message TEXT, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS provider_quotas (
      provider TEXT PRIMARY KEY, monthly_free_quota INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS search_cache (
      cache_key TEXT PRIMARY KEY, provider TEXT NOT NULL, query_text TEXT NOT NULL,
      engine TEXT NOT NULL DEFAULT '', results_json TEXT NOT NULL, expires_at REAL NOT NULL, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS paid_search_reservations (
      id INTEGER PRIMARY KEY AUTOINCREMENT, provider TEXT NOT NULL, month TEXT NOT NULL,
      query_hash TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'reserved', created_at TEXT NOT NULL,
      completed_at TEXT NOT NULL DEFAULT '', task_id TEXT NOT NULL DEFAULT '');
    CREATE INDEX IF NOT EXISTS idx_paid_search_reservations_month ON paid_search_reservations(month,status);
    CREATE TABLE IF NOT EXISTS search_engine_performance (
      engine TEXT PRIMARY KEY, calls INTEGER NOT NULL DEFAULT 0,
      parsed_results INTEGER NOT NULL DEFAULT 0, qualified_leads INTEGER NOT NULL DEFAULT 0,
      errors INTEGER NOT NULL DEFAULT 0, last_status TEXT NOT NULL DEFAULT '', updated_at TEXT NOT NULL DEFAULT '');
    CREATE TABLE IF NOT EXISTS lead_evidence (
      id INTEGER PRIMARY KEY AUTOINCREMENT, domain TEXT NOT NULL, evidence_type TEXT NOT NULL,
      evidence_text TEXT NOT NULL, source_url TEXT NOT NULL, observed_at TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_lead_evidence_domain ON lead_evidence(domain);
    CREATE TABLE IF NOT EXISTS lead_contact_evidence (
      id INTEGER PRIMARY KEY AUTOINCREMENT, domain TEXT NOT NULL,
      contact_type TEXT NOT NULL, contact_value TEXT NOT NULL,
      raw_value TEXT NOT NULL DEFAULT '', source_url TEXT NOT NULL,
      source_channel TEXT NOT NULL DEFAULT '官网', observed_at TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT '未核实', validation_json TEXT NOT NULL DEFAULT '{}'
    );
    CREATE INDEX IF NOT EXISTS idx_lead_contact_domain ON lead_contact_evidence(domain);
    CREATE TABLE IF NOT EXISTS lead_duplicate_reviews (
      id INTEGER PRIMARY KEY AUTOINCREMENT, domain_a TEXT NOT NULL, domain_b TEXT NOT NULL,
      reason TEXT NOT NULL, status TEXT NOT NULL DEFAULT '待人工审核', created_at TEXT NOT NULL,
      UNIQUE(domain_a, domain_b, reason)
    );
    """)
    reservation_cols={row[1] for row in con.execute('PRAGMA table_info(paid_search_reservations)')}
    if 'task_id' not in reservation_cols:
        con.execute("ALTER TABLE paid_search_reservations ADD COLUMN task_id TEXT NOT NULL DEFAULT ''")
    con.execute('CREATE INDEX IF NOT EXISTS idx_paid_search_reservations_task ON paid_search_reservations(task_id)')
    # Migrate already-recorded paid API usage from older versions into the new shared monthly ledger.
    month = _dt.datetime.now().strftime("%Y-%m")
    try:
        existing = con.execute("SELECT COUNT(*) FROM paid_search_reservations WHERE month=?", (month,)).fetchone()[0]
        if int(existing or 0) == 0:
            legacy = con.execute("SELECT provider,calls,updated_at FROM provider_usage WHERE month=?", (month,)).fetchall()
            for provider, calls, updated_at in legacy:
                for _ in range(max(0, int(calls or 0))):
                    con.execute("INSERT INTO paid_search_reservations(provider,month,query_hash,status,created_at,completed_at) VALUES(?,?,?,?,?,?)",
                                (provider, month, "legacy-provider-usage", "legacy", updated_at or _dt.datetime.now().isoformat(timespec="seconds"), updated_at or ""))
    except sqlite3.Error:
        pass
    con.commit(); con.close()


def record_provider_call(db_path: str, provider: str, ok: bool, result_count: int = 0,
                         status: int | None = None, error_code: str = "", error_message: str = "") -> None:
    month = _dt.datetime.now().strftime("%Y-%m")
    now = _dt.datetime.now().isoformat(timespec="seconds")
    con = sqlite3.connect(db_path)
    con.execute("""INSERT INTO provider_usage(provider,month,calls,successes,errors,results,last_status,last_error,updated_at)
      VALUES(?,?,1,?,?,?,?,?,?) ON CONFLICT(provider,month) DO UPDATE SET
      calls=calls+1,successes=successes+excluded.successes,errors=errors+excluded.errors,
      results=results+excluded.results,last_status=excluded.last_status,last_error=excluded.last_error,updated_at=excluded.updated_at""",
      (provider, month, int(ok), int(not ok), int(result_count), status, (error_message or "")[:240], now))
    if not ok:
        con.execute("INSERT INTO provider_errors(provider,status,error_code,error_message,created_at) VALUES(?,?,?,?,?)",
                    (provider, status, (error_code or "")[:80], (error_message or "")[:240], now))
    con.commit(); con.close()


def provider_usage(db_path: str, provider: str | None = None) -> list[dict]:
    con = sqlite3.connect(db_path); con.row_factory = sqlite3.Row
    if provider:
        rows = con.execute("SELECT * FROM provider_usage WHERE provider=? ORDER BY month DESC", (provider,)).fetchall()
    else:
        rows = con.execute("SELECT * FROM provider_usage ORDER BY month DESC,provider", ()).fetchall()
    con.close(); return [dict(r) for r in rows]



def set_provider_quota(db_path: str, provider: str, quota: int) -> None:
    quota=max(0,int(quota)); now=_dt.datetime.now().isoformat(timespec="seconds")
    con=sqlite3.connect(db_path)
    con.execute("INSERT INTO provider_quotas(provider,monthly_free_quota,updated_at) VALUES(?,?,?) ON CONFLICT(provider) DO UPDATE SET monthly_free_quota=excluded.monthly_free_quota,updated_at=excluded.updated_at",(provider,quota,now))
    con.commit(); con.close()


def get_provider_quotas(db_path: str) -> dict:
    con=sqlite3.connect(db_path)
    rows=con.execute("SELECT provider,monthly_free_quota FROM provider_quotas").fetchall()
    con.close(); return {p:q for p,q in rows}


def _normalize(items, provider):
    out, seen = [], set()
    for item in items or []:
        if not isinstance(item, dict):
            continue
        url = str(item.get("link") or item.get("url") or "").strip()
        title = str(item.get("title") or "").strip()
        if not url.startswith(("http://", "https://")) or len(title) < 2:
            continue
        host = (urlparse(url).hostname or "").lower()
        host = host[4:] if host.startswith("www.") else host
        if not host or host in seen:
            continue
        seen.add(host); out.append((url, title))
    return out


def search_serpapi(query: str, api_key: str, max_results: int = 20, session=None, engine: str = "google"):
    if not api_key:
        raise ValueError("SerpApi 尚未配置 API Key")
    s = session or requests.Session()
    r = s.get("https://serpapi.com/search.json", params={"engine":engine, "q":query,
                 "api_key":api_key, "gl":"cn", "hl":"zh-cn", "num":min(max_results,100)}, timeout=(8,20))
    if r.status_code >= 400:
        raise ProviderError("serpapi", r.status_code, "HTTP_ERROR", f"SerpApi HTTP {r.status_code}")
    data = r.json()
    if data.get("error"):
        raise ProviderError("serpapi", 200, "API_ERROR", "SerpApi 返回 API 错误")
    return _normalize(data.get("organic_results", []), "serpapi")[:max_results], r.status_code


def search_brave(query: str, api_key: str, max_results: int = 20, session=None):
    if not api_key:
        raise ValueError("Brave Search 尚未配置 API Key")
    s = session or requests.Session()
    r = s.get("https://api.search.brave.com/res/v1/web/search", headers={"Accept":"application/json", "X-Subscription-Token":api_key},
              params={"q":query, "count":min(max_results,20), "country":"CN", "search_lang":"zh-hans"}, timeout=(8,20))
    if r.status_code >= 400:
        raise ProviderError("brave", r.status_code, "HTTP_ERROR", f"Brave Search HTTP {r.status_code}")
    data = r.json()
    web = data.get("web", {}) if isinstance(data, dict) else {}
    return _normalize(web.get("results", []), "brave")[:max_results], r.status_code


class ProviderError(RuntimeError):
    def __init__(self, provider, status, code, message):
        super().__init__(message); self.provider=provider; self.status=status; self.code=code


def _cache_key(provider: str, query: str, engine: str) -> str:
    import hashlib
    return hashlib.sha256(f"{provider}\0{engine}\0{query.strip().lower()}".encode("utf-8")).hexdigest()


def _read_search_cache(db_path: str, provider: str, query: str, engine: str):
    key=_cache_key(provider,query,engine)
    con=sqlite3.connect(db_path)
    try:
        row=con.execute("SELECT results_json FROM search_cache WHERE cache_key=? AND expires_at>?",(key,time.time())).fetchone()
        return json.loads(row[0]) if row else None
    finally: con.close()


def _write_search_cache(db_path: str, provider: str, query: str, engine: str, rows):
    key=_cache_key(provider,query,engine); now=_dt.datetime.now().isoformat(timespec="seconds")
    con=sqlite3.connect(db_path)
    try:
        con.execute("INSERT OR REPLACE INTO search_cache(cache_key,provider,query_text,engine,results_json,expires_at,created_at) VALUES(?,?,?,?,?,?,?)",
          (key,provider,query,engine,json.dumps(rows,ensure_ascii=False),time.time()+7*86400,now))
        con.commit()
    finally: con.close()


def _within_local_quota(db_path: str, provider: str) -> bool:
    con=sqlite3.connect(db_path)
    try:
        row=con.execute("SELECT monthly_free_quota FROM provider_quotas WHERE provider=?",(provider,)).fetchone()
        quota=int(row[0]) if row else 0
        if quota<=0: return True
        month=_dt.datetime.now().strftime("%Y-%m")
        usage=con.execute("SELECT calls FROM provider_usage WHERE provider=? AND month=?",(provider,month)).fetchone()
        calls=int(usage[0]) if usage else 0
        return calls < quota
    finally: con.close()


def _reserve_paid_search_call(diagnostics: dict, limit: int = PAID_TASK_DEFAULT_CAP) -> bool:
    """Reserve one paid API request from the shared per-task budget. Failed calls count too."""
    budget = diagnostics.setdefault("_paid_search_budget", {"limit": int(limit), "used": 0})
    budget.setdefault("limit", int(limit)); budget.setdefault("used", 0)
    # The hard ceiling cannot be raised by a stale or edited UI setting.
    budget["limit"] = min(PAID_TASK_DEFAULT_CAP, max(0, int(budget.get("limit", limit))))
    if int(budget.get("used", 0)) >= budget["limit"]:
        budget["blocked"] = True
        return False
    budget["used"] = int(budget.get("used", 0)) + 1
    return True


def _reserve_monthly_paid_call(db_path: str, provider: str, query: str,
                               monthly_cap: int = PAID_MONTHLY_HARD_CAP,
                               task_id: str = '', task_cap: int = PAID_TASK_DEFAULT_CAP) -> int | None:
    """Atomically reserve a request against persistent monthly and per-task caps."""
    month = _dt.datetime.now().strftime('%Y-%m')
    now = _dt.datetime.now().isoformat(timespec='seconds')
    query_hash = hashlib.sha256(str(query).encode('utf-8')).hexdigest()
    con = sqlite3.connect(db_path, timeout=20)
    try:
        con.execute('BEGIN IMMEDIATE')
        used = con.execute('SELECT COUNT(*) FROM paid_search_reservations WHERE month=?', (month,)).fetchone()[0]
        if int(used) >= max(0, int(monthly_cap)):
            con.rollback(); return None
        if task_id:
            task_used=con.execute('SELECT COUNT(*) FROM paid_search_reservations WHERE task_id=?',(str(task_id),)).fetchone()[0]
            if int(task_used)>=max(0,int(task_cap)):
                con.rollback(); return None
        cur = con.execute('INSERT INTO paid_search_reservations(provider,month,query_hash,status,created_at,task_id) VALUES(?,?,?,?,?,?)',
                          (provider, month, query_hash, 'reserved', now, str(task_id or '')))
        con.commit(); return int(cur.lastrowid)
    finally:
        con.close()


def paid_task_usage(db_path: str, task_id: str) -> int:
    if not task_id: return 0
    con=sqlite3.connect(db_path,timeout=10)
    try:
        return int(con.execute('SELECT COUNT(*) FROM paid_search_reservations WHERE task_id=?',(str(task_id),)).fetchone()[0] or 0)
    finally: con.close()


def _finish_monthly_paid_call(db_path: str, reservation_id: int | None, status: str) -> None:
    if not reservation_id:
        return
    now = _dt.datetime.now().isoformat(timespec='seconds')
    con = sqlite3.connect(db_path, timeout=10)
    try:
        con.execute('UPDATE paid_search_reservations SET status=?,completed_at=? WHERE id=?',
                    (str(status)[:24], now, int(reservation_id)))
        con.commit()
    finally:
        con.close()


def paid_monthly_usage(db_path: str) -> int:
    month = _dt.datetime.now().strftime('%Y-%m')
    con = sqlite3.connect(db_path, timeout=10)
    try:
        row = con.execute('SELECT COUNT(*) FROM paid_search_reservations WHERE month=?', (month,)).fetchone()
        return int(row[0] or 0)
    finally:
        con.close()


def search_providers(query: str, max_results: int, diagnostics: dict, db_path: str,
                     keys: dict, session=None, serpapi_engine: str = "google",
                     paid_call_limit: int = PAID_TASK_DEFAULT_CAP) -> list[tuple[str,str]]:
    """Use paid providers only for a free-search gap, with one shared hard per-task cap."""
    merged, seen = [], set()
    for provider, fn in (("serpapi", search_serpapi), ("brave", search_brave)):
        key = (keys or {}).get(provider, "")
        if not key:
            diagnostics.setdefault(provider, {"configured":False,"calls":0,"errors":0,"last_error":"未配置"})
            continue
        d = diagnostics.setdefault(provider, {"configured":True,"calls":0,"errors":0,"last_error":""})
        d["configured"] = True
        if d.get("blocked"):
            continue
        engine=serpapi_engine if provider=="serpapi" else "brave"
        cached=_read_search_cache(db_path,provider,query,engine)
        if cached is not None:
            d["cache_hits"]=d.get("cache_hits",0)+1
            for url,title in cached:
                host=(urlparse(url).hostname or "").lower()
                if host and host not in seen:
                    seen.add(host); merged.append((url,title))
                    if len(merged)>=max_results: return merged
            continue
        if not _within_local_quota(db_path,provider):
            d["last_error"]="达到本机设置的月调用额度上限"
            d["quota_blocked"]=True
            continue
        if not _reserve_paid_search_call(diagnostics, paid_call_limit):
            d["last_error"]="本任务付费搜索上限已达到（SerpApi + Brave 合计最多 20 次）"
            d["task_budget_blocked"] = True
            break
        task_id=str(diagnostics.get('_task_id') or '')
        reservation_id = _reserve_monthly_paid_call(db_path, provider, query, PAID_MONTHLY_HARD_CAP, task_id=task_id, task_cap=PAID_TASK_DEFAULT_CAP)
        if reservation_id is None:
            budget=diagnostics.setdefault("_paid_search_budget", {})
            budget["monthly_used"] = paid_monthly_usage(db_path)
            budget["monthly_limit"] = PAID_MONTHLY_HARD_CAP
            if task_id and paid_task_usage(db_path,task_id)>=PAID_TASK_DEFAULT_CAP:
                d["last_error"] = f"本任务已达到持久化付费搜索上限（{PAID_TASK_DEFAULT_CAP} 次）；已停止付费请求"
                d["task_budget_blocked"] = True
            else:
                d["last_error"] = f"本月 SerpApi + Brave 合计付费搜索保护上限已达到（{PAID_MONTHLY_HARD_CAP} 次）；已停止付费请求"
                d["monthly_budget_blocked"] = True
            # No HTTP request was made, so do not count this as a task-level API attempt.
            budget["used"] = max(0, int(budget.get("used", 0)) - 1)
            break
        d["calls"] += 1
        try:
            rows, status = (fn(query, key, max_results=max_results, session=session, engine=serpapi_engine) if provider == "serpapi" else fn(query, key, max_results=max_results, session=session))
            _finish_monthly_paid_call(db_path, reservation_id, 'success')
            _write_search_cache(db_path,provider,query,engine,rows)
            record_provider_call(db_path, provider, True, len(rows), status)
            d["results"] = d.get("results",0) + len(rows); d["status"] = status
            for url, title in rows:
                host=(urlparse(url).hostname or "").lower()
                if host and host not in seen:
                    seen.add(host); merged.append((url,title))
                    if len(merged) >= max_results: return merged
        except Exception as exc:
            status = getattr(exc,"status",None); code=getattr(exc,"code",type(exc).__name__)
            # Never persist exception text that might contain request URLs or credentials.
            safe_message = str(exc)[:180] if isinstance(exc, ProviderError) else ("响应格式或配置错误" if isinstance(exc, ValueError) else type(exc).__name__)
            _finish_monthly_paid_call(db_path, reservation_id, 'failed')
            record_provider_call(db_path, provider, False, 0, status, str(code), safe_message)
            d["errors"] += 1; d["status"] = status or 0; d["last_error"] = safe_message
            if status in (401,403,429): d["blocked"] = True
    budget = diagnostics.get("_paid_search_budget", {})
    monthly_used = paid_monthly_usage(db_path)
    budget["monthly_used"] = monthly_used
    budget["monthly_limit"] = PAID_MONTHLY_HARD_CAP
    diagnostics.setdefault("provider_orchestration", {})["paid_search_budget"] = {
        "limit": min(PAID_TASK_DEFAULT_CAP, int(budget.get("limit", paid_call_limit))),
        "used": int(budget.get("used", 0)),
        "remaining": max(0, min(PAID_TASK_DEFAULT_CAP, int(budget.get("limit", paid_call_limit))) - int(budget.get("used", 0))),
        "monthly_limit": PAID_MONTHLY_HARD_CAP,
        "monthly_used": monthly_used,
        "monthly_remaining": max(0, PAID_MONTHLY_HARD_CAP-monthly_used),
    }
    return merged


def evidence_score(items: list[dict], allowed_types: set[str]) -> int:
    """Score only attributable evidence items with a valid source URL; max 100."""
    weights = {"factory":35,"export":35,"contact":30,"certificate":15,"product":10,"role":10}
    seen, total = set(), 0
    for item in items or []:
        if not isinstance(item, dict): continue
        kind=str(item.get("type", "")); url=str(item.get("source_url", ""))
        if kind not in allowed_types or not url.startswith(("http://","https://")): continue
        key=(kind,url,item.get("text",""))
        if key in seen: continue
        seen.add(key); total += weights.get(kind,5)
    return min(100,total)


def score_three_dimensions(factory_evidence: list[dict], export_evidence: list[dict], contact_evidence: list[dict]) -> dict:
    return {
      "factory_authenticity_score": evidence_score(factory_evidence, {"factory","certificate","product"}),
      "export_capability_score": evidence_score(export_evidence, {"export","certificate","product"}),
      "contact_evidence_score": evidence_score(contact_evidence, {"contact","role"}),
    }


def record_engine_search(db_path: str, engine: str, parsed_results: int = 0, error: bool = False, status: str = "") -> None:
    """Persist public-engine availability and parse yield; never stores query secrets."""
    now=_dt.datetime.now().isoformat(timespec="seconds")
    con=sqlite3.connect(db_path)
    con.execute("""INSERT INTO search_engine_performance(engine,calls,parsed_results,qualified_leads,errors,last_status,updated_at)
      VALUES(?,1,?,?,?, ?,?) ON CONFLICT(engine) DO UPDATE SET
      calls=calls+1, parsed_results=parsed_results+excluded.parsed_results,
      errors=errors+excluded.errors,last_status=excluded.last_status,updated_at=excluded.updated_at""",
      (engine,max(0,int(parsed_results)),0,int(bool(error)),str(status)[:120],now))
    con.commit(); con.close()


def record_engine_qualification(db_path: str, engine: str, qualified: bool) -> None:
    if not engine or not qualified: return
    con=sqlite3.connect(db_path)
    con.execute("UPDATE search_engine_performance SET qualified_leads=qualified_leads+1 WHERE engine=?",(engine,))
    con.commit(); con.close()


def search_engine_performance(db_path: str) -> list[dict]:
    con=sqlite3.connect(db_path); con.row_factory=sqlite3.Row
    rows=[dict(x) for x in con.execute("SELECT * FROM search_engine_performance ORDER BY engine").fetchall()]
    con.close(); return rows


def rank_search_engines(db_path: str, default_order: list[str]) -> list[str]:
    """Rank by real downstream qualified leads first, then parse yield and error rate."""
    stats={x['engine']:x for x in search_engine_performance(db_path)}
    def score(name):
        row=stats.get(name)
        if not row or not row['calls']: return (0,0,0)
        calls=max(1,row['calls'])
        return (row['qualified_leads']/calls, row['parsed_results']/calls, -row['errors']/calls)
    indexed={name:i for i,name in enumerate(default_order)}
    return sorted(default_order,key=lambda name:(score(name),-indexed[name]),reverse=True)
