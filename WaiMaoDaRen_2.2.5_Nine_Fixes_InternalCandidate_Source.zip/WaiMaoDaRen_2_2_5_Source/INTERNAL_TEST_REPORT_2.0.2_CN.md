# FactoryLead 2.0.2 内部开发测试报告

日期：2026-11-06

## 本轮完成
- 修复 `start()` 中 `selected_industry` 局部变量未定义问题，并增加启动异常日志。
- 更新 `run_factorylead.bat`：Python 3.10+ 检查、.venv 创建、依赖安装、启动错误提示；修正批处理括号内错误码展开风险。
- 搜索全部细分行业改为当前选中大类下每个细分行业一条精简查询。
- 细分行业变更时关键词框只填英文核心词；支持分号追加具体产品名。
- 单行业查询精简；中文查询通过 SerpApi Baidu engine，英文查询通过 Google engine。
- API 结果缓存7天；本地月额度可限制 API 调用；女性负责人辅助搜索默认关闭。
- 修复 CSV/Excel 公式注入；过滤图片文件名、Sentry/Wixpress监控邮箱。
- 核验失败/受限不覆盖旧记录；空联系方式不覆盖数据库旧联系方式；单条保存失败不会中止整批。
- 移除全局 TIMEOUT 临时修改，改为扫描函数参数传递。
- 官网页面读取上限3MB，sitemap上限2MB；历史证据改为批量加载；避免重复追加证据说明。
- 导入目录时保留内置补充行业。
- 中国大陆 WhatsApp 标签号码仅接受明确+86/0086前缀的合规手机格式；排除400/800、座机/传真；非中国 WhatsApp 仍需明确来源证据。
- ZIP 整理为单层目录结构、ASCII 文件名，不包含开发用 SQLite 数据库。

## 验证结果
- `python -m py_compile app.py api_services.py tests/test_factorylead.py tests/test_api_services.py`：通过。
- `python -m unittest discover -s tests -v`：**69/69 通过**。
- Linux/Xvfb Tkinter GUI 主窗口启动冒烟：通过。
- 搜索计划样本：当前默认大类“农副食品加工业”包含25个细分行业，生成25条查询，当前默认大类示例最长10个空格分词单元；符合一行业一查询。
- ZIP 完整性：打包后执行 testzip，预期逐包核验。

## 尚未通过 / 未执行
- 当前容器无法读取用户 Windows DPAPI 本机密钥；真实 SerpApi/Brave API 认证与在线搜索未执行。
- Windows 10 实机启动、BAT 在用户电脑的运行、真实官网抓取与 WhatsApp/邮箱命中率未验收。
- 因此本包只能称为“内部测试候选”，不能称为正式稳定版。
