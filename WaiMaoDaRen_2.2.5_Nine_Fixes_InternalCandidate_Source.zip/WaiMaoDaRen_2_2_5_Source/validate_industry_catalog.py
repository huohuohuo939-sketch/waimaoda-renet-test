"""Strict structural validator for the FactoryLead 31/176/607 taxonomy."""
from __future__ import annotations
import csv
from pathlib import Path

EXPECTED = {'大类代码': 31, '中类代码': 176, '细分行业代码': 607}
REQUIRED = {
    '大类代码', '大类', '中类代码', '中类', '细分行业代码', '细分行业',
    '英文核心词', '英文制造商搜索组合', '英文OEM_ODM搜索组合',
    '官网_LinkedIn搜索组合', '中文搜索组合', '排除词',
}


def validate_rows(rows: list[dict], expected: dict[str, int] | None = None) -> list[str]:
    expected = expected or EXPECTED
    errors: list[str] = []
    if not rows:
        return ['词库为空']
    missing = REQUIRED - set(rows[0])
    if missing:
        return [f'缺少字段：{", ".join(sorted(missing))}']
    for code_field, count in expected.items():
        found = {str(r.get(code_field, '')).strip() for r in rows if str(r.get(code_field, '')).strip()}
        if len(found) != count:
            errors.append(f'{code_field}数量应为{count}，实际{len(found)}')
    def consistent_mapping(code_field, name_field, parent_field=None):
        mapping = {}
        for r in rows:
            code = str(r.get(code_field, '')).strip()
            value = (str(r.get(name_field, '')).strip(),
                     str(r.get(parent_field, '')).strip() if parent_field else '')
            if code in mapping and mapping[code] != value:
                errors.append(f'{code_field} {code} 对应名称或父级不一致')
                break
            mapping[code] = value
        return mapping
    major_map = consistent_mapping('大类代码', '大类')
    mid_map = consistent_mapping('中类代码', '中类', '大类代码')
    small_map = consistent_mapping('细分行业代码', '细分行业', '中类代码')
    small_codes = [str(r.get('细分行业代码', '')).strip() for r in rows]
    if len(small_codes) != len(set(small_codes)):
        errors.append('细分行业代码存在重复记录')
    for r in rows:
        for f in ('大类', '中类', '细分行业', '英文核心词', '英文制造商搜索组合',
                  '英文OEM_ODM搜索组合', '官网_LinkedIn搜索组合', '中文搜索组合', '排除词'):
            if not str(r.get(f, '')).strip():
                errors.append(f'字段{f}存在空值')
                break
    for code, (_, parent) in mid_map.items():
        if parent not in major_map:
            errors.append(f'中类{code}关联的大类代码不存在：{parent}')
            break
    for code, (_, parent) in small_map.items():
        if parent not in mid_map:
            errors.append(f'细分行业{code}关联的中类代码不存在：{parent}')
            break
    english_core = [str(r.get('英文核心词', '')).strip().casefold() for r in rows]
    if len(english_core) != len(set(english_core)):
        errors.append('英文核心词存在重复，需区分行业产品表达')
    for r in rows:
        maker_value = str(r.get('英文制造商搜索组合', '')).casefold()
        if not any(term in maker_value for term in ('manufacturer', 'factory', 'plant', 'supplier', 'producer', 'company', 'mill', 'slaughterhouse', 'processing', 'foundry')):
            errors.append(f"细分行业{r.get('细分行业代码','')}缺少英文制造商/工厂搜索词")
            break
        oem_value = str(r.get('英文OEM_ODM搜索组合', '')).strip().casefold()
        if not any(marker in oem_value for marker in ('不适用', '按需', '不统一套', '按具体')) and not (('oem' in oem_value and any(marker in oem_value for marker in ('odm', 'private label'))) or any(marker in oem_value for marker in ('cdmo', 'contract manufacturer', 'foundry'))):
            errors.append(f"细分行业{r.get('细分行业代码','')}缺少OEM/ODM搜索组合且未标注不适用")
            break
        if 'site:linkedin.com/company' not in str(r.get('官网_LinkedIn搜索组合', '')).casefold():
            errors.append(f"细分行业{r.get('细分行业代码','')}缺少LinkedIn公司页搜索组合")
            break
        for f in ('大类', '中类', '细分行业', '英文核心词', '英文制造商搜索组合',
                  '英文OEM_ODM搜索组合', '官网_LinkedIn搜索组合', '中文搜索组合', '排除词'):
            if not str(r.get(f, '')).strip():
                errors.append(f'字段{f}存在空值'); break
    return errors


def validate_csv(path: Path) -> list[str]:
    with path.open('r', encoding='utf-8-sig', newline='') as f:
        return validate_rows(list(csv.DictReader(f)))

if __name__ == '__main__':
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument('csv_path', type=Path)
    a = p.parse_args()
    issues = validate_csv(a.csv_path)
    if issues:
        print('FAILED')
        print('\n'.join(issues))
        raise SystemExit(1)
    print('PASS: 31/176/607; OEM/ODM rows contain a valid OEM/private-label/CDMO/foundry pattern or an explicit conditional note')
