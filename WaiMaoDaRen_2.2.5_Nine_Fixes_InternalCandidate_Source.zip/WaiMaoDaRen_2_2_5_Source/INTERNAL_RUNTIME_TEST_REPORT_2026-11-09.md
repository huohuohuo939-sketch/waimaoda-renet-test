# WaiMaoDaRen 2.1.0 - Internal Runtime Test Report

Date: 2026-11-09
Scope: Existing 2.1.0 source package; no redesign and no production database used.

## Verified in this execution environment

1. Python source compilation: PASS (`python -m compileall -q app.py api_services.py tests`).
2. Offline regression suite: PASS, 86/86 tests.
3. Desktop UI bootstrap: PASS under Linux Xvfb; Tk window created, 609 catalog rows loaded, 14 result columns created, main loop entered and exited cleanly.
4. Local end-to-end discovery fixture: PASS. The application worker was run with a controlled local search-result fixture; it fetched the homepage and contact page, extracted a public email and explicitly labelled WhatsApp URL/number, saved the company plus contact/evidence records into a separate temporary SQLite database, updated the UI result row, and generated the expected three-column export data.
5. Local end-to-end pasted-URL verification: PASS after repairing a runtime defect. It fetched a local homepage/contact page, persisted one lead and three contact-evidence records, updated the UI status, and generated the three-column export data.
6. Windows launcher encoding: both `run_factorylead.bat` and `build_exe.bat` rewritten as ASCII, without UTF-8 BOM, with CRLF line endings. The original launchers had UTF-8 BOM and LF-only line endings; Windows CMD can display the BOM as garbled command text (matching the reported `锘緻echo` error).
7. Runtime defect repaired: `worker_verify()` referenced an undefined `diagnostics` variable after saving results. Added a regression test; now 86/86 tests pass.
8. Startup error logging repaired: `run_application()` treated a string path as a Path object when writing `factorylead_error.log`.

## Not verified; must not be represented as passed

1. Real external search from this execution environment: DNS resolution failed for Bing, DuckDuckGo, Baidu, SerpApi, and Brave hosts. Therefore no genuine search-engine results or live external company websites were collected by the app in this run.
2. Windows 10 native launch: this environment is Linux. Xvfb verifies Tk startup only, not native Windows CMD/Python behavior. The corrected batch files were byte-checked, not executed on Windows.
3. Authenticated SerpApi/Brave calls: no user API keys were available. Provider orchestration/parsing/quota behavior is covered by mocked offline tests only; account authentication and real quota behavior are unverified.
4. Large-scale collection, live accuracy, and production-volume throughput are not tested.

## Scope note

The existing 2.1.0 UI still contains the older women-in-export-contact workflow and defaults that mode on. This does not fully match the later manufacturer-first FactoryLead 2.0 direction. It is recorded as a scope mismatch, not silently treated as resolved.

## Test boundary

The local HTTP fixture proves the program's page-fetching, parsing, persistence, and export path under controlled conditions. It is not evidence of successful Internet search, API authentication, or Windows-native operation.
