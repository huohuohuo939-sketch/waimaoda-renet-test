# 外贸达人 2.1.9 启动器路径修复

## 修复原因
2.1.8 在部分 Windows 解压/启动场景中，启动器执行 pip 时未能稳定定位 `requirements.txt`，导致虚拟环境创建后依赖安装失败。

## 修复内容
- 启动器使用批处理文件自身所在目录构造 `requirements.txt`、`app.py`、`.venv` 的绝对路径。
- 启动前检查 `requirements.txt` 和 `app.py` 是否存在，并输出实际应用目录及期望文件路径。
- pip 安装依赖时使用 requirements.txt 绝对路径。
- 启动应用时使用 app.py 绝对路径。
- EXE 构建脚本同样改为绝对路径，并更新构建输出名称为 2.1.9。
- 保留 2.1.8 的完整导出、公司地址归属、去重及英文关键词轮换功能。

## 验收边界
本修复针对用户截图中的 `No such file or directory: requirements.txt`。开发环境已检查压缩包内文件结构、启动脚本路径引用和 Python 源码编译；仍需用户 Windows 电脑首次启动验证。
