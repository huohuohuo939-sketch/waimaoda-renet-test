# FactoryLead 2.0.4 新英文词库替换内测结果

## 词库实测结构
- 新上传 CSV 清理重复表头后：607 条有效行业记录。
- 与 FactoryLead 核心目录按四位细分代码匹配：607/607 全部匹配，无缺失代码、无额外代码。
- 核心目录保持 31 大类、176 中类、607 细分行业；另保留 2 条独立补充目录。
- 87 条 OEM/ODM 项明确标注“不适用”；其他按需/按具体产品/不统一套等说明保留，不自动补词。
- 新词库首行稻谷加工现已使用：`rice mill; rice milling plant`。

## 查询生成实测（离线生成计划，不是联网采集）
稻谷加工单行业生成 6 条：
1. `"rice mill" manufacturer China`
2. `"rice milling plant" supplier China`
3. `"rice processing factory" China`
4. `site:linkedin.com/company "rice mill" China`
5. `"rice milling" China company official website`
6. `"稻谷加工厂" (制造商 OR 工厂 OR 生产厂家) China`

宠物饲料加工单行业生成 9 条，其中包含 OEM、ODM、private label 组合。
当前大类“农副食品加工业”生成 25 条，与该类 25 个细分行业对应。
跨 31 个大类累计生成 609 条查询，覆盖 607 个核心细分代码和 2 个补充代码；重复行业名称通过四位代码区分。

## 自动化验证
- `validate_industry_catalog.py industry_catalog.csv`：通过。
- `python -m py_compile app.py api_services.py tests/test_factorylead.py tests/test_api_services.py validate_industry_catalog.py`：通过。
- `python -m unittest discover -s tests -v`：74/74 通过。

## 边界
- 查询生成验证是本地离线测试，不代表搜索引擎真实联网成功。
- 未使用真实 SerpApi / Brave Key 做账户认证。
- 未完成 Windows 10 实机启动和真实采集验收。
- 因此当前仍为内部测试候选，不是正式稳定版。
