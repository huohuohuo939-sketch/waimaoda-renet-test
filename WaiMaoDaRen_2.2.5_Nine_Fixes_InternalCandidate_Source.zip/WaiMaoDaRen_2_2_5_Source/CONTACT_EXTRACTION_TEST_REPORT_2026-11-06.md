# FactoryLead 联系方式提取内测报告

日期：2026-11-06  
测试基线：FactoryLead 2.0.1（已核验英文词库内部候选）  
范围：公开企业官网联系页面中的邮箱、WhatsApp 链接及明确标注 WhatsApp 的号码。

## 1. 测试结论

- 联系方式解析器：7/7 个跨行业 HTML 测试样本均提取到公开邮箱和明确标注的 WhatsApp 联系方式（WhatsApp 链接或带 WhatsApp 标签的号码）。
- 来源证据：测试样本中的邮箱和 WhatsApp 结果均保留对应来源页面 URL。
- 重复号码：发现同一号码可能同时以 `+86...` 与纯数字形式保存；已修复，按数字部分归一化去重，不自行补国家区号。
- 自动化回归：61/61 通过；`py_compile` 通过。
- 搜索 API 实际调用：未完成。当前执行环境的 SerpApi、Brave 两个 API Key 均未配置，软件主搜索流程按设计返回0条并明确记录“未配置”，没有偷偷切换到旧搜索引擎。
- 真实网站直连抓取：当前开发容器 DNS 解析失败，无法直接从目标官网拉取原始 HTML；因此本轮解析器样本是依据公开搜索索引所呈现的联系页内容构造的 HTML 测试样本，不应描述为软件已完成7家官网实时抓取。

## 2. 跨行业样本

| 行业 | 公开页面样本 | 测试中发现的联系方式 | 测试结果 |
|---|---|---|---|
| 工程机械 | https://yugongcompany.com/contact-us/ | factory@yugongmachine.com；页面明确标注 WhatsApp/Tel | 邮箱、WhatsApp解析通过 |
| 线缆机械 | https://www.cnwhmachine.com/contact-us | info@cnwhmachine.com；WhatsApp 链接和号码 | 邮箱、WhatsApp解析通过 |
| 鞋类制造 | https://www.chinashoefactory.com/contact-us/ | andy@chinashoefactory.com；WhatsApp号码及 wa.me 链接 | 邮箱、WhatsApp解析通过 |
| 小家电 | https://www.chengfei-appliance.com/contact-us | david@chengfei-appliance.com；页面标注 WhatsApp 号码 | 邮箱、WhatsApp解析通过 |
| 包装机械 | https://witymachinery.com/contact.html | wity@witymachine.com；WhatsApp号码 | 邮箱、WhatsApp解析通过 |
| 电气设备 | https://en.xintelectric.com/contact.html | wilson.wong@xintelectric.com；WeChat/WhatsApp号码 | 邮箱、WhatsApp解析通过 |
| 化工材料 | https://www.xresin.cn/en/contact.html | info@xresin.cn；WhatsApp号码 | 邮箱、WhatsApp解析通过 |

注：样本来自公开网页搜索结果/联系页内容，用于验证解析规则；不代表这些企业已由 FactoryLead API 搜索流程自动发现或完成官网真实性审查。

## 3. 本轮代码修正

1. 同一个公开电话号码若以国际格式和纯数字格式重复出现，按数字串归并，优先保留显式 `+` 国际格式。
2. WhatsApp 号码仍必须来自明确 WhatsApp 标签、WhatsApp 属性或 WhatsApp 链接；不会把普通电话自动认定为 WhatsApp。
3. 保留邮箱、电话、WhatsApp 的来源页面 URL。
4. 中国大陆 +86 WhatsApp号码必须符合 +86 后接11位手机号码（1开头，第二位3-9）；过滤400/800客服号码、座机及传真号码。非中国国际号码在有明确WhatsApp标签/链接时仍可保留。WhatsApp短链接（如 message/invite）可保留为链接，但不作为电话号码。
5. 新增专项回归测试，验证中国手机号码保留、400客服号和座机/传真号排除。
4. 不推测邮箱、不生成 WhatsApp 链接、不验证号码是否实际注册 WhatsApp。

## 4. 尚未通过的关键验收

要验证“行业词库 -> SerpApi/Brave 搜索 -> 官网候选 -> 官网/contact页抓取 -> 邮箱/WhatsApp提取 -> 来源证据保存”的完整链路，必须在目标 Windows 环境配置并成功认证至少一个搜索 API。

当前本地测试环境检测：

- SerpApi Key：未配置
- Brave Search Key：未配置
- `search_web("packaging machinery manufacturer China")`：0条候选；诊断为未配置 API Key，搜索调用数0
- 开发容器对样本官网的直接 HTTPS 请求：DNS解析失败

因此本轮不宣称搜索引擎真实联网采集已通过，也不将此内部候选标为稳定版。

## 5. 下一轮验收标准

- SerpApi 或 Brave 至少一个认证成功，真实返回候选官网。
- 至少覆盖机械、电子电气、包装、化工、鞋类、小家电等行业；每类记录搜索查询、候选域名、官网响应状态、扫描页面数。
- 分别统计邮箱命中率、明确 WhatsApp 命中率、只有普通电话的比例、无联系方式比例。
- 每个邮箱/WhatsApp 必须有可打开的来源 URL；重复项按域名和号码去重。
- 将贸易商、目录页、无关企业和错误行业结果单独统计，不与真实工厂混算。
- 对 robots.txt、HTTP 403/429、验证码、登录墙等情况尊重限制，不尝试绕过。
