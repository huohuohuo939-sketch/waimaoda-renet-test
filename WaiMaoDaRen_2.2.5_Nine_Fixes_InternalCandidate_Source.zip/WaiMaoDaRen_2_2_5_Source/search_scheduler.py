"""Round-based manufacturer search scheduler for WaiMaoDaRen / FactoryLead.

Each Chinese sub-industry is a complete round containing six search intents.
Progress is persisted locally so interrupted tasks can resume at the next query.
"""
from __future__ import annotations
import hashlib
import json
import os
import tempfile
from pathlib import Path
from typing import Iterable

INTENTS = (
    ("manufacturer", '"{term}" (manufacturer OR factory OR producer) {country}'),
    ("production", '"{term}" ("production facility" OR "production line" OR plant) {country}'),
    ("oem_odm", '"{term}" (OEM OR ODM) manufacturer {country}'),
    ("export", '"{term}" (exporter OR "export manufacturer" OR "international sales") {country}'),
    ("whatsapp_link", '"{term}" (site:wa.me OR site:api.whatsapp.com OR site:web.whatsapp.com) (manufacturer OR factory OR OEM) {country}'),
    ("whatsapp_cta", '"{term}" ("WhatsApp Us" OR "Chat on WhatsApp" OR "Contact via WhatsApp" OR "WhatsApp sales") (factory OR manufacturer) {country}'),
    ("whatsapp_contact", '"{term}" ("WhatsApp number" OR "WhatsApp contact" OR "WhatsApp: +" OR "WhatsApp +86") (supplier OR factory OR manufacturer) {country}'),
    ("contact", '"{term}" ("Contact Us" OR "sales contact" OR email OR inquiry) manufacturer {country}'),
)


def _split_terms(value: str) -> list[str]:
    return [x.strip() for x in str(value or "").replace("；", ";").split(";") if x.strip()]


def _split_english_phrases(value: str) -> list[str]:
    """Split synonym phrases in the English core-keyword field without splitting words."""
    raw = str(value or "").replace("；", ";")
    parts = []
    for group in raw.split(";"):
        # The curated vocabulary uses slash to separate alternative English phrases.
        parts.extend(x.strip(" ,|/") for x in group.split("/") if x.strip(" ,|/"))
    return list(dict.fromkeys(parts))


def build_rounds(catalog_rows: Iterable[dict], country: str = "China", *,
                 selected_category: str | None = None, selected_code: str | None = None,
                 all_categories: bool = False, extra_terms: str = "",
                 keyword_cycle: int = 0) -> list[dict]:
    """Build one full vocabulary pass, rotating the active English phrase per completed task."""
    rows = list(catalog_rows)
    if not all_categories:
        if selected_code:
            rows = [r for r in rows if str(r.get("细分行业代码", "")) == str(selected_code)]
        elif selected_category:
            rows = [r for r in rows if r.get("大类") == selected_category]
    extras = _split_terms(extra_terms)[:2]
    rounds = []
    seen_codes = set()
    for row in rows:
        code = str(row.get("细分行业代码", "")).strip()
        if not code or code in seen_codes:
            continue
        seen_codes.add(code)
        raw = row.get("新英文核心词") or row.get("英文核心词") or row.get("英文搜索关键词") or ""
        terms = _split_english_phrases(raw)
        if not terms:
            continue
        # Each complete task uses one synonym phrase per sub-industry. Once the
        # task completes, the next task advances the persistent cycle cursor.
        active_index = int(keyword_cycle) % len(terms)
        term = terms[active_index]
        if extras:
            term = " ".join([term] + extras)
        queries = []
        for intent, template in INTENTS:
            query = " ".join(template.format(term=term, country=(country or "China")).split())
            queries.append({
                "query": query,
                "intent": intent,
                "industry": row.get("细分行业", ""),
                "category": row.get("大类", ""),
                "industry_code": code,
                "keywords": "; ".join(terms + extras),
                "active_english_term": term,
                "keyword_cycle": int(keyword_cycle),
                "keyword_variant_index": active_index,
                "verified_english_terms": raw,
                "vocabulary_source": "industry_catalog.csv / core 607 taxonomy",
            })
        rounds.append({"industry_code": code, "industry": row.get("细分行业", ""),
                       "category": row.get("大类", ""), "keyword_cycle": int(keyword_cycle),
                       "active_english_term": term, "queries": queries})
    return rounds


def plan_signature(rounds: list[dict], country: str) -> str:
    payload = {"country": country, "rounds": [
        {"code": r["industry_code"], "queries": [q["query"] for q in r["queries"]]} for r in rounds
    ]}
    return hashlib.sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()


def progress_path() -> Path:
    root = os.environ.get("LOCALAPPDATA") or str(Path.home() / ".local" / "share")
    return Path(root) / "WaiMaoDaRen" / "search_progress.json"


def load_progress(path: str | Path | None = None) -> dict:
    target = Path(path) if path else progress_path()
    try:
        value = json.loads(target.read_text(encoding="utf-8"))
        if isinstance(value, dict):
            return value
    except (OSError, ValueError, TypeError):
        pass
    return {}


def save_progress(state: dict, path: str | Path | None = None) -> None:
    target = Path(path) if path else progress_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=".search_progress_", suffix=".tmp", dir=str(target.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False, indent=2)
            f.flush(); os.fsync(f.fileno())
        os.replace(tmp_name, target)
    finally:
        try:
            if os.path.exists(tmp_name): os.unlink(tmp_name)
        except OSError:
            pass


def flatten_rounds(rounds: list[dict]) -> list[dict]:
    flat = []
    for round_index, round_info in enumerate(rounds):
        for intent_index, item in enumerate(round_info["queries"]):
            flat.append({**item, "round_index": round_index,
                         "intent_index": intent_index, "round_total": len(rounds)})
    return flat


def performance_path() -> Path:
    root = os.environ.get("LOCALAPPDATA") or str(Path.home() / ".local" / "share")
    return Path(root) / "WaiMaoDaRen" / "search_keyword_performance.json"


def load_performance(path: str | Path | None = None) -> dict:
    target = Path(path) if path else performance_path()
    try:
        value = json.loads(target.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError, TypeError):
        return {}


def record_query_performance(query: str, new_domains: int, path: str | Path | None = None) -> None:
    """Persist yield observations; low-yield queries are deprioritized, never removed."""
    target = Path(path) if path else performance_path()
    data = load_performance(target)
    item = data.setdefault(query, {"calls": 0, "new_domains": 0})
    item["calls"] = int(item.get("calls", 0)) + 1
    item["new_domains"] = int(item.get("new_domains", 0)) + max(0, int(new_domains))
    item["last_new_domains"] = max(0, int(new_domains))
    save_progress(data, target)


def prioritize_rounds(rounds: list[dict], performance: dict | None = None) -> list[dict]:
    """Move historically productive intents earlier while retaining every query."""
    performance = performance or {}
    prioritized = []
    for round_info in rounds:
        queries = list(round_info["queries"])
        indexed = list(enumerate(queries))
        def score(pair):
            index, item = pair
            # WhatsApp-specific queries are deliberately front-loaded so the paid
            # provider's per-task cap is spent on the user's priority contact type.
            intent = item.get("intent", "")
            if intent.startswith("whatsapp"):
                return (-1, {"whatsapp_link": 0, "whatsapp_cta": 1, "whatsapp_contact": 2}.get(intent, 3), index)
            history = performance.get(item["query"], {})
            calls = int(history.get("calls", 0) or 0)
            if calls <= 0:
                return (1, 0.0, index)
            average = int(history.get("new_domains", 0) or 0) / calls
            return (0, -average, index)
        ordered = [item for _, item in sorted(indexed, key=score)]
        prioritized.append({**round_info, "queries": ordered})
    return prioritized
