# 外贸达人 2.5.3 历史分割与行业归档内部测试报告

## 测试基线

- 输入：用户上传的 2.5.2 制造商识别与 WhatsApp 质量修复候选版 ZIP。
- 本轮目标：当前任务与历史数据分离；历史统一归档到单个 SQLite 文件；每个任务的行业大类、细分行业、国家、任务编号与企业快照保持一致。

## 已执行修改

- `history_store.py`：旧归档表结构自动迁移；迁移前 SQLite 在线备份；任务元数据补齐；任务数/完成状态同步；历史分类筛选；旧归档幂等合并；v2 主库历史迁移标记。
- `app.py`：统一归档路径；旧程序目录归档复制/合并；历史窗口打开归档文件夹；Excel 导入只归档本次导入记录；版本显示更新至 2.5.3。
- 原企业主库 `factorylead.db` 不删除、不清空；旧历史归档源文件不删除。

## 自动化测试

- `python -m unittest discover -s tests -q`：70 项通过。
- `python -m compileall -q .`：通过。
- `python -m py_compile app.py history_store.py`：通过。
- 旧版归档数据库实测迁移：原 `(task_id, domain)` 主键升级为 `(task_id, domain, category, industry)`；原任务记录保留；生成 `.pre_category_sync.bak`；新任务可以继续写入。
- 新增回归测试：旧 schema 保留数据、任务元数据自动补齐、行业分类筛选同步、旧归档幂等合并、v1 迁移标记不阻断 v2 主库归档迁移、Excel 导入行业大类/细分行业/国家字段读取。

## 文件位置

Windows 主归档：`%LOCALAPPDATA%\\WaiMaoDaRen\\collection_history.db`

升级前备份：`%LOCALAPPDATA%\\WaiMaoDaRen\\collection_history.db.pre_category_sync.bak`

## 尚未完成的实机验收

当前环境没有用户 Windows 10 桌面会话，未能验证 Windows 实机首次启动、旧数据库迁移和 UI 显示。68 项测试通过不等于 Windows 实机验收通过。下一步需要在用户电脑验证历史窗口的分类列表、任务数量和新旧任务隔离；如果出现归档错误，检查 `%LOCALAPPDATA%\\WaiMaoDaRen\\history_archive_error.log`。
