# -*- coding: utf-8 -*-
"""Independent, persistent cross-task/cross-industry company identity registry.

The registry deliberately uses conservative identity rules: exact official root
-domain is a hard identity; exact normalized company name on another domain is
reported as a possible duplicate and is never silently merged.
"""
import os, re, sqlite3, time, html
from urllib.parse import urlparse


def normalize_name(value):
    value = html.unescape(re.sub(r'\s+', ' ', str(value or '')).strip()).lower()
    value = re.sub(r'https?://|www\.', ' ', value)
    value = re.sub(r'\b(official website|official site|homepage|官网|官方网站)\b', ' ', value, flags=re.I)
    value = re.sub(r'\s+(?:co\.?\s*,?\s*)?(?:ltd\.?|limited|inc\.?|corp\.?|corporation|company)$', '', value, flags=re.I)
    value = re.sub(r'[\s\-_,，。·.()（）\[\]【】]+', '', value)
    for suffix in ('有限责任公司','股份有限公司','有限公司','集团有限公司','集团'):
        while value.endswith(suffix) and len(value) > len(suffix) + 1:
            value = value[:-len(suffix)]
    return value


def domain_key(value):
    raw = str(value or '').strip()
    if not raw: return ''
    parsed = urlparse(raw if '://' in raw else 'https://' + raw)
    host = (parsed.hostname or '').lower().strip('.')
    if host.startswith('www.'): host = host[4:]
    labels = host.split('.')
    if len(labels) < 2: return host
    multi = {'com.cn','net.cn','org.cn','gov.cn','com.hk','com.sg','com.au','co.uk','org.uk','co.jp','com.tw','com.my','co.nz'}
    return '.'.join(labels[-3:]) if '.'.join(labels[-2:]) in multi and len(labels) >= 3 else '.'.join(labels[-2:])


class GlobalDedup:
    def __init__(self, path):
        self.path = os.path.abspath(path)
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        self._init()

    def connect(self):
        con = sqlite3.connect(self.path, timeout=60)
        con.execute('PRAGMA busy_timeout=60000')
        return con

    def _init(self):
        con = self.connect()
        try:
            con.execute('PRAGMA journal_mode=WAL')
            con.execute('PRAGMA synchronous=NORMAL')
            con.executescript('''
            CREATE TABLE IF NOT EXISTS companies(
              id INTEGER PRIMARY KEY AUTOINCREMENT, domain TEXT NOT NULL UNIQUE,
              normalized_name TEXT NOT NULL DEFAULT '', company_name TEXT NOT NULL DEFAULT '',
              website TEXT NOT NULL DEFAULT '', country TEXT NOT NULL DEFAULT '',
              status TEXT NOT NULL DEFAULT 'discovered', first_seen TEXT NOT NULL,
              last_seen TEXT NOT NULL, collected_at TEXT NOT NULL DEFAULT '',
              last_reason TEXT NOT NULL DEFAULT '', last_query TEXT NOT NULL DEFAULT '');
            CREATE INDEX IF NOT EXISTS idx_global_name ON companies(normalized_name,status);
            CREATE TABLE IF NOT EXISTS identifiers(
              id INTEGER PRIMARY KEY AUTOINCREMENT, company_id INTEGER NOT NULL,
              id_type TEXT NOT NULL, id_value TEXT NOT NULL, source_url TEXT NOT NULL DEFAULT '',
              first_seen TEXT NOT NULL, last_seen TEXT NOT NULL,
              UNIQUE(company_id,id_type,id_value), FOREIGN KEY(company_id) REFERENCES companies(id));
            CREATE INDEX IF NOT EXISTS idx_global_identifier ON identifiers(id_type,id_value);
            CREATE TABLE IF NOT EXISTS collection_events(
              id INTEGER PRIMARY KEY AUTOINCREMENT, company_id INTEGER NOT NULL,
              event_type TEXT NOT NULL, task_id TEXT NOT NULL DEFAULT '', industry TEXT NOT NULL DEFAULT '',
              query TEXT NOT NULL DEFAULT '', source_url TEXT NOT NULL DEFAULT '',
              reason TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL,
              FOREIGN KEY(company_id) REFERENCES companies(id));
            CREATE INDEX IF NOT EXISTS idx_global_events ON collection_events(company_id,created_at);
            CREATE TABLE IF NOT EXISTS schema_meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
            ''')
            con.commit()
        finally: con.close()

    def _event(self, con, cid, event, task_id='', industry='', query='', source_url='', reason=''):
        con.execute('INSERT INTO collection_events(company_id,event_type,task_id,industry,query,source_url,reason,created_at) VALUES(?,?,?,?,?,?,?,?)',
                    (cid,event,str(task_id or ''),str(industry or ''),str(query or ''),str(source_url or ''),str(reason or '')[:1000],time.strftime('%Y-%m-%d %H:%M:%S')))

    def lookup(self, domain='', company_name=''):
        d, n = domain_key(domain), normalize_name(company_name)
        con = self.connect()
        try:
            if d:
                row = con.execute('SELECT id,status,normalized_name,domain FROM companies WHERE domain=?',(d,)).fetchone()
                if row: return {'match':'domain','company_id':row[0],'status':row[1],'normalized_name':row[2],'domain':row[3]}
            if n:
                rows = con.execute('SELECT id,status,normalized_name,domain FROM companies WHERE normalized_name=? ORDER BY id',(n,)).fetchall()
                if rows:
                    # A name-only match is a possible duplicate, not permission to merge domains.
                    return {'match':'name','possible_duplicate':True,'matches':[{'company_id':x[0],'status':x[1],'normalized_name':x[2],'domain':x[3]} for x in rows]}
            return None
        finally: con.close()

    def record(self, domain='', company_name='', website='', status='discovered', query='', industry='', source_url='', reason='', task_id='', country=''):
        d, n = domain_key(domain or website), normalize_name(company_name)
        if not d:
            if not n: return {'result':'ignored','reason':'no_stable_identity'}
            # Keep name-only candidates under a synthetic key; they are not considered a hard domain match.
            d = 'name-only:' + n
        now = time.strftime('%Y-%m-%d %H:%M:%S')
        con = self.connect()
        try:
            con.execute('BEGIN IMMEDIATE')
            row = con.execute('SELECT id,status FROM companies WHERE domain=?',(d,)).fetchone()
            if row:
                cid, old_status = row
                new_status = 'collected' if old_status == 'collected' else status
                con.execute('''UPDATE companies SET normalized_name=CASE WHEN ?!='' THEN ? ELSE normalized_name END,
                  company_name=CASE WHEN ?!='' THEN ? ELSE company_name END,website=CASE WHEN ?!='' THEN ? ELSE website END,
                  country=CASE WHEN ?!='' THEN ? ELSE country END,last_seen=?,status=?,last_reason=CASE WHEN ?!='' THEN ? ELSE last_reason END,
                  last_query=CASE WHEN ?!='' THEN ? ELSE last_query END WHERE id=?''',
                  (n,n,company_name,company_name,website,website,country,country,now,new_status,reason,reason,query,query,cid))
                event='seen_again'
            else:
                cur=con.execute('''INSERT INTO companies(domain,normalized_name,company_name,website,country,status,first_seen,last_seen,last_reason,last_query)
                  VALUES(?,?,?,?,?,?,?,?,?,?)''',(d,n,company_name or '',website or '',country or '',status,now,now,reason or '',query or ''))
                cid=cur.lastrowid; event='first_seen'
                # Exact name already registered on another domain => flag, never merge automatically.
                if n and not d.startswith('name-only:'):
                    matches=con.execute('SELECT id FROM companies WHERE normalized_name=? AND id<>?',(n,cid)).fetchall()
                    if matches:
                        status='review'; con.execute("UPDATE companies SET status='review',last_reason=? WHERE id=?",('同名企业存在不同官网域名，疑似重复，需人工核验',cid))
                        event='possible_name_duplicate'
            self._event(con,cid,event,task_id,industry,query,source_url,reason)
            if website:
                host=domain_key(website)
                con.execute('INSERT OR IGNORE INTO identifiers(company_id,id_type,id_value,source_url,first_seen,last_seen) VALUES(?,?,?,?,?,?)',(cid,'website',str(website),source_url,now,now))
            if n:
                con.execute('INSERT OR IGNORE INTO identifiers(company_id,id_type,id_value,source_url,first_seen,last_seen) VALUES(?,?,?,?,?,?)',(cid,'normalized_name',n,source_url,now,now))
            con.commit()
            return {'result':'recorded','company_id':cid,'domain':d,'status':status}
        except Exception:
            con.rollback(); raise
        finally: con.close()

    def reserve_candidate(self, domain, company_name='', website='', query='', industry='', source_url='', task_id='', country='', retry_after_days=30, allow_collected_refresh=False):
        """Reserve a candidate. Incomplete discoveries are retryable; collected rows may be refreshed when contacts are missing."""
        d, n = domain_key(domain or website), normalize_name(company_name)
        if not d: return False, 'no_stable_identity'
        now=time.strftime('%Y-%m-%d %H:%M:%S')
        cutoff=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()-max(1,int(retry_after_days))*86400))
        con=self.connect()
        try:
            con.execute('BEGIN IMMEDIATE')
            row=con.execute('SELECT id,status,last_seen FROM companies WHERE domain=?',(d,)).fetchone()
            if row:
                cid,state,last_seen=row
                if state=='collected':
                    if not allow_collected_refresh:
                        con.commit(); return False,'already_collected'
                    con.execute('UPDATE companies SET last_seen=?,last_query=? WHERE id=?',(now,query or '',cid))
                    self._event(con,cid,'contact_refresh_reserved',task_id,industry,query,source_url,'已采集企业缺少联系方式，允许补充核验')
                    con.commit(); return True,'refresh_contacts'
                if state=='excluded':
                    con.commit(); return False,'confirmed_excluded'
                if state=='reserved' and str(last_seen or '') >= time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()-1800)):
                    con.commit(); return False,'currently_reserved'
                # discovered / previously_collected / review / failed are incomplete
                # candidates, not completed companies. Retry immediately, but mark the
                # row reserved so parallel tasks cannot crawl it simultaneously.
                con.execute("UPDATE companies SET normalized_name=?,company_name=?,website=?,status='reserved',last_seen=?,last_query=? WHERE id=?",
                            (n,company_name or '',website or '',now,query or '',cid))
                self._event(con,cid,'retry_incomplete_candidate',task_id,industry,query,source_url,'未完成候选允许重新核验并原子预留')
                con.commit(); return True,'retry_incomplete'
            name_match=con.execute('SELECT id FROM companies WHERE normalized_name=? AND status="collected" LIMIT 1',(n,)).fetchone() if n else None
            if name_match:
                cur=con.execute("""INSERT INTO companies(domain,normalized_name,company_name,website,country,status,first_seen,last_seen,last_reason,last_query)
                    VALUES(?,?,?,?,?,'review',?,?,?,?)""",(d,n,company_name or '',website or '',country or '',now,now,'同名企业已有其他官网域名，需人工核验',query or ''))
                cid=cur.lastrowid
                self._event(con,cid,'possible_name_duplicate',task_id,industry,query,source_url,'与已采集企业名称相同但官网域名不同')
                con.commit(); return False,'possible_name_duplicate'
            cur=con.execute("""INSERT INTO companies(domain,normalized_name,company_name,website,country,status,first_seen,last_seen,last_query)
                VALUES(?,?,?,?,?,'reserved',?,?,?)""",(d,n,company_name or '',website or '',country or '',now,now,query or ''))
            cid=cur.lastrowid
            self._event(con,cid,'reserved',task_id,industry,query,source_url,'候选已原子预留，防止并发任务重复核验')
            con.commit(); return True,'new'
        except Exception:
            con.rollback(); raise
        finally: con.close()

    def mark_collected(self, domain, company_name='', website='', query='', industry='', source_url='', task_id='', country='', emails=(), phones=()):
        result=self.record(domain,company_name,website,'collected',query,industry,source_url,'已保存至制造商结果库',task_id,country)
        d=domain_key(domain or website)
        if d:
            con=self.connect()
            try:
                con.execute('UPDATE companies SET status="collected",collected_at=?,last_seen=? WHERE domain=?',(time.strftime('%Y-%m-%d %H:%M:%S'),time.strftime('%Y-%m-%d %H:%M:%S'),d)); con.commit()
            finally: con.close()
        # Keep contact identifiers as supporting identity evidence. They are not
        # used alone to merge companies because shared/group contacts are common.
        con=self.connect()
        try:
            cid=con.execute('SELECT id FROM companies WHERE domain=?',(d,)).fetchone()
            if cid:
                now=time.strftime('%Y-%m-%d %H:%M:%S')
                for value in emails or ():
                    v=str(value or '').strip().lower()
                    if '@' in v:
                        con.execute('INSERT OR IGNORE INTO identifiers(company_id,id_type,id_value,source_url,first_seen,last_seen) VALUES(?,?,?,?,?,?)',(cid[0],'email',v,source_url,now,now))
                for value in phones or ():
                    v=re.sub(r'[^0-9+]','',str(value or ''))
                    if len(re.sub(r'\D','',v))>=7:
                        con.execute('INSERT OR IGNORE INTO identifiers(company_id,id_type,id_value,source_url,first_seen,last_seen) VALUES(?,?,?,?,?,?)',(cid[0],'phone',v,source_url,now,now))
                con.commit()
        finally: con.close()
        return result

    def load_sets(self, recent_days=30):
        domains,names=set(),set(); con=self.connect()
        try:
            for d,n in con.execute("SELECT domain,normalized_name FROM companies WHERE status='collected'"):
                if d and not d.startswith('name-only:'): domains.add(domain_key(d))
                if n: names.add(n)
            cutoff=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()-max(1,int(recent_days))*86400))
            if int(recent_days or 0) > 0:
                for d,n in con.execute("SELECT domain,normalized_name FROM companies WHERE status='excluded' AND last_seen>=?",(cutoff,)):
                    if d and not d.startswith('name-only:'): domains.add(domain_key(d))
                    if n: names.add(n)
            return domains,names
        finally: con.close()

    def stats(self):
        con=self.connect()
        try:
            total=con.execute('SELECT COUNT(*) FROM companies').fetchone()[0]
            rows=dict(con.execute('SELECT status,COUNT(*) FROM companies GROUP BY status').fetchall())
            return {'total':int(total),'collected':int(rows.get('collected',0)),
                    'discovered':int(rows.get('discovered',0)),'reserved':int(rows.get('reserved',0)),'review':int(rows.get('review',0)),
                    'failed':int(rows.get('failed',0)),'excluded':int(rows.get('excluded',0))}
        finally: con.close()

    def migrate_legacy(self, lead_rows=(), registry_rows=()):
        counts={'leads':0,'registry':0}
        for d,name,website,country,quality,stamp in lead_rows:
            state='collected' if quality=='keep' else ('excluded' if quality=='excluded' else 'review')
            self.record(d,name,website,state,source_url=website,reason='从旧版制造商数据库迁移',country=country)
            counts['leads']+=1
        for d,name,website,state,query,stamp,reason in registry_rows:
            if state=='collected': state='collected'
            elif state not in ('excluded','failed','review','discovered'): state='review'
            self.record(d,name,website,state,query=query,source_url=website,reason=reason or '从旧版采集登记表迁移')
            counts['registry']+=1
        return counts
