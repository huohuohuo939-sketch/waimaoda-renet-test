# 外贸达人 2.5.6 内部测试报告

- 源码根因：`worker_discover()` 在 LinkedIn 公司主页查询中引用 `start()` 局部变量 `query_context`，导致 NameError。
- 修复：改为从任务配置读取 `config.get('query_context', {})`。
- 稳定性：LinkedIn 人员、企业主页和企业关联补充步骤分别隔离异常；可选模块失败时主官网核验继续。
- 额度回归：付费搜索额度耗尽后，付费优先模式仍会回退免费搜索。
- 自动化测试：85/85 通过（原有 82 项 + 3 项新增回归测试）。
- Python compileall：通过。
- ZIP 完整性：打包后复核。
- Windows 10 实机联网：未执行；需要用户小批量验收。
- 本包不携带用户数据库，不覆盖 `%LOCALAPPDATA%\WaiMaoDaRen` 中的现有数据。
