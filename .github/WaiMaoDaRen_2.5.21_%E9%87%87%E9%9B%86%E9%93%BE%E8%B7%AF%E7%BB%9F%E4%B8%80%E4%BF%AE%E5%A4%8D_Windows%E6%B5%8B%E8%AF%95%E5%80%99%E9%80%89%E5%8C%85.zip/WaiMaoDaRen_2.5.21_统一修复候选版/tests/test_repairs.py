import csv
import os
import tempfile
import unittest
from pathlib import Path

os.environ.setdefault('LOCALAPPDATA', tempfile.mkdtemp(prefix='waimaodaren_test_'))

import app
from search_scheduler import build_rounds


class FakeResponse:
    status_code = 200
    headers = {}
    text = '<html></html>'
    def raise_for_status(self):
        return None


class FakeSession:
    def get(self, *args, **kwargs):
        return FakeResponse()


class RepairRegressionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='wmd_repair_')
        self.db = Path(self.tmp.name) / 'test.db'
        self.old_db = app.DB_FILE
        app.DB_FILE = str(self.db)
        app.init_db()

    def tearDown(self):
        app.DB_FILE = self.old_db
        self.tmp.cleanup()

    def test_chinese_product_keywords_generate_real_query(self):
        with open(Path(app.APP_DIR) / 'industry_catalog.csv', encoding='utf-8-sig', newline='') as f:
            row = next(csv.DictReader(f))
        rounds = build_rounds([row], country='中国')
        local = [q for q in rounds[0]['queries'] if q['intent'] == 'local_product']
        self.assertEqual(len(local), 1)
        self.assertIn('稻谷加工厂', local[0]['query'])
        self.assertIn('制造商', local[0]['query'])

    def test_multilevel_domain_suffix(self):
        self.assertEqual(app.root_domain('https://factory.example.com.br/contact'), 'example.com.br')
        self.assertEqual(app.root_domain('https://www.example.co.in/about'), 'example.co.in')

    def test_robots_network_failure_fails_closed(self):
        self.assertFalse(app.robots_allows(False, 'https://example.com/contact'))
        self.assertTrue(app.robots_allows(None, 'https://example.com/contact'))

    def test_expired_site_deadline_does_not_start_another_request(self):
        class NeverCallSession:
            def get(self, *args, **kwargs):
                raise AssertionError('network request should not start after deadline')
        soup, response, reason = app.fetch_page(NeverCallSession(), 'https://example.com', deadline=0)
        self.assertIsNone(soup)
        self.assertIsNone(response)
        self.assertIn('预算已用完', reason)

    def test_formula_injection_is_neutralized(self):
        self.assertTrue(app.safe_spreadsheet_cell('  =HYPERLINK("x")').startswith("'"))
        self.assertTrue(app.safe_spreadsheet_cell('\t@SUM(A1:A2)').startswith("'"))
        self.assertEqual(app.safe_spreadsheet_cell('normal text'), 'normal text')

    def test_direct_whatsapp_is_unassigned_not_company_domain(self):
        link = 'https://wa.me/8613800138000'
        saved = app.persist_whatsapp_discoveries({
            'company_website': '', 'source_url': link,
            'company_name': 'Search result contact', 'country': 'China',
            'whatsapp_links': [link], 'whatsapp_contacts': [],
            'contact_evidence': {'whatsapp_links': {link: link}},
            'evidence_notes': {link: 'Search result direct link; company attribution pending'},
            'whatsapp_source_status': '企业归属待核验',
        })
        self.assertEqual(saved, 1)
        import sqlite3
        with sqlite3.connect(self.db) as con:
            row = con.execute('SELECT domain,website,source_url,status FROM whatsapp_discoveries').fetchone()
        self.assertEqual(row[0], 'unassigned:whatsapp')
        self.assertEqual(row[1], '')
        self.assertEqual(row[2], link)
        self.assertIn('待核验', row[3])

    def test_linkedin_domain_allowed_only_in_dedicated_search(self):
        old_pace = app._pace_public_search_request
        old_parse = app._parse_public_engine_results
        old_record = app.record_engine_search
        try:
            app._pace_public_search_request = lambda: None
            app._parse_public_engine_results = lambda provider, response, snippet_map=None, stage_stats=None: [
                ('https://www.linkedin.com/company/example-manufacturing/', 'Example Manufacturing')
            ]
            app.record_engine_search = lambda *args, **kwargs: None
            allowed = app.search_public_web('site:linkedin.com/company example', max_results=5,
                                            diagnostics={}, session=FakeSession(), allow_domains={'linkedin.com'})
            blocked = app.search_public_web('example manufacturer', max_results=5,
                                            diagnostics={}, session=FakeSession())
            self.assertEqual(len(allowed), 1)
            self.assertEqual(blocked, [])
        finally:
            app._pace_public_search_request = old_pace
            app._parse_public_engine_results = old_parse
            app.record_engine_search = old_record

    def test_upsert_does_not_erase_stronger_historical_metadata(self):
        base = {
            'company_name': 'Example Factory', 'company_website': 'https://example.com/',
            'industry_category': '制造业', 'industry': '机械制造', 'country': '中国',
            'manufacturer_score': 72, 'operation_score': 25,
            'manufacturer_evidence': '明确生产线和自有工厂', 'source_urls': ['https://example.com/about'],
            'quality_status': 'keep', 'quality_reason': '已核验',
            'whatsapp_links': ['https://wa.me/8613800138000'], 'whatsapp_contacts': [],
            'emails': ['sales@example.com'], 'phone_candidates': [], 'linkedin_links': [],
            'email_details': [], 'contact_evidence': {'whatsapp_links': {'https://wa.me/8613800138000': 'https://example.com/contact'}},
            'decision_maker_evidence': 'Founder listed', 'gender_status': '未知/未核实',
            'company_address': 'Shenzhen', 'address_source_url': 'https://example.com/contact',
            'status': 'HTTP 200', 'notes': 'Strong historical note', 'collected_at': '2026-11-19 10:00:00',
            'factory_evidence_items': [], 'export_evidence_items': [], 'contact_evidence_items': [],
        }
        app.save_lead(dict(base))
        weaker = dict(base)
        weaker.update({'manufacturer_score': 0, 'operation_score': 0, 'manufacturer_evidence': '',
                       'source_urls': [], 'whatsapp_links': [], 'emails': [], 'decision_maker_evidence': '',
                       'company_address': '', 'address_source_url': '', 'status': '', 'notes': '',
                       'quality_status': 'review', 'quality_reason': ''})
        app.save_lead(weaker)
        import sqlite3
        with sqlite3.connect(self.db) as con:
            row = con.execute('SELECT company_name,score,operation_score,evidence,whatsapp,emails,sources,quality_status,notes FROM leads WHERE domain=?',
                              ('example.com',)).fetchone()
        self.assertEqual(row[0], 'Example Factory')
        self.assertEqual(row[1], 72)
        self.assertEqual(row[2], 25)
        self.assertEqual(row[3], '明确生产线和自有工厂')
        self.assertIn('wa.me', row[4])
        self.assertIn('sales@example.com', row[5])
        self.assertIn('about', row[6])
        self.assertEqual(row[7], 'keep')
        self.assertIn('Strong historical note', row[8])

    def test_search_provider_limit_is_reported_not_silently_hidden(self):
        old_pace = app._pace_public_search_request
        old_parse = app._parse_public_engine_results
        old_record = app.record_engine_search
        try:
            app._pace_public_search_request = lambda: None
            app._parse_public_engine_results = lambda provider, response, snippet_map=None, stage_stats=None: [
                (f'https://factory{i}.example{i}.com/', f'Factory {i}') for i in range(4)
            ]
            app.record_engine_search = lambda *args, **kwargs: None
            diagnostics = {}
            rows = app.search_public_web('factory', max_results=2, diagnostics=diagnostics, session=FakeSession())
            self.assertEqual(len(rows), 2)
            self.assertEqual(diagnostics['search_pipeline']['provider_limit_exceeded'], 2)
        finally:
            app._pace_public_search_request = old_pace
            app._parse_public_engine_results = old_parse
            app.record_engine_search = old_record

    def test_partial_whatsapp_save_error_survives_final_notes(self):
        import requests
        class Session:
            def get(self, url, **kwargs):
                if url.endswith('/robots.txt'):
                    r = requests.Response(); r.status_code = 404; r.url = url; r._content = b''; r._content_consumed = True; r.headers = {}
                    return r
                if url.endswith('/sitemap.xml'):
                    raise requests.ConnectionError('test sitemap failure')
                if url.rstrip('/') == 'https://sample-factory.example':
                    body = b'<html><head><title>Sample Factory</title><meta property="og:site_name" content="Sample Factory"></head><body>manufacturer factory production line kitchen appliances <a href="https://wa.me/8613800138000">WhatsApp</a></body></html>'
                    r = requests.Response(); r.status_code = 200; r.url = url; r._content = body; r._content_consumed = True; r.headers = {'Content-Type':'text/html; charset=utf-8'}; r.encoding = 'utf-8'
                    return r
                r = requests.Response(); r.status_code = 404; r.url = url; r._content = b''; r._content_consumed = True; r.headers = {'Content-Type':'text/html'}; r.encoding = 'utf-8'
                return r
        old_persist = app.persist_whatsapp_discoveries
        try:
            app.persist_whatsapp_discoveries = lambda result: (_ for _ in ()).throw(RuntimeError('simulated database lock'))
            result = app.scan_site('https://sample-factory.example/', industry='kitchen appliances', keywords='kitchen appliances', country='China', session=Session())
            self.assertIn('WhatsApp线索即时保存失败', result['notes'])
            self.assertTrue(any('Sitemap读取失败' in x for x in result.get('diagnostic_warnings', [])))
        finally:
            app.persist_whatsapp_discoveries = old_persist

    def test_same_domain_worker_merge_preserves_old_contacts(self):
        obj = app.App.__new__(app.App)
        obj.rows = [{'company_name':'Factory A','company_website':'https://factory-a.example',
                     'emails':['sales@factory-a.example'],'whatsapp_links':['https://wa.me/8613800138000'],
                     'source_urls':['https://factory-a.example/contact'],'quality_status':'keep'}]
        obj._merge_worker_rows([{'company_name':'Factory A Ltd','company_website':'https://www.factory-a.example/about',
                                 'emails':[],'whatsapp_links':[],'source_urls':[],'quality_status':'review'}])
        row = obj.rows[0]
        self.assertIn('sales@factory-a.example', row['emails'])
        self.assertIn('https://wa.me/8613800138000', row['whatsapp_links'])
        self.assertIn('https://factory-a.example/contact', row['source_urls'])
        self.assertEqual(row['company_name'], 'Factory A Ltd')


if __name__ == '__main__':
    unittest.main(verbosity=2)
