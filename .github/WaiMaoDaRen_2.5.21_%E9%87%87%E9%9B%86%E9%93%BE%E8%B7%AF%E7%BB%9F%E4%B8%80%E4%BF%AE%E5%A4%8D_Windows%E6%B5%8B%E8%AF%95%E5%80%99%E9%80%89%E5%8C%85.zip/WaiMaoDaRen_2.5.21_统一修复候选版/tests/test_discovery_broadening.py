import unittest
import app
from search_scheduler import INTENTS, query_budget_for_target, build_rounds

class DiscoveryBroadeningTests(unittest.TestCase):
    def test_site_scan_page_budget_is_expanded_but_bounded(self):
        self.assertEqual(app.MAX_SITE_PAGES, 8)

    def test_public_search_pool_is_simplified_to_bing_and_qwant(self):
        from pathlib import Path
        source = Path(app.__file__).read_text(encoding='utf-8')
        self.assertIn("default_order=['Bing','Qwant']", source)
        self.assertIn("engine_order=['Bing','Qwant']", source)
        self.assertNotIn("default_order=['Bing','DuckDuckGo'", source)

    def test_search_intents_cover_chinese_supplier_and_contact_discovery(self):
        names = {name for name, _ in INTENTS}
        self.assertGreaterEqual(len(INTENTS), 12)
        self.assertTrue({'china_factory','china_supplier','supplier','email_contact','whatsapp_contact'}.issubset(names))

    def test_query_budget_expands_for_realistic_targets(self):
        self.assertEqual(query_budget_for_target(30), 90)
        self.assertEqual(query_budget_for_target(100), 240)
        self.assertEqual(query_budget_for_target(300), 240)

    def test_contact_or_export_signal_alone_does_not_enter_manufacturer_queue(self):
        candidate = {
            'company_name': 'Example Industrial Supplies Co., Ltd.',
            'manufacturer_score': 16,
            'operation_score': 45,
            'industry': 'industrial equipment',
            'keywords': 'industrial equipment manufacturer',
            'manufacturer_evidence': '未找到明确生产制造证据',
            'emails': ['sales@example.com'],
            'whatsapp_links': [],
        }
        self.assertFalse(app.is_broad_discovery_candidate(candidate))
        self.assertFalse(app.is_manufacturer_candidate(candidate, 25))

    def test_freeguider_accessibility_portal_is_hard_excluded_by_site_score(self):
        from bs4 import BeautifulSoup
        soup=BeautifulSoup('<html><head><title>FreeGuider 無障礙生活</title></head><body>無障礙生活資訊平台，提供景點介紹、餐廳指南、活動資訊及旅遊資訊。</body></html>','html.parser')
        score,evidence=app.score_site([('https://freeguider.com/',soup)],'纺织服装','woven sportswear manufacturer')
        self.assertEqual(score,0)
        self.assertIn('网站类型排除',evidence)

    def test_export_signal_is_not_factory_proof(self):
        from bs4 import BeautifulSoup
        pages=[('https://example.com/',BeautifulSoup('<html><title>Trading Company</title><body>International trade export sales and sourcing services.</body></html>','html.parser'))]
        score,status,hits=app.operation_signals(pages)
        self.assertGreater(score,0)
        self.assertFalse(app.is_broad_discovery_candidate({'company_name':'Example Trading','manufacturer_score':0,'operation_score':score,'manufacturer_evidence':'','page_title':'Trading Company'}))

    def test_each_query_uses_bing_then_qwant_only_as_fallback(self):
        class FakeResponse:
            status_code = 200
            text = '<html><body>no parsed results</body></html>'
            def raise_for_status(self): pass
        class FakeSession:
            def __init__(self): self.calls=[]
            def get(self, url, **kwargs):
                self.calls.append(url)
                return FakeResponse()
        session=FakeSession()
        diagnostics={}
        from unittest.mock import patch
        with patch.object(app, 'rank_search_engines', return_value=['Bing','DuckDuckGo','Baidu','Yahoo','Mojeek']), \
             patch.object(app, 'record_engine_search'), patch.object(app, '_pace_public_search_request'):
            app.search_public_web('test manufacturer China', max_results=20, diagnostics=diagnostics, session=session)
        self.assertEqual(len(session.calls), 2)
        self.assertEqual(diagnostics['public_search']['engines_tried_this_query'], ['Bing', 'Qwant'])

    def test_unrelated_low_signal_company_is_not_broadly_kept(self):
        candidate = {
            'company_name': 'Example University',
            'manufacturer_score': 0,
            'operation_score': 0,
            'industry': 'industrial equipment',
            'keywords': '',
            'emails': [],
            'whatsapp_links': [],
        }
        self.assertFalse(app.is_broad_discovery_candidate(candidate))

    def test_search_title_or_task_industry_is_not_factory_proof(self):
        candidate = {
            'company_name': 'Example Medical Services',
            'page_title': 'Factory Manufacturer Directory',
            'industry': 'industrial equipment factory manufacturer',
            'manufacturer_score': 30,
            'manufacturer_evidence': 'industrial equipment products and contact information',
            'factory_evidence_items': [],
            'industry_relevance_status': '匹配',
        }
        self.assertFalse(app.is_broad_discovery_candidate(candidate))
        self.assertFalse(app.is_manufacturer_candidate(candidate, 25))

    def test_explicit_manufacturer_identity_without_workshop_proof_is_kept_for_review(self):
        candidate = {
            'company_name': 'Example Pump Manufacturer Ltd.',
            'page_title': 'Example Pump Manufacturer',
            'industry': 'industrial pump',
            'manufacturer_score': 20,
            'manufacturer_evidence': 'manufacturer×2; industrial pump products',
            'factory_evidence_items': [],
            'industry_relevance_status': '匹配',
        }
        self.assertTrue(app.is_broad_discovery_candidate(candidate))
        self.assertFalse(app.is_manufacturer_candidate(candidate, 25))

    def test_actual_site_factory_evidence_can_qualify_broad_candidate(self):
        candidate = {
            'company_name': 'Example Machinery Co., Ltd.',
            'page_title': 'Example Machinery',
            'industry': 'industrial machinery',
            'manufacturer_score': 18,
            'manufacturer_evidence': 'production line×2; own factory×1',
            'factory_evidence_items': [{'type': 'factory', 'text': 'production line', 'source_url': 'https://example.com/factory'}],
            'industry_relevance_status': '匹配',
        }
        self.assertTrue(app.is_broad_discovery_candidate(candidate))


    def test_overseas_country_search_does_not_force_china_factory_queries(self):
        from search_scheduler import build_rounds
        rows=[{'大类':'工业设备','细分行业':'工业泵','细分行业代码':'PUMP','英文核心词':'industrial pump manufacturer'}]
        rounds=build_rounds(rows,'United States')
        queries=[x['query'] for x in rounds[0]['queries']]
        local=[q for q in queries if 'factory OR manufacturer OR producer OR production facility' in q or 'supplier OR manufacturer OR factory OR exporter contact' in q]
        self.assertEqual(len(local),3)  # two local-term templates plus the new local product intent
        self.assertTrue(all('United States' in q for q in local))
        self.assertTrue(all('中国' not in q for q in local))

    def test_china_search_keeps_chinese_factory_and_supplier_intents(self):
        from search_scheduler import build_rounds
        rows=[{'大类':'工业设备','细分行业':'工业泵','细分行业代码':'PUMP','英文核心词':'industrial pump manufacturer'}]
        rounds=build_rounds(rows,'China')
        queries=[x['query'] for x in rounds[0]['queries']]
        self.assertTrue(any('工厂 OR 厂家 OR 制造商' in q and '中国' in q for q in queries))
        self.assertTrue(any('供应商 OR 生产企业 OR 制造厂' in q and '中国' in q for q in queries))

if __name__ == '__main__':
    unittest.main()
