import csv
import unittest
from pathlib import Path

from industry_relevance import build_relevance_terms, match_industry_relevance
from search_scheduler import build_rounds


class IndustryRelevanceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with open(Path(__file__).resolve().parents[1] / 'industry_catalog.csv', encoding='utf-8-sig', newline='') as f:
            cls.catalog = list(csv.DictReader(f))

    def _row(self, code):
        return next(row for row in self.catalog if row.get('细分行业代码') == code)

    def test_automation_industry_rejects_consumer_electronics_and_fitness_sites(self):
        row = self._row('4011')
        terms = build_relevance_terms(row, row.get('新英文核心词', ''))
        belkin = 'Belkin consumer electronics wireless routers networking accessories support contact us'
        fitness = 'Japanese fitness club gym training coach magazine membership classes'
        self.assertFalse(match_industry_relevance(belkin, terms)[0])
        self.assertFalse(match_industry_relevance(fitness, terms)[0])

    def test_automation_industry_accepts_relevant_plc_control_system_site(self):
        row = self._row('4011')
        terms = build_relevance_terms(row, row.get('新英文核心词', ''))
        site = 'Industrial automation control systems, PLC and SCADA control equipment manufacturer'
        matched, score, evidence = match_industry_relevance(site, terms)
        self.assertTrue(matched)
        self.assertGreater(score, 0)
        self.assertTrue(evidence)

    def test_wood_furniture_rejects_gym_and_accepts_furniture_factory(self):
        row = next(r for r in self.catalog if '木质家具制造' in r.get('细分行业', ''))
        terms = build_relevance_terms(row, row.get('新英文核心词', ''))
        self.assertFalse(match_industry_relevance('Japanese gym fitness club exercise coach', terms)[0])
        self.assertTrue(match_industry_relevance('wooden furniture tables chairs furniture factory', terms)[0])

    def test_build_rounds_carries_industry_specific_relevance_terms(self):
        row = self._row('4011')
        rounds = build_rounds([row], 'China', selected_code='4011')
        self.assertEqual(len(rounds), 1)
        terms = rounds[0]['queries'][0]['relevance_terms']
        self.assertIn('industrial automation control system', terms)
        self.assertIn('工控系统', terms)

    def test_scan_site_marks_belkin_as_unrelated_for_automation_task(self):
        from bs4 import BeautifulSoup
        from types import SimpleNamespace
        from unittest.mock import patch
        import app
        row = self._row('4011')
        terms = build_relevance_terms(row, row.get('新英文核心词', ''))
        soup = BeautifulSoup('<html><head><title>Belkin wireless router</title><meta property="og:site_name" content="Belkin"></head><body>Consumer electronics wireless networking products and support.</body></html>', 'html.parser')
        response = SimpleNamespace(url='https://www.belkin.com/', status_code=200, headers={})
        blank_contact = {'whatsapp_links': [], 'whatsapp_contacts': [], 'emails': [], 'phones': [], 'linkedin': [],
                         'email_evidence': {}, 'phone_evidence': {}, 'whatsapp_evidence': {}}
        with patch.object(app, 'fetch_page', return_value=(soup, response, '')), \
             patch.object(app, 'load_robots_parser', return_value=object()), \
             patch.object(app, 'robots_allows', return_value=False), \
             patch.object(app, 'extract_contact_evidence', return_value=blank_contact), \
             patch.object(app, 'extract_company_address', return_value=''):
            result = app.scan_site('https://www.belkin.com/', industry=row['细分行业'],
                                   keywords=row['新英文核心词'], country='China', relevance_terms=terms)
        self.assertEqual(result['industry_relevance_status'], '不相关/未发现目标行业证据')
        self.assertEqual(result['industry_relevance_evidence'], [])

    def test_unrelated_explicit_factory_is_not_accepted_if_relevance_is_negative(self):
        import app
        candidate = {
            'company_name': 'Belkin',
            'manufacturer_score': 60,
            'manufacturer_evidence': 'production line factory own factory',
            'industry_relevance_status': '不相关/未发现目标行业证据',
        }
        self.assertFalse(app.is_manufacturer_candidate(candidate, 25))
        self.assertFalse(app.is_broad_discovery_candidate(candidate))


if __name__ == '__main__':
    unittest.main()
