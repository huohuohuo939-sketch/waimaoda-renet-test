import os, unittest
import app

class StartupResponsivenessTests(unittest.TestCase):
    def test_website_scan_has_bounded_page_count(self):
        self.assertLessEqual(app.MAX_SITE_PAGES, 8)
        self.assertGreaterEqual(app.MAX_SITE_PAGES, 6)
    def test_default_http_timeout_is_bounded_tuple(self):
        self.assertEqual(app.TIMEOUT, (4, 7))

if __name__ == "__main__":
    unittest.main()
