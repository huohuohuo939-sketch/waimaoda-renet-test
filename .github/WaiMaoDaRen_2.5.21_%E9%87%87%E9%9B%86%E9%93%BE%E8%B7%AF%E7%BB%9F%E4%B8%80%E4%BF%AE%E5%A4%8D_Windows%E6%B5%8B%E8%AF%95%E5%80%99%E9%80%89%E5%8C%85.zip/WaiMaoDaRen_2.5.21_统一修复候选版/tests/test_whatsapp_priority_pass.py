import threading
import unittest
from unittest.mock import patch
import app


class WhatsAppPriorityPassTests(unittest.TestCase):
    def test_dedicated_pass_saves_contacts_even_when_industry_is_unmatched(self):
        calls = []
        def fake_scan(url, industry, keywords, country, cancel_event=None):
            self.assertEqual(industry, 'Mining machinery')
            return {
                'company_website': url,
                'company_name': 'Factory Candidate',
                'status': 'HTTP 200',
                'industry_relevance_status': '不相关/未发现目标行业证据',
                'whatsapp_links': ['https://wa.me/8613800138000'],
                'whatsapp_contacts': ['+8613800138000'],
                'contact_evidence': {'whatsapp_links': {}, 'whatsapp_contacts': {}},
            }
        def fake_persist(result):
            calls.append(result)
            return 2
        stats = app.scan_whatsapp_discovery_sites(
            [('https://factory.example/contact', 'Factory'), ('https://www.factory.example/', 'Duplicate')],
            industry='Mining machinery', keywords='mining machinery manufacturer',
            country='中国', scan_fn=fake_scan, persist_fn=fake_persist)
        self.assertEqual(len(calls), 1)
        self.assertEqual(stats['sites_seen'], 1)
        self.assertEqual(stats['sites_scanned'], 1)
        self.assertEqual(stats['whatsapp_numbers_saved'], 1)
        self.assertEqual(stats['whatsapp_links_saved'], 1)

    def test_dedicated_pass_handles_scan_failure_without_aborting_other_sites(self):
        def fake_scan(url, industry, keywords, country, cancel_event=None):
            if 'bad.' in url:
                raise RuntimeError('temporary failure')
            return {'company_website': url, 'whatsapp_links': [], 'whatsapp_contacts': []}
        stats = app.scan_whatsapp_discovery_sites(
            [('https://bad.example/', 'Bad'), ('https://good.example/', 'Good')],
            scan_fn=fake_scan, persist_fn=lambda row: 0)
        self.assertEqual(stats['sites_seen'], 2)
        self.assertEqual(stats['sites_scanned'], 1)
        self.assertEqual(stats['sites_failed'], 1)

    def test_cancelled_pass_does_not_start_new_scan_jobs(self):
        event = threading.Event(); event.set()
        def fake_scan(*args, **kwargs):
            raise AssertionError('must not start scan after cancellation')
        stats = app.scan_whatsapp_discovery_sites(
            [('https://factory.example/', 'Factory')], cancel_event=event,
            scan_fn=fake_scan, persist_fn=lambda row: 0)
        self.assertEqual(stats['sites_scanned'], 0)


    def test_search_snippets_are_retained_for_contact_extraction(self):
        from types import SimpleNamespace
        html = '''<html><body><li class="b_algo"><h2><a href="https://factory.example">Factory</a></h2><p>WhatsApp: +86 13800138000</p></li></body></html>'''
        snippets = {}
        rows = app._parse_public_engine_results('Bing', SimpleNamespace(text=html), snippet_map=snippets)
        self.assertEqual(rows[0][0], 'https://factory.example')
        self.assertIn('WhatsApp', snippets['https://factory.example'])
        contact = app.extract_contact_evidence(app.BeautifulSoup(snippets['https://factory.example'], 'html.parser'), 'https://factory.example')
        self.assertIn('+8613800138000', contact['whatsapp_contacts'])

    def test_distinct_public_wa_me_links_are_not_collapsed_by_host_dedup(self):
        rows = [('https://wa.me/8613800138000', 'Contact A'), ('https://wa.me/8613900139000', 'Contact B')]
        with patch.object(app, 'search_public_web', return_value=rows):
            result = app.search_web('WhatsApp factory', max_results=10, diagnostics={},
                                    search_mode='仅免费搜索（不调用API）')
        self.assertEqual(len(result), 2)

    def test_same_whatsapp_host_keeps_distinct_direct_numbers_in_discovery_queue(self):
        saved = []
        def no_scan(url, *args, **kwargs):
            if 'wa.me' in url:
                raise AssertionError('direct WhatsApp links must not be fetched as company websites')
            return {'company_website':url,'whatsapp_links':[],'whatsapp_contacts':[]}
        rows = [
            ('https://wa.me/8613800138000', 'Contact A'),
            ('https://wa.me/8613900139000', 'Contact B'),
            ('https://www.factory.example/contact', 'Factory'),
        ]
        stats = app.scan_whatsapp_discovery_sites(
            rows, scan_fn=no_scan, persist_fn=lambda result: saved.append(result) or 1)
        direct_rows = [row for row in saved if row.get('whatsapp_links')]
        self.assertEqual(len(direct_rows), 2)
        self.assertEqual(stats['direct_links_saved'], 2)
        self.assertEqual(stats['whatsapp_links_saved'], 2)

    def test_direct_whatsapp_urls_persist_as_separate_ledger_rows(self):
        import os, sqlite3, tempfile
        old_db = app.DB_FILE
        try:
            with tempfile.TemporaryDirectory() as td:
                app.DB_FILE = os.path.join(td, 'wa.db')
                app.init_db()
                stats = app.scan_whatsapp_discovery_sites([
                    ('https://wa.me/8613800138000', 'Contact A'),
                    ('https://wa.me/8613900139000', 'Contact B'),
                ])
                con = sqlite3.connect(app.DB_FILE)
                rows = con.execute('SELECT whatsapp_value,source_url FROM whatsapp_discoveries ORDER BY whatsapp_value').fetchall()
                con.close()
                self.assertEqual(len(rows), 2)
                self.assertEqual(stats['direct_links_saved'], 2)
                self.assertNotEqual(rows[0][0], rows[1][0])
        finally:
            app.DB_FILE = old_db

    def test_invalid_whatsapp_path_is_not_saved_as_contact(self):
        saved = []
        stats = app.scan_whatsapp_discovery_sites(
            [('https://wa.me/not-a-phone', 'Invalid')],
            persist_fn=lambda row: saved.append(row) or 1)
        self.assertEqual(saved, [])
        self.assertEqual(stats['direct_links_saved'], 0)

    def test_database_save_failure_is_not_counted_as_site_scan_failure(self):
        def fake_scan(url, industry, keywords, country, cancel_event=None):
            return {'company_website': url, 'status': 'HTTP 200',
                    'whatsapp_links': ['https://wa.me/8613800138000'], 'whatsapp_contacts': []}
        def fail_save(_row):
            raise sqlite3.OperationalError('database locked')
        stats = app.scan_whatsapp_discovery_sites(
            [('https://factory.example/', 'Factory')], scan_fn=fake_scan, persist_fn=fail_save)
        self.assertEqual(stats['sites_scanned'], 1)
        self.assertEqual(stats['sites_failed'], 0)
        self.assertEqual(stats['save_errors'], 1)



if __name__ == '__main__':
    unittest.main()
