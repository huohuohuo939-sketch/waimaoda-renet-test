import os
import tempfile
import unittest

import api_services


class PaidSearchEvidenceTests(unittest.TestCase):
    def test_provider_normalization_preserves_whatsapp_snippets_and_distinct_numbers(self):
        snippets = {}
        rows = api_services._normalize([
            {"link": "https://wa.me/8613800000001", "title": "Sales WhatsApp", "snippet": "WhatsApp: +86 13800000001"},
            {"link": "https://wa.me/8613800000002", "title": "Export WhatsApp", "description": "Chat via WhatsApp +86 13800000002"},
            {"link": "https://www.factory.example/contact", "title": "Factory Contact", "snippet": "WhatsApp +86 13800000003"},
            {"link": "https://factory.example/about", "title": "Factory About", "snippet": "Same company domain"},
        ], "fixture", snippet_map=snippets)
        self.assertEqual(len(rows), 3)
        self.assertIn("https://wa.me/8613800000001", snippets)
        self.assertIn("https://wa.me/8613800000002", snippets)
        self.assertIn("WhatsApp +86 13800000003", snippets["https://www.factory.example/contact"])

    def test_search_cache_roundtrips_rows_and_snippets_and_reads_legacy_list(self):
        with tempfile.TemporaryDirectory() as td:
            db = os.path.join(td, "cache.db")
            api_services.init_provider_db(db)
            rows = [("https://wa.me/8613800000001", "WhatsApp")]
            snippets = {rows[0][0]: "WhatsApp: +86 13800000001"}
            api_services._write_search_cache(db, "fixture", "q", "engine", rows, snippets)
            cached = api_services._read_search_cache(db, "fixture", "q", "engine")
            self.assertEqual([tuple(x) for x in cached["rows"]], rows)
            self.assertEqual(cached["snippets"], snippets)
            # Legacy cache entries from 2.5.13 and earlier were stored as a bare list.
            import sqlite3, json, time
            con = sqlite3.connect(db)
            key = api_services._cache_key("legacy", "q", "engine")
            con.execute("INSERT OR REPLACE INTO search_cache(cache_key,provider,query_text,engine,results_json,expires_at,created_at) VALUES(?,?,?,?,?,?,?)",
                        (key, "legacy", "q", "engine", json.dumps(rows), time.time()+60, "now"))
            con.commit(); con.close()
            legacy = api_services._read_search_cache(db, "legacy", "q", "engine")
            self.assertEqual([tuple(x) for x in legacy["rows"]], rows)
            self.assertEqual(legacy["snippets"], {})

    def test_whatsapp_cache_identity_is_url_not_shared_host(self):
        rows = [
            ("https://wa.me/8613800000001", "One"),
            ("https://wa.me/8613800000002", "Two"),
        ]
        # Exercise the same identity rule used by the provider merge path.
        seen = set()
        kept = []
        from urllib.parse import urlparse
        for url, title in rows:
            host = (urlparse(url).hostname or "").lower()
            is_whatsapp = host in ("wa.me", "whatsapp.com") or host.endswith(".whatsapp.com")
            identity = url.split("#", 1)[0].rstrip("/").lower() if is_whatsapp else host
            if identity and identity not in seen:
                seen.add(identity)
                kept.append((url, title))
        self.assertEqual(kept, rows)


if __name__ == "__main__":
    unittest.main()
