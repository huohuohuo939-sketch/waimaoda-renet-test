import threading
import unittest
from unittest.mock import Mock, patch

import requests
import app


class NetworkFailureDetailTests(unittest.TestCase):
    def test_fetch_page_preserves_http_response_when_body_stream_fails(self):
        response = requests.Response()
        response.status_code = 200
        response.url = 'https://factory.example.com/'
        response.headers['Content-Type'] = 'text/html; charset=utf-8'
        response.iter_content = Mock(side_effect=requests.ConnectionError('simulated stream reset'))
        session = Mock()
        session.get.return_value = response

        soup, returned_response, reason = app.fetch_page(session, response.url)

        self.assertIsNone(soup)
        self.assertIs(returned_response, response)
        self.assertIn('读取网页响应正文失败', reason)
        self.assertIn('ConnectionError', reason)
        self.assertIn('已收到 HTTP 200', reason)
        self.assertIn('factory.example.com', reason)

    def test_scan_site_does_not_label_http_200_body_failure_as_http_error(self):
        response = requests.Response()
        response.status_code = 200
        response.url = 'https://factory.example.com/'
        response.headers['Content-Type'] = 'text/html'
        reason = '读取网页响应正文失败：ConnectionError: simulated stream reset'

        with patch.object(app, 'fetch_page', return_value=(None, response, reason)):
            result = app.scan_site('https://factory.example.com/', 'industrial automation', 'industrial automation manufacturer', 'China')

        self.assertEqual(result['status'], '访问失败/响应异常')
        self.assertIn('HTTP：200', result['notes'])
        self.assertIn('simulated stream reset', result['notes'])


if __name__ == '__main__':
    unittest.main()
