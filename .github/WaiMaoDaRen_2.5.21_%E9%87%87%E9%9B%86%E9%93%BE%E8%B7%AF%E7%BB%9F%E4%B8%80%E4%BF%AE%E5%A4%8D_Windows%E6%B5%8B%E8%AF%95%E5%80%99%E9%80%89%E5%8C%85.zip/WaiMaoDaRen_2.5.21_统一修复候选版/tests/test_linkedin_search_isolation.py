import unittest
import ast
import inspect
import textwrap
import app
from search_scheduler import build_rounds


class LinkedInSearchIsolationTests(unittest.TestCase):
    def test_people_queries_are_product_and_country_bound(self):
        queries = app.build_people_queries('wood pulp and bamboo pulp manufacturer', 'China')
        self.assertTrue(queries)
        self.assertLessEqual(len(queries), 3)
        for q in queries:
            self.assertIn('wood pulp and bamboo pulp manufacturer', q)
            self.assertIn('China', q)
            self.assertNotIn('female', q.lower())
            self.assertNotIn('women', q.lower())

    def test_optional_women_queries_remain_product_and_country_bound(self):
        queries = app.build_people_queries('wood pulp and bamboo pulp manufacturer', 'China', women_only=True)
        self.assertTrue(queries)
        for q in queries:
            self.assertIn('wood pulp and bamboo pulp manufacturer', q)
            self.assertIn('China', q)
            self.assertTrue('female' in q.lower() or 'woman' in q.lower())

    def test_linkedin_company_queries_exclude_cross_industry_people_context(self):
        queries = [
            'wood pulp and bamboo pulp manufacturer',
            'China female export sales contact WhatsApp email',
            'wood pulp and bamboo pulp manufacturer',
        ]
        contexts = {
            queries[0]: {'search_intent': 'manufacturer'},
            queries[1]: {'search_intent': 'women_trade_contacts'},
        }
        out = app.build_linkedin_company_queries(queries, contexts, max_queries=3)
        self.assertEqual(out, ['wood pulp and bamboo pulp manufacturer'])

    def test_repeated_exact_phrase_is_collapsed(self):
        q = 'wood pulp and bamboo pulp manufacturer wood pulp and bamboo pulp manufacturer'
        self.assertEqual(app._collapse_repeated_query_phrase(q), 'wood pulp and bamboo pulp manufacturer')


    def test_manual_keyword_identical_to_catalog_phrase_is_not_duplicated(self):
        row = {
            '细分行业代码': 'TEST1', '细分行业': '木浆和竹浆', '大类': '造纸及纸制品',
            '新英文核心词': 'wood pulp and bamboo pulp manufacturer',
        }
        rounds = build_rounds([row], 'China', selected_code='TEST1',
                              extra_terms='wood pulp and bamboo pulp manufacturer')
        self.assertEqual(len(rounds), 1)
        for item in rounds[0]['queries']:
            self.assertNotIn('manufacturer wood pulp and bamboo pulp manufacturer', item['query'])
            if item.get('intent') != 'local_product':
                self.assertEqual(item['query'].count('wood pulp and bamboo pulp manufacturer'), 1)
            else:
                self.assertIn('木浆和竹浆', item['query'])


    def test_worker_reads_linkedin_query_context_from_task_config(self):
        source = inspect.getsource(app.App.worker_discover)
        tree = ast.parse(textwrap.dedent(source))
        bare_query_context = [
            node for node in ast.walk(tree)
            if isinstance(node, ast.Name) and node.id == 'query_context'
        ]
        self.assertEqual(
            bare_query_context, [],
            'worker_discover must not reference the UI method local query_context'
        )
        self.assertIn("config.get('query_context', {})", source)

    def test_linkedin_enrichment_errors_are_isolated_from_primary_scan(self):
        source = inspect.getsource(app.App.worker_discover)
        self.assertIn('LinkedIn企业主页补充搜索失败，主采集继续', source)
        self.assertIn('LinkedIn职业资料补充搜索失败，主采集继续', source)
        self.assertIn('官网核验继续', source)


    def test_worker_people_discovery_is_disabled_unless_user_checks_optional_switch(self):
        self.assertEqual(app.build_task_people_queries({'women_mode':False,'keywords':'industrial pump','country':'China'}),[])
        enabled=app.build_task_people_queries({'women_mode':True,'keywords':'industrial pump','country':'China'})
        self.assertTrue(enabled)
        self.assertTrue(all('female' in q.lower() or 'woman' in q.lower() for q in enabled))

    def test_company_specific_linkedin_enrichment_is_tightly_bounded(self):
        source=inspect.getsource(app.App.worker_discover)
        self.assertIn('search_linkedin_for_company_candidates(items,diagnostics,search_session,limit=8)',source)

    def test_company_query_count_is_bounded(self):
        queries = [f'product {i} manufacturer China' for i in range(12)]
        self.assertEqual(len(app.build_linkedin_company_queries(queries, max_queries=3)), 3)


if __name__ == '__main__':
    unittest.main()
