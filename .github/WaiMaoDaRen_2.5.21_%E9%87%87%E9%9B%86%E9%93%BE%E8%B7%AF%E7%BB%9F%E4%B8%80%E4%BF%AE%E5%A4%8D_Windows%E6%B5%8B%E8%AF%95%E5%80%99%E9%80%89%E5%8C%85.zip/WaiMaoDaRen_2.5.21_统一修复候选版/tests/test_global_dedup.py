import os, tempfile, threading, unittest, sqlite3, time
from global_dedup import GlobalDedup, domain_key, normalize_name

class GlobalDedupTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.db=GlobalDedup(os.path.join(self.tmp.name,'global_dedup.db'))
    def tearDown(self): self.tmp.cleanup()

    def test_domain_normalization_handles_www_and_country_suffix(self):
        self.assertEqual(domain_key('https://www.example.com.cn/contact'), 'example.com.cn')

    def test_cross_industry_and_restart_permanent_skip(self):
        self.db.mark_collected('https://www.acme-machinery.com/about','ACME Machinery Co., Ltd.','https://www.acme-machinery.com',industry='矿山机械')
        # New object simulates application restart; industry is intentionally not part of identity.
        reopened=GlobalDedup(self.db.path)
        domains,names=reopened.load_sets(0)
        self.assertIn('acme-machinery.com',domains)
        self.assertIn(normalize_name('ACME Machinery Co., Ltd.'),names)
        accepted,reason=reopened.reserve_candidate('acme-machinery.com','ACME Machinery','https://acme-machinery.com',industry='农业机械')
        self.assertFalse(accepted); self.assertEqual(reason,'already_collected')

    def test_recent_candidate_is_atomically_reserved_once(self):
        results=[]; barrier=threading.Barrier(8)
        def worker():
            barrier.wait()
            results.append(self.db.reserve_candidate('factory-example.cn','示例工厂','https://factory-example.cn'))
        threads=[threading.Thread(target=worker) for _ in range(8)]
        [t.start() for t in threads]; [t.join() for t in threads]
        self.assertEqual(sum(1 for ok,_ in results if ok),1)

    def test_expired_failed_candidate_can_be_retried(self):
        self.db.record('retry-example.com','Retry Factory','https://retry-example.com','failed')
        con=sqlite3.connect(self.db.path)
        con.execute("UPDATE companies SET last_seen='2020-01-01 00:00:00' WHERE domain='retry-example.com'")
        con.commit(); con.close()
        accepted,reason=self.db.reserve_candidate('retry-example.com','Retry Factory','https://retry-example.com')
        self.assertTrue(accepted); self.assertEqual(reason,'retry_incomplete')


    def test_recent_failed_candidate_can_be_retried_immediately(self):
        self.db.record('fresh-failure.example','Fresh Failure Factory','https://fresh-failure.example','failed')
        accepted,reason=self.db.reserve_candidate('fresh-failure.example','Fresh Failure Factory','https://fresh-failure.example')
        self.assertTrue(accepted)
        self.assertEqual(reason,'retry_incomplete')

    def test_recent_review_candidate_is_not_in_recent_skip_sets(self):
        self.db.record('review-factory.example','Review Factory','https://review-factory.example','review')
        domains,names=self.db.load_sets(recent_days=30)
        self.assertNotIn('review-factory.example',domains)
        self.assertNotIn(normalize_name('Review Factory'),names)
        accepted,reason=self.db.reserve_candidate('review-factory.example','Review Factory','https://review-factory.example')
        self.assertTrue(accepted)
        self.assertEqual(reason,'retry_incomplete')


    def test_recent_discovered_candidate_can_be_retried_immediately(self):
        self.db.record('discovered-factory.cn','Discovered Factory','https://discovered-factory.cn','discovered')
        domains,names=self.db.load_sets(recent_days=30)
        self.assertNotIn('discovered-factory.cn',domains)
        self.assertNotIn(normalize_name('Discovered Factory'),names)
        accepted,reason=self.db.reserve_candidate('discovered-factory.cn','Discovered Factory','https://discovered-factory.cn')
        self.assertTrue(accepted)
        self.assertEqual(reason,'retry_incomplete')

    def test_collected_company_can_be_reserved_for_contact_refresh(self):
        self.db.mark_collected('contact-gap.cn','Contact Gap Factory','https://contact-gap.cn')
        accepted,reason=self.db.reserve_candidate('contact-gap.cn','Contact Gap Factory','https://contact-gap.cn',allow_collected_refresh=True)
        self.assertTrue(accepted)
        self.assertEqual(reason,'refresh_contacts')
        # Refresh reservation must not downgrade the permanent collected state.
        self.assertEqual(self.db.lookup('contact-gap.cn')['status'],'collected')

    def test_confirmed_excluded_candidate_is_not_retried(self):
        self.db.record('irrelevant.example','Irrelevant Site','https://irrelevant.example','excluded')
        accepted,reason=self.db.reserve_candidate('irrelevant.example','Irrelevant Site','https://irrelevant.example')
        self.assertFalse(accepted)
        self.assertEqual(reason,'confirmed_excluded')

    def test_same_name_different_domain_is_not_merged(self):
        self.db.mark_collected('first-example.com','华星机械有限公司','https://first-example.com')
        accepted,reason=self.db.reserve_candidate('second-example.com','华星机械有限公司','https://second-example.com')
        self.assertFalse(accepted); self.assertEqual(reason,'possible_name_duplicate')
        con=sqlite3.connect(self.db.path)
        count=con.execute('SELECT COUNT(*) FROM companies').fetchone()[0]
        con.close(); self.assertEqual(count,2)

    def test_legacy_migration_is_additive(self):
        self.db.migrate_legacy([('old-factory.cn','旧工厂有限公司','https://old-factory.cn','中国','keep','2025-01-01')],
                               [('old-factory.cn','旧工厂有限公司','https://old-factory.cn','collected','old query','2025-01-01','')])
        domains,names=self.db.load_sets(0)
        self.assertIn('old-factory.cn',domains)
        self.assertIn(normalize_name('旧工厂有限公司'),names)

if __name__=='__main__': unittest.main()
