import json
import os
import sqlite3
import tempfile
import unittest

import history_store


class HistoryStoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.archive = os.path.join(self.tmp.name, 'collection_history.db')

    def tearDown(self):
        self.tmp.cleanup()

    def test_same_company_can_be_archived_in_two_industries_without_mixing(self):
        history_store.create_task(self.archive, 'task-furniture', '家居制造业', '木质家具制造', 'China', 'wood furniture manufacturer')
        history_store.create_task(self.archive, 'task-textile', '纺织服装', '运动服装制造', 'China', 'sportswear factory')
        row1 = {'company_name': 'Example Factory', 'company_website': 'https://example.com', 'industry_category': '家居制造业', 'industry': '木质家具制造', 'country': 'China', 'quality_status': 'review'}
        row2 = {'company_name': 'Example Factory', 'company_website': 'https://example.com', 'industry_category': '纺织服装', 'industry': '运动服装制造', 'country': 'China', 'quality_status': 'keep'}
        self.assertTrue(history_store.record_lead(self.archive, 'task-furniture', row1))
        self.assertTrue(history_store.record_lead(self.archive, 'task-textile', row2))
        self.assertEqual(len(history_store.list_task_leads(self.archive, 'task-furniture')), 1)
        self.assertEqual(len(history_store.list_task_leads(self.archive, 'task-textile')), 1)
        self.assertEqual(set(history_store.list_categories(self.archive)), {'家居制造业', '纺织服装'})

    def test_duplicate_domain_in_same_task_updates_not_duplicates(self):
        history_store.create_task(self.archive, 'task-1', '家居', '家具', 'China', 'wood furniture')
        a = {'company_name': 'A', 'company_website': 'https://www.example.com', 'industry': '家具'}
        b = {'company_name': 'A Updated', 'company_website': 'https://example.com/', 'industry': '家具'}
        history_store.record_lead(self.archive, 'task-1', a)
        history_store.record_lead(self.archive, 'task-1', b)
        rows = history_store.list_task_leads(self.archive, 'task-1')
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['company_name'], 'A Updated')

    def test_master_migration_is_grouped_and_idempotent(self):
        master = os.path.join(self.tmp.name, 'factorylead.db')
        con = sqlite3.connect(master)
        con.execute('''CREATE TABLE leads(domain TEXT,company_name TEXT,website TEXT,category TEXT,industry TEXT,country TEXT,
                     score INTEGER,operation_score INTEGER,evidence TEXT,whatsapp TEXT,emails TEXT,phones TEXT,linkedin TEXT,
                     sources TEXT,status TEXT,notes TEXT,collected_at TEXT,email_details TEXT,whatsapp_contacts TEXT,
                     contact_evidence TEXT,quality_status TEXT,quality_reason TEXT)''')
        con.execute("INSERT INTO leads VALUES('a.com','A','https://a.com','家具','木质家具','China',1,2,'factory','[]','[]','[]','[]','[]','','','2026-01-01','[]','[]','{}','review','')")
        con.execute("INSERT INTO leads VALUES('b.com','B','https://b.com','纺织','运动服装','China',1,2,'factory','[]','[]','[]','[]','[]','','','2026-01-01','[]','[]','{}','review','')")
        con.commit(); con.close()
        first = history_store.migrate_master_once(self.archive, master)
        second = history_store.migrate_master_once(self.archive, master)
        self.assertEqual(first['imported'], 2)
        self.assertEqual(first['groups'], 2)
        self.assertTrue(second.get('already_migrated'))
        self.assertEqual(len(history_store.list_tasks(self.archive)), 2)

    def test_task_count_and_completion_are_synced(self):
        history_store.create_task(self.archive, 'task-2', '家居', '家具', 'China', 'wood furniture')
        history_store.record_lead(self.archive, 'task-2', {'company_name': 'A', 'company_website': 'https://a.com'})
        history_store.finish_task(self.archive, 'task-2', '已完成')
        row = history_store.list_tasks(self.archive)[0]
        self.assertEqual(row[6], 1)
        self.assertEqual(row[7], '已完成')


    def test_old_archive_schema_is_upgraded_without_losing_rows(self):
        con = sqlite3.connect(self.archive)
        con.execute("CREATE TABLE tasks(task_id TEXT PRIMARY KEY,created_at TEXT NOT NULL,finished_at TEXT NOT NULL DEFAULT '',category TEXT NOT NULL DEFAULT '',industry TEXT NOT NULL DEFAULT '',country TEXT NOT NULL DEFAULT '',keywords TEXT NOT NULL DEFAULT '',task_type TEXT NOT NULL DEFAULT '采集',record_count INTEGER NOT NULL DEFAULT 0,status TEXT NOT NULL DEFAULT '进行中')")
        con.execute("CREATE TABLE task_leads(task_id TEXT NOT NULL,domain TEXT NOT NULL,company_name TEXT NOT NULL DEFAULT '',website TEXT NOT NULL DEFAULT '',category TEXT NOT NULL DEFAULT '',industry TEXT NOT NULL DEFAULT '',country TEXT NOT NULL DEFAULT '',quality_status TEXT NOT NULL DEFAULT 'review',collected_at TEXT NOT NULL DEFAULT '',record_json TEXT NOT NULL,PRIMARY KEY(task_id,domain))")
        con.execute("INSERT INTO tasks(task_id,created_at,category,industry,country,record_count) VALUES('old-task','2026-01-01','家居制造业','木质家具制造','China',1)")
        con.execute("INSERT INTO task_leads VALUES('old-task','old.example','旧企业','https://old.example','家居制造业','木质家具制造','China','review','2026-01-01','{\"company_name\":\"旧企业\"}')")
        con.commit(); con.close()
        history_store.init(self.archive)
        self.assertTrue(os.path.isfile(self.archive + '.pre_category_sync.bak'))
        self.assertEqual(history_store.list_task_leads(self.archive, 'old-task')[0]['company_name'], '旧企业')
        history_store.create_task(self.archive, 'new-task', '纺织服装', '运动服装制造', 'China', 'sportswear factory')
        self.assertTrue(history_store.record_lead(self.archive, 'new-task', {'company_name':'新企业','company_website':'https://new.example'}))
        self.assertEqual(history_store.list_task_leads(self.archive, 'new-task')[0]['industry_category'], '纺织服装')

    def test_task_metadata_fills_missing_row_category_and_syncs_filters(self):
        history_store.create_task(self.archive, 'task-meta', '家居制造业', '木质家具制造', 'China', 'wood furniture factory')
        history_store.record_lead(self.archive, 'task-meta', {'company_name':'Metadata Factory','company_website':'https://meta.example'})
        row = history_store.list_task_leads(self.archive, 'task-meta')[0]
        self.assertEqual(row['industry_category'], '家居制造业')
        self.assertEqual(row['industry'], '木质家具制造')
        self.assertEqual(row['country'], 'China')
        self.assertIn('家居制造业', history_store.list_categories(self.archive))
        self.assertEqual(len(history_store.list_tasks(self.archive, '家居制造业')), 1)

    def test_merge_legacy_archive_is_idempotent(self):
        source = os.path.join(self.tmp.name, 'old_archive.db')
        target = os.path.join(self.tmp.name, 'canonical_archive.db')
        history_store.create_task(source, 'legacy-task', '家居', '家具', 'China', 'wood')
        history_store.record_lead(source, 'legacy-task', {'company_name':'Legacy','company_website':'https://legacy.example'})
        first = history_store.merge_archive_file(target, source)
        second = history_store.merge_archive_file(target, source)
        self.assertEqual(first, {'tasks': 1, 'records': 1})
        self.assertEqual(second, {'tasks': 0, 'records': 0})
        self.assertEqual(len(history_store.list_task_leads(target, 'legacy-task')), 1)


    def test_old_v1_migration_marker_does_not_skip_new_master_archive_sync(self):
        master = os.path.join(self.tmp.name, 'factorylead_v1.db')
        con = sqlite3.connect(master)
        con.execute('''CREATE TABLE leads(domain TEXT,company_name TEXT,website TEXT,category TEXT,industry TEXT,country TEXT,score INTEGER,operation_score INTEGER,evidence TEXT,whatsapp TEXT,emails TEXT,phones TEXT,linkedin TEXT,sources TEXT,status TEXT,notes TEXT,collected_at TEXT,email_details TEXT,whatsapp_contacts TEXT,contact_evidence TEXT,quality_status TEXT,quality_reason TEXT)''')
        con.execute("INSERT INTO leads VALUES('old-a.cn','旧家具厂','https://old-a.cn','家居制造业','木质家具制造','China',10,3,'factory','[]','[]','[]','[]','[]','','','2026-01-01','[]','[]','{}','review','')")
        con.commit(); con.close()
        history_store.create_task(self.archive, 'legacy-master-migration-v1', '系统', '旧版迁移标记', '', '', '系统标记')
        history_store.finish_task(self.archive, 'legacy-master-migration-v1', '完成')
        result = history_store.migrate_master_once(self.archive, master)
        self.assertEqual(result['imported'], 1)
        self.assertEqual(len(history_store.list_task_leads(self.archive, 'legacy-' + __import__('hashlib').sha1('家居制造业|木质家具制造|China'.encode()).hexdigest()[:16])), 1)
        self.assertTrue(history_store.migrate_master_once(self.archive, master).get('already_migrated'))


    def test_system_migration_marker_is_not_shown_as_industry_category(self):
        history_store.create_task(self.archive, 'system-marker', '系统', '迁移标记', '', '', '系统标记')
        history_store.create_task(self.archive, 'real-task', '家居制造业', '木质家具制造', 'China', 'wood')
        self.assertEqual(history_store.list_categories(self.archive), ['家居制造业'])


if __name__ == '__main__':
    unittest.main()
