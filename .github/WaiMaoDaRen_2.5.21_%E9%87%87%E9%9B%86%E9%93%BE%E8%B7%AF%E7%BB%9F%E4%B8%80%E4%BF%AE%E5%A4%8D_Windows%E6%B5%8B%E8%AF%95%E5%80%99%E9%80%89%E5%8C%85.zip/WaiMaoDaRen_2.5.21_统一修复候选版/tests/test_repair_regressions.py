import os
import queue
import sqlite3
import tempfile
import threading
import types
import unittest
from unittest.mock import patch

import app
import api_services
import data_quality


class _Status:
    def __init__(self): self.value = ''
    def set(self, value): self.value = value


class _FakeQueueApp:
    def __init__(self):
        self._ui_events = queue.Queue()
        self.status = _Status()
        self.delays = []
        self.processed = 0
    def winfo_exists(self): return True
    def after(self, delay, callback): self.delays.append(delay)


class RepairRegressionTests(unittest.TestCase):

    def test_contact_discovery_includes_chinese_factory_navigation_labels(self):
        required = ('联系我们', '联系方式', '关于我们', '公司简介', '工厂介绍', '业务咨询', '询盘')
        for term in required:
            self.assertIn(term, app.CONTACT_PATHS)

    def test_site_scan_page_budget_remains_bounded_after_contact_fallback_expansion(self):
        self.assertLessEqual(app.MAX_SITE_PAGES, 8)
        self.assertGreaterEqual(app.MAX_SITE_PAGES, 7)

    def test_whatsapp_discovery_persists_before_manufacturer_qualification(self):
        with tempfile.TemporaryDirectory() as td:
            db = os.path.join(td, 'contacts.db')
            with patch.object(app, 'DB_FILE', db):
                result = {
                    'company_website': 'https://example-factory.test/',
                    'company_name': 'Example Factory', 'country': '中国', 'industry': '测试行业',
                    'whatsapp_links': ['https://wa.me/8613800138000'],
                    'whatsapp_contacts': ['+8613800138000'],
                    'contact_evidence': {
                        'whatsapp_links': {'https://wa.me/8613800138000': 'https://example-factory.test/contact'},
                        'whatsapp_contacts': {'+8613800138000': 'https://example-factory.test/contact'},
                    },
                    'quality_status': 'excluded',
                }
                saved = app.persist_whatsapp_discoveries(result)
                self.assertEqual(saved, 2)
                con = sqlite3.connect(db)
                rows = con.execute('SELECT whatsapp_type,whatsapp_value,source_url FROM whatsapp_discoveries ORDER BY whatsapp_type').fetchall()
                con.close()
                self.assertEqual(len(rows), 2)
                self.assertTrue(all(row[2] == 'https://example-factory.test/contact' for row in rows))



    def test_root_domain_collapses_common_subdomains_and_country_suffixes(self):
        self.assertEqual(app.root_domain('https://www.sales.example.com.cn/contact'), 'example.com.cn')
        self.assertEqual(app.root_domain('https://m.factory.example.co.uk/contact'), 'example.co.uk')
        self.assertEqual(app.root_domain('https://example.com/contact'), 'example.com')

    def test_search_indexed_whatsapp_evidence_keeps_review_status_and_source_note(self):
        with tempfile.TemporaryDirectory() as td:
            db=os.path.join(td,'wa.db')
            old=app.DB_FILE
            try:
                app.DB_FILE=db
                app.init_db()
                value='https://wa.me/8613800138000'
                app.persist_whatsapp_discoveries({
                    'company_website':'https://factory.example/', 'company_name':'Factory',
                    'whatsapp_links':[value], 'whatsapp_contacts':[],
                    'contact_evidence':{'whatsapp_links':{value:'https://factory.example/'},'whatsapp_contacts':{}},
                    'evidence_notes':{value:'搜索引擎公开摘要明确展示 WhatsApp；尚未在原网页复核'},
                    'whatsapp_source_status':'待原网页复核',
                })
                con=sqlite3.connect(db)
                row=con.execute('SELECT evidence,status FROM whatsapp_discoveries').fetchone()
                con.close()
                self.assertEqual(row[1],'待原网页复核')
                self.assertIn('尚未在原网页复核',row[0])
            finally:
                app.DB_FILE=old

    def test_database_migration_row_counter_preserves_whatsapp_only_database(self):
        with tempfile.TemporaryDirectory() as td:
            db=os.path.join(td,'whatsapp-only.db')
            con=sqlite3.connect(db)
            con.execute('CREATE TABLE whatsapp_discoveries (id INTEGER PRIMARY KEY, whatsapp_value TEXT)')
            con.execute("INSERT INTO whatsapp_discoveries(whatsapp_value) VALUES('+8613812345678')")
            con.commit(); con.close()
            self.assertEqual(app._sqlite_user_row_count(db),1)


    def test_windows_db_resolution_does_not_overwrite_whatsapp_only_user_data(self):
        with tempfile.TemporaryDirectory() as td:
            data_root=os.path.join(td,'local')
            app_dir=os.path.join(td,'WaiMaoDaRen_2.5.9')
            os.makedirs(data_root); os.makedirs(app_dir)
            target_dir=os.path.join(data_root,'WaiMaoDaRen')
            os.makedirs(target_dir)
            target=os.path.join(target_dir,'factorylead.db')
            con=sqlite3.connect(target)
            con.execute('CREATE TABLE whatsapp_discoveries (id INTEGER PRIMARY KEY, whatsapp_value TEXT)')
            con.execute("INSERT INTO whatsapp_discoveries(whatsapp_value) VALUES('+8613812345678')")
            con.commit(); con.close()
            legacy=os.path.join(app_dir,'factorylead.db')
            con=sqlite3.connect(legacy)
            con.execute('CREATE TABLE leads (id INTEGER PRIMARY KEY, company_name TEXT)')
            con.execute("INSERT INTO leads(company_name) VALUES('Legacy Factory')")
            con.commit(); con.close()
            with patch.object(app.os,'name','nt'), patch.dict(app.os.environ,{'LOCALAPPDATA':data_root}):
                resolved=app.resolve_persistent_db_file(app_dir)
            self.assertEqual(os.path.abspath(resolved),os.path.abspath(target))
            con=sqlite3.connect(target)
            self.assertEqual(con.execute('SELECT COUNT(*) FROM whatsapp_discoveries').fetchone()[0],1)
            con.close()

    def test_database_migration_row_counter_treats_empty_schema_as_empty(self):
        with tempfile.TemporaryDirectory() as td:
            db=os.path.join(td,'empty.db')
            con=sqlite3.connect(db)
            con.execute('CREATE TABLE leads (id INTEGER PRIMARY KEY, company_name TEXT)')
            con.execute('CREATE TABLE whatsapp_discoveries (id INTEGER PRIMARY KEY, whatsapp_value TEXT)')
            con.commit(); con.close()
            self.assertEqual(app._sqlite_user_row_count(db),0)

    def test_init_db_creates_whatsapp_ledger_before_first_scan(self):
        with tempfile.TemporaryDirectory() as td:
            old_db=app.DB_FILE
            try:
                app.DB_FILE=os.path.join(td,'fresh.db')
                app.init_db()
                con=sqlite3.connect(app.DB_FILE)
                cols={row[1] for row in con.execute('PRAGMA table_info(whatsapp_discoveries)')}
                count=con.execute('SELECT COUNT(*) FROM whatsapp_discoveries').fetchone()[0]
                con.close()
                self.assertTrue({'whatsapp_value','source_url','evidence','first_seen','last_seen'}.issubset(cols))
                self.assertEqual(count,0)
            finally:
                app.DB_FILE=old_db

    def test_manual_url_verification_persists_whatsapp_before_status_filter(self):
        fake=types.SimpleNamespace()
        fake.current_task_id='manual-test'
        fake.rows=[]
        fake._post_ui=lambda *args,**kwargs: None
        fake._merge_worker_rows=lambda items: setattr(fake,'merged',items)
        fake._finish_task_ui=lambda: None
        fake.add_result=lambda *args,**kwargs: None
        calls=[]
        result={'company_name':'Manual Factory','company_website':'https://manual-factory.test',
                'industry_category':'测试','whatsapp_links':['https://wa.me/8613812345678'],
                'whatsapp_contacts':['+8613812345678'],'contact_evidence':{},
                'status':'访问失败 HTTP 503','notes':'temporary'}
        with patch.object(app,'scan_site',return_value=result), \
             patch.object(app,'persist_whatsapp_discoveries',side_effect=lambda row: calls.append(row) or 2), \
             patch.object(app,'save_lead') as save:
            app.App.worker_verify(fake,['https://manual-factory.test'],{'_archive_task_id':'manual-test','industry':'测试','keywords':'','country':'China','category':'测试','workers':1})
        self.assertEqual(len(calls),1)
        save.assert_not_called()

    def test_history_skip_is_paused_without_forking_the_canonical_registry(self):
        with tempfile.TemporaryDirectory() as td:
            normal = app.resolve_global_dedup_path(td, diagnostic=False)
            diagnostic = app.resolve_global_dedup_path(td, diagnostic=True)
            self.assertNotEqual(normal, diagnostic)  # resolver can still identify legacy diagnostic paths
            self.assertTrue(normal.endswith('global_dedup.db'))
            self.assertTrue(diagnostic.endswith('global_dedup_diagnostic.db'))
        self.assertTrue(app.DIAGNOSTIC_DISABLE_GLOBAL_HISTORY_FILTER)
        self.assertTrue(app.GLOBAL_DEDUP_FILE.endswith('global_dedup.db'))

    def test_ui_event_drain_is_bounded(self):
        fake = _FakeQueueApp()
        fake._process_ui_events = types.MethodType(app.App._process_ui_events, fake)
        for _ in range(1000):
            fake._ui_events.put((lambda: setattr(fake, 'processed', fake.processed + 1), (), {}))
        app.App._process_ui_events(fake)
        self.assertGreater(fake.processed, 0)
        self.assertLessEqual(fake.processed, 60)
        self.assertTrue(fake.delays)
        self.assertEqual(fake.delays[-1], 1)
        self.assertGreater(fake._ui_events.qsize(), 0)


    def test_contact_incomplete_collected_leads_are_returned_for_refresh(self):
        with tempfile.TemporaryDirectory() as td:
            db=os.path.join(td,'leads.db')
            old_db=app.DB_FILE
            try:
                app.DB_FILE=db
                app.init_db()
                con=sqlite3.connect(db)
                con.execute("INSERT INTO leads(domain,company_name,website,quality_status,whatsapp,emails) VALUES(?,?,?,?,?,?)",
                            ('factory-a.cn','Factory A','https://factory-a.cn','keep','[]','[]'))
                con.execute("INSERT INTO leads(domain,company_name,website,quality_status,whatsapp,emails) VALUES(?,?,?,?,?,?)",
                            ('factory-b.cn','Factory B','https://factory-b.cn','keep','[\"https://wa.me/8613812345678\"]','[\"sales@factory-b.cn\"]'))
                con.commit(); con.close()
                domains,names=app.load_contact_incomplete_registry()
                self.assertIn('factory-a.cn',domains)
                self.assertIn(app.normalize_company_key('Factory A'),names)
                self.assertNotIn('factory-b.cn',domains)
            finally:
                app.DB_FILE=old_db

    def test_review_manufacturer_with_missing_contacts_is_eligible_for_refresh(self):
        with tempfile.TemporaryDirectory() as td:
            db=os.path.join(td,'leads.db')
            old_db=app.DB_FILE
            try:
                app.DB_FILE=db
                app.init_db()
                con=sqlite3.connect(db)
                con.execute("INSERT INTO leads(domain,company_name,website,quality_status,evidence,score,whatsapp,emails) VALUES(?,?,?,?,?,?,?,?)",
                            ('review-maker.cn','Review Maker','https://review-maker.cn','review','production line；factory workshop',42,'[]','[]'))
                con.execute("INSERT INTO leads(domain,company_name,website,quality_status,evidence,score,whatsapp,emails) VALUES(?,?,?,?,?,?,?,?)",
                            ('review-directory.cn','Review Directory','https://review-directory.cn','review','supplier directory',42,'[]','[]'))
                con.commit(); con.close()
                domains,names=app.load_contact_incomplete_registry()
                self.assertIn('review-maker.cn',domains)
                self.assertNotIn('review-directory.cn',domains)
            finally:
                app.DB_FILE=old_db

    def test_recent_seen_registry_never_hides_incomplete_candidates(self):
        domains,names=app.load_recently_seen_registry(days=30)
        self.assertEqual(domains,set())
        self.assertEqual(names,set())

    def test_invalid_company_names_are_not_shown_as_manufacturer_results(self):
        self.assertFalse(app.is_displayable_company_name(''))
        self.assertFalse(app.is_displayable_company_name('https://example.com'))
        self.assertFalse(app.is_displayable_company_name('www.example.com'))
        self.assertTrue(app.is_displayable_company_name('深圳华星机械有限公司'))

    def test_startup_hides_blank_or_url_only_legacy_rows_without_deleting_them(self):
        with tempfile.TemporaryDirectory() as td:
            old_db=app.DB_FILE
            try:
                app.DB_FILE=os.path.join(td,'startup_filter.db')
                app.init_db()
                con=sqlite3.connect(app.DB_FILE)
                for domain,name,website in [
                    ('valid-factory.cn','深圳华星机械有限公司','https://valid-factory.cn'),
                    ('blank-factory.cn','','https://blank-factory.cn'),
                    ('url-title-factory.cn','https://url-title-factory.cn','https://url-title-factory.cn')]:
                    con.execute('INSERT INTO leads(domain,company_name,website,quality_status) VALUES(?,?,?,?)',(domain,name,website,'review'))
                con.commit(); con.close()
                rows=app.load_saved_leads()
                self.assertEqual([x['company_name'] for x in rows],['深圳华星机械有限公司'])
                con=sqlite3.connect(app.DB_FILE)
                self.assertEqual(con.execute('SELECT COUNT(*) FROM leads').fetchone()[0],3)
                con.close()
            finally:
                app.DB_FILE=old_db

    def test_whatsapp_requires_explicit_international_number(self):
        self.assertTrue(app.is_eligible_whatsapp_number('+8613812345678'))
        self.assertFalse(app.is_eligible_whatsapp_number('13812345678'))
        self.assertFalse(app.is_eligible_whatsapp_number('+864001234567'))
        self.assertFalse(app.is_eligible_whatsapp_number('+861381234'))
        self.assertEqual(app.normalize_whatsapp_number_display('+86 138 1234 5678'), '+8613812345678')
        self.assertEqual(app.normalize_whatsapp_number_display('13812345678'), '')

    def test_compact_international_whatsapp_label_is_supported_but_china_mobile_is_not_inferred(self):
        self.assertTrue(app.is_eligible_whatsapp_number('447911123456', allow_compact_international=True, country='中国'))
        self.assertFalse(app.is_eligible_whatsapp_number('13812345678', allow_compact_international=True, country='中国'))
        self.assertEqual(app.normalize_whatsapp_number_display('13812345678'), '')

    def test_compact_international_whatsapp_label_extraction_keeps_evidence(self):
        from bs4 import BeautifulSoup
        html='<html><body><p>WhatsApp: 447911123456</p><p>Phone: 13812345678</p></body></html>'
        result=app.extract_contact_evidence(BeautifulSoup(html,'html.parser'),'https://example-factory.cn/contact',country='中国')
        self.assertIn('+447911123456',result['whatsapp_contacts'])
        self.assertNotIn('+13812345678',result['whatsapp_contacts'])

    def test_company_country_does_not_restrict_whatsapp_phone_country(self):
        self.assertTrue(app.is_eligible_whatsapp_number('+8613812345678', country='中国'))
        self.assertTrue(app.is_eligible_whatsapp_number('+14155552671', country='中国'))
        self.assertTrue(app.is_eligible_whatsapp_number('+6581234567', country='中国'))
        self.assertFalse(app.is_eligible_whatsapp_number('+8675512345678', country='中国'))
        self.assertFalse(app.is_eligible_whatsapp_number('13812345678', country='中国'))

    def test_china_factory_whatsapp_label_accepts_overseas_number_but_not_plain_phone(self):
        from bs4 import BeautifulSoup
        html = '''<html><body>
        <p>WhatsApp: +86 138 1234 5678</p>
        <p>WhatsApp: +1 415 555 2671</p>
        <p>Phone: +86 139 1234 5678</p>
        </body></html>'''
        result = app.extract_contact_evidence(BeautifulSoup(html, 'html.parser'), 'https://example-factory.cn/contact', country='中国')
        self.assertIn('+8613812345678', result['whatsapp_contacts'])
        self.assertIn('+14155552671', result['whatsapp_contacts'])
        self.assertNotIn('+8613912345678', result['whatsapp_contacts'])

    def test_china_whatsapp_accepts_0086_and_normalizes_to_plus86(self):
        self.assertTrue(app.is_eligible_whatsapp_number('0086 138 1234 5678', country='中国'))
        self.assertEqual(app.normalize_whatsapp_number_display('0086 138 1234 5678', country='中国'), '+8613812345678')
        accepted, _, _ = data_quality.clean_and_dedupe([{
            'company_name':'中国示例工厂', 'company_website':'https://example-factory.cn', 'country':'中国',
            'manufacturer_evidence':'自有工厂 生产线 manufacturer', 'whatsapp_contacts':['0086 138 1234 5678']
        }])
        self.assertIn('+8613812345678', accepted[0]['whatsapp_contacts'])

    def test_whatsapp_api_send_slash_url_is_extracted(self):
        from bs4 import BeautifulSoup
        html = '''<html><body><a href="https://api.whatsapp.com/send/?phone=8613812345678&amp;text=Hello">WhatsApp</a></body></html>'''
        result = app.extract_contact_evidence(BeautifulSoup(html, 'html.parser'), 'https://example-factory.cn/contact', country='中国')
        self.assertIn('+8613812345678', result['whatsapp_contacts'])
        self.assertTrue(any('api.whatsapp.com/send/' in x for x in result['whatsapp_links']))




    def test_scan_site_keeps_homepage_whatsapp_when_stopped_before_contact_pages(self):
        from bs4 import BeautifulSoup
        from types import SimpleNamespace
        event=threading.Event()
        html='''<html><head><title>Factory Contact</title></head><body><h1>Example Factory</h1><a href="https://wa.me/8613812345678">WhatsApp</a><p>manufacturer factory production line industrial pump</p></body></html>'''
        response=SimpleNamespace(url='https://factory.test/',headers={'Content-Type':'text/html'},status_code=200)
        def stop_after_homepage(*args,**kwargs):
            event.set()
            return None
        persisted=[]
        with patch.object(app,'fetch_page',return_value=(BeautifulSoup(html,'html.parser'),response,'')), \
             patch.object(app,'load_robots_parser',side_effect=stop_after_homepage), \
             patch.object(app,'persist_whatsapp_discoveries',side_effect=lambda row: persisted.append(row) or 2):
            result=app.scan_site('https://factory.test','industrial pump','industrial pump manufacturer','China',cancel_event=event)
        self.assertTrue(persisted, 'homepage WhatsApp must be saved before the later stop')
        self.assertEqual(result['status'],'任务已停止')
        self.assertIn('https://wa.me/8613812345678',result['whatsapp_links'])
        self.assertIn('+8613812345678',result['whatsapp_contacts'])
        self.assertEqual(result['contact_evidence']['whatsapp_links']['https://wa.me/8613812345678'],'https://factory.test/')

    def test_whatsapp_url_with_0086_phone_normalizes_number_without_double_zero(self):
        from bs4 import BeautifulSoup
        html='''<html><body><a href="https://api.whatsapp.com/send?phone=008613812345678">WhatsApp</a></body></html>'''
        result=app.extract_contact_evidence(BeautifulSoup(html,'html.parser'),'https://factory.test/contact',country='中国')
        self.assertIn('+8613812345678',result['whatsapp_contacts'])
        self.assertNotIn('+008613812345678',result['whatsapp_contacts'])

    def test_whatsapp_channel_and_group_invite_links_are_preserved_without_guessing_numbers(self):
        from bs4 import BeautifulSoup
        html = '''<html><body><a href="https://chat.whatsapp.com/AbCdEf123">Join WhatsApp</a><a href="https://www.whatsapp.com/channel/12345">WhatsApp Channel</a></body></html>'''
        result=app.extract_contact_evidence(BeautifulSoup(html,'html.parser'),'https://example-factory.cn/contact',country='中国')
        self.assertTrue(any('chat.whatsapp.com/invite/' in x or 'chat.whatsapp.com/AbCdEf123' in x for x in result['whatsapp_links']))
        self.assertTrue(any('whatsapp.com/channel/' in x for x in result['whatsapp_links']))
        self.assertEqual(result['whatsapp_contacts'], [])

    def test_data_quality_keeps_www_whatsapp_and_normalizes_0086_link(self):
        accepted, _, _ = data_quality.clean_and_dedupe([{
            'company_name':'中国示例工厂', 'company_website':'https://example-factory.cn', 'country':'中国',
            'manufacturer_evidence':'自有工厂 生产线 manufacturer',
            'whatsapp_links':['https://www.whatsapp.com/send/?phone=008613812345678']
        }])
        self.assertIn('https://wa.me/8613812345678', accepted[0]['whatsapp_links'])

    def test_whatsapp_widget_sibling_data_attributes_are_combined(self):
        from bs4 import BeautifulSoup
        html = '''<html><body><div class="whatsapp-widget" data-whatsapp="true" data-phone="+86 138 1234 5678"></div></body></html>'''
        result = app.extract_contact_evidence(BeautifulSoup(html, 'html.parser'), 'https://example-factory.cn/contact', country='中国')
        self.assertIn('+8613812345678', result['whatsapp_contacts'])

    def test_non_factory_software_and_education_pages_are_score_capped(self):
        from bs4 import BeautifulSoup
        soup = BeautifulSoup('<html><head><title>TeamViewer - Remote Software Platform</title></head><body><p>Products, contact, international business, manufacturing software</p></body></html>', 'html.parser')
        score, evidence = app.score_site([('https://www.teamviewer.com/', soup)], 'mining machinery', 'mining machinery manufacturer China')
        self.assertLessEqual(score, 12)
        self.assertIn('teamviewer', evidence.lower())

    def test_factory_candidate_requires_public_contact_and_relevant_factory_proof(self):
        no_contact = {'emails':[], 'whatsapp_links':[], 'whatsapp_contacts':[], 'manufacturer_score':60,
                      'manufacturer_evidence':'factory manufacturer mining machinery'}
        self.assertFalse(app.is_trade_contact_candidate(no_contact, 25))
        no_product_relevance = {'emails':['sales@example.cn'], 'manufacturer_score':22,
                                'manufacturer_evidence':'factory manufacturer'}
        self.assertFalse(app.is_trade_contact_candidate(no_product_relevance, 25))

    def test_trade_candidate_requires_factory_proof_not_just_email_and_export_signal(self):
        non_factory = {'emails':['hello@teamviewer.example'], 'operation_score':80, 'manufacturer_score':0,
                       'manufacturer_evidence':'产品、联系、国际业务'}
        self.assertFalse(app.is_trade_contact_candidate(non_factory, 25))
        factory = {'emails':['sales@maker.example'], 'operation_score':5, 'manufacturer_score':35,
                   'manufacturer_evidence':'manufacturer factory production line 产品相关词命中: mining machinery'}
        self.assertTrue(app.is_trade_contact_candidate(factory, 25))

    def test_data_quality_excludes_accessibility_portal_from_manufacturer_results(self):
        status,reason=data_quality.assess({'company_name':'FreeGuider','page_title':'FreeGuider 無障礙生活','site_type':'资讯/目录/旅游/无障碍等非制造业门户（待排除）','manufacturer_evidence':'manufacturer'})
        self.assertEqual(status,'excluded')
        self.assertTrue(reason)

    def test_quality_filter_accepts_labelled_compact_international_whatsapp_only(self):
        row={'company_name':'Compact WA Factory','company_website':'https://compact-wa.example','country':'中国',
             'manufacturer_evidence':'自有工厂 生产线 manufacturer',
             'whatsapp_contacts':['447911123456'], 'phone_candidates':['13812345678']}
        accepted,_,_=data_quality.clean_and_dedupe([row])
        self.assertEqual(accepted[0]['whatsapp_contacts'],['+447911123456'])
        self.assertIn('13812345678',accepted[0]['phone_candidates'])

    def test_quality_filter_keeps_overseas_whatsapp_for_china_factory(self):
        row = {'company_name':'Example Factory','company_website':'https://example-factory.cn','country':'中国',
               'manufacturer_evidence':'工厂 生产线 manufacturer','whatsapp_contacts':['+14155552671'],
               'whatsapp_links':['https://wa.me/14155552671']}
        accepted, _, _ = data_quality.clean_and_dedupe([row])
        self.assertEqual(accepted[0]['whatsapp_contacts'], ['+14155552671'])
        self.assertEqual(accepted[0]['whatsapp_links'], ['https://wa.me/14155552671'])


    def test_network_failure_candidate_is_retained_as_review_not_manufacturer(self):
        row = app.build_review_candidate(
            ('https://example-factory.cn/', 'Example Factory', 'factory manufacturer China'),
            '连接超时，等待稍后重试',
            context={'category':'机械制造','industry':'工业设备','keywords':'industrial equipment','country':'中国'},
            status='网络失败/待重试')
        self.assertIsNotNone(row)
        self.assertEqual(row['quality_status'], 'review')
        self.assertEqual(row['quality_category'], '潜在供应商/待人工核验')
        self.assertEqual(row['company_name'], 'Example Factory')
        self.assertIn('连接超时', row['notes'])
        self.assertEqual(row['emails'], [])
        self.assertEqual(row['whatsapp_contacts'], [])


    def test_persist_review_candidate_writes_network_failure_to_leads_db(self):
        import tempfile, os, sqlite3
        from unittest.mock import patch
        from global_dedup import GlobalDedup
        with tempfile.TemporaryDirectory() as tmp:
            old_db=app.DB_FILE
            old_dedup=app.GLOBAL_DEDUP
            try:
                app.DB_FILE=os.path.join(tmp,'leads.db')
                app.GLOBAL_DEDUP=GlobalDedup(os.path.join(tmp,'global_dedup.db'))
                app.init_db()
                item=('https://example-review-factory.cn/','Example Review Factory','factory China')
                row=app.persist_review_candidate(item,'DNS lookup failed',context={'industry':'工业设备','country':'中国'},status='网络失败/待重试')
                self.assertIsNotNone(row)
                con=sqlite3.connect(app.DB_FILE)
                saved=con.execute('SELECT company_name,quality_status,status,quality_reason FROM leads WHERE domain=?',('example-review-factory.cn',)).fetchone()
                con.close()
                self.assertEqual(saved[0],'Example Review Factory')
                self.assertEqual(saved[1],'review')
                self.assertEqual(saved[2],'网络失败/待重试')
                self.assertIn('DNS lookup failed',saved[3])
            finally:
                app.DB_FILE=old_db
                app.GLOBAL_DEDUP=old_dedup

    def test_explicit_whatsapp_link_extracts_number_but_plain_phone_does_not(self):
        from bs4 import BeautifulSoup
        html = '''<html><body>
        <a href="https://wa.me/8613812345678">Chat on WhatsApp</a>
        <p>Phone: +86 139 1234 5678</p>
        <p>Fax: +86 755 1234 5678</p>
        <a href="mailto:sales@example-factory.cn">sales</a>
        </body></html>'''
        result = app.extract_contact_evidence(BeautifulSoup(html, 'html.parser'), 'https://example-factory.cn/contact')
        self.assertIn('+8613812345678', result['whatsapp_contacts'])
        self.assertNotIn('+8613912345678', result['whatsapp_contacts'])
        self.assertTrue(result['whatsapp_evidence'].get('+8613812345678'))
        self.assertIn('sales@example-factory.cn', result['emails'])

    def test_resource_and_placeholder_emails_are_rejected(self):
        for email in ('logo@factory.png', 'font@factory.woff2', 'bundle@factory.js', 'a@example.com', 'x@sentry.io'):
            self.assertEqual(app.clean_email_candidate(email), '')
        self.assertEqual(app.clean_email_candidate('sales@factory-example.cn'), 'sales@factory-example.cn')

    def test_quality_filter_never_promotes_plain_phone_to_whatsapp(self):
        row = {
            'company_name': 'Example Machinery Factory',
            'company_website': 'https://example-factory.cn',
            'manufacturer_evidence': '自有工厂 生产线 manufacturer',
            'phone_candidates': ['+86 755 1234 5678'],
            'whatsapp_contacts': [],
            'whatsapp_links': [],
        }
        accepted, _, _ = data_quality.clean_and_dedupe([row])
        self.assertEqual(accepted[0]['whatsapp_contacts'], [])
        self.assertTrue(accepted[0]['phone_candidates'])

    def test_free_first_mode_never_calls_paid_provider(self):
        diagnostics = {}
        with patch.object(app, 'search_public_web', return_value=[('https://maker.example', 'Example Factory')]), \
             patch.object(app, 'search_providers', side_effect=AssertionError('paid provider must not be called')), \
             patch.object(app, 'load_api_keys', side_effect=AssertionError('keys must not be read in free-first mode')):
            rows = app.search_web('machine factory China', 5, diagnostics=diagnostics,
                                  search_mode='免费优先（手动控制付费）')
        self.assertEqual(len(rows), 1)
        self.assertIn('手动切换', diagnostics['provider_orchestration']['status'])

    def test_paid_budget_exhaustion_still_falls_back_to_free_search(self):
        free_rows = [('https://factory.example', 'Example Factory')]
        with (
            patch.object(app, 'load_api_keys', return_value={'serpapi': 'test-key'}),
            patch.object(app, 'search_providers', return_value=[]),
            patch.object(app, 'search_public_web', return_value=free_rows),
        ):
            rows = app.search_web('industrial control manufacturer China', 5,
                                  diagnostics={}, search_mode='付费优先（免费补充）')
        self.assertEqual(rows, free_rows)

    def test_legacy_free_first_label_is_also_no_spend(self):
        with patch.object(app, 'search_public_web', return_value=[]), \
             patch.object(app, 'search_providers', side_effect=AssertionError('legacy mode must not spend')):
            app.search_web('factory China', 5, diagnostics={}, search_mode='免费优先（付费补漏）')

    def test_paid_provider_failure_stops_provider_chaining_and_counts_attempt(self):
        with tempfile.TemporaryDirectory() as td:
            db = os.path.join(td, 'test.db')
            api_services.init_provider_db(db)
            brave_calls = []
            def fail_serp(*args, **kwargs):
                raise api_services.ProviderError('serpapi', 500, 'HTTP_500', 'test failure')
            def brave(*args, **kwargs):
                brave_calls.append(True)
                return [], 200
            diagnostics = {'_task_id': 'test-task', '_paid_search_budget': {'limit': 20, 'used': 0}}
            with patch.object(api_services, 'search_serpapi', side_effect=fail_serp), \
                 patch.object(api_services, 'search_brave', side_effect=brave):
                api_services.search_providers('test query', 5, diagnostics, db,
                                              {'serpapi': 'test-key', 'brave': 'test-key'})
            self.assertEqual(brave_calls, [])
            self.assertEqual(api_services.paid_monthly_usage(db), 1)
            self.assertEqual(api_services.paid_task_usage(db, 'test-task'), 1)

    def test_export_does_not_mix_historical_database_rows_into_current_task(self):
        with tempfile.TemporaryDirectory() as td:
            old_db = app.DB_FILE
            app.DB_FILE = os.path.join(td, 'leads.db')
            try:
                app.init_db()
                app.save_lead({
                    'company_name': 'Example Manufacturing Co',
                    'company_website': 'https://example-manufacturing.cn',
                    'industry': 'machinery', 'country': 'China',
                    'manufacturer_evidence': 'factory production line manufacturer',
                    'emails': ['sales@example-manufacturing.cn'],
                    'phone_candidates': [], 'whatsapp_contacts': [], 'whatsapp_links': [],
                    'source_urls': ['https://example-manufacturing.cn/contact'],
                    'contact_evidence': {'emails': {'sales@example-manufacturing.cn': 'https://example-manufacturing.cn/contact'}},
                })
                fake = types.SimpleNamespace(rows=[])
                with patch.object(app.messagebox, 'showinfo') as info:
                    self.assertFalse(app.App._ensure_rows_for_export(fake))
                    info.assert_called_once()
                self.assertEqual(fake.rows, [])
            finally:
                app.DB_FILE = old_db

    def test_result_batch_flush_is_bounded(self):
        fake = types.SimpleNamespace(
            _pending_result_lock=threading.Lock(),
            _pending_result_updates=[((i,), {}) for i in range(23)],
            _result_flush_scheduled=True,
            rendered=[], after_calls=[],
            add_result=lambda value: fake.rendered.append(value),
            after=lambda delay, callback: fake.after_calls.append((delay, callback)),
        )
        fake._flush_result_batch=types.MethodType(app.App._flush_result_batch,fake)
        app.App._flush_result_batch(fake)
        self.assertEqual(fake.rendered, [0])
        self.assertEqual(len(fake._pending_result_updates), 22)
        self.assertTrue(fake._result_flush_scheduled)
        self.assertEqual(fake.after_calls[0][0], 8)

    def test_search_mode_setting_is_persisted(self):
        with tempfile.TemporaryDirectory() as td:
            old_path=app.SEARCH_MODE_FILE
            app.SEARCH_MODE_FILE=os.path.join(td,'search_mode.json')
            try:
                fake=types.SimpleNamespace(search_mode=types.SimpleNamespace(get=lambda:'付费优先（免费补充）'), status=_Status())
                app.App._save_search_mode_setting(fake)
                self.assertEqual(app.load_search_mode_setting(),'付费优先（免费补充）')
            finally:
                app.SEARCH_MODE_FILE=old_path

    def test_concurrent_database_writes_do_not_lose_leads(self):
        from concurrent.futures import ThreadPoolExecutor
        with tempfile.TemporaryDirectory() as td:
            old_db=app.DB_FILE
            app.DB_FILE=os.path.join(td,'parallel.db')
            try:
                app.init_db()
                def save(i):
                    app.save_lead({
                        'company_name':f'Factory {i}',
                        'company_website':f'https://factory-{i}.example{i}.cn',
                        'industry':'machinery', 'country':'China',
                        'manufacturer_evidence':'factory production line manufacturer',
                        'emails':[f'sales{i}@factory-{i}.example{i}.cn'],
                        'phone_candidates':[], 'whatsapp_contacts':[], 'whatsapp_links':[],
                        'source_urls':[f'https://factory-{i}.example{i}.cn/contact'],
                    })
                with ThreadPoolExecutor(max_workers=8) as pool:
                    list(pool.map(save,range(16)))
                con=sqlite3.connect(app.DB_FILE,timeout=60)
                try: count=con.execute('SELECT COUNT(*) FROM leads').fetchone()[0]
                finally: con.close()
                self.assertEqual(count,16)
            finally:
                app.DB_FILE=old_db


    def test_manufacturer_qualification_does_not_require_public_contact(self):
        row = {
            'manufacturer_score': 72,
            'manufacturer_evidence': 'factory×3；production line×2；产品相关词命中: mining machinery',
            'factory_evidence_items': [{'type':'factory','text':'factory','source_url':'https://maker.example/about'}],
            'emails': [], 'whatsapp_links': [], 'whatsapp_contacts': [],
        }
        self.assertTrue(app.is_manufacturer_candidate(row, 25))
        self.assertFalse(app.is_trade_contact_candidate(row, 25))

    def test_contact_only_is_not_enough_to_qualify_manufacturer(self):
        row = {
            'manufacturer_score': 8,
            'manufacturer_evidence': 'contact×2; export×2',
            'factory_evidence_items': [],
            'emails': ['sales@example.com'],
        }
        self.assertFalse(app.is_manufacturer_candidate(row, 25))
        self.assertFalse(app.is_trade_contact_candidate(row, 25))

    def test_public_search_retries_one_transient_timeout_before_pausing_engine(self):
        class FakeResponse:
            status_code = 200
            text = '<html><body>empty</body></html>'
            def raise_for_status(self): pass
        class FakeSession:
            def __init__(self): self.calls=[]
            def get(self, url, **kwargs):
                self.calls.append(url)
                if 'bing.com' in url:
                    raise app.requests.Timeout('simulated timeout')
                return FakeResponse()
        diagnostics={}
        session=FakeSession()
        with patch.object(app, 'rank_search_engines', return_value=['Bing','DuckDuckGo']), \
             patch.object(app, 'record_engine_search'):
            app.search_public_web('site:linkedin.com/company example', max_results=3, diagnostics=diagnostics, session=session)
            first_calls=len(session.calls)
            self.assertNotIn('Bing', diagnostics.get('_blocked_public_engines',{}))
            app.search_public_web('site:linkedin.com/in export manager China', max_results=3, diagnostics=diagnostics, session=session)
            self.assertIn('Bing', diagnostics.get('_blocked_public_engines',{}))
            blocked_call_count=sum('bing.com' in u for u in session.calls)
            app.search_public_web('industrial pump manufacturer China', max_results=3, diagnostics=diagnostics, session=session)
        self.assertEqual(blocked_call_count,2)
        self.assertEqual(sum('bing.com' in u for u in session.calls),2)
        self.assertGreater(first_calls,0)


    def test_excel_import_returns_only_imported_rows_with_industry_metadata(self):
        from openpyxl import Workbook
        with tempfile.TemporaryDirectory() as td:
            xlsx=os.path.join(td,'industry_import.xlsx')
            wb=Workbook(); ws=wb.active
            ws.append(['公司名称','官方网站','行业大类','细分行业','目标国家'])
            ws.append(['深圳木艺家具有限公司','https://wood.example','家居制造业','木质家具制造','China'])
            wb.save(xlsx); wb.close()
            old_db=app.DB_FILE
            try:
                app.DB_FILE=os.path.join(td,'leads.db')
                app.init_db()
                class _Dedup:
                    def record(self,*args,**kwargs): return None
                    def mark_collected(self,*args,**kwargs): return None
                with patch.object(app,'GLOBAL_DEDUP',_Dedup()):
                    result=app.import_legacy_xlsx_to_database(xlsx)
                self.assertEqual(result['imported'],1)
                self.assertEqual(len(result['rows']),1)
                self.assertEqual(result['rows'][0]['industry_category'],'家居制造业')
                self.assertEqual(result['rows'][0]['industry'],'木质家具制造')
                self.assertEqual(result['rows'][0]['country'],'China')
            finally:
                app.DB_FILE=old_db



    def test_fetch_page_does_not_start_network_request_after_stop(self):
        import threading
        calls=[]
        class FakeSession:
            def get(self,*args,**kwargs):
                calls.append((args,kwargs))
                raise AssertionError('request must not start after cancellation')
        event=threading.Event(); event.set()
        soup,response,reason=app.fetch_page(FakeSession(),'https://example.com',cancel_event=event)
        self.assertIsNone(soup)
        self.assertIsNone(response)
        self.assertIn('任务已停止',reason)
        self.assertEqual(calls,[])

    def test_scan_site_returns_stopped_without_fetching_when_cancelled(self):
        import threading
        event=threading.Event(); event.set()
        class FakeSession:
            def get(self,*args,**kwargs):
                raise AssertionError('site scan must not start network request after cancellation')
        result=app.scan_site('https://example.com','工业设备','industrial equipment manufacturer','China',session=FakeSession(),cancel_event=event)
        self.assertEqual(result['status'],'任务已停止')


if __name__ == '__main__':
    unittest.main(verbosity=2)
