import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch
import app

class EngineSimplificationTests(unittest.TestCase):
    def setUp(self):
        self.response = SimpleNamespace(status_code=200, text='ok', url='https://www.bing.com/search')
        self.response.raise_for_status = Mock()
        self.session = Mock()
        self.session.get.return_value = self.response

    @patch.object(app, '_pace_public_search_request')
    @patch.object(app, 'record_engine_search')
    @patch.object(app, '_parse_public_engine_results')
    @patch.object(app, 'DB_FILE', '/tmp/factorylead_engine_test.db')
    def test_bing_is_always_first_and_qwant_not_called_when_bing_meets_usable_threshold(self, parse, record, pace):
        parse.return_value = [(f'https://factory{i}.example{i}.net', f'Factory {i}') for i in range(1,4)]
        diag = {}
        rows = app.search_public_web('industrial pump manufacturer China', 10, diag, self.session)
        self.assertEqual(len(rows), 3)
        self.assertEqual(diag['public_search']['engine_order'], ['Bing', 'Qwant'])
        self.assertEqual(diag['public_search']['engines_tried_this_query'], ['Bing'])
        self.assertEqual(self.session.get.call_count, 1)
        self.assertIn('bing.com', self.session.get.call_args.args[0])

    @patch.object(app, '_pace_public_search_request')
    @patch.object(app, 'record_engine_search')
    @patch.object(app, '_parse_public_engine_results')
    @patch.object(app, 'DB_FILE', '/tmp/factorylead_engine_test.db')
    def test_qwant_only_fallback_when_bing_has_no_parseable_results(self, parse, record, pace):
        parse.side_effect = [[], [('https://qwant-factory.example.com', 'Factory')]]
        diag = {}
        rows = app.search_public_web('industrial pump manufacturer China', 10, diag, self.session)
        self.assertEqual(rows, [('https://qwant-factory.example.com', 'Factory')])
        self.assertEqual(diag['public_search']['engines_tried_this_query'], ['Bing', 'Qwant'])
        self.assertEqual(self.session.get.call_count, 2)
        self.assertIn('bing.com', self.session.get.call_args_list[0].args[0])
        self.assertIn('qwant.com', self.session.get.call_args_list[1].args[0])

    @patch.object(app, '_pace_public_search_request')
    @patch.object(app, 'record_engine_search')
    @patch.object(app, '_parse_public_engine_results')
    @patch.object(app, 'DB_FILE', '/tmp/factorylead_engine_test.db')
    def test_disabled_engines_are_never_in_rotation(self, parse, record, pace):
        parse.return_value = [('https://factory.example.com', 'Factory')]
        diag = {}
        app.search_public_web('factory China', 10, diag, self.session)
        self.assertEqual(diag['public_search']['engine_order'], ['Bing', 'Qwant'])
        self.assertFalse(any(x in str(diag) for x in ['DuckDuckGo', 'Baidu', 'Ecosia', 'Mojeek', 'Startpage', 'Yahoo', 'Yandex']))

    @patch.object(app, '_pace_public_search_request')
    @patch.object(app, 'record_engine_search')
    @patch.object(app, '_parse_public_engine_results')
    @patch.object(app, 'DB_FILE', '/tmp/factorylead_engine_test.db')
    def test_qwant_supplements_when_bing_has_too_few_usable_domains(self, parse, record, pace):
        parse.side_effect = [
            [('https://one-factory.example.net', 'One Factory')],
            [('https://two-factory.example.org', 'Two Factory')],
        ]
        diag = {}
        rows = app.search_public_web('industrial automation manufacturer China', 10, diag, self.session)
        self.assertEqual(len(rows), 2)
        self.assertEqual(diag['public_search']['engines_tried_this_query'], ['Bing', 'Qwant'])
        self.assertEqual(diag['public_search']['bing_usable_new_domains'], 1)
        self.assertIn('低于阈值', diag['public_search']['fallback_reason'])

    @patch.object(app, '_pace_public_search_request')
    @patch.object(app, 'record_engine_search')
    @patch.object(app, '_parse_public_engine_results')
    @patch.object(app, 'DB_FILE', '/tmp/factorylead_engine_test.db')
    def test_marketplace_only_bing_results_do_not_block_qwant_fallback(self, parse, record, pace):
        parse.side_effect = [
            [('https://www.alibaba.com/company/abc', 'Factory supplier')],
            [('https://real-factory.example.com', 'Real Factory')],
        ]
        diag = {}
        rows = app.search_public_web('industrial automation manufacturer China', 10, diag, self.session)
        self.assertEqual(rows, [('https://real-factory.example.com', 'Real Factory')])
        self.assertEqual(diag['public_search']['engines_tried_this_query'], ['Bing', 'Qwant'])
        self.assertEqual(diag['_filtered_search_results'], 1)


    def test_engine_stats_store_parsed_count_not_post_filter_added_count(self):
        parsed_rows = [
            ('https://www.alibaba.com/company/abc', 'Marketplace supplier'),
            ('https://real-factory.example.com/', 'Real Factory'),
        ]
        with patch.object(app, '_pace_public_search_request'), \
             patch.object(app, 'record_engine_search') as record, \
             patch.object(app, '_parse_public_engine_results', side_effect=[parsed_rows, []]), \
             patch.object(app, 'DB_FILE', '/tmp/factorylead_engine_test.db'):
            diag = {}
            rows = app.search_public_web('factory China', 10, diag, self.session)
        self.assertEqual(rows, [('https://real-factory.example.com/', 'Real Factory')])
        self.assertEqual(diag['public_search']['Bing']['parsed_results'], 2)
        self.assertEqual(record.call_args_list[0].args[2], 2)
        self.assertEqual(diag['search_pipeline']['social_or_directory'], 1)

    def test_parser_reports_anchor_loss_reasons(self):
        response = SimpleNamespace(text="""<html><body><nav><h2><a href="https://menu.example.org/">Menu Link</a></h2></nav>
            <ol><li class="b_algo"><h2><a href="/relative">Relative Link</a></h2></li>
            <li class="b_algo"><h2><a href="https://maker.example.com/">Real Manufacturer</a></h2></li></ol></body></html>""",
            url='https://www.bing.com/search')
        stats = {}
        rows = app._parse_public_engine_results('Bing', response, stage_stats=stats)
        self.assertEqual(rows, [('https://maker.example.com/', 'Real Manufacturer')])
        self.assertEqual(stats['matched_anchors'], 2)
        self.assertEqual(stats['invalid_link_or_title'], 1)
        self.assertEqual(stats['parsed_rows'], 1)

    def test_manufacturer_score_is_not_capped_only_because_product_keyword_is_missing(self):
        from bs4 import BeautifulSoup
        soup = BeautifulSoup('<html><head><title>Industrial Manufacturing Factory</title></head><body>'
                             '<h1>Our Factory</h1><p>We are a manufacturer with own factory, production line, workshop and production facility.</p>'
                             '<p>Contact our export sales team for OEM production.</p></body></html>', 'html.parser')
        score, evidence = app.score_site([('https://maker.example.com/', soup)],
                                         'industrial automation control system',
                                         'industrial automation control system manufacturer China')
        self.assertGreater(score, 22)
        self.assertIn('制造商身份与行业匹配分开判断', evidence)

    def test_explicit_factory_evidence_can_be_kept_for_industry_review(self):
        candidate = {
            'manufacturer_score': 28,
            'manufacturer_evidence': 'own factory production line workshop',
            'industry_relevance_status': '不相关/未发现目标行业证据',
        }
        self.assertTrue(app.has_reviewable_factory_evidence(candidate))
        self.assertFalse(app.is_manufacturer_candidate(candidate, 25))

    def test_qwant_parser_ignores_navigation_links_and_keeps_organic_results(self):
        response = SimpleNamespace(text='''<html><body><nav><a href="https://www.qwant.com/">Qwant Home</a></nav>
            <article class="result"><h2><a href="https://maker-one.example.com/">Maker One Factory</a></h2>
            <p>Industrial automation equipment manufacturer</p></article></body></html>''', url='https://www.qwant.com/')
        snippets = {}
        rows = app._parse_public_engine_results('Qwant', response, snippet_map=snippets)
        self.assertEqual(rows, [('https://maker-one.example.com/', 'Maker One Factory')])
        self.assertIn('Industrial automation equipment', snippets['https://maker-one.example.com/'])

    def test_qwant_parser_rejects_external_navigation_links(self):
        response = SimpleNamespace(text='''<html><body>
            <nav><a href="https://unrelated-menu.example.org/">Partner Directory</a></nav>
            <footer><a href="https://unrelated-footer.example.net/">Footer Supplier</a></footer>
            <article class="result"><h2><a href="https://real-maker.example.com/">Real Manufacturer</a></h2>
            <p>Own factory and production line</p></article>
            </body></html>''', url='https://www.qwant.com/')
        rows = app._parse_public_engine_results('Qwant', response)
        self.assertEqual(rows, [('https://real-maker.example.com/', 'Real Manufacturer')])

    def test_bing_parser_requires_natural_result_container(self):
        response = SimpleNamespace(text='''<html><body>
            <nav><h2><a href="https://menu.example.org/">Navigation Link</a></h2></nav>
            <ol id="b_results"><li class="b_algo"><h2><a href="https://factory.example.com/">Factory Manufacturer</a></h2></li></ol>
            </body></html>''', url='https://www.bing.com/search')
        rows = app._parse_public_engine_results('Bing', response)
        self.assertEqual(rows, [('https://factory.example.com/', 'Factory Manufacturer')])

    @patch.object(app, '_pace_public_search_request')
    @patch.object(app, 'record_engine_search')
    @patch.object(app, '_parse_public_engine_results')
    @patch.object(app, 'DB_FILE', '/tmp/factorylead_engine_test.db')
    def test_bing_subdomains_count_as_one_usable_company_domain(self, parse, record, pace):
        parse.side_effect = [[
            ('https://www.same-factory.example.com/', 'Factory Home'),
            ('https://contact.same-factory.example.com/', 'Factory Contact'),
        ], [('https://backup-factory.example.net/', 'Backup Factory')]]
        diag = {}
        rows = app.search_public_web('factory manufacturer China', 10, diag, self.session)
        self.assertEqual(diag['public_search']['bing_usable_new_domains'], 1)
        self.assertEqual(diag['public_search']['engines_tried_this_query'], ['Bing', 'Qwant'])
        self.assertEqual(len(rows), 2)

    @patch.object(app, '_pace_public_search_request')
    @patch.object(app, 'record_engine_search')
    @patch.object(app, '_parse_public_engine_results')
    @patch.object(app, 'DB_FILE', '/tmp/factorylead_engine_test.db')
    def test_known_history_domains_do_not_prevent_qwant_from_finding_new_domains(self, parse, record, pace):
        parse.side_effect = [
            [('https://known-factory.example.com/', 'Known Factory')],
            [('https://new-factory.example.net/', 'New Factory')],
        ]
        diag = {}
        rows = app.search_public_web('factory manufacturer China', 10, diag, self.session,
                                     exclude_domains={'example.com'})
        self.assertEqual(rows, [('https://new-factory.example.net/', 'New Factory')])
        self.assertEqual(diag['public_search']['engines_tried_this_query'], ['Bing', 'Qwant'])
        self.assertEqual(diag['_historical_or_known_results'], 1)

if __name__ == '__main__':
    unittest.main()
