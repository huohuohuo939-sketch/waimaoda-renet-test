# 外贸达人 2.5.14 付费搜索证据链修复

## 本轮新增查明并修复

1. SerpApi / Brave 结果标准化只保留 URL 和标题，丢弃 snippet / description，导致付费搜索摘要无法进入 WhatsApp 提取链路。现将摘要写入统一 `_search_snippets` 证据映射。
2. 付费搜索结果按 host 去重，`wa.me` 是所有号码共用的域名，多个不同公开号码会被错误合并。现对 WhatsApp 链接按具体 URL 去重，普通企业网站仍按域名去重。
3. 搜索缓存只保存 URL / 标题，缓存命中时摘要证据丢失。现将摘要随缓存保存，并兼容读取旧版本的纯列表缓存。
4. SearXNG 解析中摘要字段重复赋值，前一个字段会被后一个覆盖；统一按 content / snippet / description / title 优先级处理。
5. OpenSERP 结果此前没有写入摘要证据映射，现已补齐。

## 本轮验证

- 115 项自动化测试通过。
- `app.py`、`api_services.py` 源码编译通过。
- 新增测试覆盖付费搜索摘要保留、多个 `wa.me` 入口、缓存读写及旧缓存兼容。
- 未完成真实 SerpApi / Brave API 联网验收；没有配置真实密钥的环境不能证明外部 API 实际可用。
