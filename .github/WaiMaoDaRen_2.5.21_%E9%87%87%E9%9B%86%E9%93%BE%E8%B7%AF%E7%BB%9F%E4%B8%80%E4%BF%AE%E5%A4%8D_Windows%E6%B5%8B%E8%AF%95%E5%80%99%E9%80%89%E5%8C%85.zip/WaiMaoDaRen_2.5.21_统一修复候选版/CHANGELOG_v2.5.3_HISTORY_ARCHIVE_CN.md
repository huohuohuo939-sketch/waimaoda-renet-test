# 外贸达人 2.5.3 历史分割与行业归档修复

基线：用户上传的 2.5.2 制造商识别与 WhatsApp 质量修复候选版。

## 本轮实际修改

1. 统一历史归档文件位置：Windows 使用 `%LOCALAPPDATA%\\WaiMaoDaRen\\collection_history.db`；非 Windows 开发运行时保存在程序数据目录。
2. 新任务启动前创建独立任务记录，并清空当前任务结果显示；历史记录不自动混入当前结果列表。
3. 每条归档快照保存任务编号、行业大类、细分行业、目标国家、质量状态和完整记录 JSON。
4. `record_lead` 在采集行缺少行业/国家字段时，使用本次任务元数据补齐，并同步写入快照与索引列。
5. 旧版归档表从 `(task_id, domain)` 主键升级为 `(task_id, domain, category, industry)`；升级前创建 `.pre_category_sync.bak`，原数据保留。
6. 启动时将旧程序目录的归档文件复制或幂等合并到用户数据目录，不删除旧文件。
7. 历史主数据库迁移使用 v2 标记，避免随包携带的旧 v1 标记导致用户既有企业数据被跳过。
8. 历史窗口行业筛选同时读取任务元数据和记录分类；任务列表显示正确的分类、国家、记录数。
9. 历史窗口增加“打开归档文件夹”入口，便于用户找到唯一归档文件。
10. Excel 导入归档仅处理本次 Excel 导入的行，不再把整个企业主库重复写入历史任务；同时读取 Excel 中的行业大类、细分行业和目标国家字段。
11. 清空当前结果仅清空当前任务视图，不删除历史归档或主企业数据库。

## 自动化验证

- 历史归档模块专项测试：覆盖旧表结构迁移、旧记录保留、行业/国家元数据补齐、跨任务分类、历史归档合并幂等、旧 v1 迁移标记恢复迁移。
- 全部项目自动化测试与 Python 编译检查见 `INTERNAL_TEST_REPORT_2.5.3_CN.md`。

## 数据文件

- 企业主数据库：`%LOCALAPPDATA%\\WaiMaoDaRen\\factorylead.db`
- 唯一历史归档文件：`%LOCALAPPDATA%\\WaiMaoDaRen\\collection_history.db`
- 归档结构升级前备份：`collection_history.db.pre_category_sync.bak`

本版本尚未在用户 Windows 10 设备上实机运行；自动化测试不能替代 Windows 实机验收。
