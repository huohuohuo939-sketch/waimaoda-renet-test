@echo off
setlocal
cd /d "%~dp0"
call "%~dp0run_factorylead.bat"
exit /b %ERRORLEVEL%
