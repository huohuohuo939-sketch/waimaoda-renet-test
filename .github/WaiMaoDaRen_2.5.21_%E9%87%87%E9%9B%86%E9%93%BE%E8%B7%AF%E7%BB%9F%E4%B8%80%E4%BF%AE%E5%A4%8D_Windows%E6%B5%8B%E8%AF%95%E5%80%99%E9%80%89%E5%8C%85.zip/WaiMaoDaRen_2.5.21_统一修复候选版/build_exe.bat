﻿@echo off
setlocal EnableExtensions
set "APP_DIR=%~dp0"
for %%I in ("%APP_DIR%.") do set "APP_DIR=%%~fI\"
set "REQ_FILE=%APP_DIR%requirements.txt"
set "APP_FILE=%APP_DIR%app.py"
set "BUILD_NAME=WaiMaoDaRen_2_5_21_PIPELINE_REPAIR_CANDIDATE"
set "DIST_DIR=%APP_DIR%dist\%BUILD_NAME%"

title WaiMaoDaRen 2.5.21 采集链路统一修复候选版 - Windows Build
echo ==============================================
echo WaiMaoDaRen 2.5.21 采集链路统一修复候选版 Windows build
echo ==============================================
if not exist "%REQ_FILE%" (
  echo [ERROR] Missing requirements.txt: "%REQ_FILE%"
  pause
  exit /b 2
)
if not exist "%APP_FILE%" (
  echo [ERROR] Missing app.py: "%APP_FILE%"
  pause
  exit /b 2
)
set "PYTHON_CMD="
where py >nul 2>nul
if not errorlevel 1 set "PYTHON_CMD=py -3"
if not defined PYTHON_CMD (
  where python >nul 2>nul
  if not errorlevel 1 set "PYTHON_CMD=python"
)
if not defined PYTHON_CMD (
  echo [ERROR] Python 3.10 or newer was not found.
  pause
  exit /b 1
)
%PYTHON_CMD% -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)"
if errorlevel 1 (
  echo [ERROR] Python 3.10 or newer is required.
  pause
  exit /b 1
)
%PYTHON_CMD% -m pip install --disable-pip-version-check -r "%REQ_FILE%" pyinstaller
if errorlevel 1 (
  echo [ERROR] Build dependencies failed. Check network and pip output.
  pause
  exit /b 1
)
pushd "%APP_DIR%"
if exist "%DIST_DIR%" rmdir /s /q "%DIST_DIR%"
%PYTHON_CMD% -m PyInstaller --noconfirm --clean --windowed --onedir --name "%BUILD_NAME%" "%APP_FILE%"
if errorlevel 1 (
  popd
  echo [ERROR] PyInstaller build failed.
  pause
  exit /b 1
)
for %%F in (industry_catalog.csv industry_catalog_supplement.csv) do (
  if exist "%%F" copy /Y "%%F" "%DIST_DIR%" >nul
)
if exist "source_vocabulary" (
  xcopy "source_vocabulary" "%DIST_DIR%\source_vocabulary" /E /I /Y >nul
  if errorlevel 1 (
    popd
    echo [ERROR] Failed to copy source_vocabulary resources.
    pause
    exit /b 1
  )
)
if exist "README_CN.txt" copy /Y "README_CN.txt" "%DIST_DIR%" >nul
if not exist "%DIST_DIR%\%BUILD_NAME%.exe" (
  popd
  echo [ERROR] EXE was not found in output directory.
  pause
  exit /b 1
)
popd
echo.
echo [OK] Build output: "%DIST_DIR%"
echo [INFO] User data is stored under %%LOCALAPPDATA%%\WaiMaoDaRen.
echo [INFO] No database is bundled. Existing user databases under %%LOCALAPPDATA%%\WaiMaoDaRen are preserved.
pause
endlocal
