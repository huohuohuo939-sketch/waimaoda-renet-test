"""Strict target-industry relevance checks for discovered company websites.

This module intentionally separates task target labels from evidence that the
actual website belongs to that target industry. It is conservative: ambiguous
sites are quarantined instead of being shown as matching companies.
"""
from __future__ import annotations
import math
import re

_GENERIC_EN = {
    'manufacturer','manufacturers','manufacturing','factory','factories','factorys',
    'producer','producers','supplier','suppliers','exporter','exporters','export',
    'oem','odm','china','chinese','manufacturerchina','factorychina','plant','plants',
    'production','facility','facilities','company','companies','official','website',
    'industry','equipment','products','product',
    'business','sales','wholesale','direct','made','custom','service','services',
}
_GENERIC_CN = (
    '生产厂家','生产企业','源头工厂','自有工厂','工厂直供','厂家直供','制造商','制造厂',
    '制造业','制造','生产','工厂','厂家','供应商','出口商','出口','外贸','进出口',
    '中国','生产线','生产基地','加工厂','企业','设备制造',
)
_FIELD_NAMES = (
    '新英文核心词','英文核心词','英文搜索关键词','中文搜索关键词',
    '英文制造商搜索组合','英文OEM_ODM搜索组合','英文材料工艺搜索组合','中文搜索组合',
)


def _split_values(value: str) -> list[str]:
    value = str(value or '').replace('；', ';')
    parts = []
    for part in re.split(r'[;|\n]+', value):
        part = part.strip().strip('"\' ,')
        if not part:
            continue
        # Search-combination columns often contain several quoted product phrases.
        quoted = re.findall(r'["\']([^"\']{2,80})["\']', part)
        parts.extend(quoted if quoted else [part])
    return parts


def _clean_phrase(value: str) -> str:
    s = str(value or '').lower().strip()
    s = re.sub(r'\b(?:manufacturer|manufacturers|manufacturing|factory|factories|producer|supplier|suppliers|exporter|exporters|export|oem|odm|china|chinese|plant|plants|production|facility|facilities|company|companies|official|website|industry|equipment|products|product|business|sales|wholesale|direct|made|custom|service|services)\b', ' ', s)
    for word in _GENERIC_CN:
        s = s.replace(word, ' ')
    s = re.sub(r'[^a-z0-9\u4e00-\u9fff]+', ' ', s)
    return ' '.join(s.split())


def build_relevance_terms(row: dict, fallback_terms: str = '') -> list[str]:
    values = []
    for field in _FIELD_NAMES:
        values.extend(_split_values(row.get(field, '')))
    values.extend(_split_values(fallback_terms))
    cleaned = []
    seen = set()
    for raw in values:
        phrase = _clean_phrase(raw)
        if not phrase or phrase in seen:
            continue
        english_tokens = re.findall(r'[a-z]{3,}', phrase)
        chinese_chars = re.findall(r'[\u4e00-\u9fff]', phrase)
        if english_tokens and len(english_tokens) < 1:
            continue
        if chinese_chars and len(chinese_chars) < 2 and not english_tokens:
            continue
        # Avoid adding a generic category-only phrase as a relevance requirement.
        if not english_tokens and not chinese_chars:
            continue
        seen.add(phrase)
        cleaned.append(phrase)
    return cleaned[:40]


def match_industry_relevance(page_text: str, terms: list[str] | tuple[str, ...] | None) -> tuple[bool, int, list[str]]:
    text = _clean_phrase(page_text)
    if not terms:
        return False, 0, []
    hits = []
    for phrase in terms:
        p = _clean_phrase(phrase)
        if not p:
            continue
        if re.search(r'[\u4e00-\u9fff]', p):
            if p.replace(' ', '') in text.replace(' ', ''):
                hits.append(phrase)
                continue
        tokens = [t for t in re.findall(r'[a-z]{3,}', p) if t not in _GENERIC_EN]
        if not tokens:
            continue
        text_tokens = set(re.findall(r'[a-z]{3,}', text))
        matched = [t for t in tokens if t in text_tokens or (t.endswith('s') and t[:-1] in text_tokens) or (t+'s' in text_tokens)]
        required = 1 if len(tokens) == 1 else max(2, math.ceil(len(tokens) * 0.6))
        if len(set(matched)) >= required:
            hits.append(phrase)
    hits = list(dict.fromkeys(hits))
    return bool(hits), min(100, 30 * len(hits)), hits
