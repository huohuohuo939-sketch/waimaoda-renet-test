import csv, re, time, threading, os, html, sqlite3, json, base64, sys, queue, socket, urllib.request, platform, random, shutil, uuid
from urllib.parse import urljoin, urlparse, unquote, parse_qs, urlencode, urlunparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from urllib.robotparser import RobotFileParser
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import requests
from bs4 import BeautifulSoup
try:
    import phonenumbers
except ImportError:
    phonenumbers = None
from data_quality import clean_and_dedupe, assess
import history_store
from global_dedup import GlobalDedup
from search_scheduler import (build_rounds, flatten_rounds, plan_signature, load_progress, save_progress,
                               load_performance, record_query_performance, prioritize_rounds, query_budget_for_target, query_budget_reached)
from industry_relevance import build_relevance_terms, match_industry_relevance
from api_services import (load_api_keys, save_api_keys, search_providers, init_provider_db, provider_usage,
                          record_provider_call, search_serpapi, search_brave, score_three_dimensions, ProviderError, set_provider_quota, get_provider_quotas, rank_search_engines, record_engine_search, record_engine_qualification, search_engine_performance, paid_monthly_usage, paid_task_usage)
try:
    import truststore
    truststore.inject_into_ssl()
except Exception:
    pass

def resolve_app_dir(is_frozen=False, executable=None, source_file=None):
    if is_frozen and executable:
        return os.path.dirname(os.path.abspath(executable))
    return os.path.dirname(os.path.abspath(source_file or __file__))


APP_DIR = resolve_app_dir(getattr(sys, 'frozen', False), sys.executable, __file__)


def resolve_user_data_dir(app_dir=None):
    # Choose a writable per-user data directory for installed Windows builds.
    if os.name == 'nt':
        root = os.environ.get('LOCALAPPDATA') or os.path.join(os.path.expanduser('~'), 'AppData', 'Local')
        path = os.path.join(root, 'WaiMaoDaRen')
    else:
        path = os.path.abspath(app_dir or APP_DIR)
    os.makedirs(path, exist_ok=True)
    return path


USER_DATA_DIR = resolve_user_data_dir(APP_DIR)


def migrate_legacy_user_file(filename, app_dir=None, data_dir=None):
    """Copy a legacy writable-app-folder file into the user data folder without deleting it."""
    source=os.path.join(app_dir or APP_DIR,filename)
    target=os.path.join(data_dir or USER_DATA_DIR,filename)
    if not os.path.exists(target) and os.path.isfile(source):
        os.makedirs(os.path.dirname(target),exist_ok=True)
        shutil.copy2(source,target)
        return True
    return False


if os.name == 'nt':
    migrate_legacy_user_file('quality_quarantine.json',APP_DIR,USER_DATA_DIR)
    migrate_legacy_user_file('factorylead_error.log',APP_DIR,USER_DATA_DIR)

CATALOG_FILE = os.path.join(APP_DIR, 'industry_catalog.csv')

def _sqlite_user_row_count(db_path):
    """Count rows across all application tables; WhatsApp-only databases are valuable too."""
    if not os.path.isfile(db_path):
        return 0
    con=None
    try:
        con=sqlite3.connect(db_path, timeout=5)
        tables=[row[0] for row in con.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").fetchall()]
        total=0
        for table in tables:
            # Table names originate from sqlite_master, not user input; quote defensively.
            quoted='"'+str(table).replace('"','""')+'"'
            total += int(con.execute(f'SELECT COUNT(*) FROM {quoted}').fetchone()[0])
        return total
    except Exception:
        return 0
    finally:
        if con is not None:
            try: con.close()
            except sqlite3.Error: pass


def resolve_persistent_db_file(app_dir):
    """Keep every kind of user data across version-folder upgrades on Windows.

    A database containing only independently discovered WhatsApp contacts is not
    empty: never replace it merely because the manufacturer leads table is empty.
    First launch migrates the richest non-empty legacy database only when the
    canonical per-user database contains no application rows at all.
    """
    if os.name != 'nt':
        return os.path.join(app_dir, 'factorylead.db')
    root = os.environ.get('LOCALAPPDATA') or os.path.join(os.path.expanduser('~'), 'AppData', 'Local')
    data_dir = os.path.join(root, 'WaiMaoDaRen')
    os.makedirs(data_dir, exist_ok=True)
    target = os.path.join(data_dir, 'factorylead.db')
    if os.path.exists(target) and _sqlite_user_row_count(target) > 0:
        return target
    candidates = [os.path.join(app_dir, 'factorylead.db')]
    roots = [os.path.abspath(app_dir), os.path.dirname(os.path.abspath(app_dir)),
             os.path.dirname(os.path.dirname(os.path.abspath(app_dir)))]
    for scan_root in dict.fromkeys(roots):
        try:
            for walk_root, dirs, files in os.walk(scan_root):
                depth = os.path.relpath(walk_root, scan_root).count(os.sep)
                if depth >= 2: dirs[:] = []
                if 'factorylead.db' in files:
                    folder = os.path.basename(walk_root).lower()
                    if folder.startswith(('waimaodaren','factorylead')):
                        candidates.append(os.path.join(walk_root,'factorylead.db'))
        except OSError:
            continue
    ranked=[]
    for source in dict.fromkeys(candidates):
        if os.path.abspath(source)==os.path.abspath(target):
            continue
        count=_sqlite_user_row_count(source)
        if count > 0:
            try: ranked.append((count,os.path.getmtime(source),source))
            except OSError: continue
    if ranked:
        _,_,source=max(ranked)
        src=sqlite3.connect(source,timeout=10); dst=sqlite3.connect(target,timeout=10)
        try: src.backup(dst)
        finally: dst.close(); src.close()
    return target

DB_FILE = resolve_persistent_db_file(APP_DIR)
HISTORY_ARCHIVE_FILE = os.path.join(USER_DATA_DIR, 'collection_history.db')
# Keep one canonical history archive under the per-user data directory.
# Import an archive shipped beside an older extracted app without deleting it.
try:
    _legacy_history_path = os.path.join(APP_DIR, 'collection_history.db')
    if os.name == 'nt' and os.path.isfile(_legacy_history_path):
        if not os.path.exists(HISTORY_ARCHIVE_FILE):
            shutil.copy2(_legacy_history_path, HISTORY_ARCHIVE_FILE)
        elif os.path.abspath(_legacy_history_path) != os.path.abspath(HISTORY_ARCHIVE_FILE):
            history_store.merge_archive_file(HISTORY_ARCHIVE_FILE, _legacy_history_path)
except Exception as _history_file_migration_error:
    try:
        with open(os.path.join(USER_DATA_DIR, 'history_archive_error.log'), 'a', encoding='utf-8') as _hf:
            _hf.write(time.strftime('%Y-%m-%d %H:%M:%S') + ' archive-file-migration ' + repr(_history_file_migration_error) + '\n')
    except Exception:
        pass
_ACTIVE_COLLECTION_TASK = threading.local()
QUALITY_QUARANTINE_FILE = os.path.join(USER_DATA_DIR, 'quality_quarantine.json')
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
TIMEOUT = (4, 7)
MAX_SITE_PAGES = 8

WA_RE = re.compile(r'''(?i)(?:https?:)?//(?:www\.)?(?:wa\.me/(?:[+\d][\d(). -]*|(?:message|invite)/[A-Za-z0-9_-]+)|(?:(?:api|web)\.)?whatsapp\.com/(?:send/?|channel/|invite/)[^\s\"'<>\\]+|chat\.whatsapp\.com/[A-Za-z0-9_-]+)''')
EMAIL_RE = re.compile(r'(?i)(?<![\w.+-])([A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,})(?![\w.-])')
PHONE_RE = re.compile(r'(?<![\w@])(?:\+?\d[\d\s().\-]{5,}\d)(?![\w@])')
LINKEDIN_RE = re.compile(r'https?://(?:[a-z]{2,3}\.)?linkedin\.com/(?:company|in|showcase|school)/[^\s"<>?#]+', re.I)
EMAIL_ROLE_RULES = [
    ('sales', ('sales', 'sale', 'businessdevelopment', 'bd', 'commercial'), 95, '销售'),
    ('export', ('export', 'overseas', 'international', 'global'), 95, '外贸/出口'),
    ('inquiry', ('inquiry', 'enquiry', 'rfq', 'quote', 'quotation', 'request'), 90, '询盘/报价'),
    ('purchase', ('purchase', 'purchasing', 'procurement', 'sourcing', 'buying'), 70, '采购'),
    ('marketing', ('marketing', 'market'), 65, '市场'),
    ('info', ('info', 'contact', 'office', 'hello', 'general'), 65, '通用商务'),
    ('service', ('service', 'support', 'after sales', 'aftersales'), 50, '客服/售后'),
    ('hr', ('hr', 'career', 'careers', 'recruit', 'job', 'jobs'), 10, '人力资源'),
    ('finance', ('finance', 'account', 'accounting', 'billing', 'invoice'), 10, '财务'),
]

MANUFACTURER_WORDS = {
    'manufacturer': 7, 'manufacturing': 7, 'factory': 8, 'plant': 6, 'producer': 6,
    'production': 5, 'oem': 5, 'odm': 5, 'exporter': 4, 'supplier': 3,
    'fabricat': 5, 'workshop': 3, 'industrial': 2, 'made in': 4, 'production line': 7,
    'manufacture': 6, 'own factory': 9, 'production facility': 9, 'factory direct': 9,
    '工厂': 8, '厂家': 8, '生产厂家': 10, '制造厂': 10, '制造商': 9, '制造': 5,
    '生产': 6, '源头工厂': 10, '自有工厂': 10, '工厂直销': 8, '生产线': 8,
    '厂房': 5, '车间': 5, '加工厂': 9, '实业': 3, '产业园': 3, '代工': 6,
    '贴牌生产': 7, '研发生产': 7, '生产基地': 8, '生产企业': 8, '厂家直供': 8,
}
NEGATIVE_WORDS = {'distributor': -4, 'trading company': -7, 'trading': -3, 'wholesale': -2, 'agent': -5, '经销商': -8, '代理商': -8, '贸易公司': -7, '批发': -4, '零售': -6, '电商': -7, '商城': -7, '招聘': -15, '新闻': -12, '博客': -8, '培训': -8, '企业黄页': -12, '供应商目录': -12}
CONTACT_PATHS = ['contact', 'contact-us', 'contactus', 'get-in-touch', 'reach-us', 'inquiry', 'enquiry', 'support', 'customer-service', 'about', 'about-us', 'company', 'company-profile', 'factory', 'products', 'services', 'export', 'oem', 'certification', 'sales', '联系我们', '联络我们', '联系方式', '联系', '关于我们', '公司简介', '企业简介', '工厂介绍', '生产基地', '产品中心', '售后服务', '业务咨询', '在线咨询', '询盘', '询价', 'whatsapp', 'wa.me']

# Site-level negative classification. These are portal/service signals, not merely
# low scores: they prevent unrelated portals from entering the manufacturer queue.
NON_MANUFACTURER_SITE_RE = re.compile(
    r'accessibility\s+(?:guide|directory|portal)|barrier[- ]free\s+(?:guide|directory|travel|tourism)|'
    r'universal\s+design\s+(?:guide|directory)|accessible\s+(?:travel|tourism|living)\s+(?:guide|portal)|'
    r'tourist?\s+information\s+(?:portal|guide)|travel\s+(?:guide|directory|portal)|'
    r'news\s+(?:portal|website|platform)|business\s+directory|supplier\s+directory|'
    r'资讯门户|新闻门户|行业资讯平台|企业黄页|供应商目录|旅游指南|无障碍生活|无障碍旅游|'
    r'无障碍资讯|景点介绍|餐厅指南|活动资讯|無障礙生活|無障礙旅遊|無障礙資訊', re.I)
FACTORY_PROOF_RE = re.compile(
    r'production\s+line|production\s+facility|manufacturing\s+plant|own\s+factory|'
    r'factory\s+(?:address|tour|floor|area|workshop)|manufacturing\s+process|'
    r'生产线|生产车间|厂房面积|生产设备|生产基地|自有工厂|工厂地址|制造车间|加工车间|生产能力', re.I)
SOCIAL_DOMAINS = ['linkedin.com','facebook.com','instagram.com','youtube.com','tiktok.com','x.com','twitter.com','pinterest.com']
DIRECTORY_DOMAINS = ['alibaba.com','made-in-china.com','globalsources.com','indiamart.com','1688.com','amazon.com','aliexpress.com','shunqi.com','gongchang.com']
IGNORED_OUTBOUND_DOMAINS = set(SOCIAL_DOMAINS + DIRECTORY_DOMAINS + ['google.com','baidu.com','qq.com','weixin.qq.com'])


_HTTP_SESSION_LOCAL = threading.local()


def get_thread_http_session():
    """Reuse one configured HTTP session per worker thread to retain keep-alive pools safely."""
    session = getattr(_HTTP_SESSION_LOCAL, 'session', None)
    if session is None:
        session = create_http_session()
        _HTTP_SESSION_LOCAL.session = session
    return session


def create_http_session():
    """Create a browser-like HTTP session and honor Windows/Python proxy settings."""
    session = requests.Session()
    # requests honors HTTP_PROXY/HTTPS_PROXY/NO_PROXY by default. On Windows,
    # urllib also reads the user's Internet Settings proxy configuration.
    try:
        system_proxies = urllib.request.getproxies()
        if system_proxies and not any((os.environ.get(k) or os.environ.get(k.upper())) for k in ('http_proxy','https_proxy','all_proxy')):
            if hasattr(session, 'proxies'):
                session.proxies.update({k: v for k, v in system_proxies.items() if k in ('http','https','all') and v})
    except Exception:
        pass
    try:
        session.trust_env = True
    except Exception:
        pass
    default_headers = {
        'User-Agent': USER_AGENT,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9,zh-CN;q=0.7,zh;q=0.6',
        'Upgrade-Insecure-Requests': '1',
    }
    if hasattr(session, 'headers'):
        session.headers.update(default_headers)
    retry = Retry(total=2, connect=2, read=1, backoff_factor=0.5,
                  status_forcelist=(500, 502, 503, 504),
                  allowed_methods=frozenset(['GET', 'HEAD']),
                  raise_on_status=False)
    adapter = HTTPAdapter(max_retries=retry, pool_connections=12, pool_maxsize=12)
    if hasattr(session, 'mount'):
        session.mount('http://', adapter)
        session.mount('https://', adapter)
    return session


def run_network_diagnostics():
    """Check optional API endpoints and API-free public search entry points."""
    targets = [
        ('自主搜索 Bing', 'www.bing.com', 'https://www.bing.com/search?q=export+manager+China'),
        ('自主搜索 Qwant（备用）', 'www.qwant.com', 'https://www.qwant.com/?q=export+manager+China'),
        ('自主搜索 DuckDuckGo（非当前主流程）', 'html.duckduckgo.com', 'https://html.duckduckgo.com/html/?q=export+manager+China'),
        ('自主搜索 Baidu', 'www.baidu.com', 'https://www.baidu.com/s?wd=外贸经理'),
        ('自主搜索 Ecosia', 'www.ecosia.org', 'https://www.ecosia.org/search?q=export+manager+China'),
        ('自主搜索 Yandex', 'yandex.com', 'https://yandex.com/search/?text=export+manager+China'),
        ('SerpApi 搜索 API（可选）', 'serpapi.com', 'https://serpapi.com/search.json'),
        ('Brave Search API（可选）', 'api.search.brave.com', 'https://api.search.brave.com/res/v1/web/search'),
    ]
    session = create_http_session()
    rows = []
    for label, host, url in targets:
        dns_text = 'DNS失败'
        try:
            socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)
            dns_text = 'DNS成功'
        except Exception as exc:
            dns_text = f'DNS失败：{type(exc).__name__}: {str(exc)[:100]}'
        try:
            # No API key is sent. An authentication/parameter response still proves
            # endpoint reachability, not that the account is authenticated.
            response = session.get(url, timeout=(8, 12), allow_redirects=False)
            status = response.status_code
            result = ('公开搜索入口可访问' if status < 400 else '公开搜索入口返回访问限制/错误') if '自主搜索' in label else ('API端点可访问（未验证密钥）' if status < 500 else 'API服务端异常')
            rows.append({'site': label, 'host': host, 'dns': dns_text,
                         'https': f'HTTP {status}', 'final_url': url,
                         'content_type': response.headers.get('Content-Type', ''),
                         'bytes': len(response.content), 'result': result})
        except requests.RequestException as exc:
            rows.append({'site': label, 'host': host, 'dns': dns_text,
                         'https': f'{type(exc).__name__}: {str(exc)[:120]}',
                         'final_url': '', 'content_type': '', 'bytes': 0, 'result': ('公开搜索入口连接失败' if '自主搜索' in label else 'API端点连接失败')})
    try:
        proxy_summary = ', '.join(f'{k}={v}' for k,v in urllib.request.getproxies().items() if k in ('http','https')) or '未检测到系统代理'
    except Exception:
        proxy_summary = '系统代理读取失败'
    return {'platform': platform.platform(), 'proxy': proxy_summary, 'rows': rows}


def load_catalog():
    rows=[]
    try:
        with open(CATALOG_FILE, encoding='utf-8-sig', newline='') as f:
            rows=list(csv.DictReader(f))
    except Exception:
        rows=[]
    # Keep the requested 607-row core taxonomy separate from explicitly marked additions.
    supplement_file=os.path.join(APP_DIR,'industry_catalog_supplement.csv')
    if os.path.isfile(supplement_file):
        try:
            with open(supplement_file,encoding='utf-8-sig',newline='') as f:
                rows.extend(csv.DictReader(f))
        except Exception:
            pass
    return rows


def is_displayable_company_name(name):
    value=html.unescape(re.sub(r'\s+',' ',str(name or '')).strip())
    if not value: return False
    low=value.lower().strip()
    if low in {'unknown','n/a','na','none','null','未获取','未发现','未知','无','暂无','公司名称未获取'}: return False
    if low.startswith(('http://','https://','www.')): return False
    if re.fullmatch(r'[a-z0-9.-]+\.(?:com|cn|net|org|com\.cn|net\.cn)(?:/.*)?',low): return False
    return len(value)>=2


def normalize_company_key(name):
    'Conservative exact-name key; avoids fuzzy merging unrelated subsidiaries.'
    value = html.unescape(re.sub(r'\s+', ' ', str(name or '')).strip()).lower()
    value = re.sub(r'https?://|www\.', ' ', value)
    value = re.sub(r'\b(official website|official site|homepage|官网|官方网站)\b', ' ', value, flags=re.I)
    # Remove English legal suffixes only when they are visibly separate words;
    # never strip a coincidental ending such as the 'co' in a brand name 'Maco'.
    value = re.sub(r'\s+(?:co\.?\s*,?\s*)?(?:ltd\.?|limited|inc\.?|corp\.?|corporation|company)$', '', value, flags=re.I)
    value = re.sub(r'[\s\-_,，。·.()（）\[\]【】]+', '', value)
    suffixes = ('有限责任公司','股份有限公司','有限公司','集团有限公司','集团')
    changed = True
    while changed and value:
        changed = False
        for suffix in suffixes:
            if value.endswith(suffix) and len(value) > len(suffix) + 1:
                value = value[:-len(suffix)]; changed = True; break
    return value


def registry_domain_key(domain):
    host = str(domain or '').lower().strip().split(':')[0].strip('.')
    if host.startswith('www.'): host = host[4:]
    labels = host.split('.')
    if len(labels) < 2: return host
    if labels[0] in {'m','mobile','shop','store','en','cn','global','www'} and len(labels) >= 3:
        labels = labels[1:]
    multi_suffixes = {'com.cn','net.cn','org.cn','gov.cn','edu.cn','com.hk','net.hk','org.hk','com.sg','com.au','net.au','org.au','co.uk','org.uk','ac.uk','gov.uk','co.jp','ne.jp','or.jp','com.tw','net.tw','org.tw','com.my','com.br','net.br','org.br','com.mx','com.ar','com.co','co.in','firm.in','net.in','org.in','co.za','com.tr','com.pl','com.ua','com.vn','com.ph','com.pk','com.bd','com.eg','com.ng','com.id','co.kr','co.th','co.nz','com.pe'}
    suffix = '.'.join(labels[-2:])
    return '.'.join(labels[-3:]) if suffix in multi_suffixes and len(labels) >= 3 else '.'.join(labels[-2:])


def is_previously_collected(domain, company_name, known_domains, known_company_names):
    domain_key = registry_domain_key(domain)
    name_key = normalize_company_key(company_name)
    return bool((domain_key and domain_key in known_domains) or (name_key and name_key in known_company_names))


def load_collected_registry(db_file=None):
    """Read permanent/recent company identities from the independent global registry."""
    if db_file and os.path.abspath(db_file) != os.path.abspath(DB_FILE):
        # Compatibility path for tests/legacy callers using an explicit DB.
        domains, names = set(), set()
        con=sqlite3.connect(db_file,timeout=60)
        try:
            for domain,name in con.execute("SELECT domain,company_name FROM leads WHERE quality_status='keep'"):
                if domain: domains.add(registry_domain_key(domain))
                key=normalize_company_key(name)
                if key: names.add(key)
        finally: con.close()
        return domains,names
    return GLOBAL_DEDUP.load_sets(recent_days=0)


def load_recently_seen_registry(db_file=None, days=30):
    """Incomplete discoveries must not be hidden by a time-based skip window."""
    return set(), set()


def load_contact_incomplete_registry(db_file=None):
    """Return confirmed leads missing either public email or WhatsApp so they can be enriched."""
    path = db_file or DB_FILE
    domains, names = set(), set()
    try:
        con = sqlite3.connect(path, timeout=15)
        try:
            rows = con.execute("SELECT domain,company_name,whatsapp,whatsapp_contacts,emails,quality_status,evidence,score FROM leads WHERE quality_status IN ('keep','review')").fetchall()
        finally:
            con.close()
        for domain, name, whatsapp, whatsapp_contacts, emails, quality_status, evidence_text, score in rows:
            # Review records are eligible for contact refresh only when they already
            # contain explicit factory proof; generic supplier/contact leads are excluded.
            if quality_status == 'review':
                proof = str(evidence_text or '')
                if not (STRONG_FACTORY_PROOF_RE.search(proof) or FACTORY_PROOF_RE.search(proof)) or int(score or 0) < 14:
                    continue
            try: wa_values = json.loads(whatsapp or '[]')
            except (TypeError, ValueError): wa_values = []
            try: wa_number_values = json.loads(whatsapp_contacts or '[]')
            except (TypeError, ValueError): wa_number_values = []
            wa_values = list(wa_values or []) + list(wa_number_values or [])
            try: email_values = json.loads(emails or '[]')
            except (TypeError, ValueError): email_values = []
            if not wa_values or not email_values:
                if domain: domains.add(registry_domain_key(domain))
                key = normalize_company_key(name)
                if key: names.add(key)
    except (sqlite3.Error, OSError):
        pass
    return domains, names


def record_registry_candidate(domain, title='', website='', source_query='', status='discovered', reason=''):
    """Write every seen candidate to the independent cross-industry registry."""
    return GLOBAL_DEDUP.record(domain,title,website,status,query=source_query,
                               source_url=website,reason=reason)


def init_db():
    con = sqlite3.connect(DB_FILE, timeout=60)
    con.execute('PRAGMA busy_timeout=60000')
    # WAL allows the UI/readers to continue while background workers persist leads.
    try:
        con.execute('PRAGMA journal_mode=WAL')
        con.execute('PRAGMA synchronous=NORMAL')
    except sqlite3.Error:
        pass
    con.execute('''CREATE TABLE IF NOT EXISTS leads (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        domain TEXT UNIQUE, company_name TEXT, website TEXT, category TEXT, industry TEXT,
        country TEXT, score INTEGER, operation_score INTEGER, evidence TEXT,
        whatsapp TEXT, emails TEXT, phones TEXT, linkedin TEXT, sources TEXT,
        status TEXT, notes TEXT, collected_at TEXT
    )''')
    existing = {row[1] for row in con.execute('PRAGMA table_info(leads)')}
    for name, decl in [('email_details', "TEXT DEFAULT '[]'"), ('whatsapp_contacts', "TEXT DEFAULT '[]'"), ('contact_evidence', "TEXT DEFAULT '{}'"), ('decision_maker_evidence', "TEXT DEFAULT ''"), ('gender_status', "TEXT DEFAULT '未知/未核实'"), ('company_address', "TEXT DEFAULT ''"), ('address_source_url', "TEXT DEFAULT ''"), ('quality_status', "TEXT DEFAULT 'review'"), ('quality_reason', "TEXT DEFAULT ''")]:
        if name not in existing:
            con.execute(f'ALTER TABLE leads ADD COLUMN {name} {decl}')
    existing = {row[1] for row in con.execute('PRAGMA table_info(leads)')}
    for name in ('factory_authenticity_score','export_capability_score','contact_evidence_score'):
        if name not in existing:
            con.execute(f'ALTER TABLE leads ADD COLUMN {name} INTEGER NOT NULL DEFAULT 0')
    con.commit(); con.close()
    init_provider_db(DB_FILE)
    # Additive migration; legacy company/evidence rows are preserved.
    con = sqlite3.connect(DB_FILE, timeout=60)
    con.execute('CREATE INDEX IF NOT EXISTS idx_lead_evidence_dedupe ON lead_evidence(domain,evidence_type,evidence_text,source_url,observed_at)')
    con.execute('''CREATE TABLE IF NOT EXISTS collection_registry (
        domain TEXT PRIMARY KEY, normalized_name TEXT NOT NULL DEFAULT '', company_name TEXT NOT NULL DEFAULT '',
        website TEXT NOT NULL DEFAULT '', first_seen TEXT NOT NULL, last_seen TEXT NOT NULL,
        seen_count INTEGER NOT NULL DEFAULT 1, status TEXT NOT NULL DEFAULT 'discovered',
        last_query TEXT NOT NULL DEFAULT '', collected_at TEXT NOT NULL DEFAULT '',
        last_reason TEXT NOT NULL DEFAULT '')''')
    registry_cols={row[1] for row in con.execute('PRAGMA table_info(collection_registry)')}
    if 'last_reason' not in registry_cols:
        con.execute("ALTER TABLE collection_registry ADD COLUMN last_reason TEXT NOT NULL DEFAULT ''")
    con.execute('CREATE INDEX IF NOT EXISTS idx_collection_registry_name ON collection_registry(normalized_name,status)')
    con.execute('''CREATE TABLE IF NOT EXISTS contact_registry (
        domain TEXT NOT NULL, contact_type TEXT NOT NULL, normalized_value TEXT NOT NULL,
        raw_value TEXT NOT NULL DEFAULT '', first_seen TEXT NOT NULL, last_seen TEXT NOT NULL,
        source_url TEXT NOT NULL DEFAULT '', evidence_count INTEGER NOT NULL DEFAULT 1,
        status TEXT NOT NULL DEFAULT '未核实', PRIMARY KEY(domain,contact_type,normalized_value))''')
    con.execute('CREATE INDEX IF NOT EXISTS idx_contact_registry_value ON contact_registry(contact_type,normalized_value)')
    # Independent WhatsApp discovery ledger; additive and non-destructive.
    con.execute("""CREATE TABLE IF NOT EXISTS whatsapp_discoveries (
        id INTEGER PRIMARY KEY AUTOINCREMENT, domain TEXT NOT NULL DEFAULT '',
        company_name TEXT NOT NULL DEFAULT '', website TEXT NOT NULL DEFAULT '',
        whatsapp_type TEXT NOT NULL, whatsapp_value TEXT NOT NULL,
        source_url TEXT NOT NULL DEFAULT '', evidence TEXT NOT NULL DEFAULT '',
        country TEXT NOT NULL DEFAULT '', industry TEXT NOT NULL DEFAULT '',
        first_seen TEXT NOT NULL, last_seen TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT '来源已记录',
        UNIQUE(domain, whatsapp_type, whatsapp_value, source_url))""")
    con.execute('CREATE INDEX IF NOT EXISTS idx_whatsapp_discoveries_value ON whatsapp_discoveries(whatsapp_value)')
    # Backfill legacy leads with conservative quality labels. Only confirmed
    # manufacturer candidates become permanent skips; review rows stay in the
    # 30-day candidate registry so a later run can retry them.
    legacy_rows=con.execute('SELECT domain,company_name,website,industry,evidence,notes,collected_at,quality_status,quality_reason FROM leads').fetchall()
    for domain, name, website, industry, evidence, notes, collected_at, qstatus, qreason in legacy_rows:
        if not qreason:
            qstatus,qreason=assess({'company_name':name or '', 'industry':industry or '', 'manufacturer_evidence':evidence or '', 'notes':notes or ''})
            con.execute('UPDATE leads SET quality_status=?,quality_reason=? WHERE domain=?',(qstatus,qreason,domain))
        registry_status='collected' if qstatus=='keep' else ('excluded' if qstatus=='excluded' else 'review')
        key = normalize_company_key(name); stamp = collected_at or time.strftime('%Y-%m-%d %H:%M:%S')
        con.execute('''INSERT INTO collection_registry(domain,normalized_name,company_name,website,first_seen,last_seen,seen_count,status,last_query,collected_at)
          VALUES(?,?,?,?,?,?,1,?,'',?) ON CONFLICT(domain) DO UPDATE SET
          normalized_name=CASE WHEN excluded.normalized_name!='' THEN excluded.normalized_name ELSE collection_registry.normalized_name END,
          company_name=CASE WHEN excluded.company_name!='' THEN excluded.company_name ELSE collection_registry.company_name END,
          website=CASE WHEN excluded.website!='' THEN excluded.website ELSE collection_registry.website END,
          status=CASE WHEN collection_registry.status='collected' THEN 'collected' ELSE excluded.status END,
          collected_at=CASE WHEN excluded.collected_at!='' THEN excluded.collected_at ELSE collection_registry.collected_at END''',
          (domain,key,name or '',website or '',stamp,stamp,registry_status,stamp))
    con.commit(); con.close()


CATALOG = load_catalog(); init_db()
history_store.init(HISTORY_ARCHIVE_FILE)
try:
    _history_migration = history_store.migrate_master_once(HISTORY_ARCHIVE_FILE, DB_FILE)
except Exception as _history_migration_error:
    _history_migration = {'error': type(_history_migration_error).__name__ + ': ' + str(_history_migration_error)}
    try:
        with open(os.path.join(USER_DATA_DIR, 'history_archive_error.log'), 'a', encoding='utf-8') as _hf:
            _hf.write(time.strftime('%Y-%m-%d %H:%M:%S') + ' ' + repr(_history_migration_error) + '\n')
    except Exception:
        pass

# Temporary collection policy: pause ONLY cross-task historical skip/filtering.
# The canonical history registry remains active for recording and future reference.
# Existing user history is neither deleted nor moved to a diagnostic database.
DIAGNOSTIC_DISABLE_GLOBAL_HISTORY_FILTER = True

def resolve_global_dedup_path(user_data_dir, diagnostic=False):
    filename = 'global_dedup_diagnostic.db' if diagnostic else 'global_dedup.db'
    return os.path.join(user_data_dir, filename)

# Keep the user's canonical registry even while historical filtering is paused.
# Pausing skips must never fork the registry or hide previously stored history.
GLOBAL_DEDUP_FILE = resolve_global_dedup_path(USER_DATA_DIR, diagnostic=False)
GLOBAL_DEDUP = GlobalDedup(GLOBAL_DEDUP_FILE)


def migrate_global_dedup_from_legacy():
    """One-time additive migration; never deletes or rewrites the legacy database."""
    gcon=GLOBAL_DEDUP.connect()
    try:
        done=gcon.execute("SELECT value FROM schema_meta WHERE key='legacy_migration_v1'").fetchone()
        if done and done[0]=='done': return {'skipped':'already_migrated'}
    finally: gcon.close()
    con=sqlite3.connect(DB_FILE,timeout=60)
    try:
        lead_rows=con.execute('SELECT domain,company_name,website,country,quality_status,collected_at FROM leads').fetchall()
        try:
            registry_rows=con.execute('SELECT domain,company_name,website,status,last_query,last_seen,last_reason FROM collection_registry').fetchall()
        except sqlite3.OperationalError:
            registry_rows=[]
    finally: con.close()
    result=GLOBAL_DEDUP.migrate_legacy(lead_rows,registry_rows)
    gcon=GLOBAL_DEDUP.connect()
    try:
        gcon.execute("INSERT OR REPLACE INTO schema_meta(key,value) VALUES('legacy_migration_v1','done')")
        gcon.commit()
    finally: gcon.close()
    return result


try:
    # Migration remains enabled so legacy history stays in the canonical registry;
    # only the runtime skip decision is disabled.
    migrate_global_dedup_from_legacy()
    if DIAGNOSTIC_DISABLE_GLOBAL_HISTORY_FILTER:
        print('[CONFIG] 历史重复跳过已暂停；继续使用原 global_dedup.db 保存历史记录。')
except Exception as _dedup_migration_error:
    try:
        with open(os.path.join(USER_DATA_DIR,'global_dedup_migration_error.log'),'a',encoding='utf-8') as _f:
            _f.write(time.strftime('%Y-%m-%d %H:%M:%S')+' '+repr(_dedup_migration_error)+'\n')
    except Exception:
        pass


def normalize_url(s):
    s = (s or '').strip()
    if not s: return ''
    if not s.startswith(('http://','https://')): s = 'https://' + s
    return s


def site_root_url(url):
    """Return the website origin root while keeping actual page URLs separately as evidence."""
    try:
        p=urlparse(normalize_url(url))
        if p.scheme and p.netloc:
            return urlunparse((p.scheme,p.netloc,'/','','',''))
    except Exception:
        pass
    return normalize_url(url)


def root_domain(url):
    """Return a registrable-domain key, collapsing common public subdomains safely."""
    try:
        host = (urlparse(url).hostname or '').lower().strip('.')
        return registry_domain_key(host) if host else ''
    except Exception:
        return ''


def same_domain(a, b): return root_domain(a) == root_domain(b) and bool(root_domain(a))


def clean_text(s): return re.sub(r'\s+', ' ', html.unescape(s or '')).strip()


def canonicalize_contact(url):
    try:
        p = urlparse(url)
        return p._replace(fragment='', query='').geturl().rstrip('/')
    except Exception: return url


def is_eligible_whatsapp_number(value, allow_compact_international=False, country='中国'):
    """Validate a number explicitly presented as WhatsApp, independent of company country.

    The target country describes the manufacturer location, not the phone numbering plan.
    Chinese manufacturers may publish overseas WhatsApp numbers, so +852/+65/+1 etc.
    must not be rejected merely because the company is in China.
    """
    raw = str(value or '').strip()
    digits = re.sub(r'\D', '', raw)
    if raw.startswith('00') and digits.startswith('00'):
        digits = digits[2:]
    if not 9 <= len(digits) <= 15 or digits.startswith(('400', '800')):
        return False
    explicit = raw.startswith('+') or raw.startswith('00')
    if not explicit and not allow_compact_international:
        return False
    if not explicit and str(country or '').strip() in {'中国','China','CN','中国大陆'}:
        # A bare 11-digit Chinese mobile is a domestic phone, not an international WA number.
        if len(digits) == 11 and digits.startswith('1'):
            return False
        if digits.startswith('86'):
            national=digits[2:]
            if not (len(national)==11 and national.startswith('1') and national[1] in '3456789'):
                return False
    normalized = '+' + digits
    if phonenumbers is not None:
        try:
            parsed = phonenumbers.parse(normalized, None)
            if not phonenumbers.is_valid_number(parsed):
                return False
            number_type = phonenumbers.number_type(parsed)
            allowed = {phonenumbers.PhoneNumberType.MOBILE,
                       phonenumbers.PhoneNumberType.FIXED_LINE_OR_MOBILE,
                       phonenumbers.PhoneNumberType.FIXED_LINE,
                       phonenumbers.PhoneNumberType.VOIP}
            # Some WhatsApp Business accounts legitimately use fixed-line or VoIP numbers.
            # The explicit WhatsApp label/link is the evidence; never infer WA from a plain phone.
            return number_type in allowed
        except phonenumbers.NumberParseException:
            return False
    # Conservative fallback when phonenumbers is unavailable: retain only an explicit
    # international number with a plausible length; the source must still label it WA.
    if not (explicit or allow_compact_international):
        return False
    if digits.startswith('86'):
        national = digits[2:]
        return len(national) == 11 and national.startswith('1') and national[1] in '3456789'
    return 9 <= len(digits) <= 15


def normalize_whatsapp_number_display(value, country='中国'):
    """Return a clean E.164-style display only for explicitly international WA numbers."""
    raw = str(value or '').strip()
    if not is_eligible_whatsapp_number(raw, country=country):
        return ''
    digits = re.sub(r'\D', '', raw)
    if raw.startswith('00') and digits.startswith('00'):
        digits = digits[2:]
    return '+' + digits


def whatsapp_url_has_eligible_number(url, country='中国'):
    """Check a WhatsApp contact URL's embedded phone number without inventing one."""
    try:
        parsed = urlparse(html.unescape((url or '').strip()))
        host = (parsed.hostname or '').lower()
        digits = ''
        if host == 'wa.me':
            first_path = parsed.path.strip('/').split('/')[0]
            # Preserve explicit non-number WhatsApp short links (e.g. message/invite);
            # they remain links, not extracted phone numbers.
            if first_path.lower() in {'message', 'invite'}:
                return True
            digits = re.sub(r'\D', '', first_path)
        elif host == 'whatsapp.com' or host.endswith('.whatsapp.com'):
            if host == 'chat.whatsapp.com' or re.match(r'^/(?:channel|invite)/', parsed.path, re.I):
                return True
            values = parse_qs(parsed.query).get('phone', [])
            digits = re.sub(r'\D', '', values[0]) if values else ''
        else:
            return False
        # Number-bearing contact links must pass the same mobile/service-number filter.
        return is_eligible_whatsapp_number(digits, allow_compact_international=True, country=country) if digits else False
    except Exception:
        return False


def normalize_whatsapp_url(url):
    """Normalize an explicitly published WhatsApp URL; never create one from a phone number."""
    try:
        p = urlparse(html.unescape((url or '').strip()))
        if p.scheme.lower() not in ('http', 'https'):
            return ''
        host = (p.hostname or '').lower().rstrip('.')
        if host == 'wa.me':
            # wa.me links identify WhatsApp by domain; preserve the path, discard tracking.
            return p._replace(fragment='', query='').geturl().rstrip('/')
        if host == 'whatsapp.com' or host.endswith('.whatsapp.com'):
            q = parse_qs(p.query)
            kept = {}
            if q.get('phone'):
                phone = re.sub(r'\D', '', q['phone'][0])
                if 8 <= len(phone) <= 15:
                    kept['phone'] = phone
            if q.get('app_absent'):
                kept['app_absent'] = q['app_absent'][0]
            return p._replace(fragment='', query=urlencode(kept)).geturl().rstrip('?')
        return ''
    except Exception:
        return ''


def classify_email(email, page_url):
    """Classify only from the public email string; never infer a person's gender."""
    email = (email or '').strip().lower()
    if not EMAIL_RE.fullmatch(email):
        return {'email': email, 'role': 'unknown', 'role_label': '未分类', 'email_score': 20,
                'email_type': '格式待核验', 'domain_match': False, 'public_source_url': page_url}
    local, domain = email.rsplit('@', 1)
    role, label, base = 'general', '通用/未分类', 55
    normalized = re.sub(r'[._+\-]+', '', local)
    for key, tokens, score, cn_label in EMAIL_ROLE_RULES:
        if any(t.replace(' ', '') in normalized for t in tokens):
            role, label, base = key, cn_label, score
            break
    role_mailboxes = {'sales','export','inquiry','purchase','marketing','info','service','hr','finance'}
    generic = role in role_mailboxes or local in {'admin','administrator','webmaster','noreply','no-reply','postmaster'}
    personal_like = not generic and bool(re.fullmatch(r'[a-z][a-z0-9._+-]{1,30}', local))
    if personal_like:
        role, label, base = 'person_or_team', '个人/团队邮箱（身份未核实）', 82
    site_domain = root_domain(page_url)
    email_domain_match = bool(site_domain and (domain == site_domain or domain.endswith('.' + site_domain)))
    score = base + (10 if email_domain_match else 0)
    if domain in {'gmail.com','outlook.com','hotmail.com','yahoo.com','163.com','126.com','qq.com'}:
        score -= 12
    score = max(0, min(100, score))
    return {'email': email, 'role': role, 'role_label': label, 'email_score': score,
            'email_type': '角色邮箱' if generic else '个人/团队邮箱候选',
            'domain_match': email_domain_match, 'public_source_url': page_url}


def enrich_emails(emails, page_urls):
    """Attach public page evidence and priority; no SMTP probing or email sending."""
    details = []
    for email in sorted(set(x.strip().lower() for x in emails if x and '@' in x)):
        sources = [u for u in page_urls if email in u.lower()]  # fallback only; page text evidence is added by caller below
        detail = classify_email(email, page_urls[0] if page_urls else '')
        detail['public_source_url'] = sources[0] if sources else (page_urls[0] if page_urls else '')
        details.append(detail)
    return sorted(details, key=lambda x: (-x['email_score'], x['email']))


PLACEHOLDER_EMAIL_DOMAINS = {
    'example.com', 'example.org', 'example.net', 'test.com', 'invalid',
    'email.com', 'domain.com', 'yourdomain.com', 'company.com'
}

def clean_email_candidate(value):
    """Return a plausible email address or an empty string; never invent addresses."""
    value = html.unescape(unquote((value or '').strip())).strip('\t\r\n <>()[]{}\"\'.,;:')
    value = value.lower()
    if not EMAIL_RE.fullmatch(value):
        return ''
    local, domain = value.rsplit('@', 1)
    if len(value) > 254 or len(local) > 64 or '..' in value:
        return ''
    if domain in PLACEHOLDER_EMAIL_DOMAINS or domain.endswith(('.example', '.test', '.invalid', '.localhost')):
        return ''
    if domain in {'sentry.io','wixpress.com','sentry-next.wixpress.com'} or domain.endswith(('.sentry.io','.wixpress.com')):
        return ''
    resource_suffixes={'png','jpg','jpeg','gif','svg','webp','avif','ico','bmp','tif','tiff','pdf','woff','woff2','css','js','map'}
    if domain.rsplit('.',1)[-1] in resource_suffixes:
        return ''
    if domain.startswith('.') or domain.endswith('.') or '..' in domain:
        return ''
    # Reject obvious file/document artefacts sometimes mistaken for email text.
    if local.endswith(tuple('.'+x for x in resource_suffixes)):
        return ''
    return value


def clean_phone_candidate(value, context=''):
    """Conservative phone cleanup: exclude dates, IPs, identifiers and implausible lengths."""
    value = html.unescape(unquote((value or '').strip()))
    context = (context or '').lower()
    if any(marker in context for marker in ('isbn', 'orcid', 'doi:', 'doi.org', 'ip address', 'copyright', 'order id', 'tracking number', 'publication date')):
        return '' 
    value = re.sub(r'^(?:tel:)', '', value, flags=re.I).strip().strip('.,;:()[]{}')
    if not value:
        return ''
    digits = re.sub(r'\D', '', value)
    if not 9 <= len(digits) <= 15:
        return ''
    # A visible IPv4 address is not a phone number.
    if re.fullmatch(r'\d{1,3}(?:\.\d{1,3}){3}', value):
        return ''
    # Reject common date forms and ISBN-shaped identifiers even in legacy exports.
    if re.fullmatch(r'97[89][-\s]?\d[-\s]?\d{2,5}[-\s]?\d{2,7}[-\s]?[\dX]', value, re.I):
        return ''
    if re.fullmatch(r'(?:19|20)\d{2}[-/.年](?:0?[1-9]|1[0-2])[-/.月](?:0?[1-9]|[12]\d|3[01])日?', value):
        return ''
    if re.fullmatch(r'\d{4}[-/]\d{2}[-/]\d{2}', value):
        return ''
    if len(set(digits)) <= 2 and len(digits) >= 10:
        return ''
    # Plain numeric identifiers without formatting are risky; require contact-label context.
    contact_context=any(k in context for k in ('phone','mobile','telephone','tel:','contact','whatsapp','call us','电话','手机','联系','联络','热线','传真'))
    formatted=any(c in value for c in ' ()-') or value.lstrip().startswith('+')
    if not formatted and not contact_context and len(digits) >= 8:
        return ''
    if len(digits) >= 12 and not formatted and not contact_context:
        return ''
    return value


def deduplicate_phone_formats(values, evidence=None):
    """Collapse formatting variants of the same public phone number without guessing country codes."""
    chosen = {}
    source_map = {}
    for value in values or []:
        raw = str(value or '').strip()
        digits = re.sub(r'\D', '', raw)
        if not 9 <= len(digits) <= 15:
            continue
        current = chosen.get(digits)
        # Prefer an explicit international '+' form, then a human-readable formatted value.
        rank = (raw.startswith('+'), any(ch in raw for ch in ' -()'), len(raw))
        current_rank = (current.startswith('+'), any(ch in current for ch in ' -()'), len(current)) if current else None
        if current is None or rank > current_rank:
            chosen[digits] = raw
        if evidence and raw in evidence:
            source_map.setdefault(digits, evidence[raw])
    output = sorted(chosen.values())
    normalized_sources = {chosen[d]: source_map[d] for d in chosen if d in source_map}
    return output, normalized_sources


def _decode_cloudflare_email(encoded):
    """Decode Cloudflare's public email-protection markup when it is present in page HTML."""
    try:
        data = bytes.fromhex(encoded.strip())
        if len(data) < 2:
            return ''
        key = data[0]
        decoded = ''.join(chr(b ^ key) for b in data[1:])
        return clean_email_candidate(decoded)
    except (ValueError, TypeError):
        return ''


def extract_obfuscated_emails(text):
    """Recover common human-readable email obfuscations without guessing missing text."""
    value = html.unescape(text or '')
    found = set()
    patterns = [
        r'(?i)([A-Z0-9._%+-]+)\s*\[\s*at\s*\]\s*([A-Z0-9.-]+)\s*\[\s*dot\s*\]\s*([A-Z]{2,}(?:\s*\[\s*dot\s*\]\s*[A-Z]{2,})*)',
        r'(?i)([A-Z0-9._%+-]+)\s*\(\s*at\s*\)\s*([A-Z0-9.-]+)\s*\(\s*dot\s*\)\s*([A-Z]{2,}(?:\s*\(\s*dot\s*\)\s*[A-Z]{2,})*)',
        r'(?i)([A-Z0-9._%+-]+)\s+at\s+([A-Z0-9.-]+)\s+dot\s+([A-Z]{2,}(?:\s+dot\s+[A-Z]{2,})*)',
    ]
    for pattern in patterns:
        for match in re.finditer(pattern, value):
            candidate = match.group(1) + '@' + match.group(2) + '.' + re.sub(r'(?i)\s*(?:\[\s*dot\s*\]|\(\s*dot\s*\)|\bdot\b)\s*', '.', match.group(3))
            candidate = clean_email_candidate(candidate)
            if candidate:
                found.add(candidate)
    # Common JS-style forms: name [at] domain (dot) tld, with spaces around separators.
    loose = re.compile(r'(?i)([A-Z0-9._%+-]+)\s*(?:\[at\]|\(at\)|\bat\b)\s*([A-Z0-9.-]+)\s*(?:\[dot\]|\(dot\)|\bdot\b)\s*([A-Z]{2,})')
    for match in loose.finditer(value):
        candidate = clean_email_candidate(f'{match.group(1)}@{match.group(2)}.{match.group(3)}')
        if candidate:
            found.add(candidate)
    # Emails sometimes render across adjacent HTML spans as visible text with whitespace around @.
    spaced_at = re.compile(r'(?i)([A-Z0-9._%+-]+)\s*@\s*([A-Z0-9.-]+\.[A-Z]{2,})')
    for match in spaced_at.finditer(value):
        candidate = clean_email_candidate(match.group(1) + '@' + match.group(2))
        if candidate:
            found.add(candidate)
    # Cloudflare protected email payloads are embedded in public HTML attributes.
    for encoded in re.findall(r'data-cfemail=[\"\']([0-9a-fA-F]+)[\"\']', value, re.I):
        decoded = _decode_cloudflare_email(encoded)
        if decoded:
            found.add(decoded)
    return found




def iter_jsonld_objects(soup):
    """Yield dictionaries embedded in public schema.org JSON-LD blocks."""
    def walk(value):
        if isinstance(value, dict):
            yield value
            for child in value.values():
                yield from walk(child)
        elif isinstance(value, list):
            for child in value:
                yield from walk(child)
    for script in soup.find_all('script', attrs={'type': re.compile(r'application/ld\+json', re.I)}):
        raw=script.string or script.get_text(' ',strip=True)
        if not raw:
            continue
        try:
            data=json.loads(raw.strip())
        except (ValueError, TypeError):
            continue
        yield from walk(data)


def structured_company_name(soup):
    preferred=('organization','localbusiness','corporation','store','manufacturer','professionalservice')
    for obj in iter_jsonld_objects(soup):
        types=obj.get('@type', [])
        if isinstance(types,str): types=[types]
        normalized=[str(x).lower().replace('schema:','') for x in types]
        if any(any(t in typ for t in preferred) for typ in normalized):
            name=clean_text(str(obj.get('name','')))
            if 2 <= len(name) <= 180:
                return name
    return ''


def extract_company_address(soup):
    """Extract a conservative company address; reject contact blocks polluted by phones/emails."""
    def format_address(value):
        if isinstance(value, str):
            return clean_text(value)
        if isinstance(value, dict):
            keys=('streetAddress','addressLocality','addressRegion','postalCode','addressCountry')
            parts=[]
            for key in keys:
                item=value.get(key)
                if isinstance(item,dict): item=item.get('name') or item.get('@id')
                if item:
                    if isinstance(item,dict): item=item.get('name','')
                    parts.append(clean_text(str(item)))
            return ', '.join(dict.fromkeys(x for x in parts if x))
        return ''
    def plausible(value, structured=False):
        value=clean_text(value)
        if not (8 <= len(value) <= 400): return False
        if re.search(r'(?i)privacy|terms|copyright|cookie|sales service|tel(?:ephone)?\s*[:：]|phone\s*[:：]|fax\s*[:：]|whats\s*app|e-?mail\s*[:：]|www\.|https?://',value): return False
        if len(re.findall(r'\+?\d[\d ()-]{6,}\d',value)) >= 2: return False
        if structured: return True
        address_cues=r'(?i)\b(road|rd\.?|street|st\.?|avenue|ave\.?|industrial park|building|floor|district|city|province|county|zone|postal|zip|china|ningbo|shenzhen|guangzhou|shanghai|dongguan)\b|地址|路|街|工业园|产业园|大厦|楼|区|市|省|县|镇|邮编'
        return bool(re.search(address_cues,value))
    for obj in iter_jsonld_objects(soup):
        addr=obj.get('address')
        if addr:
            value=format_address(addr)
            if plausible(value, structured=True): return value
    candidates=[]
    for node in soup.find_all(['address']):
        value=clean_text(node.get_text(' ',strip=True))
        if plausible(value): candidates.append(value)
    for node in soup.find_all(True, attrs={'class': re.compile(r'address|location|company-info',re.I)}):
        value=clean_text(node.get_text(' ',strip=True))
        if plausible(value) and re.search(r'(?i)address|地址|location|所在地|street|road|路|街|区|市|省|邮编',value): candidates.append(value)
    for value in candidates:
        value=re.sub(r'(?i)^.*?(?:company\s+address|office\s+address|address|地址|公司地址|联系地址)\s*[:：]?\s*','',value)
        if plausible(value): return value[:400]
    return ''


def phone_context_for_match(block, start, end):
    """Use nearby labels and separators so unrelated identifiers do not contaminate phone context."""
    # Restrict context to the current clause; semicolons and vertical bars commonly separate contact fields.
    left = max(block.rfind(';', 0, start), block.rfind('|', 0, start), block.rfind('；', 0, start), block.rfind('｜', 0, start), block.rfind('\n', 0, start)) + 1
    right_candidates = [x for x in (block.find(';', end), block.find('|', end), block.find('；', end), block.find('｜', end), block.find('\n', end)) if x >= 0]
    right = min(right_candidates) if right_candidates else len(block)
    clause = block[left:right]
    rel_start = start - left
    prefix = clause[:rel_start]
    labels = list(re.finditer(r'(?i)(whats\s*app|whatsapp|wa\.me|\bwa\b|telephone|phone|mobile|tel|fax|电话|手机|热线|联系号码|联系方式|联系|isbn|orcid|doi(?:\.org)?|ip address|publication date|copyright|tracking number|order id)\s*[:：-]?', prefix))
    label = labels[-1].group(0) if labels else ''
    # The current clause is still useful for formatting and the candidate itself, but use the nearest label
    # as the context anchor so a preceding WhatsApp label cannot classify a later ordinary phone as WhatsApp.
    return (label + ' ' + block[start:end] + ' ' + clause[rel_start + (end-start):]).strip()


def extract_contact_evidence(soup, page_url, country='中国'):
    """Extract public contacts with per-field evidence; WhatsApp numbers require an explicit label/link."""
    raw = html.unescape(str(soup))
    text = clean_text(soup.get_text(' ', strip=True))
    # Many sites keep WhatsApp CTA URLs in inline JS/JSON rather than visible anchors.
    # Decode common escaped URL forms, but never synthesize a link from a plain phone number.
    script_text = ' '.join(x.get_text(' ', strip=True) for x in soup.find_all('script'))
    wa_scan_text = html.unescape(raw + ' ' + script_text).replace('\\/', '/')
    wa_scan_text = re.sub(r'\\u002[fF]', '/', wa_scan_text)
    wa_links = set()
    whatsapp_contacts = set()
    linkedin = set()
    email_candidates = set(EMAIL_RE.findall(html.unescape(text)))
    email_candidates.update(extract_obfuscated_emails(text))
    email_candidates.update(EMAIL_RE.findall(raw))
    email_candidates.update(extract_obfuscated_emails(raw))
    phone_candidates = []  # Keep context alongside each candidate to avoid losing tel/schema evidence.
    email_evidence = {}
    phone_evidence = {}
    wa_evidence = {}

    def add_whatsapp_url(candidate, source=page_url):
        candidate = html.unescape(unquote(str(candidate or '').strip().strip('\"\'`.,);]')))
        if candidate.startswith('//'):
            candidate = 'https:' + candidate
        if not candidate.lower().startswith(('http://', 'https://')):
            return
        normalized = normalize_whatsapp_url(candidate)
        if normalized and whatsapp_url_has_eligible_number(normalized, country=country):
            wa_links.add(normalized)
            wa_evidence.setdefault(normalized, source)
            # A phone-bearing WhatsApp URL is direct evidence for its embedded number.
            # Previously we retained the link but did not populate the separate number field.
            parsed = urlparse(normalized)
            embedded = ''
            if (parsed.hostname or '').lower() == 'wa.me':
                embedded = parsed.path.strip('/').split('/')[0]
            elif (parsed.hostname or '').lower().endswith('whatsapp.com'):
                values = parse_qs(parsed.query).get('phone', [])
                embedded = values[0] if values else ''
            digits = re.sub(r'\D','',embedded)
            if digits.startswith('00'):
                digits = digits[2:]
            if digits and is_eligible_whatsapp_number(digits,allow_compact_international=True,country=country):
                display_number = '+' + digits
                cleaned_number = clean_phone_candidate(display_number,'WhatsApp URL')
                if cleaned_number:
                    whatsapp_contacts.add(cleaned_number)
                    wa_evidence.setdefault(cleaned_number,source)

    for match in WA_RE.finditer(wa_scan_text):
        add_whatsapp_url(match.group(0))

    def add_email(value, source=page_url):
        for candidate in EMAIL_RE.findall(html.unescape(unquote(str(value or '')))):
            cleaned = clean_email_candidate(candidate)
            if cleaned:
                email_candidates.add(cleaned)
                email_evidence.setdefault(cleaned, source)
        for candidate in extract_obfuscated_emails(str(value or '')):
            email_candidates.add(candidate)
            email_evidence.setdefault(candidate, source)

    def add_phone(value, context='', source=page_url):
        cleaned = clean_phone_candidate(str(value or ''), context)
        if cleaned:
            phone_candidates.append((cleaned, context, source))
            phone_evidence.setdefault(cleaned, source)
            if re.search(r'(?i)whats\s*app|whatsapp|wa\.me|whats-app|chat\s+on\s+wa|contact\s+via\s+wa|wa\s+contact|聊\s*天\s*whatsapp|whatsapp\s*联系|通过\s*whatsapp| واتساب|whatsapp\s*销售|contato\s+whatsapp|contacto\s+whatsapp', context) and is_eligible_whatsapp_number(cleaned, allow_compact_international=True, country=country):
                # Normalize international dial-out prefix 00 to E.164 + form.
                wa_digits=re.sub(r'\D','',cleaned)
                if wa_digits.startswith('00'):
                    wa_digits=wa_digits[2:]
                canonical_wa='+'+wa_digits
                # Store only eligible explicitly labelled contacts; this is not proof of registration.
                whatsapp_contacts.add(canonical_wa)
                wa_evidence.setdefault(canonical_wa, source)

    # Schema.org structured public business information.
    for obj in iter_jsonld_objects(soup):
        for key in ('email', 'emailAddress'):
            value = obj.get(key)
            if isinstance(value, str):
                add_email(value)
        for key in ('telephone', 'phone', 'faxNumber'):
            value = obj.get(key)
            if isinstance(value, str):
                add_phone(value, f'{key} telephone contact')
        for key in ('url', 'sameAs'):
            value = obj.get(key)
            vals = value if isinstance(value, list) else [value]
            for link in vals:
                if isinstance(link, str) and re.match(r'https?://', link, re.I):
                    if re.search(r'(?:wa\.me/|(?:api\.)?whatsapp\.com/)', link, re.I):
                        add_whatsapp_url(link)
                    if 'linkedin.com/' in link.lower():
                        linkedin.add(link.split('?')[0].rstrip('/'))

    # Parse explicit anchors. tel: links retain phone context even when the number is digits-only.
    for a in soup.find_all('a', href=True):
        href_raw = html.unescape(a['href'].strip())
        href = urljoin(page_url, href_raw)
        host = (urlparse(href).hostname or '').lower()
        label = clean_text(' '.join([a.get_text(' ', strip=True), a.get('aria-label', ''), a.get('title', '')]))
        low = href.lower()
        if host == 'wa.me' or host == 'whatsapp.com' or host.endswith('.whatsapp.com'):
            add_whatsapp_url(href)
        if 'linkedin.com/' in low:
            linkedin.add(href.split('?')[0].rstrip('/'))
        if href_raw.lower().startswith('mailto:'):
            address = unquote(href_raw[7:].split('?')[0]).strip()
            add_email(address)
        if href_raw.lower().startswith('tel:'):
            add_phone(unquote(href_raw[4:]), 'tel link telephone contact ' + label)
        # If a phone number appears in a clearly labelled WhatsApp link's text, record it as a labelled contact.
        if re.search(r'(?i)whats\s*app|whatsapp|wa\.me|chat\s+on\s+wa|contact\s+via\s+wa|wa\s+contact|whatsapp\s*联系|通过\s*whatsapp|contato\s+whatsapp|contacto\s+whatsapp', label):
            for match in PHONE_RE.finditer(label):
                add_phone(match.group(0), 'WhatsApp label ' + label)

    # Inspect related attributes on the same element together. Many website widgets
    # store the WA flag and phone in sibling attributes (data-whatsapp + data-phone).
    # A phone is promoted only when the same element explicitly declares WhatsApp.
    for tag in soup.find_all(True):
        attrs = tag.attrs or {}
        attr_items = []
        for attr, value in attrs.items():
            values = value if isinstance(value, list) else [value]
            for item in values:
                if isinstance(item, str):
                    attr_items.append((str(attr).lower(), item))
        # Use only this element's own text, not all descendant text: otherwise a
        # WhatsApp label in a parent <body> could incorrectly promote every phone
        # number elsewhere on the page to WhatsApp.
        direct_text = clean_text(' '.join(str(x) for x in tag.find_all(string=True, recursive=False)))
        tag_context = ' '.join([str(tag.get('class') or ''), str(tag.get('id') or ''),
                                direct_text, ' '.join(k + ' ' + v for k, v in attr_items)]).lower()
        explicit_wa_element = bool(re.search(r'whats\s*app|whatsapp|wa\.me|whats-app|chat[-_ ]?on[-_ ]?wa|contact[-_ ]?via[-_ ]?wa', tag_context))
        for attr_low, item in attr_items:
            if attr_low in {'data-email', 'email', 'content', 'aria-label', 'title', 'alt', 'href'}:
                add_email(item)
            if attr_low in {'href', 'data-href', 'data-url', 'data-link', 'onclick', 'data-whatsapp', 'data-whatsapp-url'} or 'whatsapp' in attr_low:
                decoded_item = html.unescape(item).replace('\\/', '/').replace('\\u002f', '/').replace('\\u002F', '/')
                for wa_match in WA_RE.finditer(decoded_item):
                    add_whatsapp_url(wa_match.group(0))
            if any(k in attr_low for k in ('phone', 'telephone', 'mobile', 'whatsapp', 'fax', 'tel')):
                add_phone(item, f'{attr_low} contact attribute')
                if explicit_wa_element and any(k in attr_low for k in ('phone', 'telephone', 'mobile', 'tel')):
                    for match in PHONE_RE.finditer(item):
                        add_phone(match.group(0), f'WhatsApp element {attr_low} attribute')
            if 'whatsapp' in attr_low or 'whatsapp' in item.lower() or 'wa.me/' in item.lower():
                for match in PHONE_RE.finditer(item):
                    add_phone(match.group(0), f'WhatsApp {attr_low} attribute')
        if explicit_wa_element:
            for match in PHONE_RE.finditer(direct_text):
                add_phone(match.group(0), 'WhatsApp labelled element ' + tag.name)

    # Prefer paragraph/list/address blocks so an ISBN or ORCID elsewhere on the page does not
    # poison a legitimate nearby phone number's context.
    text_blocks = []
    for node in soup.find_all(['p', 'li', 'address', 'footer', 'header', 'td', 'dd']):
        block = clean_text(node.get_text(' ', strip=True))
        if block and block not in text_blocks:
            text_blocks.append(block)
    if not text_blocks:
        text_blocks = [text]
    for block in text_blocks:
        for match in PHONE_RE.finditer(block):
            context = phone_context_for_match(block, match.start(), match.end())
            add_phone(match.group(0), context)

    emails = {e for candidate in email_candidates if (e := clean_email_candidate(candidate))}
    for email in emails:
        email_evidence.setdefault(email, page_url)
    phones = set()
    for candidate, context, source in phone_candidates:
        cleaned = clean_phone_candidate(candidate, context)
        if cleaned:
            phones.add(cleaned)
            phone_evidence.setdefault(cleaned, source)
    phones, phone_evidence = deduplicate_phone_formats(phones, phone_evidence)
    whatsapp_contacts, normalized_wa_sources = deduplicate_phone_formats(whatsapp_contacts, wa_evidence)
    # WhatsApp numbers are displayed in one canonical international form (E.164
    # digits with a leading '+'), not a mixture of spaces, brackets and hyphens.
    whatsapp_contacts = sorted({'+' + re.sub(r'\D', '', str(x)) for x in whatsapp_contacts
                                if 9 <= len(re.sub(r'\D', '', str(x))) <= 15})
    # Preserve evidence under the same canonical number key used in exports/SQLite.
    wa_evidence = {k: v for k, v in wa_evidence.items() if str(k).startswith(('http://', 'https://'))}
    for raw_number, source_url in normalized_wa_sources.items():
        digits=re.sub(r'\D','',str(raw_number))
        if 9 <= len(digits) <= 15:
            wa_evidence['+'+digits]=source_url
    # Do not claim WhatsApp registration; these are only numbers explicitly labelled as WhatsApp.
    return {
        'whatsapp_links': sorted(wa_links),
        'whatsapp_contacts': whatsapp_contacts,
        'emails': sorted(emails),
        'phones': phones,
        'linkedin': sorted(linkedin),
        'email_evidence': email_evidence,
        'phone_evidence': phone_evidence,
        'whatsapp_evidence': wa_evidence,
    }


def extract_contacts(soup, page_url):
    """Compatibility wrapper: return the historical four contact lists."""
    details = extract_contact_evidence(soup, page_url)
    return details['whatsapp_links'], details['emails'], details['phones'], details['linkedin']


def load_robots_parser(session, base_url, deadline=None):
    """Read public robots.txt once for a site; if unavailable, do not bypass other access controls."""
    parsed_base=urlparse(normalize_url(base_url))
    robots_url=urlunparse((parsed_base.scheme, parsed_base.netloc, '/robots.txt', '', '', ''))
    try:
        if deadline is not None and time.monotonic() >= deadline:
            return False
        remaining=max(0.2, float(deadline-time.monotonic())) if deadline is not None else 5.0
        response=session.get(robots_url,headers={'User-Agent':USER_AGENT},timeout=(min(3.0,remaining), min(5.0,remaining)),allow_redirects=True)
        if response.status_code in (404, 410):
            parser=RobotFileParser(); parser.set_url(robots_url); parser.parse([]); return parser
        if response.status_code >= 400 or len(response.text or '') > 1_000_000:
            return False
        parser=RobotFileParser()
        parser.set_url(robots_url)
        parser.parse((response.text or '').splitlines())
        return parser
    except requests.RequestException:
        return False
    except Exception:
        return False


def robots_allows(parser, url):
    if parser is False:
        return False
    if parser is None:
        return True
    try:
        return bool(parser.can_fetch(USER_AGENT, url))
    except Exception:
        return False


def fetch_page(session, url, timeout=None, cancel_event=None, deadline=None):
    """Fetch a public page with bounded reads and preserve the exact failing stage."""
    if cancel_event is not None and cancel_event.is_set():
        return None, None, '任务已停止；尚未开始新的网页请求。'
    started = time.monotonic()
    total_deadline = min(started + 25.0, float(deadline)) if deadline is not None else started + 25.0
    if time.monotonic() >= total_deadline:
        return None, None, '站点总耗时预算已用完；未开始新的网页请求。'
    remaining=max(0.2,total_deadline-time.monotonic())
    request_timeout=timeout or TIMEOUT
    try:
        connect_timeout=float(request_timeout[0]) if isinstance(request_timeout,(tuple,list)) else float(request_timeout)
        read_timeout=float(request_timeout[1]) if isinstance(request_timeout,(tuple,list)) else float(request_timeout)
    except (TypeError,ValueError,IndexError):
        connect_timeout,read_timeout=4.0,8.0
    request_timeout=(max(0.2,min(connect_timeout,remaining)),max(0.2,min(read_timeout,remaining)))
    request_url = normalize_url(url)
    last_response = None
    stage = '建立 HTTPS/HTTP 连接'
    try:
        r = session.get(
            request_url,
            headers={
                'User-Agent': USER_AGENT,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.8,zh-CN;q=0.6',
                'Cache-Control': 'no-cache',
            },
            timeout=request_timeout, allow_redirects=True, stream=True
        )
        last_response = r
        stage = '读取网页响应正文'
        max_page_bytes=3*1024*1024
        content_length=r.headers.get('Content-Length')
        if content_length and str(content_length).isdigit() and int(content_length)>max_page_bytes:
            r.close()
            return None,r,'网页超过3 MB安全读取上限，已停止下载。'
        if isinstance(r, requests.Response):
            chunks=[]; total=0
            for chunk in r.iter_content(chunk_size=65536):
                if cancel_event is not None and cancel_event.is_set():
                    r.close()
                    return None, r, '任务已停止；已关闭当前网页响应。'
                # requests' read timeout is an inactivity timeout, not a total
                # download deadline. Enforce a wall-clock cap between chunks.
                if time.monotonic() > total_deadline:
                    r.close()
                    return None, r, '网页下载超过25秒总耗时上限，已停止读取。'
                if not chunk: continue
                total+=len(chunk)
                if total>max_page_bytes:
                    r.close()
                    return None,r,'网页超过3 MB安全读取上限，已停止下载。'
                chunks.append(chunk)
            if time.monotonic() > total_deadline:
                r.close()
                return None, r, '网页下载超过25秒总耗时上限，已停止读取。'
            r._content=b''.join(chunks); r._content_consumed=True
        stage = '检查 HTTP 状态、网页类型与访问限制'
        ct = (r.headers.get('Content-Type') or '').lower()
        current_encoding=getattr(r, 'encoding', None)
        if not current_encoding or str(current_encoding).lower() in ('iso-8859-1', 'ascii'):
            try:
                r.encoding = getattr(r, 'apparent_encoding', None) or 'utf-8'
            except Exception:
                pass
        body = (r.text or '').lstrip().lower()
        looks_html = ('html' in ct or body.startswith(('<!doctype html', '<html', '<?xml', '<!--')) or '<html' in body[:1200])
        restriction_markers = ('captcha', 'anomaly', 'verify you are human', 'unusual traffic', '机器人验证', '人机验证', '安全验证')
        if any(marker in body[:50000] for marker in restriction_markers):
            return None, r, '检测到验证码/异常访问验证页面；已停止解析，不尝试绕过访问控制。'
        if r.status_code in (401, 403, 407, 429):
            return None, r, f'HTTP {r.status_code}：网站要求登录、拒绝访问、代理认证或触发访问频率限制。'
        if r.status_code >= 400:
            return None, r, f'HTTP {r.status_code}：服务器返回错误。'
        if not looks_html:
            preview = re.sub(r'\s+', ' ', (r.text or '')[:180]).strip()
            return None, r, f'响应不是可识别的 HTML；Content-Type={ct or "（未提供）"}；响应片段={preview or "（空响应）"}'
        return BeautifulSoup(r.text, 'html.parser'), r, ''
    except requests.RequestException as e:
        detail = f'{type(e).__name__}: {str(e)[:260]}'
        response_detail = ''
        if last_response is not None:
            response_detail = (
                f"；已收到 HTTP {getattr(last_response, 'status_code', '?')}"
                f"；最终网址={getattr(last_response, 'url', request_url)}"
                f"；Content-Type={(getattr(last_response, 'headers', {}) or {}).get('Content-Type', '未知')}"
            )
        return None, last_response, f'{stage}失败：{detail}；请求网址={request_url}{response_detail}'
    except Exception as e:
        detail = f'{type(e).__name__}: {str(e)[:260]}'
        response_detail = ''
        if last_response is not None:
            response_detail = f"；已收到 HTTP {getattr(last_response, 'status_code', '?')}；最终网址={getattr(last_response, 'url', request_url)}"
        return None, last_response, f'{stage}异常：{detail}；请求网址={request_url}{response_detail}'


def score_site(pages, industry='', keywords=''):
    combined = ' '.join(clean_text(s.get_text(' ', strip=True)).lower() for _,s in pages)
    page_meta = ' '.join((url + ' ' + (s.title.get_text(' ', strip=True) if s.title else '')) for url, s in pages).lower()
    score = 0; hits=[]
    # Generic legal, publishing and identifier pages should not qualify as manufacturers.
    irrelevant_markers = {
        'teamviewer': -55, 'university': -35, 'college': -35, 'nursing': -35,
        'hospital': -35, 'accounting': -30, 'audit services': -35, 'financial index': -35,
        'software company': -35, 'saas platform': -35, 'marketing agency': -35,
        'privacy statement': -45, 'privacy policy': -45, 'cookie policy': -35,
        'terms of use': -35, 'terms and conditions': -30, 'isbn': -20,
        'orcid': -25, 'doi.org': -30, 'journal article': -30,
        'academic publisher': -30, 'book publisher': -30, 'elgaronline': -45,
        'job board': -30, 'careers': -18, 'news center': -18, 'blog': -12,
        'marketplace': -18, 'business directory': -25, 'supplier directory': -25,
        '企业黄页': -25, '供应商目录': -25, '行业资讯': -18, '新闻中心': -18,
        '人才招聘': -25, '招聘信息': -25, '教育培训': -18, '论坛': -12, '百科': -12,
    }
    for marker, penalty in irrelevant_markers.items():
        content_block_markers={'privacy statement','privacy policy','cookie policy','terms of use','elgaronline','job board','news center','business directory','supplier directory','企业黄页','供应商目录','行业资讯','新闻中心','人才招聘','招聘信息','教育培训','论坛','百科'}
        if marker in page_meta or (marker in combined and marker in content_block_markers):
            score += penalty; hits.append(f'无关页面信号:{marker}')
    for word, weight in MANUFACTURER_WORDS.items():
        n = combined.count(word)
        if n:
            score += min(weight*2, n*weight); hits.append(f'{word}×{n}')
    for word, weight in NEGATIVE_WORDS.items():
        n = combined.count(word)
        if n:
            score += max(-12, n*weight); hits.append(f'{word}×{n}')
    industry_l = (industry or '').lower().strip()
    if industry_l and industry_l in combined: score += 8; hits.append('行业名称命中')
    keyword_phrases = [x.strip().lower() for x in (keywords or '').split(';') if x.strip()]
    for kw in keyword_phrases:
        if len(kw) >= 4 and kw in combined:
            score += 3; hits.append(f'关键词:{kw}')
    # Product relevance is an industry-classification signal, not a prerequisite
    # for proving that a site is a manufacturer. Keep it separate from factory identity.
    stop = {'manufacturer','manufacturers','manufacturing','factory','factories','china','supplier','suppliers',
            'exporter','exporters','export','oem','odm','production','plant','plants','made','direct','company',
            'industrial','industry','products','product','and','for','with','the','from','parts','components',
            'small','home','supplier','wholesale','manufacturer china'}
    product_terms = set()
    for phrase in keyword_phrases + [industry_l]:
        for token in re.findall(r'[a-z]{3,}', phrase):
            if token not in stop and len(token) >= 4:
                product_terms.add(token.rstrip('s'))
        # Chinese industry/product phrases are meaningful without whitespace tokenization.
        # Strip generic manufacturing/export words first, then retain the core product phrase
        # and short contiguous n-grams so '家用电器及配套' can match '家用电器'.
        chinese_core=re.sub(r'制造商|生产厂家|厂家直供|源头工厂|自有工厂|制造厂|加工厂|工厂|厂家|制造|生产|供应商|出口商|出口|外贸|进出口|国际贸易|及配套|配套|OEM|ODM|中国', ' ', phrase, flags=re.I)
        for token in re.findall(r'[\u4e00-\u9fff]{2,}', chinese_core):
            product_terms.add(token)
            if len(token)>=4:
                product_terms.update(token[i:i+3] for i in range(len(token)-2))
    matched_terms = sorted(t for t in product_terms if t in combined or (t + 's') in combined)
    if matched_terms:
        bonus = min(18, 6 + 3 * len(matched_terms))
        score += bonus; hits.append('产品相关词命中:' + ', '.join(matched_terms[:8]))
    elif product_terms:
        # Missing a product token must not erase explicit factory evidence.
        # Industry relevance is checked independently and can mark the lead for review.
        hits.append('未找到明确产品相关词；制造商身份与行业匹配分开判断')
    if len(pages) >= 3: score += 5; hits.append('官网多页面可访问')
    hard_non_factory = ('teamviewer', 'university', 'college', 'nursing', 'hospital', 'accounting',
                        'audit services', 'financial index', 'software company', 'saas platform', 'marketing agency')
    if any(marker in page_meta for marker in ('privacy statement', 'privacy policy', 'terms of use', 'elgaronline', 'doi.org', 'journal article', *hard_non_factory)):
        score = min(score, 12)
    # Portal/service sites are not manufacturers even when article text mentions products.
    site_text = (page_meta + ' ' + combined)
    portal_hits = list(dict.fromkeys(m.group(0) for m in NON_MANUFACTURER_SITE_RE.finditer(site_text)))
    has_factory_proof = bool(FACTORY_PROOF_RE.search(combined))
    if portal_hits and not has_factory_proof:
        score = 0
        hits.append('网站类型排除：非制造业资讯/目录/服务门户（' + ', '.join(portal_hits[:4]) + '）')
    return max(0, min(100, score)), '；'.join(dict.fromkeys(hits))[:900]


def operation_signals(pages):
    """Score explicit export/international-sales evidence, not generic site activity."""
    combined = ' '.join(clean_text(s.get_text(' ', strip=True)).lower() for _,s in pages)
    strong = {
        'export sales': 18, 'exporter': 16, 'export department': 16,
        'international sales': 16, 'foreign trade': 18, 'import and export': 16,
        'overseas sales': 15, 'global sales': 12, 'export business': 16,
        '出口业务': 18, '出口部': 18, '外贸业务': 18, '外贸部': 18,
        '进出口业务': 18, '国际销售': 16, '海外销售': 15, '海外市场': 12,
        '国际贸易': 14, '出口产品': 12, '出口国家': 12,
    }
    moderate = {
        'export': 7, 'international business': 8, 'global market': 7,
        'overseas business': 9, 'international trade': 9,
        '出口': 7, '外贸': 8, '海外业务': 9, '国际业务': 8,
    }
    score=0; hits=[]
    for terms, weight in ((strong, 1), (moderate, 1)):
        for phrase, points in terms.items():
            if phrase in combined:
                score += points * weight
                hits.append(phrase)
    score = min(100, score)
    if score >= 30: status='存在明确外贸/出口信号'
    elif score >= 12: status='存在少量外贸信号，建议核验'
    else: status='未找到明确外贸证据'
    return score, status, ', '.join(hits)


STRONG_FACTORY_PROOF_RE = re.compile(
    r'\b(manufacturer|manufacturing|factory|factories|production line|production facility|own factory|producer|oem|odm)\b'
    r'|制造商|制造厂|生产厂|生产厂家|生产线|生产基地|生产企业|自有工厂|源头工厂|加工厂|工厂直销|厂家直供', re.I)


def persist_whatsapp_discoveries(result):
    """Persist explicitly evidenced WhatsApp contacts before any qualification gate."""
    if not isinstance(result, dict): return 0
    domain = root_domain(result.get('company_website') or '')
    unassigned = not domain and str(result.get('whatsapp_source_status') or '').find('待核验') >= 0
    if not domain and not unassigned: return 0
    if unassigned: domain = 'unassigned:whatsapp'
    evidence = result.get('contact_evidence') or {}
    rows = []
    for value in result.get('whatsapp_links') or []:
        source = (evidence.get('whatsapp_links') or {}).get(value) or result.get('source_url') or result.get('company_website') or ''
        proof = (result.get('evidence_notes') or {}).get(value) or ('搜索结果直达 WhatsApp；企业归属待核验' if unassigned else '官网公开 WhatsApp 链接')
        rows.append(('whatsapp_link', str(value), str(source), str(proof)))
    for value in result.get('whatsapp_contacts') or []:
        source = (evidence.get('whatsapp_contacts') or {}).get(value) or result.get('source_url') or result.get('company_website') or ''
        proof = (result.get('evidence_notes') or {}).get(value) or '网页明确标注 WhatsApp；号码注册状态未验证'
        rows.append(('whatsapp_labelled_number', str(value), str(source), str(proof)))
    # Remove duplicate observations within this one result before writing; each
    # remaining row is then guaranteed to be committed by the single transaction.
    rows = list(dict.fromkeys(rows))
    if not rows: return 0
    now = time.strftime('%Y-%m-%d %H:%M:%S')
    con = sqlite3.connect(DB_FILE, timeout=30)
    try:
        con.execute('PRAGMA busy_timeout=30000')
        con.execute("""CREATE TABLE IF NOT EXISTS whatsapp_discoveries (
            id INTEGER PRIMARY KEY AUTOINCREMENT, domain TEXT NOT NULL DEFAULT '',
            company_name TEXT NOT NULL DEFAULT '', website TEXT NOT NULL DEFAULT '',
            whatsapp_type TEXT NOT NULL, whatsapp_value TEXT NOT NULL,
            source_url TEXT NOT NULL DEFAULT '', evidence TEXT NOT NULL DEFAULT '',
            country TEXT NOT NULL DEFAULT '', industry TEXT NOT NULL DEFAULT '',
            first_seen TEXT NOT NULL, last_seen TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT '来源已记录',
            UNIQUE(domain, whatsapp_type, whatsapp_value, source_url))""")
        for kind, value, source, proof in rows:
            con.execute("""INSERT INTO whatsapp_discoveries
                (domain,company_name,website,whatsapp_type,whatsapp_value,source_url,evidence,country,industry,first_seen,last_seen,status)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(domain,whatsapp_type,whatsapp_value,source_url) DO UPDATE SET
                company_name=CASE WHEN excluded.company_name!='' THEN excluded.company_name ELSE whatsapp_discoveries.company_name END,
                last_seen=excluded.last_seen,evidence=excluded.evidence,status=excluded.status""",
                (domain, str(result.get('company_name') or result.get('page_title') or '')[:200],
                 str(result.get('company_website') or ''), kind, value, source, proof,
                 str(result.get('country') or ''), str(result.get('industry') or ''), now, now, str(result.get('whatsapp_source_status') or '来源已记录')))
        con.commit()
        return len(rows)
    finally: con.close()


def scan_whatsapp_discovery_sites(items, industry='', keywords='', country='中国', workers=3,
                                  cancel_event=None, scan_fn=None, persist_fn=None):
    """Scan ordinary sites once per registrable domain, but preserve each direct WA URL.

    Direct wa.me / WhatsApp links are already contact evidence: persist them immediately
    instead of attempting to fetch them as company websites. Ordinary websites remain
    domain-deduplicated to avoid redundant crawling.
    """
    scan_fn = scan_fn or scan_site
    persist_fn = persist_fn or persist_whatsapp_discoveries
    unique = []
    seen_sites = set()
    seen_wa = set()
    stats = {'sites_seen': 0, 'sites_scanned': 0, 'sites_failed': 0,
             'whatsapp_numbers_saved': 0, 'whatsapp_links_saved': 0,
             'direct_links_saved': 0, 'save_errors': 0}
    for item in items or []:
        if not item:
            continue
        url = str(item[0] if isinstance(item, (tuple, list)) else item).strip()
        if not url.startswith(('http://', 'https://')):
            continue
        title = str(item[1] if isinstance(item, (tuple, list)) and len(item) > 1 else '')
        parsed = urlparse(url)
        host = (parsed.hostname or '').lower()
        if host in ('wa.me', 'whatsapp.com') or host.endswith('.whatsapp.com'):
            direct = normalize_whatsapp_url(url)
            if not direct or not whatsapp_url_has_eligible_number(direct, country=country) or direct in seen_wa:
                continue
            seen_wa.add(direct)
            if cancel_event is not None and cancel_event.is_set():
                break
            direct_result = {
                'company_website': '', 'source_url': url, 'company_name': title[:200] or '搜索索引中的 WhatsApp 联系入口',
                'country': country, 'industry': industry,
                'whatsapp_links': [direct], 'whatsapp_contacts': [],
                'contact_evidence': {'whatsapp_links': {direct: url}, 'whatsapp_contacts': {}},
                'evidence_notes': {direct: '搜索结果直接指向公开 WhatsApp 入口；企业归属待核验'},
                'whatsapp_source_status': '企业归属待核验',
            }
            try:
                saved = persist_fn(direct_result)
                stats['direct_links_saved'] += int(saved or 0)
                stats['whatsapp_links_saved'] += int(bool(saved))
            except Exception:
                stats['save_errors'] += 1
            continue
        domain = root_domain(url)
        if not domain or domain in seen_sites:
            continue
        seen_sites.add(domain)
        unique.append((url, title))
    stats['sites_seen'] = len(unique)
    if not unique:
        return stats

    def scan_one(entry):
        url, _title = entry
        return scan_fn(url, industry, keywords, country, cancel_event=cancel_event)

    pool = ThreadPoolExecutor(max_workers=max(1, min(int(workers or 1), 3)))
    futures = {}
    try:
        for entry in unique:
            if cancel_event is not None and cancel_event.is_set():
                break
            future = pool.submit(scan_one, entry)
            futures[future] = entry
        for future in as_completed(futures):
            if future.cancelled():
                continue
            if cancel_event is not None and cancel_event.is_set():
                for pending in futures:
                    if not pending.running() and not pending.done(): pending.cancel()
            try:
                result = future.result()
                stats['sites_scanned'] += 1
            except Exception:
                stats['sites_failed'] += 1
                continue
            if str(result.get('status', '')).startswith(('访问失败', '访问受限')):
                stats['sites_failed'] += 1
            try:
                saved = int(persist_fn(result) or 0)
                if saved:
                    stats['whatsapp_links_saved'] += len(result.get('whatsapp_links') or [])
                    stats['whatsapp_numbers_saved'] += len(result.get('whatsapp_contacts') or [])
            except Exception:
                stats['save_errors'] += 1
    finally:
        # Drain running workers: scan_site observes cancellation and returns any
        # contacts already extracted, which must still be committed before the task ends.
        pool.shutdown(wait=True, cancel_futures=True)
    return stats


def has_reviewable_factory_evidence(result, minimum_score=14):
    """Identify explicit factory evidence for a review queue, independent of industry match."""
    if not isinstance(result, dict):
        return False
    score = int(result.get('manufacturer_score') or result.get('factory_authenticity_score') or 0)
    evidence = ' '.join(str(result.get(k) or '') for k in
                        ('manufacturer_evidence', 'manufacturer_evidence_items', 'factory_evidence_items'))
    return score >= int(minimum_score) and bool(FACTORY_PROOF_RE.search(evidence) or STRONG_FACTORY_PROOF_RE.search(evidence))


def is_manufacturer_candidate(result, min_manufacturer_score=25):
    """Identify a manufacturer independently of whether contact details were found.

    Contact discovery is a separate enrichment dimension: a real factory without a
    published email/WhatsApp must remain a manufacturer lead, not be discarded.
    """
    # Final task qualification still requires industry relevance; WhatsApp
    # evidence is persisted earlier and is never blocked by this predicate.
    if result.get('industry_relevance_status') and result.get('industry_relevance_status') != '匹配':
        return False
    manufacturer_score=int(result.get('manufacturer_score') or result.get('factory_authenticity_score') or 0)
    evidence=' '.join(str(result.get(k) or '') for k in ('manufacturer_evidence','manufacturer_evidence_items','factory_evidence_items'))
    strong_factory=bool(FACTORY_PROOF_RE.search(evidence))
    return strong_factory and manufacturer_score>=max(1,int(min_manufacturer_score))


def is_trade_contact_candidate(result, min_manufacturer_score=25):
    """Backward-compatible predicate for leads requiring both factory proof and contacts."""
    has_contact=bool(result.get('emails') or result.get('whatsapp_links') or result.get('whatsapp_contacts'))
    return has_contact and is_manufacturer_candidate(result,min_manufacturer_score)


def is_broad_discovery_candidate(result):
    """Only retain review candidates with concrete manufacturing evidence.

    Generic export words, a public email, or a product keyword alone are not
    sufficient to classify a website as a manufacturer.
    """
    if result.get('industry_relevance_status') and result.get('industry_relevance_status') != '匹配':
        return False
    if not is_displayable_company_name(result.get('company_name') or result.get('page_title') or ''):
        return False
    try:
        from data_quality import assess
        quality_status, _ = assess(result)
        if quality_status == 'excluded':
            return False
    except Exception:
        pass
    manufacturer_score=int(result.get('manufacturer_score') or result.get('factory_authenticity_score') or 0)
    # Only content/evidence extracted from the actual website may prove a factory.
    # Search-result titles and task labels are discovery metadata, not proof.
    evidence=' '.join(str(result.get(k) or '') for k in
        ('manufacturer_evidence','factory_evidence_items'))
    explicit_factory=bool(FACTORY_PROOF_RE.search(evidence))
    explicit_manufacturer_identity=bool(STRONG_FACTORY_PROOF_RE.search(evidence))
    # Explicit manufacturer/factory identity without detailed workshop evidence is a
    # review lead, not a confirmed factory. Keep it visible instead of silently losing it.
    return (explicit_factory and manufacturer_score >= 14) or (explicit_manufacturer_identity and manufacturer_score >= 18)


def scan_site(url, industry='', keywords='', country='', timeout=None, session=None, relevance_terms=None, cancel_event=None):
    url=normalize_url(url)
    result={'company_name':'','company_website':url,'industry_category':'','industry':industry,'keywords':keywords,'country':country,
            'page_title':'','company_address':'','address_source_url':'','industry_relevance_status':'待核验','industry_relevance_score':0,'industry_relevance_evidence':[],'industry_relevance_terms':list(relevance_terms or []),'manufacturer_score':0,'operation_score':0,'manufacturer_evidence':'','operation_evidence':'','factory_authenticity_score':0,'export_capability_score':0,'contact_evidence_score':0,'factory_evidence_items':[],'export_evidence_items':[],'contact_evidence_items':[],
            'whatsapp_links':[],'whatsapp_contacts':[],'emails':[],'email_details':[],'contact_evidence':{},'email_priority':'','decision_maker_evidence':'未发现可确认的公开负责人身份信息','gender_status':'未知/未核实','phone_candidates':[],'linkedin_links':[],'source_urls':[],'status':'','notes':'',
            'collected_at':time.strftime('%Y-%m-%d %H:%M:%S')}
    session=session or get_thread_http_session()
    site_deadline=time.monotonic()+90.0
    soup,r,diagnostic=fetch_page(session,url,timeout=timeout,cancel_event=cancel_event,deadline=site_deadline)
    if not soup:
        if cancel_event is not None and cancel_event.is_set():
            result['status']='任务已停止'; result['notes']=diagnostic or '收到停止信号。'; return result
        if r is not None:
            result['company_website']=r.url or url
            ct=(r.headers.get('Content-Type') or '（未提供）')
            restricted = (r.status_code in (401,403,407,429) or '验证码' in diagnostic or '异常访问验证' in diagnostic)
            if restricted:
                result['status']=f'访问受限 HTTP {r.status_code}'
            elif r.status_code >= 400:
                result['status']=f'访问失败 HTTP {r.status_code}'
            else:
                # HTTP 200 does not mean the complete body was downloaded or parsed.
                # Keep transport/body failures distinct from HTTP status failures.
                result['status']='访问失败/响应异常'
            result['notes']=f'原始网址：{url}；最终网址：{r.url}；HTTP：{r.status_code}；Content-Type：{ct}；诊断：{diagnostic}。未绕过验证码、登录、付费墙或访问限制。'
        else:
            result['status']='访问失败/连接异常'
            result['notes']=f'网址：{url}；诊断：{diagnostic or "未获取到 HTTP 响应"}。请检查网络、代理、DNS、证书或防火墙。'
        return result
    result['status']=f'HTTP {r.status_code}'; result['company_website']=site_root_url(r.url); result['source_urls']=[r.url]
    result['page_title']=clean_text(soup.title.get_text(' ',strip=True) if soup.title else '')[:300]
    initial_site_text=(result['page_title']+' '+clean_text(soup.get_text(' ',strip=True))[:12000])
    if NON_MANUFACTURER_SITE_RE.search(initial_site_text):
        result['site_type']='资讯/目录/旅游/无障碍等非制造业门户（待排除）'
    result['company_name']=(soup.find('meta',property='og:site_name') or {}).get('content','').strip() if soup.find('meta',property='og:site_name') else ''
    if not result['company_name']:
        result['company_name']=structured_company_name(soup)
    if not result['company_name']:
        title_parts=[clean_text(x) for x in re.split(r'\s*[|·–—]\s*|\s+-\s+',result['page_title']) if clean_text(x)]
        generic_titles={'home','homepage','welcome','welcome to our website','contact','contact us','about','about us','products','official website','index'}
        meaningful=[x for x in title_parts if x.lower() not in generic_titles]
        result['company_name']=(meaningful[0] if meaningful else (title_parts[0] if title_parts else ''))[:180]
    pages=[(r.url,soup)]; result['company_address']=extract_company_address(soup); result['address_source_url']=r.url if result['company_address'] else ''; wa=[]; wa_contacts=[]; emails=[]; phones=[]; linkedin=[]; email_sources={}; phone_sources={}; wa_sources={}

    def finalize_contact_fields():
        # Commit all contacts found so far, including on cooperative cancellation.
        result['whatsapp_links']=sorted(set(x for x in wa if normalize_whatsapp_url(x)))
        result['whatsapp_contacts']=sorted(set(wa_contacts))
        result['emails']=sorted(set(x.lower() for x in emails if clean_email_candidate(x)))[:50]
        result['source_urls']=list(dict.fromkeys([u for u,_ in pages]))
        result['email_details']=[]
        for email in result['emails']:
            detail=classify_email(email,email_sources.get(email,result['company_website']))
            detail['public_source_url']=email_sources.get(email,result['company_website'])
            result['email_details'].append(detail)
        result['email_details'].sort(key=lambda x:(-x['email_score'],x['email']))
        result['phone_candidates']=sorted(set(phones))[:40]
        result['linkedin_links']=sorted(set(linkedin))[:10]
        result['contact_evidence']={
            'emails':{e:email_sources.get(e,result['company_website']) for e in result['emails']},
            'phones':{p:phone_sources.get(p,result['company_website']) for p in result['phone_candidates']},
            'whatsapp_links':{w:wa_sources.get(w,result['company_website']) for w in result['whatsapp_links']},
            'whatsapp_contacts':{w:wa_sources.get(w,result['company_website']) for w in result['whatsapp_contacts']},
        }

    whatsapp_persistence_errors=[]
    def persist_partial_whatsapp():
        # Save contacts page-by-page so a later timeout/parse error cannot erase
        # already discovered WhatsApp evidence from the current website scan.
        if not wa and not wa_contacts:
            return
        snapshot={
            'company_website':result.get('company_website',''),
            'company_name':result.get('company_name',''),
            'country':country,'industry':industry,
            'whatsapp_links':sorted(set(wa)),
            'whatsapp_contacts':sorted(set(wa_contacts)),
            'contact_evidence':{
                'whatsapp_links':dict(wa_sources),
                'whatsapp_contacts':dict(wa_sources),
            },
        }
        try:
            persist_whatsapp_discoveries(snapshot)
        except Exception as exc:
            whatsapp_persistence_errors.append(f'WhatsApp线索即时保存失败：{type(exc).__name__}: {str(exc)[:120]}')

    if cancel_event is not None and cancel_event.is_set():
        result['status']='任务已停止'; result['notes']='收到停止信号；已结束当前官网核验。'; finalize_contact_fields(); return result
    robots_parser=load_robots_parser(session,r.url,deadline=site_deadline)
    contact=extract_contact_evidence(soup,r.url,country=country)
    wa+=contact['whatsapp_links']; wa_contacts+=contact['whatsapp_contacts']; emails+=contact['emails']; phones+=contact['phones']; linkedin+=contact['linkedin']
    email_sources.update(contact['email_evidence']); phone_sources.update(contact['phone_evidence']); wa_sources.update(contact['whatsapp_evidence'])
    persist_partial_whatsapp()
    links=[]
    link_priority_hint={}
    for a in soup.find_all('a',href=True):
        href=urljoin(r.url,a['href']); label=clean_text(a.get_text(' ',strip=True)).lower()
        aria=clean_text(a.get('aria-label','')).lower()
        key=(href.lower()+' '+label+' '+aria)
        if same_domain(r.url,href) and (any(k in key for k in CONTACT_PATHS) or re.search(r'whats\s*app|wa\.me|chat on wa|contact via wa', key, re.I)):
            clean_href=href.split('#')[0]
            links.append(clean_href)
            if any(k in key for k in ('联系我们','联络我们','联系方式','联系','contact')): link_priority_hint[clean_href]=min(link_priority_hint.get(clean_href,99),0)
            elif any(k in key for k in ('关于我们','公司简介','企业简介','about','company')): link_priority_hint[clean_href]=min(link_priority_hint.get(clean_href,99),1)
    # Add common contact-page routes as a fallback. Many Chinese factory sites use
    # Chinese navigation labels, JS menus, or omit contact links from the first HTML.
    # These are ordinary public pages; 404s are harmless and robots.txt is respected.
    fallback_contact_paths = [
        '/contact', '/contact-us', '/contactus', '/contact.html', '/contact-us.html',
        '/联系我们', '/联系我们.html', '/contact/index.html', '/about/contact',
        '/cn/contact', '/en/contact', '/contact.php', '/contact.asp',
        '/about-us/contact', '/company/contact', '/inquiry', '/inquiry.html',
    ]
    existing_paths = {urlparse(x).path.rstrip('/').lower() for x in links}
    for path in fallback_contact_paths:
        candidate = urljoin(r.url, path)
        if urlparse(candidate).path.rstrip('/').lower() not in existing_paths:
            links.append(candidate)
            existing_paths.add(urlparse(candidate).path.rstrip('/').lower())
    # Also look for sitemap.xml as a low-cost source of relevant internal pages.
    for href in [urljoin(r.url,'/sitemap.xml')]:
        if not robots_allows(robots_parser,href):
            continue
        try:
            if cancel_event is not None and cancel_event.is_set():
                result['status']='任务已停止'; result['notes']='收到停止信号；未继续读取网站地图。'; finalize_contact_fields(); return result
            remaining=site_deadline-time.monotonic()
            if remaining <= 0.2:
                result.setdefault('diagnostic_warnings', []).append('站点总耗时达到90秒；未继续读取Sitemap。')
                continue
            rr=session.get(href,headers={'User-Agent':USER_AGENT},timeout=(min(3.0,remaining),min(5.0,remaining)),stream=True)
            sitemap_limit=2*1024*1024
            if rr.headers.get('Content-Length','').isdigit() and int(rr.headers['Content-Length'])>sitemap_limit:
                rr.close(); continue
            if isinstance(rr, requests.Response):
                data=bytearray()
                for chunk in rr.iter_content(chunk_size=65536):
                    if cancel_event is not None and cancel_event.is_set():
                        rr.close(); result['status']='任务已停止'; result['notes']='收到停止信号；已关闭网站地图响应。'; finalize_contact_fields(); return result
                    if time.monotonic() >= site_deadline:
                        rr.close(); result.setdefault('diagnostic_warnings', []).append('站点总耗时达到90秒；Sitemap读取提前结束。'); break
                    if chunk:
                        data.extend(chunk)
                        if len(data)>sitemap_limit: break
                sitemap_text=data.decode(rr.encoding or 'utf-8',errors='replace')
            else: sitemap_text=rr.text or ''
            if rr.status_code < 400 and 'sitemap' in href and len(sitemap_text.encode('utf-8',errors='ignore'))<=sitemap_limit:
                for loc in re.findall(r'<loc>(.*?)</loc>', sitemap_text, re.I):
                    if same_domain(r.url,loc) and any(k in loc.lower() for k in CONTACT_PATHS): links.append(loc)
        except requests.RequestException as sitemap_exc:
            result.setdefault('diagnostic_warnings', []).append(f'Sitemap读取失败：{type(sitemap_exc).__name__}: {str(sitemap_exc)[:160]}')
        except Exception as sitemap_exc:
            result.setdefault('diagnostic_warnings', []).append(f'Sitemap处理异常：{type(sitemap_exc).__name__}: {str(sitemap_exc)[:160]}')
    def contact_priority(href):
        low=href.lower()
        if any(k in low for k in ('whatsapp','wa.me','chat-on-wa','contact-via-wa')): return -1
        if any(k in low for k in ('contact','联系我们','联络我们','联系方式','联系')): return 0
        if any(k in low for k in ('about','company','关于我们','公司简介','企业简介')): return 1
        if 'factory' in low or 'oem' in low or 'export' in low: return 2
        if 'products' in low: return 4
        return 3
    ordered_links=sorted(dict.fromkeys(links), key=lambda href: min(contact_priority(href),link_priority_hint.get(href,99)))
    for href in ordered_links[:MAX_SITE_PAGES-1]:
        if cancel_event is not None and cancel_event.is_set():
            result['status']='任务已停止'; result['notes']='收到停止信号；已结束当前官网核验。'; finalize_contact_fields(); return result
        if time.monotonic() >= site_deadline:
            result.setdefault('diagnostic_warnings', []).append('站点总耗时达到90秒；未继续访问后续联系页面。')
            break
        if same_domain(r.url,href) and href != r.url and robots_allows(robots_parser,href):
            s2,r2,diag2=fetch_page(session,href,timeout=timeout,cancel_event=cancel_event,deadline=site_deadline)
            if s2:
                pages.append((r2.url,s2));
                if not result.get('company_address'):
                    address_value=extract_company_address(s2)
                    if address_value: result['company_address']=address_value; result['address_source_url']=r2.url
                contact=extract_contact_evidence(s2,r2.url,country=country)
                wa+=contact['whatsapp_links']; wa_contacts+=contact['whatsapp_contacts']; emails+=contact['emails']; phones+=contact['phones']; linkedin+=contact['linkedin']
                for k,v in contact['email_evidence'].items(): email_sources.setdefault(k,v)
                for k,v in contact['phone_evidence'].items(): phone_sources.setdefault(k,v)
                for k,v in contact['whatsapp_evidence'].items(): wa_sources.setdefault(k,v)
                persist_partial_whatsapp()
                # Continue through the bounded page budget: WhatsApp buttons are often placed
                # on About/product pages even when Contact already yielded an email or phone.
    relevance_text=' '.join([result.get('page_title','')] + [clean_text(ps.get_text(' ', strip=True)) for _,ps in pages])
    active_relevance_terms=list(relevance_terms or build_relevance_terms({}, fallback_terms='; '.join(x for x in (industry, keywords) if x)))
    relevance_ok,relevance_score,relevance_hits=match_industry_relevance(relevance_text,active_relevance_terms)
    result['industry_relevance_status']='匹配' if relevance_ok else '不相关/未发现目标行业证据'
    result['industry_relevance_score']=relevance_score
    result['industry_relevance_evidence']=relevance_hits
    result['industry_relevance_terms']=active_relevance_terms
    result['manufacturer_score'],result['manufacturer_evidence']=score_site(pages,industry,keywords)
    result['operation_score'],op_status,result['operation_evidence']=operation_signals(pages)
    finalize_contact_fields()
    # Store independent evidence records with the exact public page URL that supports each score.
    combined_pages=[(u, clean_text(ps.get_text(' ', strip=True))) for u,ps in pages]
    factory_terms=('manufacturer','factory','production facility','production line','工厂','生产厂家','制造商','生产线','自有工厂','源头工厂')
    export_terms=('export','exporter','export sales','foreign trade','international trade','import and export','trading company','overseas business','international sales','global sales','出口','外贸','海外市场','出口业务','进出口','国际贸易','国际销售','外贸公司','进出口公司')
    result['factory_evidence_items']=[{'type':'factory','text':term,'source_url':u} for u,txt in combined_pages for term in factory_terms if term.lower() in txt.lower()][:80]
    result['export_evidence_items']=[{'type':'export','text':term,'source_url':u} for u,txt in combined_pages for term in export_terms if term.lower() in txt.lower()][:80]
    result['contact_evidence_items']=[{'type':'contact','text':kind+': '+value,'source_url':source}
        for kind,mapping in [('email',email_sources),('phone',phone_sources),('whatsapp',wa_sources)]
        for value,source in mapping.items() if source.startswith(('http://','https://'))][:120]
    scores=score_three_dimensions(result['factory_evidence_items'],result['export_evidence_items'],result['contact_evidence_items'])
    result.update(scores)
    result['score_evidence_sources']={
        'factory':sorted({x['source_url'] for x in result['factory_evidence_items']}),
        'export':sorted({x['source_url'] for x in result['export_evidence_items']}),
        'contact':sorted({x['source_url'] for x in result['contact_evidence_items']}),
    }
    result['email_priority'] = '；'.join(f"{d['email']}（{d['role_label']}，{d['email_score']}分）" for d in result['email_details'][:5])
    # Decision-maker evidence is evidence-only. Gender remains unknown unless an explicit, attributable public source supports it.
    combined_text = ' '.join(clean_text(ps.get_text(' ', strip=True)) for _, ps in pages)
    leadership_terms = ['founder', 'co-founder', 'chief executive officer', 'ceo', 'president', 'owner', 'executive director', 'managing director', 'general manager', 'export manager', 'foreign trade manager', 'international sales', 'overseas sales', 'sales director', 'sales manager', 'business development', 'sourcing manager', 'supply chain manager', 'export sales', 'foreign trade', '外贸经理', '出口经理', '国际销售', '海外业务', '销售总监', '业务经理', '供应链经理', '董事长', '总经理', '创始人']
    role_evidence=[]
    for page_url,page_soup in pages:
        page_text=clean_text(page_soup.get_text(' ',strip=True))
        page_low=page_text.lower()
        for term in leadership_terms:
            pos=page_low.find(term.lower())
            if pos>=0:
                excerpt=page_text[max(0,pos-65):min(len(page_text),pos+115)]
                role_evidence.append(f'{term}：{excerpt[:180]}（{page_url}）')
    if role_evidence:
        result['decision_maker_evidence'] = '公开网页职位/外贸业务证据：' + '；'.join(dict.fromkeys(role_evidence))[:1200] + '；姓名、职位归属及女性身份需人工核验。'
        result['notes']=(result.get('notes','')+' '+result['decision_maker_evidence']).strip()
    if result['whatsapp_links'] or result['whatsapp_contacts']: note='发现明确公开的 WhatsApp 链接或带 WhatsApp 标签的号码；标签号码不代表已验证 WhatsApp 注册状态。'
    else: note='未发现明确 WhatsApp 链接或带标签号码；普通电话不会被推断为 WhatsApp。'
    note += ' 邮箱按公开页面证据提取并分类；未进行 SMTP 探测或发送测试邮件。性别默认未知，不根据姓名/邮箱前缀推断。'
    result['notes']=note+' '+op_status+'。'
    if whatsapp_persistence_errors:
        result['notes'] += ' ' + '；'.join(dict.fromkeys(whatsapp_persistence_errors))
    if result.get('diagnostic_warnings'):
        result['notes'] += ' ' + '；'.join(result['diagnostic_warnings'])
    src=result['score_evidence_sources']
    result['notes'] += ' 评分证据来源网址：工厂真实性=' + ('; '.join(src['factory']) or '无') + '；出口能力=' + ('; '.join(src['export']) or '无') + '；联系人证据=' + ('; '.join(src['contact']) or '无')
    return result




def balance_candidate_items(items, query_context, limit=None):
    """Round-robin candidates by subindustry so early search results do not crowd out later industries."""
    groups={}
    for item in items:
        query=item[2] if len(item)>2 else ''
        context=(query_context or {}).get(query,{})
        group_key=context.get('industry') or query or 'unknown'
        groups.setdefault(group_key,[]).append(item)
    balanced=[]
    while any(groups.values()):
        for group in groups.values():
            if group:
                balanced.append(group.pop(0))
                if limit is not None and len(balanced)>=limit:
                    return balanced
    return balanced


def _parse_public_engine_results(provider, response, snippet_map=None, stage_stats=None):
    # Parse public result snippets without bypassing access controls.
    stage_stats = stage_stats if stage_stats is not None else {}
    soup=BeautifulSoup(response.text or '', 'html.parser')
    selectors={
        'Bing':'li.b_algo h2 a',
        'DuckDuckGo':'a.result__a, a[data-testid="result-title-a"]',
        'Baidu':'.result h3 a, .c-container h3 a, h3 a',
        'Ecosia':'a.result-title, a[data-test-id="result-title-link"], .result h2 a',
        'Yandex':'a.OrganicTitle-Link, .serp-item h2 a, h2 a',
        'Yahoo':'div.dd.algo h3 a, h3.title a, h3 a',
        'Mojeek':'a.ob, .results-standard a.ob, h2 a',
        'Startpage':'a.w-gl__result-title, a.result-link, h3 a',
        'Qwant':'.result h2 a, article h2 a, [data-testid*=\"result\"] h2 a, [class*=\"web-result\"] h2 a, [class*=\"result-item\"] h2 a',
    }
    anchors=soup.select(selectors.get(provider,'')) if provider in selectors else []
    stage_stats['matched_anchors'] = len(anchors)
    stage_stats['invalid_link_or_title'] = 0
    stage_stats['internal_search_links'] = 0
    rows=[]
    for a in anchors:
        href=(a.get('href') or '').strip(); title=a.get_text(' ',strip=True)
        parent = a.find_parent(['li','article','div'])
        snippet = clean_text(parent.get_text(' ', strip=True)) if parent else title
        if 'duckduckgo.com/l/?' in href:
            target=parse_qs(urlparse(href).query).get('uddg',[''])[0]
            href=unquote(target) if target else href
        if provider=='Bing' and 'bing.com/ck/a' in href:
            encoded=parse_qs(urlparse(href).query).get('u',[''])[0]
            if encoded.startswith('a1'):
                try:
                    payload=encoded[2:]
                    payload += '=' * (-len(payload) % 4)
                    decoded=base64.urlsafe_b64decode(payload.encode('ascii')).decode('utf-8','strict')
                    if decoded.startswith(('http://','https://')):
                        href=decoded
                except (ValueError,UnicodeError):
                    pass
        if provider=='Baidu' and 'baidu.com/link?' in href:
            continue
        if not href.startswith(('http://','https://')) or len(title)<2:
            stage_stats['invalid_link_or_title'] += 1
            continue
        host=(urlparse(href).hostname or '').lower()
        if not host or any(host==d or host.endswith('.'+d) for d in ('bing.com','duckduckgo.com','baidu.com','ecosia.org','yandex.com','google.com','search.yahoo.com','mojeek.com','startpage.com','qwant.com')):
            stage_stats['internal_search_links'] += 1
            continue
        rows.append((href,title))
        if snippet_map is not None:
            snippet_map[href] = snippet[:3000]
    # SearXNG is an optional self-hosted metasearch endpoint returning JSON.
    if provider=='SearXNG':
        try:
            payload=response.json()
            for item in payload.get('results',[]):
                href=str(item.get('url') or '').strip(); title=str(item.get('title') or '').strip()
                if href.startswith(('http://','https://')) and len(title)>=2:
                    rows.append((href,title))
                    if snippet_map is not None:
                        snippet_map[href] = clean_text(item.get('content') or item.get('snippet') or item.get('description') or title)[:3000]
        except Exception:
            pass
    if provider=='OpenSERP':
        try:
            payload=response.json(); items=payload.get('results') or payload.get('organic_results') or []
            for item in items:
                href=str(item.get('url') or item.get('link') or '').strip(); title=str(item.get('title') or '').strip()
                if href.startswith(('http://','https://')) and len(title)>=2:
                    rows.append((href,title))
                    if snippet_map is not None:
                        snippet_map[href] = clean_text(item.get('content') or item.get('snippet') or item.get('description') or title)[:3000]
        except Exception:
            pass
    stage_stats['parsed_rows'] = len(rows)
    return rows


_PUBLIC_SEARCH_MIN_INTERVAL = 0.75
_PUBLIC_SEARCH_PACE_LOCK = threading.Lock()
_PUBLIC_SEARCH_LAST_REQUEST_AT = 0.0


def _pace_public_search_request():
    """Apply a process-wide minimum interval between public search-engine requests."""
    global _PUBLIC_SEARCH_LAST_REQUEST_AT
    with _PUBLIC_SEARCH_PACE_LOCK:
        now = time.monotonic()
        wait_for = _PUBLIC_SEARCH_MIN_INTERVAL - (now - _PUBLIC_SEARCH_LAST_REQUEST_AT)
        if wait_for > 0:
            time.sleep(wait_for)
        _PUBLIC_SEARCH_LAST_REQUEST_AT = time.monotonic()


def _public_search_restriction(response):
    """Return a user-facing reason when a search engine presents an access challenge."""
    status = getattr(response, 'status_code', None)
    if status in (401, 403, 407, 429):
        return f'访问受限 HTTP {status}；已停止该搜索引擎请求，不尝试绕过限制。'
    body = (getattr(response, 'text', '') or '')[:60000].lower()
    markers = (
        'captcha', 'verify you are human', 'unusual traffic', 'automated requests',
        '机器人验证', '人机验证', '安全验证', '请输入验证码', '访问过于频繁',
    )
    if any(marker in body for marker in markers):
        return '检测到验证码或异常访问验证页面；已停止该搜索引擎请求，不尝试绕过限制。'
    return ''


def search_public_web(query, max_results=20, diagnostics=None, session=None, exclude_domains=None, exclude_company_names=None, allow_domains=None):
    """Bing-first search with Qwant as a controlled fallback; unstable engines are excluded."""
    diagnostics=diagnostics if diagnostics is not None else {}
    session=session or create_http_session()
    merged=[]; seen=set(); engine_map=diagnostics.setdefault('result_engine_map',{}); domain_engine_map=diagnostics.setdefault('domain_engine_map',{})
    pipeline = diagnostics.setdefault('search_pipeline', {})
    pipeline.setdefault('html_parsed', 0); pipeline.setdefault('historical_or_known', 0)
    pipeline.setdefault('social_or_directory', 0); pipeline.setdefault('duplicate_domain_or_url', 0)
    pipeline.setdefault('accepted_from_engines', 0); pipeline.setdefault('invalid_domain', 0); pipeline.setdefault('provider_limit_exceeded', 0)
    prior_domains={registry_domain_key(x) for x in (exclude_domains or set()) if x}
    prior_names={normalize_company_key(x) for x in (exclude_company_names or set()) if x}
    allowed_hosts={str(x).lower().strip('.') for x in (allow_domains or set())}
    # Deliberately keep the public search pool small. Historical performance
    # ranking must never promote disabled/unreliable providers into rotation.
    default_order=['Bing','Qwant']
    engine_order=['Bing','Qwant']
    diagnostics.setdefault('public_search',{})['engine_order']=engine_order
    endpoints={
        'Bing':('https://www.bing.com/search',{'q':query,'count':min(max_results,20)}),
        'Qwant':('https://www.qwant.com/',{'q':query}),
    }
    # Bing is primary; Qwant supplements it when Bing yields too few usable,
    # distinct company domains. Raw parse count alone is not a success metric.
    diagnostics.setdefault('public_search',{})['engine_order_for_query']=engine_order
    tried_engines=[]
    bing_usable_added=0
    fallback_threshold=max(1,min(3,int(max_results)))
    blocked_engines=diagnostics.setdefault('_blocked_public_engines',{})
    engine_failures=diagnostics.setdefault('_public_engine_failures',{})
    for provider in engine_order:
        if len(merged)>=max_results:
            break
        if provider == 'Qwant' and bing_usable_added >= fallback_threshold:
            diagnostics.setdefault('public_search',{})['fallback_reason']=(
                f'Bing 已提供 {bing_usable_added} 个不同且可用的企业域名，达到备用阈值 {fallback_threshold}'
            )
            break
        if provider in blocked_engines:
            continue
        tried_engines.append(provider)
        endpoint,params=endpoints[provider]
        state=diagnostics.setdefault('public_search',{}).setdefault(provider,{'status':'未尝试','results':0})
        try:
            _pace_public_search_request()
            response=session.get(endpoint,params=params,timeout=(4,7),headers={'Referer':'https://www.google.com/'})
            state['http_status']=getattr(response,'status_code',None)
            restriction_reason=_public_search_restriction(response)
            if restriction_reason:
                state['status']=restriction_reason
                blocked_engines[provider]=state['status']
                record_engine_search(DB_FILE,provider,0,True,state['status'])
                continue
            response.raise_for_status()
            snippets = diagnostics.setdefault('_search_snippets', {})
            parser_stats = {}
            parsed=_parse_public_engine_results(provider,response, snippet_map=snippets, stage_stats=parser_stats)
            public_diag=diagnostics.setdefault('public_search',{})
            public_diag['raw_parsed_results']=public_diag.get('raw_parsed_results',0)+len(parsed)
            pipeline['html_parsed'] += len(parsed)
            provider_stage = diagnostics.setdefault('search_pipeline_by_engine', {}).setdefault(provider, {})
            for key, value in parser_stats.items():
                provider_stage[key] = provider_stage.get(key, 0) + int(value or 0)
            state['sample_results']=[{'title':title,'url':href} for href,title in parsed[:5]]
            added=0
            usable_added=0
            for href,title in parsed:
                host=(urlparse(href).hostname or '').lower()
                host=host[4:] if host.startswith('www.') else host
                if not host:
                    pipeline['invalid_domain'] += 1
                    continue
                direct_whatsapp = host in ('wa.me', 'whatsapp.com') or host.endswith('.whatsapp.com')
                site_domain = registry_domain_key(root_domain(href))
                site_identity = canonicalize_contact(href).lower() if direct_whatsapp else site_domain
                if not site_identity: continue
                title_key=normalize_company_key(title)
                if not direct_whatsapp and (site_domain in prior_domains or (title_key and title_key in prior_names)):
                    diagnostics['_historical_or_known_results']=diagnostics.get('_historical_or_known_results',0)+1
                    pipeline['historical_or_known'] += 1
                    continue
                # Do not spend the backup engine on social profiles and generic
                # B2B marketplaces; they are not independent manufacturer websites.
                excluded_hosts=() if direct_whatsapp else tuple(d for d in (SOCIAL_DOMAINS + DIRECTORY_DOMAINS) if not any(d == a or d.endswith('.' + a) or a.endswith('.' + d) for a in allowed_hosts))
                if any(host == d or host.endswith('.' + d) for d in excluded_hosts):
                    diagnostics['_filtered_search_results']=diagnostics.get('_filtered_search_results',0)+1
                    pipeline['social_or_directory'] += 1
                    continue
                if added >= max_results:
                    pipeline['provider_limit_exceeded'] += 1
                    continue
                domain_key = registry_domain_key(root_domain(href)) if not direct_whatsapp else host
                domain_engine_map.setdefault(domain_key,[])
                if provider not in domain_engine_map[domain_key]: domain_engine_map[domain_key].append(provider)
                identity = site_identity
                if identity in seen:
                    diagnostics['_duplicate_search_results']=diagnostics.get('_duplicate_search_results',0)+1
                    pipeline['duplicate_domain_or_url'] += 1
                    continue
                seen.add(identity); merged.append((href,title)); engine_map[href]=provider; added+=1; usable_added+=1
                pipeline['accepted_from_engines'] += 1
            state['parsed_results']=len(parsed)
            state['results']=added
            state['usable_new_domains']=usable_added
            if provider == 'Bing':
                bing_usable_added=usable_added
            engine_failures[provider]=0
            state['status']=('成功' if added else ('页面可访问，解析到结果但筛选后没有新增网址' if parsed else '页面可访问但未解析到自然搜索结果'))
            # The performance table column is explicitly '解析结果数': persist the parser
            # output count, not the post-filter newly accepted domain count.
            record_engine_search(DB_FILE,provider,len(parsed),False,state['status'])
            if provider == 'Bing' and usable_added < fallback_threshold:
                diagnostics.setdefault('public_search',{})['fallback_reason']=(
                    f'Bing 仅产生 {usable_added} 个可用新域名，低于阈值 {fallback_threshold}，尝试 Qwant 补充'
                )
        except Exception as exc:
            state['status']=f'请求失败：{type(exc).__name__}'
            failures=int(engine_failures.get(provider,0) or 0)+1
            engine_failures[provider]=failures
            # A single transient timeout/connection error must not disable a useful
            # engine for the entire task. Pause only after repeated failures; explicit
            # HTTP restrictions/CAPTCHA are still blocked immediately above.
            if failures >= 2 or provider == 'Qwant':
                blocked_engines[provider]=state['status'] + '（本任务暂停该引擎后续请求）'
            else:
                state['status'] += '（暂时性失败；后续查询允许重试）'
            record_engine_search(DB_FILE,provider,0,True,state['status'])
    diagnostics.setdefault('public_search',{})['bing_usable_new_domains']=bing_usable_added
    diagnostics.setdefault('public_search',{})['fallback_threshold']=fallback_threshold
    diagnostics.setdefault('public_search',{})['returned_results']=len(merged)
    diagnostics.setdefault('public_search',{})['engines_tried_this_query']=tried_engines
    diagnostics.setdefault('public_search',{})['rotation_exhausted']=len(merged)<max_results
    return merged[:max_results]


def search_web(query, max_results=20, diagnostics=None, include_directories=False, session=None, search_mode='免费优先（手动控制付费）', exclude_domains=None, exclude_company_names=None, paid_call_limit=20, allow_domains=None):
    """Three explicit strategies: free-only, free-first, and paid-first.

    Historical company/domain exclusions are applied to both result streams before
    they are merged, so known companies never trigger a paid fallback request.
    """
    diagnostics = diagnostics if diagnostics is not None else {}
    session = session or create_http_session()
    mode = '免费优先（手动控制付费）' if search_mode is None else str(search_mode).strip()
    if mode == '免费优先（付费补漏）': mode = '免费优先（手动控制付费）'  # legacy setting; never auto-spend
    if mode not in ('仅免费搜索（不调用API）', '免费优先（手动控制付费）', '付费优先（免费补充）'):
        raise ValueError(f'不支持的搜索模式：{mode!r}；请明确选择仅免费、免费优先或付费优先。')
    orchestration = diagnostics.setdefault('provider_orchestration', {})
    orchestration['strategy'] = mode
    allowed_hosts={str(x).lower().strip('.') for x in (allow_domains or set())}
    excluded = set(d for d in (SOCIAL_DOMAINS + DIRECTORY_DOMAINS + ['google.com','baidu.com','bing.com','duckduckgo.com']) if not any(d == a or d.endswith('.' + a) or a.endswith('.' + d) for a in allowed_hosts))
    prior_domains={registry_domain_key(x) for x in (exclude_domains or set()) if x}
    prior_names={normalize_company_key(x) for x in (exclude_company_names or set()) if x}
    raw_candidate_cap=max_results*max(1,len(diagnostics.get('public_search',{}).get('engine_order',[])))
    def eligible(source_rows):
        accepted=[]; seen=set()
        filter_stats=diagnostics.setdefault('search_web_filter', {})
        for key in ('invalid_domain','duplicate_or_history','social_or_directory','accepted'): filter_stats.setdefault(key,0)
        for href,title in source_rows:
            domain=root_domain(href); domain_key=registry_domain_key(domain)
            name_key=normalize_company_key(title)
            if not domain:
                filter_stats['invalid_domain'] += 1
                continue
            host=(urlparse(href).hostname or '').lower()
            direct_whatsapp = host in ('wa.me', 'whatsapp.com') or host.endswith('.whatsapp.com')
            identity = canonicalize_contact(href).lower() if direct_whatsapp else domain_key
            if identity in seen or (not direct_whatsapp and domain_key in prior_domains) or (name_key and name_key in prior_names and not direct_whatsapp):
                diagnostics['_duplicate_search_results']=diagnostics.get('_duplicate_search_results',0)+1
                filter_stats['duplicate_or_history'] += 1
                continue
            if any(domain == d or domain.endswith('.' + d) for d in excluded):
                filter_stats['social_or_directory'] += 1
                continue
            seen.add(identity); accepted.append((href,title)); filter_stats['accepted'] += 1
        filter_stats['accepted_before_cap'] = len(accepted)
        filter_stats['candidate_cap_exceeded'] = max(0, len(accepted) - raw_candidate_cap)
        return accepted[:raw_candidate_cap]
    def paid_search(needed):
        if needed <= 0: return []
        keys=load_api_keys()
        if not (keys.get('serpapi') or keys.get('brave')):
            orchestration['status']='未配置付费 API；没有产生付费请求'
            return []
        engine='baidu' if re.search(r'[\u4e00-\u9fff]', query) else 'google'
        return eligible(search_providers(query, needed, diagnostics, DB_FILE, keys,
                         session=session, serpapi_engine=engine, paid_call_limit=paid_call_limit))
    rows=[]
    if mode == '付费优先（免费补充）':
        try: rows.extend(paid_search(max_results))
        except Exception as exc: orchestration['paid_error']=type(exc).__name__
        if len(rows)<max_results:
            rows.extend(x for x in eligible(search_public_web(query,max_results-len(rows),diagnostics,session=session,exclude_domains=exclude_domains,exclude_company_names=exclude_company_names)) if registry_domain_key(root_domain(x[0])) not in {registry_domain_key(root_domain(y[0])) for y in rows})
    else:
        rows=eligible(search_public_web(query,max_results,diagnostics,session=session,exclude_domains=exclude_domains,exclude_company_names=exclude_company_names,allow_domains=allow_domains))
        orchestration['free_results']=orchestration.get('free_results',0)+len(rows)
        if mode == '仅免费搜索（不调用API）':
            orchestration['status']='仅免费搜索模式：已禁止调用 SerpApi 和 Brave'
        elif mode == '免费优先（手动控制付费）':
            orchestration['status']='免费优先模式：本次仅使用免费搜索；如需付费搜索，请手动切换付费优先后重新启动任务'
            orchestration['paid_auto_fallback']=False
        else:
            orchestration['status']='免费搜索已满足本次候选数量；未调用付费 API'
    budget=diagnostics.get('_paid_search_budget',{})
    orchestration['paid_search_budget']={'limit':min(20,int(budget.get('limit',paid_call_limit))), 'used':int(budget.get('used',0)), 'remaining':max(0,min(20,int(budget.get('limit',paid_call_limit)))-int(budget.get('used',0)))}
    return rows[:raw_candidate_cap]


def search_linkedin_companies(query, max_results=12, diagnostics=None, session=None, search_mode='免费优先（手动控制付费）', paid_call_limit=20):
    """Discover public LinkedIn company pages with the same explicit paid strategy."""
    diagnostics = diagnostics if diagnostics is not None else {}
    q = query if 'site:linkedin.com/company' in query.lower() else f'site:linkedin.com/company {query}'
    session = session or create_http_session()
    mode='免费优先（手动控制付费）' if search_mode is None else str(search_mode).strip()
    if mode == '免费优先（付费补漏）': mode='免费优先（手动控制付费）'  # legacy setting; never auto-spend
    if mode not in ('仅免费搜索（不调用API）','免费优先（手动控制付费）','付费优先（免费补充）'):
        raise ValueError(f'不支持的 LinkedIn 搜索模式：{mode!r}；请明确选择仅免费、免费优先或付费优先。')
    def only_company_pages(rows):
        out=[]; seen=set()
        for url,title in rows:
            parsed=urlparse(url)
            if ((parsed.hostname or '').lower() == 'linkedin.com' or (parsed.hostname or '').lower().endswith('.linkedin.com')) and '/company/' in parsed.path.lower():
                clean=url.split('?')[0].rstrip('/')
                if clean not in seen: seen.add(clean); out.append((clean,title))
                if len(out)>=max_results: break
        return out
    rows=[]
    if mode=='付费优先（免费补充）':
        keys=load_api_keys()
        if keys.get('serpapi') or keys.get('brave'):
            engine='baidu' if re.search(r'[\u4e00-\u9fff]',q) else 'google'
            rows=only_company_pages(search_providers(q,max_results,diagnostics,DB_FILE,keys,session=session,serpapi_engine=engine,paid_call_limit=paid_call_limit))
        if len(rows)<max_results:
            existing={x[0] for x in rows}
            rows += [x for x in only_company_pages(search_public_web(q,max_results,diagnostics,session=session,allow_domains={'linkedin.com'})) if x[0] not in existing]
    else:
        rows=only_company_pages(search_public_web(q,max_results,diagnostics,session=session,allow_domains={'linkedin.com'}))
        if mode=='免费优先（手动控制付费）':
            diagnostics.setdefault('provider_orchestration',{})['linkedin_paid_auto_fallback']=False
    diag=diagnostics.setdefault('linkedin_company_search',{})
    diag['queries'] = diag.get('queries',0)+1
    diag['results'] = diag.get('results',0)+len(rows[:max_results])
    diag['successes'] = diag.get('successes',0)+int(bool(rows))
    diag['failures'] = diag.get('failures',0)+int(not bool(rows))
    diag['last_query'] = q[:180]
    tried=diagnostics.get('public_search',{}).get('engines_tried_this_query',[])
    engine_states=diagnostics.get('public_search',{})
    reasons=[]
    for engine in tried:
        state=engine_states.get(engine,{}) if isinstance(engine_states,dict) else {}
        status=str(state.get('status','')).strip()
        if status and status not in ('成功','页面可访问但未解析到自然搜索结果'):
            reasons.append(f'{engine}: {status}')
    diag['last_failure_reasons']=list(dict.fromkeys(reasons)) if not rows else []
    diag['failure_reasons']=list(dict.fromkeys((diag.get('failure_reasons',[]) or [])+diag['last_failure_reasons']))[-30:]
    if rows:
        diag['last_status']='命中公开 LinkedIn 企业主页'
    elif reasons:
        diag['last_status']='未命中；搜索引擎异常：'+'；'.join(reasons[:3])
    else:
        diag['last_status']='未命中可识别的公开企业主页（个人页/其他页面已过滤或搜索结果不足）'
    return [(title,url) for url,title in rows[:max_results]]


def search_linkedin_for_company_candidates(items, diagnostics=None, session=None, limit=20):
    """Search public index for LinkedIn company pages using each candidate's company title."""
    diagnostics = diagnostics if diagnostics is not None else {}
    session = session or create_http_session()
    found=[]; seen_urls=set(); seen_names=set()
    for item in list(items or [])[:max(0,int(limit))]:
        if not item: continue
        candidate_url=item[0] if len(item)>0 else ''
        candidate_title=clean_text(item[1] if len(item)>1 else '')
        if len(candidate_title)<3: continue
        normalized=re.sub(r'[^a-z0-9\u4e00-\u9fff ]+',' ',candidate_title.lower()).strip()
        if not normalized or normalized in seen_names: continue
        seen_names.add(normalized)
        domain=root_domain(candidate_url)
        query=f'site:linkedin.com/company "{candidate_title[:90]}"'
        if domain: query += f' "{domain}"'
        try:
            hits=search_public_web(query,max_results=4,diagnostics=diagnostics,session=session,allow_domains={'linkedin.com'})
            for url,title in hits:
                parsed=urlparse(url)
                if ((parsed.hostname or '').lower() == 'linkedin.com' or (parsed.hostname or '').lower().endswith('.linkedin.com')) and '/company/' in parsed.path.lower():
                    clean=url.split('?')[0].rstrip('/')
                    if clean not in seen_urls:
                        seen_urls.add(clean); found.append((clean_text(title),clean))
        except Exception as exc:
            diagnostics.setdefault('linkedin_company_search_errors',[]).append(type(exc).__name__)
    return found


def _normalize_search_query(query):
    return re.sub(r'\s+', ' ', re.sub(r'[^\w\u4e00-\u9fff]+', ' ', str(query or '').lower())).strip()


def _collapse_repeated_query_phrase(query):
    """Collapse an exact duplicated first/second half introduced by keyword composition."""
    raw=re.sub(r'\s+', ' ', str(query or '')).strip()
    words=raw.split(' ')
    if len(words)>=4 and len(words)%2==0:
        mid=len(words)//2
        if _normalize_search_query(' '.join(words[:mid])) == _normalize_search_query(' '.join(words[mid:])):
            return ' '.join(words[:mid])
    return raw


def build_linkedin_company_queries(manufacturer_queries, query_context=None, max_queries=3):
    """Build a small, deduplicated LinkedIn company search set from manufacturer queries only."""
    query_context=query_context or {}
    out=[]; seen=set()
    for raw in manufacturer_queries or []:
        q=_collapse_repeated_query_phrase(raw)
        ctx=query_context.get(raw,{})
        if ctx.get('search_intent') == 'women_trade_contacts':
            continue
        if not q:
            continue
        key=_normalize_search_query(q)
        if not key or key in seen:
            continue
        seen.add(key)
        out.append(q)
        if len(out)>=max(1,int(max_queries)):
            break
    return out


def build_people_queries(keywords, country='China', women_only=False):
    """Find public professional profiles using product- and country-bound queries only."""
    products=[_collapse_repeated_query_phrase(x.strip()) for x in (keywords or '').split(';') if x.strip()] or ['manufacturer']
    products=list(dict.fromkeys(products))[:3]
    queries=[]
    female='("female" OR "woman" OR "women" OR "woman owner" OR "female owner") '
    roles='("export manager" OR "foreign trade manager" OR "international sales" OR "overseas sales" OR "business development" OR founder OR CEO OR "general manager" OR director)'
    for product in products:
        gender_clause=female if women_only else ''
        queries.append(f'site:linkedin.com/in {gender_clause}{roles} (export OR exporter OR "foreign trade" OR "international trade") "{product}" {country}')
    return list(dict.fromkeys(queries))[:3]


def build_task_people_queries(config):
    """Only run optional LinkedIn people discovery when the user explicitly enables it."""
    config=config or {}
    if not bool(config.get('women_mode')):
        return []
    return build_people_queries(
        config.get('keywords','') or config.get('industry',''),
        config.get('country','China'),
        women_only=True,
    )


def build_trade_contact_queries(country='China'):
    """Cross-industry searches for women working in export/trade, not just factory owners."""
    return [
        f'(female OR woman OR women OR "she/her") ("export manager" OR "export sales" OR "foreign trade" OR "international sales" OR "overseas sales") {country} (WhatsApp OR email)',
        f'女性 ("外贸经理" OR "外贸业务" OR "国际销售" OR "出口业务" OR "海外业务") {country} (WhatsApp OR 邮箱)',
        f'(female OR woman OR women) ("international trade" OR "import export" OR exporter) ("sales manager" OR "export sales") China (WhatsApp OR email)',
        f'(female OR woman OR women) ("foreign trade company" OR "export company") China ("sales manager" OR "export sales") (contact OR email)',
        f'(female OR woman OR women) ("overseas business" OR "global sales") China (manager OR director) (contact OR email)',
    ]

def search_people_web(query, max_results=8, diagnostics=None, session=None, search_mode='免费优先（手动控制付费）'):
    """Find publicly indexed LinkedIn profiles free-first; no login or access-control bypass."""
    diagnostics=diagnostics if diagnostics is not None else {}
    session=session or create_http_session()

    def only_profiles(rows):
        out=[]; seen=set()
        for url,title in rows:
            if root_domain(url)!='linkedin.com' or '/in/' not in url.lower(): continue
            clean=url.split('?')[0].rstrip('/')
            if clean not in seen: seen.add(clean); out.append((clean,title))
            if len(out)>=max_results: break
        return out

    rows=only_profiles(search_public_web(query,max_results,diagnostics,session=session))
    # Supplementary person-profile searches obey the same manual paid-mode switch.
    if len(rows)<max_results and str(search_mode).strip()=='付费优先（免费补充）':
        try:
            keys=load_api_keys()
            if keys.get('serpapi') or keys.get('brave'):
                engine='baidu' if re.search(r'[\u4e00-\u9fff]',query) else 'google'
                rows += only_profiles(search_providers(query,max_results-len(rows),diagnostics,DB_FILE,keys,session=session,serpapi_engine=engine))
        except Exception as exc:
            diagnostics.setdefault('provider_orchestration',{})['people_error']=type(exc).__name__
    return [(title,url) for url,title in rows[:max_results]]


def save_lead(r):
    """Atomically upsert one company and append evidence without deleting history."""
    if not r.get('quality_status'):
        qstatus,qreason=assess(r)
        r['quality_status']=qstatus; r['quality_reason']=qreason
        r['quality_category']='制造商候选' if qstatus=='keep' else ('无关/隔离' if qstatus=='excluded' else '待人工复核')
    if not is_displayable_company_name(r.get('company_name','')):
        raise ValueError('企业名称为空或只是网址，拒绝写入制造商结果库')
    domain = root_domain(r.get('company_website', ''))
    if not domain:
        raise ValueError('企业官网域名为空，拒绝保存无稳定匹配键的企业记录')
    now = time.strftime('%Y-%m-%d %H:%M:%S')
    con = sqlite3.connect(DB_FILE, timeout=60)
    con.execute('PRAGMA busy_timeout=60000')
    try:
        con.execute('BEGIN IMMEDIATE')
        # Merge historical contacts/evidence before upsert; a later crawl must never erase older contacts.
        previous = con.execute('SELECT whatsapp,emails,phones,linkedin,sources,email_details,whatsapp_contacts,contact_evidence FROM leads WHERE domain=?', (domain,)).fetchone()
        if previous:
            for field, old_json in zip(('whatsapp_links','emails','phone_candidates','linkedin_links','source_urls','email_details','whatsapp_contacts'), previous[:7]):
                try: old_values = json.loads(old_json or '[]')
                except (TypeError, ValueError): old_values = []
                new_values = r.get(field, []) or []
                if field == 'email_details':
                    by_email = {str(x.get('email','')).lower(): x for x in old_values + new_values if isinstance(x,dict) and x.get('email')}
                    r[field] = list(by_email.values())
                else:
                    r[field] = list(dict.fromkeys(old_values + new_values))
            try: old_evidence = json.loads(previous[7] or '{}')
            except (TypeError, ValueError): old_evidence = {}
            merged_evidence = dict(old_evidence) if isinstance(old_evidence,dict) else {}
            for evidence_type, mapping in (r.get('contact_evidence',{}) or {}).items():
                if isinstance(mapping,dict):
                    combined = dict(merged_evidence.get(evidence_type,{}) or {})
                    combined.update(mapping); merged_evidence[evidence_type] = combined
            r['contact_evidence'] = merged_evidence
        con.execute('''INSERT INTO leads(domain,company_name,website,category,industry,country,score,operation_score,evidence,whatsapp,emails,phones,linkedin,sources,status,notes,collected_at,email_details,whatsapp_contacts,contact_evidence,decision_maker_evidence,gender_status,company_address,address_source_url,quality_status,quality_reason)
          VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
          ON CONFLICT(domain) DO UPDATE SET company_name=CASE WHEN excluded.company_name!='' THEN excluded.company_name ELSE leads.company_name END,website=CASE WHEN excluded.website!='' THEN excluded.website ELSE leads.website END,category=CASE WHEN excluded.category!='' THEN excluded.category ELSE leads.category END,
          industry=CASE WHEN excluded.industry!='' THEN excluded.industry ELSE leads.industry END,country=CASE WHEN excluded.country!='' THEN excluded.country ELSE leads.country END,score=MAX(leads.score,excluded.score),operation_score=MAX(leads.operation_score,excluded.operation_score),
          evidence=CASE WHEN excluded.evidence!='' THEN excluded.evidence ELSE leads.evidence END,whatsapp=CASE WHEN excluded.whatsapp NOT IN ('','[]','null') THEN excluded.whatsapp ELSE leads.whatsapp END,emails=CASE WHEN excluded.emails NOT IN ('','[]','null') THEN excluded.emails ELSE leads.emails END,phones=CASE WHEN excluded.phones NOT IN ('','[]','null') THEN excluded.phones ELSE leads.phones END,linkedin=CASE WHEN excluded.linkedin NOT IN ('','[]','null') THEN excluded.linkedin ELSE leads.linkedin END,
          sources=CASE WHEN excluded.sources NOT IN ('','[]','null') THEN excluded.sources ELSE leads.sources END,status=CASE WHEN excluded.status!='' THEN excluded.status ELSE leads.status END,notes=CASE WHEN excluded.notes!='' THEN CASE WHEN leads.notes='' THEN excluded.notes WHEN instr(leads.notes,excluded.notes)>0 THEN leads.notes ELSE leads.notes || '；' || excluded.notes END ELSE leads.notes END,collected_at=excluded.collected_at,email_details=CASE WHEN excluded.email_details NOT IN ('','[]','null') THEN excluded.email_details ELSE leads.email_details END,
          whatsapp_contacts=CASE WHEN excluded.whatsapp_contacts NOT IN ('','[]','null') THEN excluded.whatsapp_contacts ELSE leads.whatsapp_contacts END,contact_evidence=CASE WHEN excluded.contact_evidence NOT IN ('','{}','null') THEN excluded.contact_evidence ELSE leads.contact_evidence END,
          decision_maker_evidence=CASE WHEN excluded.decision_maker_evidence!='' THEN excluded.decision_maker_evidence ELSE leads.decision_maker_evidence END,gender_status=CASE WHEN excluded.gender_status NOT IN ('','未知/未核实','未知') THEN excluded.gender_status ELSE leads.gender_status END,company_address=CASE WHEN excluded.company_address!='' THEN excluded.company_address ELSE leads.company_address END,address_source_url=CASE WHEN excluded.address_source_url!='' THEN excluded.address_source_url ELSE leads.address_source_url END,quality_status=CASE WHEN leads.quality_status='keep' THEN 'keep' ELSE excluded.quality_status END,quality_reason=CASE WHEN excluded.quality_reason!='' THEN excluded.quality_reason ELSE leads.quality_reason END''',
          (domain,r.get('company_name',''),r.get('company_website',''),r.get('industry_category',''),r.get('industry',''),r.get('country',''),
           r.get('manufacturer_score',0),r.get('operation_score',0),r.get('manufacturer_evidence',''),json.dumps(r.get('whatsapp_links',[]),ensure_ascii=False),
           json.dumps(r.get('emails',[]),ensure_ascii=False),json.dumps(r.get('phone_candidates',[]),ensure_ascii=False),json.dumps(r.get('linkedin_links',[]),ensure_ascii=False),
           json.dumps(r.get('source_urls',[]),ensure_ascii=False),r.get('status',''),r.get('notes',''),r.get('collected_at',now),
           json.dumps(r.get('email_details',[]),ensure_ascii=False),json.dumps(r.get('whatsapp_contacts',[]),ensure_ascii=False),
           json.dumps(r.get('contact_evidence',{}),ensure_ascii=False),r.get('decision_maker_evidence',''),r.get('gender_status','未知/未核实'),r.get('company_address',''),r.get('address_source_url',''),r.get('quality_status','review'),r.get('quality_reason','')))
        registry_now = time.strftime('%Y-%m-%d %H:%M:%S')
        company_key = normalize_company_key(r.get('company_name',''))
        registry_status='collected' if r.get('quality_status')=='keep' else ('excluded' if r.get('quality_status')=='excluded' else 'review')
        con.execute('''INSERT INTO collection_registry(domain,normalized_name,company_name,website,first_seen,last_seen,seen_count,status,last_query,collected_at)
          VALUES(?,?,?,?,?,?,1,?,'',?) ON CONFLICT(domain) DO UPDATE SET
          normalized_name=CASE WHEN excluded.normalized_name!='' THEN excluded.normalized_name ELSE collection_registry.normalized_name END,
          company_name=CASE WHEN excluded.company_name!='' THEN excluded.company_name ELSE collection_registry.company_name END,
          website=CASE WHEN excluded.website!='' THEN excluded.website ELSE collection_registry.website END,
          last_seen=excluded.last_seen,status=CASE WHEN collection_registry.status='collected' THEN 'collected' ELSE excluded.status END,collected_at=excluded.collected_at''',
          (domain,company_key,r.get('company_name',''),r.get('company_website',''),registry_now,registry_now,registry_status,registry_now))
        scores=score_three_dimensions(r.get('factory_evidence_items',[]),r.get('export_evidence_items',[]),r.get('contact_evidence_items',[]))
        con.execute('UPDATE leads SET factory_authenticity_score=?,export_capability_score=?,contact_evidence_score=? WHERE domain=?',
          (scores['factory_authenticity_score'],scores['export_capability_score'],scores['contact_evidence_score'],domain))
        for kind,items in [('factory',r.get('factory_evidence_items',[])),('export',r.get('export_evidence_items',[])),('contact',r.get('contact_evidence_items',[]))]:
            for item in items or []:
                source=str(item.get('source_url','')).strip()
                if source.startswith(('http://','https://')):
                    observed=str(item.get('observed_at') or now); body=str(item.get('text',''))[:300]
                    con.execute('''INSERT INTO lead_evidence(domain,evidence_type,evidence_text,source_url,observed_at)
                      SELECT ?,?,?,?,? WHERE NOT EXISTS (SELECT 1 FROM lead_evidence WHERE domain=? AND evidence_type=? AND evidence_text=? AND source_url=? AND observed_at=?)''',
                      (domain,kind,body,source,observed,domain,kind,body,source,observed))
        ce=r.get('contact_evidence',{}) or {}; observed=str(r.get('collected_at') or now); contacts=[]
        for email in r.get('emails',[]) or []:
            source=(ce.get('emails',{}) or {}).get(email,'')
            detail=next((x for x in r.get('email_details',[]) if x.get('email')==email),{})
            validation={'format_valid':bool(EMAIL_RE.fullmatch(str(email))),'domain_match':detail.get('domain_match'),
              'mx_status':'未检查','third_party_status':'未检查','overall_status':'未核实','role':detail.get('role','unknown')}
            contacts.append(('email',email,email,source,'公开网页',observed,'未核实',validation))
        for link in r.get('whatsapp_links',[]) or []:
            source=(ce.get('whatsapp_links',{}) or {}).get(link,'')
            contacts.append(('whatsapp_link',link,link,source,'官网',observed,'官网明确展示 WhatsApp 链接',{}))
        for number in r.get('whatsapp_contacts',[]) or []:
            source=(ce.get('whatsapp_contacts',{}) or {}).get(number,'')
            contacts.append(('whatsapp_labelled_number',number,number,source,'官网',observed,'官网有 WhatsApp 标签；注册状态未确认',{}))
        for number in r.get('phone_candidates',[]) or []:
            if number not in (r.get('whatsapp_contacts',[]) or []):
                source=(ce.get('phones',{}) or {}).get(number,'')
                contacts.append(('phone',number,number,source,'官网',observed,'仅普通电话号码',{}))
        for ctype,value,raw,source,channel,seen,status,validation in contacts:
            if ctype == 'email': normalized_value = str(value).strip().lower()
            elif ctype in ('phone','whatsapp_labelled_number'): normalized_value = re.sub(r'\D','',str(value))
            else: normalized_value = str(value).strip().lower().rstrip('/')
            if normalized_value:
                con.execute("""INSERT INTO contact_registry(domain,contact_type,normalized_value,raw_value,first_seen,last_seen,source_url,evidence_count,status)
                    VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(domain,contact_type,normalized_value) DO UPDATE SET
                    raw_value=CASE WHEN excluded.raw_value!='' THEN excluded.raw_value ELSE contact_registry.raw_value END,
                    last_seen=excluded.last_seen,source_url=CASE WHEN excluded.source_url!='' THEN excluded.source_url ELSE contact_registry.source_url END,
                    evidence_count=contact_registry.evidence_count+1,status=excluded.status""",
                    (domain,ctype,normalized_value,str(raw),seen,seen,str(source or ''),1,str(status)))
            if str(source).startswith(('http://','https://')):
                con.execute("""INSERT INTO lead_contact_evidence(domain,contact_type,contact_value,raw_value,source_url,source_channel,observed_at,status,validation_json)
                  SELECT ?,?,?,?,?,?,?,?,? WHERE NOT EXISTS (SELECT 1 FROM lead_contact_evidence WHERE domain=? AND contact_type=? AND contact_value=? AND source_url=? AND observed_at=?)""",
                  (domain,ctype,str(value),str(raw),str(source),channel,seen,status,json.dumps(validation,ensure_ascii=False),domain,ctype,str(value),str(source),seen))
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()
    # Append this task's own industry-classified snapshot to the separate history archive.
    archive_task_id = getattr(_ACTIVE_COLLECTION_TASK, 'task_id', '')
    if archive_task_id:
        try:
            row_snapshot = dict(r)
            task_meta = getattr(_ACTIVE_COLLECTION_TASK, 'meta', {}) or {}
            row_snapshot['industry_category'] = row_snapshot.get('industry_category') or task_meta.get('category', '')
            row_snapshot['industry'] = row_snapshot.get('industry') or task_meta.get('industry', '')
            row_snapshot['country'] = row_snapshot.get('country') or task_meta.get('country', '')
            row_snapshot['collection_task_id'] = archive_task_id
            history_store.record_lead(HISTORY_ARCHIVE_FILE, archive_task_id, row_snapshot)
        except Exception as archive_exc:
            try:
                with open(os.path.join(USER_DATA_DIR, 'history_archive_error.log'), 'a', encoding='utf-8') as _hf:
                    _hf.write(time.strftime('%Y-%m-%d %H:%M:%S') + ' archive ' + repr(archive_exc) + '\n')
            except Exception:
                pass
    # Commit global identity only after the lead transaction succeeded.
    # Only confirmed manufacturer rows become permanent skips; review rows
    # remain retryable after the configured cooldown.
    try:
        if r.get('quality_status') == 'keep':
            GLOBAL_DEDUP.mark_collected(domain, r.get('company_name',''), r.get('company_website',''),
                                        industry=r.get('industry_category') or r.get('industry',''),
                                        source_url=(r.get('source_urls') or [r.get('company_website','')])[0],
                                        country=r.get('country',''),emails=r.get('emails',[]),
                                        phones=r.get('phone_candidates',[]))
        else:
            GLOBAL_DEDUP.record(domain,r.get('company_name',''),r.get('company_website',''),'review',
                                industry=r.get('industry_category') or r.get('industry',''),
                                source_url=(r.get('source_urls') or [r.get('company_website','')])[0],
                                reason=r.get('quality_reason','待人工复核'))
    except Exception as dedup_exc:
        try:
            with open(os.path.join(USER_DATA_DIR,'global_dedup_sync_error.log'),'a',encoding='utf-8') as _gf:
                _gf.write(time.strftime('%Y-%m-%d %H:%M:%S')+' '+domain+' '+repr(dedup_exc)+'\n')
        except OSError:
            pass



def load_saved_leads():
    rows=[]
    con=None
    try:
        con=sqlite3.connect(DB_FILE, timeout=60)
        con.execute('PRAGMA busy_timeout=60000')
        cur=con.execute('SELECT company_name,website,category,industry,country,score,operation_score,evidence,whatsapp,emails,phones,linkedin,sources,status,notes,collected_at,email_details,whatsapp_contacts,contact_evidence,decision_maker_evidence,gender_status,company_address,address_source_url,quality_status,quality_reason FROM leads ORDER BY id DESC')
        for rec in cur.fetchall():
            (company,website,category,industry,country,score,op,evidence,wa,emails,phones,linkedin,sources,status,notes,collected,email_details,wa_contacts,contact_evidence,dm,gender,company_address,address_source_url,quality_status,quality_reason)=rec
            if not is_displayable_company_name(company) or str(quality_status or '').lower()=='excluded':
                continue
            def parsed_json(v, expected_type, fallback):
                """Parse one stored JSON field without letting a malformed legacy value hide every lead."""
                if not v:
                    return fallback
                try:
                    value = json.loads(v)
                    return value if isinstance(value, expected_type) else fallback
                except (TypeError, ValueError, json.JSONDecodeError):
                    return fallback
            rows.append({'company_name':company or '', 'company_website':website or '', 'industry_category':category or '', 'industry':industry or '', 'keywords':'', 'country':country or '',
                         'manufacturer_score':score or 0,'operation_score':op or 0,'manufacturer_evidence':evidence or '','operation_evidence':'',
                         'whatsapp_links':parsed_json(wa, list, []),
                          'whatsapp_contacts':list(dict.fromkeys(filter(None, (normalize_whatsapp_number_display(x, country=country or '中国') for x in parsed_json(wa_contacts, list, []))))),'contact_evidence':parsed_json(contact_evidence, dict, {}),'emails':parsed_json(emails, list, []),'phone_candidates':parsed_json(phones, list, []),'linkedin_links':parsed_json(linkedin, list, []),'source_urls':parsed_json(sources, list, []),
                         'status':status or '','notes':notes or '','collected_at':collected or '', 'email_details':parsed_json(email_details, list, []),
                         'email_priority':'','decision_maker_evidence':dm or '','gender_status':gender or '未知/未核实','company_address':company_address or '', 'address_source_url':address_source_url or '', 'quality_status':quality_status or 'review', 'quality_reason':quality_reason or ''})
        cur=con.execute('SELECT domain,factory_authenticity_score,export_capability_score,contact_evidence_score FROM leads')
        score_map={row[0]:row[1:] for row in cur.fetchall()}
        evidence_by_domain={}
        try:
            for erow in con.execute('SELECT domain,evidence_type,evidence_text,source_url FROM lead_evidence').fetchall():
                evidence_by_domain.setdefault(erow[0],[]).append(erow[1:])
        except sqlite3.Error:
            evidence_by_domain={}
        for item in rows:
            domain=root_domain(item.get('company_website',''))
            vals=score_map.get(domain,(0,0,0))
            item['factory_authenticity_score'],item['export_capability_score'],item['contact_evidence_score']=vals
            evidence_rows=evidence_by_domain.get(domain,[])
            item['factory_evidence_items']=[{'type':'factory','text':t,'source_url':u} for k,t,u in evidence_rows if k=='factory']
            item['export_evidence_items']=[{'type':'export','text':t,'source_url':u} for k,t,u in evidence_rows if k=='export']
            item['contact_evidence_items']=[{'type':'contact','text':t,'source_url':u} for k,t,u in evidence_rows if k=='contact']
            item['score_evidence_sources']={
                'factory':sorted({u for k,t,u in evidence_rows if k=='factory'}),
                'export':sorted({u for k,t,u in evidence_rows if k=='export'}),
                'contact':sorted({u for k,t,u in evidence_rows if k=='contact'}),
            }
            if any(item['score_evidence_sources'].values()):
                src=item['score_evidence_sources']
                if '评分证据来源网址：' not in item['notes']:
                    item['notes'] += ' 评分证据来源网址：工厂真实性=' + ('; '.join(src['factory']) or '无') + '；出口能力=' + ('; '.join(src['export']) or '无') + '；联系人证据=' + ('; '.join(src['contact']) or '无')
    except Exception as exc:
        # Keep rows already recovered and record a safe diagnostic instead of
        # silently presenting a populated database as an empty one.
        try:
            with open(os.path.join(USER_DATA_DIR,'factorylead_error.log'),'a',encoding='utf-8') as log:
                log.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] load_saved_leads: {type(exc).__name__}: {str(exc)[:300]}\n")
        except OSError:
            pass
    finally:
        if con is not None:
            try: con.close()
            except sqlite3.Error: pass
    return rows


def _split_import_values(value):
    return list(dict.fromkeys(x.strip() for x in re.split(r"[;\n；、]+", str(value or "")) if x.strip()))


def import_legacy_xlsx_to_database(file_path):
    """Import a prior WaiMaoDaRen export into the persistent DB without inventing evidence."""
    try:
        from openpyxl import load_workbook
    except ImportError as exc:
        raise RuntimeError("缺少 openpyxl，无法导入 Excel") from exc
    wb = load_workbook(file_path, read_only=True, data_only=True)
    ws = wb.active
    headers = [str(c.value or "").strip() for c in ws[1]]
    index = {name: i for i, name in enumerate(headers)}
    aliases = {
        "company": ("公司名称", "工厂/公司名称", "企业名称"),
        "website": ("官方网站", "官网", "公司网站"),
        "address": ("公司地址", "地址"),
        "address_source": ("地址来源网址", "地址来源"),
        "wa_number": ("WhatsApp号码（明确标注）", "WhatsApp号码", "WhatsApp号码（明确信息）"),
        "wa_number_source": ("WhatsApp号码证据网址", "WhatsApp号码来源网址"),
        "wa_link": ("WhatsApp联系链接", "WhatsApp链接"),
        "wa_link_source": ("WhatsApp链接证据网址", "WhatsApp联系链接来源"),
        "email": ("公开邮箱", "邮箱"),
        "phone": ("公开电话（非WhatsApp）", "公开电话", "普通电话"),
        "linkedin": ("LinkedIn企业主页", "LinkedIn"),
        "source": ("采集来源网址", "来源网址"),
        "status": ("访问/核验状态", "核验状态", "状态"),
        "category": ("行业大类", "行业分类", "制造商分类", "企业分类"),
        "industry": ("细分行业", "行业", "制造业细分"),
        "country": ("目标国家", "国家", "地区"),
        "notes": ("核验说明", "备注"),
        "collected": ("采集时间", "发现时间"),
    }
    col = {key: next((index[n] for n in names if n in index), None) for key, names in aliases.items()}
    def get(row, key):
        i = col.get(key)
        return row[i] if i is not None and i < len(row) else ""
    imported = updated = skipped = 0
    imported_rows = []
    try:
        for values in ws.iter_rows(min_row=2, values_only=True):
            company = str(get(values, "company") or "").strip()
            website = normalize_url(str(get(values, "website") or "").strip())
            if not company or not root_domain(website):
                skipped += 1
                continue
            wa_numbers = list(dict.fromkeys(
                cleaned for raw_number in _split_import_values(get(values, "wa_number"))
                if (cleaned := clean_phone_candidate(raw_number, "WhatsApp")) and
                   is_eligible_whatsapp_number(cleaned, allow_compact_international=True, country=str(get(values, 'country') or '中国'))
            ))
            wa_links = [x for x in _split_import_values(get(values, "wa_link")) if normalize_whatsapp_url(x)]
            emails = [x.lower() for x in _split_import_values(get(values, "email")) if clean_email_candidate(x)]
            phones = _split_import_values(get(values, "phone"))
            linkedin = [x for x in _split_import_values(get(values, "linkedin")) if 'linkedin.com/' in x.lower()]
            address = str(get(values, "address") or "").strip()
            address_source = str(get(values, "address_source") or "").strip()
            wa_num_source = str(get(values, "wa_number_source") or "").strip()
            wa_link_source = str(get(values, "wa_link_source") or "").strip()
            contact_evidence = {
                "emails": {x: "" for x in emails}, "phones": {x: "" for x in phones},
                "whatsapp_contacts": {x: wa_num_source for x in wa_numbers},
                "whatsapp_links": {x: wa_link_source for x in wa_links},
            }
            row = {
                "company_name": company, "company_website": website,
                "industry_category": str(get(values, "category") or "历史导入"),
                "industry": str(get(values, "industry") or ""), "country": str(get(values, "country") or "China"), "manufacturer_score": 0,
                "operation_score": 0, "manufacturer_evidence": "",
                "whatsapp_links": wa_links, "whatsapp_contacts": wa_numbers,
                "emails": emails, "phone_candidates": phones, "linkedin_links": linkedin,
                "source_urls": _split_import_values(get(values, "source")),
                "status": str(get(values, "status") or "历史资料导入，待复核"),
                "notes": (str(get(values, "notes") or "") + "；历史 Excel 导入；原文件未提供的单项证据网址不会自动补造").strip("；"),
                "collected_at": str(get(values, "collected") or time.strftime("%Y-%m-%d")),
                "email_details": [], "contact_evidence": contact_evidence,
                "decision_maker_evidence": "", "gender_status": "未知/未核实",
                "company_address": address, "address_source_url": address_source,
            }
            con = sqlite3.connect(DB_FILE, timeout=60)
            try:
                existed = con.execute("SELECT 1 FROM leads WHERE domain=?", (root_domain(website),)).fetchone() is not None
            finally:
                con.close()
            save_lead(row)
            imported_rows.append(row)
            if existed: updated += 1
            else: imported += 1
    finally:
        wb.close()
    return {"imported": imported, "updated": updated, "skipped": skipped, "rows": imported_rows}


SEARCH_MODE_OPTIONS = ('仅免费搜索（不调用API）','免费优先（手动控制付费）','付费优先（免费补充）')
SEARCH_MODE_FILE = os.path.join(USER_DATA_DIR, 'search_mode.json')

def load_search_mode_setting():
    try:
        with open(SEARCH_MODE_FILE,encoding='utf-8') as f:
            value=str(json.load(f).get('search_mode','')).strip()
        if value == '免费优先（付费补漏）': value='免费优先（手动控制付费）'
        return value if value in SEARCH_MODE_OPTIONS else '免费优先（手动控制付费）'
    except Exception:
        return '免费优先（手动控制付费）'


def safe_spreadsheet_cell(value):
    """Neutralize spreadsheet formula prefixes in untrusted scraped text."""
    text_value=str(value or '')
    if re.match(r'^\s*[=+\-@]', text_value) or text_value.startswith(('\t','\r','\n')):
        return "'" + text_value
    return text_value


def build_review_candidate(item, reason, context=None, status='待核验'):
    """Create a transparent review-only lead from a search result when a site cannot be verified."""
    href = str(item[0] if len(item) > 0 else '').strip()
    title = clean_text(str(item[1] if len(item) > 1 else ''))[:180]
    query = str(item[2] if len(item) > 2 else '')
    if not href.startswith(('http://', 'https://')) or not is_displayable_company_name(title):
        return None
    context = context or {}
    source_urls = [href]
    if len(item) > 3 and str(item[3]).startswith(('http://', 'https://')):
        source_urls.append(str(item[3]))
    return {
        'company_name': title,
        'company_website': site_root_url(href),
        'industry_category': context.get('category', ''),
        'industry': context.get('industry', ''),
        'keywords': context.get('keywords', ''),
        'country': context.get('country', '中国'),
        'manufacturer_score': 0,
        'operation_score': 0,
        'manufacturer_evidence': '',
        'operation_evidence': '',
        'whatsapp_links': [], 'whatsapp_contacts': [], 'emails': [],
        'phone_candidates': [], 'linkedin_links': [],
        'source_urls': list(dict.fromkeys(source_urls)),
        'status': status,
        'quality_status': 'review',
        'quality_category': '潜在供应商/待人工核验',
        'quality_reason': reason,
        'notes': f'搜索发现候选：{title}；原始搜索词：{query}；官网核验状态：{status}；{reason}。本条仅为待核验线索，不代表已确认制造商；未发现联系方式不代表企业没有联系方式。',
        'contact_evidence': {},
        'collected_at': time.strftime('%Y-%m-%d %H:%M:%S'),
    }


def persist_review_candidate(item, reason, context=None, status='待核验', persist_lead=True):
    """Persist a candidate row without treating a network failure as a permanent exclusion."""
    row = build_review_candidate(item, reason, context=context, status=status)
    if not row:
        return None
    try:
        if persist_lead:
            save_lead(row)
        record_registry_candidate(root_domain(row['company_website']), row['company_name'],
                                  row['company_website'], str(item[2] if len(item) > 2 else ''),
                                  status='review', reason=reason)
        return row
    except Exception:
        return None


class App(tk.Tk):
    def __init__(self):
        super().__init__(); self.title('外贸达人 2.5.21 采集链路统一修复候选版'); self.geometry('1520x900'); self.minsize(1150,700)
        self._ui_events=queue.Queue()
        self._pending_result_lock=threading.Lock()
        self._pending_result_updates=[]
        self._result_flush_scheduled=False
        # A set pause event means the worker may run; clearing it requests a pause.
        self._pause_event=threading.Event(); self._pause_event.set()
        self._stop_event=threading.Event(); self._task_active=False
        self.rows=[]; self.current_task_id=''; self._row_domain_index={}; self.people_rows=[]; self.quality_quarantine=self._load_quality_quarantine(); self.quality_review=[]; self.catalog=CATALOG; self._last_raw_search_results=0; self._last_raw_candidates=0; self._last_excluded_count=0; self._last_duplicates_skipped=0; self._last_linkedin_hits=0; self._last_final_independent=0; self._rebuild_row_domain_index(); self._ui()
        self.after(100,self._process_ui_events)

    def _ui(self):
        """Chinese blue-white desktop layout based on the user's reference screenshot."""
        self.configure(bg='#edf4ff')
        style=ttk.Style(self)
        try: style.theme_use('clam')
        except Exception: pass
        bg='#edf4ff'; blue='#1677e8'; navy='#173f73'; border='#cbdcf5'
        style.configure('TFrame',background=bg)
        style.configure('Card.TFrame',background='#ffffff')
        style.configure('TLabel',background=bg,foreground='#142d52',font=('Microsoft YaHei UI',10))
        style.configure('Title.TLabel',background='#ffffff',foreground='#173b68',font=('Microsoft YaHei UI',14,'bold'))
        style.configure('Sub.TLabel',background='#ffffff',foreground='#71839b',font=('Microsoft YaHei UI',9))
        style.configure('TLabelframe',background='#ffffff',bordercolor=border,relief='solid')
        style.configure('TLabelframe.Label',background='#ffffff',foreground='#173b68',font=('Microsoft YaHei UI',10,'bold'))
        style.configure('TButton',font=('Microsoft YaHei UI',10),padding=(11,7),background='#f7faff',foreground='#173b68')
        style.map('TButton',background=[('active','#e5f0ff')])
        style.configure('Accent.TButton',background='#16b879',foreground='#ffffff',font=('Microsoft YaHei UI',10,'bold'),padding=(16,8))
        style.map('Accent.TButton',background=[('active','#0f9e67'),('disabled','#aabbd0')],foreground=[('disabled','#edf2f7')])
        style.configure('Treeview',background='#ffffff',fieldbackground='#ffffff',foreground='#26364a',rowheight=31,font=('Microsoft YaHei UI',9))
        style.configure('Treeview.Heading',background='#e8f1ff',foreground='#173b68',font=('Microsoft YaHei UI',9,'bold'),padding=8)
        style.map('Treeview',background=[('selected','#d8e9fb')],foreground=[('selected','#173b68')])
        style.configure('TNotebook',background='#ffffff',borderwidth=0)
        style.configure('TNotebook.Tab',padding=(15,8),font=('Microsoft YaHei UI',9,'bold'))

        shell=tk.Frame(self,bg=bg); shell.pack(fill='both',expand=True)
        header=tk.Frame(shell,bg='#ffffff',height=78,highlightbackground='#d8e5f7',highlightthickness=1); header.pack(fill='x'); header.pack_propagate(False)
        brand=tk.Frame(header,bg='#ffffff'); brand.pack(side='left',fill='y',padx=22,pady=8)
        tk.Label(brand,text='🌐 外贸达人',bg='#ffffff',fg='#1255a0',font=('Microsoft YaHei UI',23,'bold')).pack(side='left')
        tk.Label(brand,text='  2.5.21 采集链路统一修复候选版',bg='#ffffff',fg='#d97706',font=('Microsoft YaHei UI',17,'bold')).pack(side='left',pady=(7,0))
        tk.Label(brand,text='  │  专业的中国制造商采集工具',bg='#ffffff',fg='#647b9c',font=('Microsoft YaHei UI',11)).pack(side='left',pady=(10,0))
        quick=tk.Frame(header,bg='#ffffff'); quick.pack(side='right',padx=22)
        tk.Button(quick,text='▥ 采集统计',command=lambda:messagebox.showinfo('采集统计',f'当前载入记录：{len(self.rows)} 条'),relief='flat',bg='#ffffff',fg=navy,font=('Microsoft YaHei UI',10,'bold')).pack(side='left',padx=8,pady=22)
        tk.Button(quick,text='⚙ 设置',command=self.api_settings,relief='flat',bg='#ffffff',fg=navy,font=('Microsoft YaHei UI',10,'bold')).pack(side='left',padx=8,pady=22)
        tk.Button(quick,text='ⓘ 帮助',command=lambda:messagebox.showinfo('使用帮助','选择行业、细分行业、国家和目标数量后，点击“开始采集”。'),relief='flat',bg='#ffffff',fg=navy,font=('Microsoft YaHei UI',10,'bold')).pack(side='left',padx=8,pady=22)

        body=tk.Frame(shell,bg=bg); body.pack(fill='both',expand=True)
        sidebar=tk.Frame(body,bg='#214d80',width=190); sidebar.pack(side='left',fill='y'); sidebar.pack_propagate(False)
        tk.Label(sidebar,text='工作空间',bg='#214d80',fg='#bcd5f4',font=('Microsoft YaHei UI',10,'bold')).pack(anchor='w',padx=20,pady=(22,12))
        content=tk.Frame(body,bg=bg); content.pack(side='left',fill='both',expand=True,padx=15,pady=12)
        pages=[]
        page_host=tk.Frame(content,bg=bg); page_host.pack(fill='both',expand=True)
        for _ in range(5):
            p=tk.Frame(page_host,bg=bg); pages.append(p)
        def show_page(index):
            for p in pages: p.pack_forget()
            pages[index].pack(fill='both',expand=True)
            for j,b in enumerate(nav_buttons):
                b.configure(bg=('#3488ef' if j==index else '#214d80'))
        nav_buttons=[]
        for i,label in enumerate(('⌕  开始采集','▦  数据管理','⇩  导出结果','⚙  系统设置','ⓘ  使用帮助')):
            b=tk.Button(sidebar,text=label,anchor='w',relief='flat',bd=0,bg=('#3488ef' if i==0 else '#214d80'),fg='#ffffff',activebackground='#347ac0',activeforeground='#ffffff',font=('Microsoft YaHei UI',11),padx=18,pady=13,command=lambda n=i:show_page(n))
            b.pack(fill='x',padx=8,pady=3); nav_buttons.append(b)
        tk.Frame(sidebar,bg='#214d80').pack(fill='both',expand=True)
        promo=tk.Frame(sidebar,bg='#dceaff',highlightbackground='#a8c7ef',highlightthickness=1); promo.pack(fill='x',padx=12,pady=16)
        tk.Label(promo,text='👑 专业工作台',bg='#dceaff',fg='#173b68',font=('Microsoft YaHei UI',11,'bold')).pack(pady=(12,4))
        tk.Label(promo,text='本地保存 · 证据可追溯',bg='#dceaff',fg='#42658e',font=('Microsoft YaHei UI',9)).pack(pady=(0,12))

        # Collection task page
        task=pages[0]
        intro=tk.Frame(task,bg='#ffffff',highlightbackground=border,highlightthickness=1); intro.pack(fill='x',pady=(0,9))
        lf=ttk.LabelFrame(intro,text=' ① 采集任务设置 ',padding=(12,9)); lf.pack(fill='x',padx=8,pady=7)
        line=tk.Frame(lf,bg='#ffffff'); line.pack(fill='x',pady=4)
        tk.Label(line,text='行业分类：',bg='#ffffff',font=('Microsoft YaHei UI',10)).pack(side='left')
        self.cat_var=tk.StringVar(); cats=sorted(set(x.get('大类','') for x in self.catalog if x.get('大类')))
        self.cat=ttk.Combobox(line,textvariable=self.cat_var,values=cats,state='readonly',width=22); self.cat.pack(side='left',padx=(4,14)); self.cat.bind('<<ComboboxSelected>>',self.cat_changed)
        tk.Label(line,text='细分行业：',bg='#ffffff',font=('Microsoft YaHei UI',10)).pack(side='left')
        self.sub_var=tk.StringVar(); self.sub=ttk.Combobox(line,textvariable=self.sub_var,state='readonly',width=30); self.sub.pack(side='left',padx=(4,14)); self.sub.bind('<<ComboboxSelected>>',self.sub_changed)
        tk.Label(line,text='目标国家：',bg='#ffffff',font=('Microsoft YaHei UI',10)).pack(side='left')
        self.country=ttk.Combobox(line,values=('中国','China','美国','United States','德国','Germany','英国','United Kingdom','全球','Worldwide'),width=17); self.country.pack(side='left',padx=4); self.country.set('中国')
        tk.Label(line,text='采集数量：',bg='#ffffff',font=('Microsoft YaHei UI',10)).pack(side='left',padx=(12,2))
        self.target=ttk.Spinbox(line,from_=5,to=300,width=8); self.target.pack(side='left'); self.target.set('100')
        line2=tk.Frame(lf,bg='#ffffff'); line2.pack(fill='x',pady=(8,3))
        tk.Label(line2,text='关键词：',bg='#ffffff',font=('Microsoft YaHei UI',10)).pack(side='left')
        self.kw=tk.StringVar(); ttk.Entry(line2,textvariable=self.kw).pack(side='left',fill='x',expand=True,padx=5)
        ttk.Button(line2,text='导入/更新行业目录',command=self.import_catalog).pack(side='right',padx=(8,0))
        self.search_all=tk.BooleanVar(value=False); ttk.Checkbutton(lf,text='搜索当前大类下全部细分行业',variable=self.search_all).pack(anchor='w',pady=(4,0))

        opts=ttk.LabelFrame(intro,text=' ② 采集选项 ',padding=(12,7)); opts.pack(fill='x',padx=8,pady=(0,8))
        optrow=tk.Frame(opts,bg='#ffffff'); optrow.pack(fill='x')
        self.search_mode=tk.StringVar(value=load_search_mode_setting())
        tk.Label(optrow,text='搜索策略：',bg='#ffffff',font=('Microsoft YaHei UI',10)).pack(side='left')
        self.search_mode_box=ttk.Combobox(optrow,textvariable=self.search_mode,values=SEARCH_MODE_OPTIONS,state='readonly',width=24); self.search_mode_box.pack(side='left',padx=(4,15)); self.search_mode_box.bind('<<ComboboxSelected>>',self._save_search_mode_setting)
        self.parallel=tk.IntVar(value=4); tk.Label(optrow,text='并发核验：',bg='#ffffff').pack(side='left'); ttk.Spinbox(optrow,from_=1,to=8,textvariable=self.parallel,width=5).pack(side='left',padx=4)
        self.min_score=ttk.Entry(optrow,width=6); self.min_score.pack(side='left',padx=(12,4)); self.min_score.insert(0,'25'); tk.Label(optrow,text='制造商参考分',bg='#ffffff').pack(side='left')
        self.women_mode=tk.BooleanVar(value=False); ttk.Checkbutton(optrow,text='附加发现公开女性商务联系人（可选）',variable=self.women_mode).pack(side='left',padx=14)
        ttk.Button(optrow,text='高级设置 / API 配置',command=self.api_settings).pack(side='right')

        controls=tk.Frame(task,bg=bg); controls.pack(fill='x',pady=(2,9))
        self.run_btn=ttk.Button(controls,text='▶  开始采集',style='Accent.TButton',command=self.start); self.run_btn.pack(side='left',padx=(0,8))
        self.pause_btn=ttk.Button(controls,text='Ⅱ  暂停任务',command=self.pause_task,state='disabled'); self.pause_btn.pack(side='left',padx=4)
        self.resume_btn=ttk.Button(controls,text='▶  继续采集',command=self.resume_task,state='disabled'); self.resume_btn.pack(side='left',padx=4)
        self.stop_btn=ttk.Button(controls,text='■  停止任务',command=self.stop_task,state='disabled'); self.stop_btn.pack(side='left',padx=4)
        ttk.Button(controls,text='仅核验网址',command=self.verify_urls).pack(side='left',padx=4)
        ttk.Button(controls,text='自动筛选 / 去重',command=self.apply_quality_filter).pack(side='left',padx=4)
        ttk.Button(controls,text='查看隔离记录',command=self.show_quality_quarantine).pack(side='left',padx=4)
        ttk.Button(controls,text='清空结果',command=self.clear).pack(side='left',padx=4)
        ttk.Button(controls,text='历史记录（按行业）',command=self.show_history_archive).pack(side='left',padx=4)
        ttk.Button(controls,text='查看日志',command=lambda:results_tabs.select(log_page)).pack(side='left',padx=4)
        ttk.Button(controls,text='WhatsApp线索',command=self.show_whatsapp_discoveries).pack(side='left',padx=4)

        resultbox=tk.Frame(task,bg='#ffffff',highlightbackground=border,highlightthickness=1); resultbox.pack(fill='both',expand=True)
        self.results_tabs=ttk.Notebook(resultbox); results_tabs=self.results_tabs; results_tabs.pack(fill='both',expand=True,padx=8,pady=7)
        result_page=tk.Frame(results_tabs,bg='#ffffff'); log_page=tk.Frame(results_tabs,bg='#ffffff'); stats_page=tk.Frame(results_tabs,bg='#ffffff')
        results_tabs.add(result_page,text='采集结果（0）'); results_tabs.add(log_page,text='任务日志'); results_tabs.add(stats_page,text='统计信息')
        searchbar=tk.Frame(result_page,bg='#ffffff'); searchbar.pack(fill='x',pady=(4,6))
        tk.Label(searchbar,text='制造商采集结果',bg='#ffffff',fg=navy,font=('Microsoft YaHei UI',11,'bold')).pack(side='left',padx=5)
        self.filter_var=tk.StringVar(); ttk.Entry(searchbar,textvariable=self.filter_var,width=30).pack(side='right',padx=5); tk.Label(searchbar,text='搜索公司名称或邮箱',bg='#ffffff',fg='#71839b').pack(side='right')
        cols=('company','website','address','industry','factory_score','export_score','contact_score','wa_number','wa_link','email','email_score','phone','linkedin','gender','status','notes')
        self.tree=ttk.Treeview(result_page,columns=cols,displaycolumns=('company','website','address','wa_number','wa_link','email','phone','linkedin','status','notes'),show='headings')
        labels={'company':'公司名称','website':'官方网站','address':'公司地址','industry':'任务目标行业','factory_score':'工厂分','export_score':'出口分','contact_score':'联系人分','wa_number':'WhatsApp号码（明确标注）','wa_link':'WhatsApp联系链接','email':'公开邮箱','email_score':'邮箱角色/评分','phone':'公开电话（非WA）','linkedin':'LinkedIn','gender':'身份核验','status':'状态','notes':'来源 / 核验说明'}
        widths={'company':170,'website':190,'address':240,'industry':100,'factory_score':70,'export_score':70,'contact_score':70,'wa_number':165,'wa_link':180,'email':210,'email_score':120,'phone':135,'linkedin':160,'gender':100,'status':100,'notes':230}
        for c in cols: self.tree.heading(c,text=labels[c]); self.tree.column(c,width=widths[c],minwidth=75,stretch=True)
        ys=ttk.Scrollbar(result_page,orient='vertical',command=self.tree.yview); xs=ttk.Scrollbar(result_page,orient='horizontal',command=self.tree.xview); self.tree.configure(yscrollcommand=ys.set,xscrollcommand=xs.set)
        self.tree.pack(side='left',fill='both',expand=True); ys.pack(side='right',fill='y'); xs.pack(side='bottom',fill='x')
        self.filter_var.trace_add('write',lambda *_:self._filter_visible_results())
        self.status=tk.StringVar(value='就绪 · 等待开始采集')
        self.log_text=tk.Text(log_page,height=10,wrap='word',font=('Microsoft YaHei UI',9),bg='#fbfdff',fg='#42566f',relief='flat',state='disabled'); self.log_text.pack(fill='both',expand=True,padx=8,pady=8)
        self.stats_text=tk.StringVar(value='当前任务结果为空。历史采集数据已独立归档，可按行业分类查看。')
        tk.Label(stats_page,textvariable=self.stats_text,bg='#ffffff',fg=navy,font=('Microsoft YaHei UI',12),justify='left').pack(anchor='nw',padx=18,pady=18)
        self._append_log(f'程序已启动。本次任务与历史记录分离；历史归档文件：{HISTORY_ARCHIVE_FILE}')

        # Other navigation pages
        data_page=pages[1]; tk.Label(data_page,text='数据管理',bg=bg,fg=navy,font=('Microsoft YaHei UI',17,'bold')).pack(anchor='w',pady=(5,12))
        tk.Label(data_page,text='管理制造商候选、待人工复核和隔离记录；完整来源证据保存在本地数据库。',bg=bg,fg='#5c7190',font=('Microsoft YaHei UI',10)).pack(anchor='w',pady=5)
        ttk.Button(data_page,text='自动筛选与去重',command=self.apply_quality_filter).pack(anchor='w',pady=6); ttk.Button(data_page,text='查看隔离记录 / 恢复',command=self.show_quality_quarantine).pack(anchor='w',pady=6); ttk.Button(data_page,text='仅核验已保存官网',command=self.verify_urls).pack(anchor='w',pady=6)
        ttk.Button(data_page,text='导入历史采集 Excel 到永久数据库',command=self.import_history_xlsx).pack(anchor='w',pady=6)
        ttk.Button(data_page,text='历史记录归档（按行业查看）',command=self.show_history_archive).pack(anchor='w',pady=6)
        tk.Label(data_page,text=f'历史归档文件：{HISTORY_ARCHIVE_FILE}',bg=bg,fg='#5c7190',font=('Microsoft YaHei UI',9),wraplength=900).pack(anchor='w',pady=4)
        export_page=pages[2]; tk.Label(export_page,text='导出结果',bg=bg,fg=navy,font=('Microsoft YaHei UI',17,'bold')).pack(anchor='w',pady=(5,12))
        tk.Label(export_page,text='完整导出包含公司名称、官网、官网公开地址及地址来源、WhatsApp号码/链接、公开邮箱、普通电话、LinkedIn、采集来源和核验状态；按官网域名优先去重。地址无法从公开页面核实时留空，不会猜测。',bg=bg,fg='#5c7190',font=('Microsoft YaHei UI',10),wraplength=850).pack(anchor='w',pady=5)
        ttk.Button(export_page,text='导出简洁联系表 CSV',command=self.export_compact_csv).pack(anchor='w',pady=7); ttk.Button(export_page,text='导出简洁联系表 Excel',command=self.export_compact_xlsx).pack(anchor='w',pady=7)
        ttk.Button(export_page,text='导出完整资料 CSV',command=self.export_csv).pack(anchor='w',pady=7); ttk.Button(export_page,text='导出完整资料 Excel',command=self.export_xlsx).pack(anchor='w',pady=7); ttk.Button(export_page,text='查看公开个人线索',command=self.show_people).pack(anchor='w',pady=7); ttk.Button(export_page,text='导出个人线索 CSV',command=self.export_people_csv).pack(anchor='w',pady=7)
        ttk.Button(export_page,text='导出独立 WhatsApp 线索 CSV（不受企业筛选影响）',command=self.export_whatsapp_discoveries_csv).pack(anchor='w',pady=7)
        settings_page=pages[3]; tk.Label(settings_page,text='系统设置',bg=bg,fg=navy,font=('Microsoft YaHei UI',17,'bold')).pack(anchor='w',pady=(5,12))
        tk.Label(settings_page,text='搜索 API 密钥保存在当前 Windows 用户的本地配置中。SerpApi 与 Brave 每任务默认最多 20 次，并增加跨任务每月合计 100 次的本地费用保护。',bg=bg,fg='#5c7190',font=('Microsoft YaHei UI',10),wraplength=850).pack(anchor='w',pady=5)
        ttk.Button(settings_page,text='搜索 API 配置 / 用量',command=self.api_settings).pack(anchor='w',pady=7); ttk.Button(settings_page,text='搜索引擎表现',command=self.show_engine_performance).pack(anchor='w',pady=7); ttk.Button(settings_page,text='搜索引擎实测（标题 / 网址）',command=self.live_engine_test).pack(anchor='w',pady=7); ttk.Button(settings_page,text='网络诊断',command=self.network_diagnostics).pack(anchor='w',pady=7)
        help_page=pages[4]; tk.Label(help_page,text='使用帮助',bg=bg,fg=navy,font=('Microsoft YaHei UI',17,'bold')).pack(anchor='w',pady=(5,12))
        help_text='1. 选择行业大类、细分行业、目标国家和采集数量。\n2. 点击开始采集后，结果页只显示本次任务，不再自动混入历史企业。\n3. 历史记录独立保存在 collection_history.db，可按行业大类筛选并查看每次任务。\n4. 同一企业在不同任务或行业下分别保留任务快照，原始企业数据库不删除。\n5. 清空结果只清空当前任务显示，不删除历史归档。\n6. WhatsApp号码、联系链接和普通电话分列；普通电话不会自动认定为 WhatsApp。'
        tk.Label(help_page,text=help_text,bg=bg,fg='#42566f',font=('Microsoft YaHei UI',11),justify='left',wraplength=900).pack(anchor='w',pady=5)

        footer=tk.Frame(shell,bg='#ffffff',height=48,highlightbackground='#d8e5f7',highlightthickness=1); footer.pack(fill='x',side='bottom'); footer.pack_propagate(False)
        self.status_label=tk.Label(footer,textvariable=self.status,bg='#ffffff',fg='#315b86',font=('Microsoft YaHei UI',9,'bold')); self.status_label.pack(side='left',padx=18,pady=13)
        self.count_label=tk.Label(footer,text=f'今日已采集：{len(self.rows)} 条   |   成功：{len(self.rows)} 条   |   失败：0 条',bg='#ffffff',fg='#315b86',font=('Microsoft YaHei UI',9)); self.count_label.pack(side='left',padx=16)
        self.progress=ttk.Progressbar(footer,mode='indeterminate',length=210); self.progress.pack(side='right',padx=18,pady=12)
        self.status.trace_add('write',self._status_changed)
        if cats: self.cat.current(0); self.cat_changed()
        show_page(0)
        for i,r in enumerate(reversed(self.rows),1): self.add_result(r,i,len(self.rows))

    def _filter_visible_results(self):
        """Filter the visible result table without changing saved records."""
        if not hasattr(self, 'tree'):
            return
        needle=(self.filter_var.get() if hasattr(self, 'filter_var') else '').strip().lower()
        for iid in self.tree.get_children(''):
            values=self.tree.item(iid, 'values')
            haystack=' '.join(str(v) for v in values).lower()
            if not needle or needle in haystack:
                self.tree.reattach(iid, '', 'end')
            else:
                self.tree.detach(iid)

    def _append_log(self, message):
        if not hasattr(self,'log_text'): return
        stamp=time.strftime('%H:%M:%S')
        try:
            self.log_text.configure(state='normal'); self.log_text.insert('end',f'[{stamp}] {message}\n'); self.log_text.see('end')
            # Keep the UI log bounded; the full diagnostic history remains in application/database logs.
            lines=int(self.log_text.index('end-1c').split('.')[0])
            if lines>180: self.log_text.delete('1.0',f'{lines-150}.0')
            self.log_text.configure(state='disabled')
        except tk.TclError: pass

    def _status_changed(self, *_):
        try:
            value=self.status.get()
            self._append_log(value)
            active=any(word in value for word in ('正在','第 ','核验候选','发现公开','搜索进度'))
            if active and str(self.progress.cget('mode'))=='indeterminate': self.progress.start(12)
            elif not active: self.progress.stop()
        except Exception: pass

    def api_settings(self):
        win=tk.Toplevel(self); win.title('搜索 API 本地配置与用量'); win.geometry('760x570'); win.transient(self)
        keys=load_api_keys(); frame=ttk.Frame(win,padding=14); frame.pack(fill='both',expand=True)
        ttk.Label(frame,text='API Key 为可选补充项，不是启动采集的前提。搜索策略可选：仅免费搜索、免费优先、付费需手动切换、付费优先免费补充。SerpApi 与 Brave 合计每个任务默认最多 20 次请求，并且跨任务每月合计最多 100 次（失败请求也计数）；达到任一上限立即停止付费调用。7 天缓存命中不产生新付费请求。密钥仅保存在本 Windows 用户配置下并使用 DPAPI 加密。',wraplength=710).pack(anchor='w',pady=(0,10))
        serp_var=tk.StringVar(); brave_var=tk.StringVar()
        ttk.Label(frame,text='SerpApi API Key').pack(anchor='w'); ttk.Entry(frame,textvariable=serp_var,show='*',width=86).pack(fill='x',pady=(2,8))
        ttk.Label(frame,text='Brave Search API Key').pack(anchor='w'); ttk.Entry(frame,textvariable=brave_var,show='*',width=86).pack(fill='x',pady=(2,8))
        ttk.Label(frame,text='输入新的密钥后点击保存；留空表示不修改现有密钥。清除密钥请使用下方清除按钮。',foreground='#666').pack(anchor='w')
        status=tk.StringVar(value=f"SerpApi：{'已配置' if keys.get('serpapi') else '未配置'}；Brave：{'已配置' if keys.get('brave') else '未配置'}")
        ttk.Label(frame,textvariable=status).pack(anchor='w',pady=8)
        quota_frame=ttk.Frame(frame); quota_frame.pack(fill='x',pady=4)
        quotas=get_provider_quotas(DB_FILE)
        ttk.Label(quota_frame,text='SerpApi 月免费额度（按账户套餐填写，0=未设置）').pack(side='left')
        serp_quota=tk.StringVar(value=str(quotas.get('serpapi',0))); ttk.Entry(quota_frame,textvariable=serp_quota,width=8).pack(side='left',padx=4)
        ttk.Label(quota_frame,text='Brave 月免费额度').pack(side='left',padx=(10,0))
        brave_quota=tk.StringVar(value=str(quotas.get('brave',0))); ttk.Entry(quota_frame,textvariable=brave_quota,width=8).pack(side='left',padx=4)
        usage_box=tk.Text(frame,height=12,wrap='word'); usage_box.pack(fill='both',expand=True,pady=6)
        def refresh_usage():
            usage_box.delete('1.0','end')
            usage_box.insert('end',f'月度调用统计：SerpApi + Brave 跨任务保护上限 100 次；本月已预留 {paid_monthly_usage(DB_FILE)} 次，剩余 {max(0,100-paid_monthly_usage(DB_FILE))} 次。失败请求也计入，缓存命中不计费。\n免费额度由账户套餐决定，请按供应商控制台填写。\n')
            try:
                set_provider_quota(DB_FILE,'serpapi',int(serp_quota.get() or 0)); set_provider_quota(DB_FILE,'brave',int(brave_quota.get() or 0))
            except ValueError:
                usage_box.insert('end','额度必须为非负整数。\n')
            rows=provider_usage(DB_FILE)
            qmap=get_provider_quotas(DB_FILE)
            if not rows: usage_box.insert('end','暂无 API 调用记录。\n')
            for row in rows[:20]:
                quota=qmap.get(row['provider'],0); pct=(row['calls']/quota*100) if quota else None
                qtext=f'额度 {quota} / 使用 {pct:.1f}%' if quota else '额度未设置'
                usage_box.insert('end',f"{row['month']} | {row['provider']} | 调用 {row['calls']} | 成功 {row['successes']} | 失败 {row['errors']} | 结果 {row['results']} | {qtext} | 最近状态 {row['last_status']} | {row['last_error'] or '无错误'}\n")
            usage_box.insert('end','\n最近错误（不含 API Key）：\n')
            con=sqlite3.connect(DB_FILE, timeout=60)
            for provider,st,code,msg,when in con.execute('SELECT provider,status,error_code,error_message,created_at FROM provider_errors ORDER BY id DESC LIMIT 20'):
                usage_box.insert('end',f'{when} | {provider} | HTTP {st} | {code} | {msg}\n')
            con.close()
        def save():
            new={"serpapi":serp_var.get().strip() or keys.get('serpapi',''),"brave":brave_var.get().strip() or keys.get('brave','')}
            try:
                save_api_keys(new); keys.update(new); serp_var.set(''); brave_var.set('')
                status.set(f"SerpApi：{'已配置' if new['serpapi'] else '未配置'}；Brave：{'已配置' if new['brave'] else '未配置'}")
                messagebox.showinfo('保存成功','API Key 已在本机加密保存。',parent=win)
            except Exception as exc: messagebox.showerror('保存失败',str(exc),parent=win)
        def clear_keys():
            if not messagebox.askyesno('确认清除','确定清除本机保存的两个 API Key？',parent=win): return
            try:
                save_api_keys({}); keys.update({"serpapi":"","brave":""}); status.set('SerpApi：未配置；Brave：未配置')
                messagebox.showinfo('已清除','本机 API Key 已清除。',parent=win)
            except Exception as exc: messagebox.showerror('清除失败',str(exc),parent=win)
        def test_one(provider):
            active=(serp_var.get().strip() if provider=='serpapi' else brave_var.get().strip()) or keys.get(provider,'')
            if not active:
                messagebox.showwarning('未配置','请先输入并保存对应 API Key。',parent=win); return
            status.set(f'{provider} 正在执行真实连接测试…')
            def worker():
                try:
                    fn=search_serpapi if provider=='serpapi' else search_brave
                    rows,http=fn('China manufacturer official website',active,max_results=1)
                    record_provider_call(DB_FILE,provider,True,len(rows),http)
                    self._post_ui(lambda:status.set(f'{provider} 真实连接成功：HTTP {http}，返回 {len(rows)} 条自然搜索结果'))
                    self._post_ui(refresh_usage)
                except Exception as exc:
                    record_provider_call(DB_FILE,provider,False,0,getattr(exc,'status',None),getattr(exc,'code',type(exc).__name__),str(exc)[:180] if isinstance(exc,ProviderError) else type(exc).__name__)
                    err_type=type(exc).__name__
                    self._post_ui(lambda e=err_type:status.set(f'{provider} 真实连接失败：{e}'))
                    self._post_ui(refresh_usage)
            threading.Thread(target=worker,daemon=True).start()
        btn=ttk.Frame(frame); btn.pack(fill='x',pady=5)
        ttk.Button(btn,text='安全保存',command=save).pack(side='left',padx=3)
        ttk.Button(btn,text='清除密钥',command=clear_keys).pack(side='left',padx=3)
        ttk.Button(btn,text='测试 SerpApi 真实连接',command=lambda:test_one('serpapi')).pack(side='left',padx=3)
        ttk.Button(btn,text='测试 Brave 真实连接',command=lambda:test_one('brave')).pack(side='left',padx=3)
        ttk.Button(btn,text='刷新用量/错误',command=refresh_usage).pack(side='left',padx=3)
        refresh_usage()

    def live_engine_test(self):
        keyword=(self.kw.get() or '').strip()
        query=(f'({keyword}) China (female OR women OR export OR foreign trade) (WhatsApp OR email)' if keyword else 'China female export sales manager WhatsApp email')
        self.status.set('正在逐个测试可用搜索引擎并读取真实标题/网址…')
        def worker():
            diagnostics={}
            try:
                rows=search_public_web(query,max_results=5,diagnostics=diagnostics,session=create_http_session())
                self._post_ui(self._show_engine_test,query,diagnostics,rows)
            except Exception as exc:
                self._post_ui(self.status.set,f'引擎实测失败：{type(exc).__name__}')
        threading.Thread(target=worker,daemon=True).start()

    def _show_engine_test(self,query,diagnostics,rows):
        win=tk.Toplevel(self); win.title('搜索引擎实测：真实标题与网址'); win.geometry('1180x650')
        ttk.Label(win,text='测试关键词：'+query,wraplength=1140).pack(anchor='w',padx=12,pady=8)
        ttk.Label(win,text='以下为当前 Windows 网络实际返回的搜索结果样本；HTTP 可访问但没有标题/网址，不算搜索成功。',foreground='#8a5a00',wraplength=1140).pack(anchor='w',padx=12,pady=(0,8))
        cols=('engine','status','count','samples')
        tree=ttk.Treeview(win,columns=cols,show='headings',height=18)
        labels={'engine':'搜索引擎','status':'本次状态','count':'HTML解析数','samples':'真实标题 / 网址样本'}
        widths={'engine':130,'status':220,'count':90,'samples':700}
        for col in cols: tree.heading(col,text=labels[col]); tree.column(col,width=widths[col],stretch=True)
        for engine in diagnostics.get('public_search',{}).get('engine_order',[]):
            state=diagnostics.get('public_search',{}).get(engine,{})
            examples='\n'.join(f"{x.get('title','')} — {x.get('url','')}" for x in state.get('sample_results',[]))
            tree.insert('','end',values=(engine,state.get('status','未尝试'),state.get('parsed_results',state.get('results',0)),examples or '未解析到真实搜索结果'))
        tree.pack(fill='both',expand=True,padx=12,pady=8)
        ttk.Label(win,text=f'合并后候选网址：{len(rows)} 条。只有后续网站核验并找到公开商务联系方式及外贸/出口业务信号，才会计入有效线索。',wraplength=1140).pack(anchor='w',padx=12,pady=4)
        ttk.Button(win,text='关闭',command=win.destroy).pack(anchor='e',padx=12,pady=10)
        self.status.set(f'引擎实测结束：合并得到 {len(rows)} 条候选网址；请查看每个引擎的标题/网址样本。')

    def show_engine_performance(self):
        rows=search_engine_performance(DB_FILE)
        win=tk.Toplevel(self); win.title('搜索引擎表现与自动排序依据'); win.geometry('850x430')
        ttk.Label(win,text='当前免费搜索主流程固定使用 Bing 优先、Qwant 备用；尚未启用按统计数据自动调整引擎顺序。注意：2.5.19及更早版本的历史“解析结果数”曾混入筛选后新增数量，不能与本版本修正后的解析口径直接比较；升级后新增统计按真实解析数量记录。',wraplength=810).pack(anchor='w',padx=12,pady=10)
        cols=('engine','calls','parsed','qualified','errors','last')
        tree=ttk.Treeview(win,columns=cols,show='headings',height=12)
        labels={'engine':'引擎','calls':'搜索次数','parsed':'解析结果数','qualified':'合格线索数','errors':'错误次数','last':'最近状态'}
        widths={'engine':140,'calls':90,'parsed':110,'qualified':110,'errors':90,'last':260}
        for col in cols: tree.heading(col,text=labels[col]); tree.column(col,width=widths[col],stretch=True)
        for row in rows: tree.insert('','end',values=(row['engine'],row['calls'],row['parsed_results'],row['qualified_leads'],row['errors'],row['last_status']))
        tree.pack(fill='both',expand=True,padx=12,pady=8)
        if not rows: ttk.Label(win,text='尚无联网搜索记录；首次运行后会自动开始积累各引擎表现。',foreground='#777').pack(anchor='w',padx=12)
        ttk.Button(win,text='关闭',command=win.destroy).pack(anchor='e',padx=12,pady=10)

    def network_diagnostics(self):
        self.status.set('正在检测 Bing / Qwant 自主搜索入口及其他诊断端点…')
        def worker():
            try:
                report = run_network_diagnostics()
                self._post_ui(self._show_network_report, report)
            except Exception as exc:
                self._post_ui(messagebox.showerror, '网络诊断失败', f'{type(exc).__name__}: {exc}')
                self._post_ui(self.status.set, '网络诊断失败')
        threading.Thread(target=worker, daemon=True).start()

    def _show_network_report(self, report):
        win = tk.Toplevel(self); win.title('外贸达人本机网络诊断'); win.geometry('980x440')
        ttk.Label(win, text='检测 Bing / Qwant 实际自主搜索入口，以及其他诊断端点；不会发送 API Key。API 端点可访问不代表账户认证成功。', wraplength=930).pack(anchor='w', padx=12, pady=(12,6))
        ttk.Label(win, text=f"系统：{report['platform']}\n代理：{report['proxy']}", wraplength=930).pack(anchor='w', padx=12, pady=4)
        cols=('site','host','dns','https','result','bytes')
        tree=ttk.Treeview(win, columns=cols, show='headings', height=10)
        labels={'site':'搜索入口','host':'主机','dns':'DNS解析','https':'HTTPS结果','result':'连接状态','bytes':'响应字节数'}
        widths={'site':125,'host':175,'dns':230,'https':250,'result':100,'bytes':70}
        for col in cols:
            tree.heading(col,text=labels[col]); tree.column(col,width=widths[col],stretch=True)
        for row in report['rows']:
            tree.insert('', 'end', values=(row['site'],row['host'],row['dns'],row['https'],row['result'],row['bytes']))
        tree.pack(fill='both',expand=True,padx=12,pady=8)
        ttk.Button(win,text='关闭',command=win.destroy).pack(anchor='e',padx=12,pady=(0,10))
        self.status.set('搜索 API 端点诊断完成')

    def _save_search_mode_setting(self, event=None):
        value=self.search_mode.get().strip()
        if value not in SEARCH_MODE_OPTIONS:
            return
        temp=SEARCH_MODE_FILE+'.tmp'
        try:
            with open(temp,'w',encoding='utf-8') as f:
                json.dump({'search_mode':value},f,ensure_ascii=False)
            os.replace(temp,SEARCH_MODE_FILE)
        except OSError as exc:
            self.status.set(f'搜索策略设置保存失败：{type(exc).__name__}')

    def _post_ui(self, callback, *args, **kwargs):
        """Thread-safe UI dispatch; high-volume result rows are batched to protect Tk."""
        if getattr(callback, '__self__', None) is self and getattr(callback, '__func__', None) is App.add_result:
            with self._pending_result_lock:
                self._pending_result_updates.append((args, kwargs))
                if not self._result_flush_scheduled:
                    self._result_flush_scheduled=True
                    self._ui_events.put((self._flush_result_batch, (), {}))
            return
        self._ui_events.put((callback,args,kwargs))

    def _flush_result_batch(self):
        """Render a small number of collected rows per Tk turn; never block on a full result set."""
        with self._pending_result_lock:
            # One full Treeview/statistics refresh per Tk turn. Keep each
            # callback small so Windows can continue processing paint/input.
            batch=self._pending_result_updates[:1]
            del self._pending_result_updates[:len(batch)]
            more=bool(self._pending_result_updates)
            if not more:
                self._result_flush_scheduled=False
        for args,kwargs in batch:
            try:
                self.add_result(*args,**kwargs)
            except Exception as exc:
                try: self.status.set(f'结果列表更新异常：{type(exc).__name__}: {exc}')
                except Exception: pass
        if more:
            try:
                self.after(8,self._flush_result_batch)
            except tk.TclError:
                with self._pending_result_lock:
                    self._result_flush_scheduled=False

    def _update_query_progress(self, done, total, candidates, new_domains, engine_note='', duplicates_skipped=0):
        try:
            self.progress.stop()
            self.progress.configure(mode='determinate', maximum=max(1,int(total)), value=max(0,min(int(done),int(total))))
        except Exception:
            pass
        duplicate_label = '本任务内重复搜索结果合并' if DIAGNOSTIC_DISABLE_GLOBAL_HISTORY_FILTER else '历史重复跳过'
        suffix=f'；本次新增域名 {new_domains} 个；累计候选网站 {candidates} 个；{duplicate_label} {duplicates_skipped} 个'
        if engine_note:
            suffix += f'；引擎：{engine_note}'
        self.status.set(f'搜索进度 {done}/{total}{suffix}')

    def _process_ui_events(self):
        """Drain a bounded UI batch so a busy worker cannot monopolize Tk's main loop."""
        processed = 0
        deadline = time.monotonic() + 0.012  # yield to input/paint at least every ~12 ms
        max_batch = 60
        while processed < max_batch and time.monotonic() < deadline:
            try:
                callback,args,kwargs=self._ui_events.get_nowait()
            except queue.Empty:
                break
            try:
                callback(*args,**kwargs)
            except Exception as exc:
                try: self.status.set(f'界面更新异常：{type(exc).__name__}: {exc}')
                except Exception: pass
            processed += 1
        try:
            if self.winfo_exists():
                # Keep draining quickly while backlog exists, but always yield to Tk.
                delay = 1 if not self._ui_events.empty() else 60
                self.after(delay,self._process_ui_events)
        except tk.TclError:
            pass

    def _rebuild_row_domain_index(self):
        """Rebuild fast indexes/counters after bulk load/filter operations."""
        self._row_domain_index = {}
        self._row_counts = {'keep': 0, 'review': 0, 'excluded': 0}
        self._contact_totals = {'whatsapp': 0, 'wa_links': 0, 'phones': 0, 'discovery_numbers': 0, 'discovery_links': 0}
        for index, row in enumerate(self.rows):
            domain = root_domain(row.get('company_website',''))
            if domain:
                self._row_domain_index[domain] = index
            status = row.get('quality_status') or 'review'
            if status not in self._row_counts: status = 'review'
            self._row_counts[status] += 1
            self._contact_totals['whatsapp'] += len(row.get('whatsapp_contacts') or [])
            self._contact_totals['wa_links'] += len(row.get('whatsapp_links') or [])
            self._contact_totals['phones'] += len(row.get('phone_candidates') or [])
        self._refresh_whatsapp_discovery_totals()

    def _refresh_whatsapp_discovery_totals(self):
        try:
            con=sqlite3.connect(DB_FILE,timeout=5)
            try:
                rows=con.execute("SELECT whatsapp_type,COUNT(DISTINCT whatsapp_value) FROM whatsapp_discoveries GROUP BY whatsapp_type").fetchall()
            finally: con.close()
            self._contact_totals['discovery_numbers']=sum(int(n) for kind,n in rows if kind=='whatsapp_labelled_number')
            self._contact_totals['discovery_links']=sum(int(n) for kind,n in rows if kind=='whatsapp_link')
        except sqlite3.Error:
            self._contact_totals['discovery_numbers']=0
            self._contact_totals['discovery_links']=0

    def _adjust_cached_row_metrics(self, row, sign):
        if not row: return
        status = row.get('quality_status') or 'review'
        if status not in self._row_counts: status = 'review'
        self._row_counts[status] += sign
        self._contact_totals['whatsapp'] += sign * len(row.get('whatsapp_contacts') or [])
        self._contact_totals['wa_links'] += sign * len(row.get('whatsapp_links') or [])
        self._contact_totals['phones'] += sign * len(row.get('phone_candidates') or [])

    def cat_changed(self,event=None):
        cat=self.cat_var.get()
        rows=[x for x in self.catalog if x.get('大类')==cat]
        # Include the official sub-industry code in the display label so repeated Chinese names remain selectable.
        labels=[f"{x.get('细分行业','')}（{x.get('细分行业代码','')}）" for x in rows]
        self.sub['values']=labels
        if labels: self.sub.current(0); self.sub_changed()
    def selected_catalog_row(self):
        selected=(self.sub_var.get() or '').strip()
        code_match=re.search(r'（(\d{4})）$',selected)
        if code_match:
            return next((x for x in self.catalog if x.get('细分行业代码')==code_match.group(1)),{})
        # Backward-compatible fallback for tests and older UI state containing only the industry name.
        return next((x for x in self.catalog if x.get('细分行业')==selected and (not self.cat_var.get() or x.get('大类')==self.cat_var.get())),{})
    def sub_changed(self,event=None):
        row=self.selected_catalog_row()
        # The keyword box is intentionally concise: the uploaded new English core terms.
        # Users may append concrete product names separated by semicolons.
        terms=[x.strip() for x in (row.get('英文核心词') or '').split(';') if x.strip()]
        if not terms:
            terms=[x.strip() for x in (row.get('英文搜索关键词') or '').split(';')[:1] if x.strip()]
        self.kw.set('; '.join(dict.fromkeys(terms)))

    def import_catalog(self):
        path=filedialog.askopenfilename(title='选择行业目录 CSV',filetypes=[('CSV','*.csv')]);
        if not path:return
        try:
            with open(path,encoding='utf-8-sig',newline='') as f:
                reader=csv.DictReader(f); data=list(reader); fieldnames=list(reader.fieldnames or [])
            if not data or not {'大类','细分行业','英文搜索关键词'}.issubset(data[0].keys()): raise ValueError('CSV 必须包含：大类、细分行业、英文搜索关键词')
            imported_codes={str(x.get('细分行业代码','')).strip() for x in data if x.get('细分行业代码')}
            supplements=[x for x in self.catalog if str(x.get('目录类型','')).startswith('补充-') and str(x.get('细分行业代码','')).strip() not in imported_codes]
            self.catalog=data+supplements
            # Preserve the built-in supplemental rows and every imported keyword column.
            all_fields=list(dict.fromkeys((fieldnames or list(data[0].keys())) + [k for row in supplements for k in row.keys()]))
            with open(CATALOG_FILE,'w',encoding='utf-8-sig',newline='') as f:
                w=csv.DictWriter(f,fieldnames=all_fields,extrasaction='ignore'); w.writeheader(); w.writerows([{k:safe_spreadsheet_cell(v) for k,v in row.items()} for row in self.catalog])
            cats=sorted(set(x.get('大类','') for x in data if x.get('大类'))); self.cat['values']=cats
            if cats:self.cat.current(0); self.cat_changed()
            messagebox.showinfo('已更新',f'已载入 {len(data)} 条细分行业，保留全部关键词字段。')
        except Exception as e: messagebox.showerror('导入失败',str(e))

    def make_queries(self):
        """Build one complete English-keyword pass and resume/rotate it persistently."""
        country={'中国':'China','美国':'United States','德国':'Germany','英国':'United Kingdom','全球':'Worldwide'}.get(self.country.get().strip(), self.country.get().strip() or 'China')
        selected_row=self.selected_catalog_row()
        selected_code=str(selected_row.get('细分行业代码','')).strip()
        selected_category=self.cat_var.get().strip() if 'cat_var' in self.__dict__ else ''
        all_categories=bool(self.__dict__.get('search_all_categories',False))
        common={
            'selected_category': selected_category if (self.search_all.get() or not selected_code) else None,
            'selected_code': (selected_code or None) if not self.search_all.get() else None,
            'all_categories': all_categories,
            'extra_terms': self.kw.get() or '',
        }
        saved_progress=load_progress()
        baseline=build_rounds(self.catalog,country,keyword_cycle=0,**common)
        rotation_signature=plan_signature(baseline,country)
        if saved_progress.get('rotation_signature')==rotation_signature:
            if not saved_progress.get('completed',False):
                keyword_cycle=max(0,int(saved_progress.get('keyword_cycle',0) or 0))
            else:
                keyword_cycle=max(0,int(saved_progress.get('next_keyword_cycle',int(saved_progress.get('keyword_cycle',0) or 0)+1)))
        else:
            keyword_cycle=0
        rounds=build_rounds(self.catalog,country,keyword_cycle=keyword_cycle,**common)
        actual_signature=plan_signature(rounds,country)
        if (saved_progress.get('rotation_signature')==rotation_signature and
                saved_progress.get('signature')==actual_signature and
                not saved_progress.get('completed') and saved_progress.get('plan_queries')):
            canonical=flatten_rounds(rounds)
            by_query={item['query']:item for item in canonical}
            restored=[by_query[q] for q in saved_progress['plan_queries'] if q in by_query]
            restored.extend(item for item in canonical if item['query'] not in set(saved_progress['plan_queries']))
            flat=restored
            rank={item['query']:i for i,item in enumerate(flat)}
            for round_info in rounds:
                round_info['queries'].sort(key=lambda x:rank.get(x['query'],10**9))
        else:
            rounds=prioritize_rounds(rounds,load_performance())
            flat=flatten_rounds(rounds)
        self._base_signature=rotation_signature
        self._rotation_signature=rotation_signature
        self._keyword_cycle=keyword_cycle
        context={item['query']:{**{k:v for k,v in item.items() if k!='query'},'search_intent':item['intent']} for item in flat}
        self._search_rounds=rounds
        self._query_context=context
        return [item['query'] for item in flat]

    def _wait_for_task_permission(self):
        """Block the worker while paused; return False when a stop was requested."""
        while not self._pause_event.wait(0.2):
            if self._stop_event.is_set():
                return False
        return not self._stop_event.is_set()

    def pause_task(self):
        if self._task_active:
            self._pause_event.clear()
            self.pause_btn.config(state='disabled')
            self.resume_btn.config(state='normal')
            self.status.set('已请求暂停 · 当前正在执行的网络请求/小批次结束后暂停，进度会保留')

    def resume_task(self):
        if self._task_active:
            self._pause_event.set()
            self.pause_btn.config(state='normal')
            self.resume_btn.config(state='disabled')
            self.status.set('正在继续采集 · 从当前任务位置接着执行')

    def stop_task(self):
        if self._task_active and messagebox.askyesno('停止采集','确定停止当前任务吗？已保存的数据会保留；停止后如需继续，请重新开始任务并从保存的搜索进度恢复。'):
            self._stop_event.set()
            self._pause_event.set()  # release a paused worker so it can exit
            self.pause_btn.config(state='disabled'); self.resume_btn.config(state='disabled'); self.stop_btn.config(state='disabled')
            self.status.set('正在安全停止 · 保存当前已完成的数据与搜索进度…')

    def start(self):
        # Snapshot all Tk variables on the UI thread; workers must not read Tk widgets.
        try: target=max(5,min(300,int(self.target.get().strip())))
        except (ValueError, TypeError): target=30
        try: min_score=max(0,min(100,int(self.min_score.get().strip())))
        except (ValueError, TypeError): min_score=25
        try: workers=max(1,min(8,int(self.parallel.get())))
        except (ValueError, TypeError): workers=4
        selected_row=self.selected_catalog_row()
        selected_industry=selected_row.get('细分行业',self.sub_var.get())
        queries=self.make_queries()
        query_context=dict(getattr(self, '_query_context', {}))
        # Optional people/contact discovery is deliberately kept out of manufacturer queries.
        # It must never change the industry candidate pool or its category context.
        if not queries:
            messagebox.showwarning('没有可执行查询','请先选择行业大类/细分行业，并填写有效的英文核心词或产品关键词。')
            return
        rounds=list(self.__dict__.get('_search_rounds',[]))
        country_value={'中国':'China','美国':'United States','德国':'Germany','英国':'United Kingdom','全球':'Worldwide'}.get(self.country.get().strip(), self.country.get().strip() or 'China')
        signature=plan_signature(rounds,country_value)
        config={
            'queries': queries,
            'query_context': query_context,
            'search_rounds': rounds,
            'progress_signature': signature,
            'base_signature': self.__dict__.get('_base_signature',signature),
            'rotation_signature': self.__dict__.get('_rotation_signature',signature),
            'keyword_cycle': int(self.__dict__.get('_keyword_cycle',0)),
            'all_industry': bool(self.search_all.get()),
            'industry': selected_industry,
            'keywords': self.kw.get().strip(),
            'country': country_value,
            'category': self.cat_var.get(),
            'min_score': min_score,
            'workers': workers,
            'women_mode': bool(self.women_mode.get()),
            'search_mode': (self.__dict__.get('search_mode').get() if self.__dict__.get('search_mode') is not None else '免费优先（手动控制付费）'),
            'query_budget': query_budget_for_target(target),
        }
        archive_task_id = uuid.uuid4().hex
        config['_archive_task_id'] = archive_task_id
        try:
            history_store.create_task(HISTORY_ARCHIVE_FILE, archive_task_id, config.get('category',''),
                                      config.get('industry',''), config.get('country',''), config.get('keywords',''), '采集')
        except Exception as exc:
            messagebox.showerror('历史归档初始化失败', f'无法创建本次任务历史记录，已取消启动以防止数据混淆：{type(exc).__name__}: {exc}')
            return
        self.current_task_id = archive_task_id
        self.rows=[]; self._rebuild_row_domain_index()
        with self._pending_result_lock:
            self._pending_result_updates.clear()
        for item in self.tree.get_children(''):
            self.tree.delete(item)
        self.results_tabs.tab(0, text='采集结果（0）')
        self.stats_text.set(f'当前任务：{config.get("category","")} / {config.get("industry","")} / {config.get("country","")}；等待采集结果。历史记录单独归档。')
        self._stop_event.clear(); self._pause_event.set(); self._task_active=True
        self.run_btn.config(state='disabled'); self.pause_btn.config(state='normal'); self.resume_btn.config(state='disabled'); self.stop_btn.config(state='normal')
        if self.__dict__.get('search_mode_box') is not None: self.search_mode_box.config(state='disabled')
        try:
            self.progress.stop(); self.progress.configure(mode='determinate',maximum=max(1,len(queries)),value=0)
        except Exception: pass
        self.status.set(f"正在发现公开网页 · 计划 {len(queries)} 条查询 · 本轮最多 {config['query_budget']} 条，剩余计划自动保存")
        threading.Thread(target=self.worker_discover,args=(target,config),daemon=True).start()

    @staticmethod
    def _name_tokens(text):
        raw=(text or '').lower()
        raw=re.sub(r'(有限责任公司|有限公司|股份有限公司|集团公司|集团|公司)$','',raw)
        text=re.sub(r'[^a-z0-9\u4e00-\u9fff]+',' ',raw)
        stop={'company','limited','ltd','co','corp','inc','the','china','plastic','products','manufacturer','factory','group','technology'}
        tokens={x for x in text.split() if len(x)>=3 and x not in stop}
        # Chinese names are not whitespace-delimited; compare character bigrams
        # so a Chinese official name can match a public LinkedIn page title.
        for run in re.findall(r'[\u4e00-\u9fff]{2,}', raw):
            tokens.update(run[i:i+2] for i in range(len(run)-1))
        return tokens

    def _match_linkedin_company(self, company_name, linkedin_candidates):
        base=self._name_tokens(company_name)
        if not base: return ''
        best=''; best_score=0
        for title,url in linkedin_candidates:
            cand=self._name_tokens(title)
            if not cand: continue
            score=len(base & cand)/max(1,len(base|cand))
            if score>best_score: best_score=score; best=url
        return best if best_score>=0.34 else ''

    def worker_discover(self,target,config):
        _ACTIVE_COLLECTION_TASK.task_id = config.get('_archive_task_id', '')
        _ACTIVE_COLLECTION_TASK.meta = {'category': config.get('category',''), 'industry': config.get('industry',''), 'country': config.get('country',''), 'keywords': config.get('keywords','')}
        candidates={}; queries=config['queries']; diagnostics={'_paid_search_budget': {'limit': 20, 'used': 0, 'monthly_used': paid_monthly_usage(DB_FILE), 'monthly_limit': 100}}; found=[]; scanned=0; retry_scanned=0; errors=0; below=0; excluded=0; industry_mismatch=0; industry_review_candidates=0; pending_no_contact=0; unverified_sites=0; failed_sites=[]; net_fail=0; restricted_sites=0; raw_search_results=0; budget_exhausted=False
        try:
            search_session=create_http_session()
            linkedin_candidates=[]
            people_found=[]
            flat_queries=flatten_rounds(config.get('search_rounds',[]))
            signature=config.get('progress_signature','')
            saved=load_progress()
            if saved.get('signature')==signature and not saved.get('completed',False):
                resume_at=max(0,min(len(flat_queries),int(saved.get('next_query_index',0))))
            else:
                resume_at=0
            task_id=str(saved.get('task_id') or uuid.uuid4().hex) if resume_at else uuid.uuid4().hex
            diagnostics['_task_id']=task_id
            if resume_at:
                diagnostics['_paid_search_budget']['used']=max(0,min(20,max(int(saved.get('paid_calls_used',0)),paid_task_usage(DB_FILE,task_id))))
            diagnostics['scheduler']={'rounds_total':len(config.get('search_rounds',[])),
                                     'queries_total':len(flat_queries),'resumed_from':resume_at,
                                     'round_metrics':saved.get('round_metrics',{}) if resume_at else {}}
            round_metrics=diagnostics['scheduler']['round_metrics']
            # Persist the stable task id before the first search/API request. If the
            # process exits mid-request, the reservation ledger can still enforce
            # the same per-task cap after restart.
            save_progress({'signature':signature,'base_signature':config.get('base_signature',signature),
                           'rotation_signature':config.get('rotation_signature',config.get('base_signature',signature)),
                           'keyword_cycle':int(config.get('keyword_cycle',0)),
                           'next_keyword_cycle':int(config.get('keyword_cycle',0)),
                           'plan_queries':[x['query'] for x in flat_queries],
                           'next_query_index':resume_at,'completed':False,
                           'round_metrics':round_metrics,'candidate_snapshot':saved.get('candidate_snapshot',[]) if resume_at else [],
                           'paid_calls_used':int(diagnostics.get('_paid_search_budget',{}).get('used',0)), 'task_id':task_id,
                           'updated_at':time.strftime('%Y-%m-%dT%H:%M:%S')})
            if DIAGNOSTIC_DISABLE_GLOBAL_HISTORY_FILTER:
                # A/B test: ignore all historical identities, including collected/excluded
                # states. Keep same-task candidate dedupe and all normal database writes.
                known_domains, known_company_names = set(), set()
                refresh_domains, refresh_names = set(), set()
            else:
                known_domains, known_company_names = load_collected_registry()
                # Missing email or WhatsApp is an enrichment opportunity, not a reason to skip.
                refresh_domains, refresh_names = load_contact_incomplete_registry()
                known_domains.difference_update(refresh_domains)
                known_company_names.difference_update(refresh_names)
            duplicates_skipped = 0
            dedup_outcomes = {'incomplete_retried': 0, 'contact_refresh': 0, 'confirmed_excluded': 0, 'currently_reserved': 0}
            if resume_at and saved.get('candidate_snapshot'):
                for entry in saved.get('candidate_snapshot',[]):
                    if isinstance(entry,list) and len(entry)==4:
                        domain,href,title,source_query=entry
                        if domain and href: candidates[domain]=(href,title,source_query)
            # Independent WhatsApp/contact discovery is deliberately separate from
            # manufacturer qualification. It runs even when manufacturer scoring later
            # rejects every candidate, and its discovered official sites join the same
            # website/contact crawler. Direct public wa.me links are saved as unassigned
            # contact leads for later company attribution, never guessed into phone numbers.
            task_query_context = config.get('query_context', {}) or {}
            try:
                raw_terms = [x.strip() for x in re.split(r'[;；,，]+', str(config.get('keywords') or '')) if x.strip()]
                if not raw_terms:
                    raw_terms = [str(config.get('industry') or 'manufacturer')]
                # Use several distinct product/industry phrases, not only the first UI term.
                industry_term = str(config.get('industry') or '').strip()
                wa_terms = list(dict.fromkeys(raw_terms[:4] + ([industry_term] if industry_term else [])))
                country_term = str(config.get('country') or 'China')
                wa_queries = []
                for product_term in wa_terms:
                    safe_term = product_term.replace('"', ' ').strip()
                    safe_industry = industry_term.replace('"', ' ').strip()
                    wa_queries.extend([
                        f'("WhatsApp" OR "wa.me") "{safe_term}" "{country_term}" (manufacturer OR factory OR producer)',
                        f'("WhatsApp contact" OR "WhatsApp number" OR "wa.me/") "{safe_term}" "{country_term}"',
                        f'("WhatsApp" OR "wa.me") ("{safe_term}" OR "{safe_industry}") "{country_term}" (supplier OR factory)',
                    ])
                wa_queries = list(dict.fromkeys(wa_queries))[:12]
                wa_seen = set()
                direct_whatsapp_links_saved = 0
                snippet_whatsapp_rows_saved = 0
                wa_candidates_before = len(candidates)
                wa_discovery_items = []
                for wa_query in list(dict.fromkeys(wa_queries)):
                    if not self._wait_for_task_permission(): return
                    self._post_ui(lambda q=wa_query: self.status.set(f'独立 WhatsApp 公开线索搜索：{q[:85]}'))
                    wa_rows = search_web(wa_query, max_results=min(12, max(8, target)), diagnostics=diagnostics,
                                         session=search_session, search_mode=config.get('search_mode','免费优先（手动控制付费）'),
                                         exclude_domains=set())
                    for href, title in wa_rows:
                        # Search snippets can themselves contain explicitly published WhatsApp links/numbers.
                        snippet = (diagnostics.get('_search_snippets') or {}).get(href, '')
                        if snippet:
                            snippet_soup = BeautifulSoup(snippet, 'html.parser')
                            snippet_contacts = extract_contact_evidence(snippet_soup, href, country=country_term)
                            if snippet_contacts.get('whatsapp_links') or snippet_contacts.get('whatsapp_contacts'):
                                is_wa_platform = (urlparse(href).hostname or '').lower() in ('wa.me','whatsapp.com') or (urlparse(href).hostname or '').lower().endswith('.whatsapp.com')
                                snippet_result = {
                                    'company_website': '' if is_wa_platform else href, 'source_url': href, 'company_name': clean_text(title)[:200],
                                    'whatsapp_source_status': '企业归属待核验' if is_wa_platform else '搜索摘要待原网页复核',
                                    'country': country_term, 'industry': config.get('industry',''),
                                    'whatsapp_links': snippet_contacts.get('whatsapp_links', []),
                                    'whatsapp_contacts': snippet_contacts.get('whatsapp_contacts', []),
                                    'contact_evidence': {
                                        'whatsapp_links': snippet_contacts.get('whatsapp_evidence', {}),
                                        'whatsapp_contacts': snippet_contacts.get('whatsapp_evidence', {}),
                                    },
                                    'evidence_notes': {v: '搜索引擎公开摘要明确展示 WhatsApp；尚未在原网页复核' for v in (snippet_contacts.get('whatsapp_links', []) + snippet_contacts.get('whatsapp_contacts', []))},
                                    'whatsapp_source_status': '待原网页复核',
                                }
                                try:
                                    snippet_whatsapp_rows_saved += int(persist_whatsapp_discoveries(snippet_result) or 0)
                                except Exception as contact_exc:
                                    errors += 1
                                    self._post_ui(self._append_log, f'搜索摘要 WhatsApp 保存失败：{type(contact_exc).__name__}: {str(contact_exc)[:120]}')
                        parsed = urlparse(href)
                        host = (parsed.hostname or '').lower()
                        if host == 'wa.me' or host == 'whatsapp.com' or host.endswith('.whatsapp.com'):
                            direct = normalize_whatsapp_url(href)
                            if direct and whatsapp_url_has_eligible_number(direct, country=country_term):
                                direct_result = {
                                    'company_website': '', 'source_url': href, 'company_name': clean_text(title)[:200] or '搜索索引中的 WhatsApp 联系入口',
                                    'country': country_term, 'industry': config.get('industry',''),
                                    'whatsapp_links': [direct], 'whatsapp_contacts': [],
                                    'contact_evidence': {'whatsapp_links': {direct: direct}, 'whatsapp_contacts': {}},
                                    'evidence_notes': {direct: '搜索结果直接指向公开 WhatsApp 入口；企业归属待核验'},
                                    'whatsapp_source_status': '企业归属待核验',
                                }
                                try: direct_whatsapp_links_saved += int(persist_whatsapp_discoveries(direct_result) or 0)
                                except Exception as contact_exc:
                                    errors += 1
                                    self._post_ui(self._append_log, f'独立 WhatsApp 链接保存失败：{type(contact_exc).__name__}: {str(contact_exc)[:140]}')
                            continue
                        domain = root_domain(href)
                        if domain:
                            # Keep a separate WhatsApp-first queue even when this domain
                            # was already discovered by the manufacturer search.
                            wa_discovery_items.append((href, title, wa_query, ''))
                            if domain not in wa_seen:
                                wa_seen.add(domain)
                                candidates[domain] = (href, title, wa_query, '')
                wa_stats = scan_whatsapp_discovery_sites(
                    wa_discovery_items, industry=config.get('industry', ''),
                    keywords=config.get('keywords', ''), country=country_term,
                    workers=min(3, config.get('workers', 3)), cancel_event=self._stop_event)
                diagnostics['whatsapp_discovery'] = {
                    'queries': len(list(dict.fromkeys(wa_queries))),
                    'candidate_sites_added': max(0, len(candidates) - wa_candidates_before),
                    'dedicated_sites_seen': wa_stats['sites_seen'],
                    'dedicated_sites_scanned': wa_stats['sites_scanned'],
                    'dedicated_sites_failed': wa_stats['sites_failed'],
                    'whatsapp_numbers_saved': wa_stats['whatsapp_numbers_saved'],
                    'whatsapp_links_saved': wa_stats['whatsapp_links_saved'],
                    'direct_whatsapp_links_saved': direct_whatsapp_links_saved,
                    'snippet_whatsapp_rows_saved': snippet_whatsapp_rows_saved,
                    'save_errors': wa_stats['save_errors'],
                    'direct_links_saved_phase': True,
                }
                self._post_ui(self._append_log,
                    'WhatsApp独立优先核验：候选网站 {sites_seen}，已扫描 {sites_scanned}，访问失败 {sites_failed}，保存号码 {whatsapp_numbers_saved}，保存官网链接 {whatsapp_links_saved}，搜索结果直达链接保存 {direct_whatsapp_links_saved}，搜索摘要线索保存 {snippet_whatsapp_rows_saved}，保存异常 {save_errors}'.format(direct_whatsapp_links_saved=direct_whatsapp_links_saved, snippet_whatsapp_rows_saved=snippet_whatsapp_rows_saved, **wa_stats))
            except Exception as exc:
                diagnostics.setdefault('whatsapp_discovery', {})['error'] = f'{type(exc).__name__}: {str(exc)[:180]}'
                self._post_ui(self._append_log, f'独立 WhatsApp 搜索异常，常规官网核验继续：{type(exc).__name__}: {str(exc)[:180]}')


            for flat_index in range(resume_at,len(flat_queries)):
                if not self._wait_for_task_permission():
                    break
                item=flat_queries[flat_index]
                q=item['query']; qi=flat_index+1
                round_no=item['round_index']+1; intent_no=item['intent_index']+1
                self._post_ui(lambda qi=qi,n=len(flat_queries),rn=round_no,rt=len(config.get('search_rounds',[])),it=intent_no,nt=len(config.get('search_rounds',[])[item['round_index']].get('queries',[])) if item.get('round_index',0)<len(config.get('search_rounds',[])) else 13,q=q,term=item.get('active_english_term',''),cycle=int(item.get('keyword_cycle',0))+1: self.status.set(f'关键词轮换第 {cycle} 组 · {term} · 行业轮次 {rn}/{rt} · 意图 {it}/{nt} · 查询 {qi}/{n}'))
                per_query_limit=20 if config.get('all_industry') else min(50,max(20,target*3))
                query_added=0
                before_domains=set(candidates)
                interrupted_query=False
                active_excluded_domains=({registry_domain_key(x) for x in candidates}
                                         if DIAGNOSTIC_DISABLE_GLOBAL_HISTORY_FILTER
                                         else set(known_domains) | {registry_domain_key(x) for x in candidates})
                active_excluded_names=({normalize_company_key(v[1]) for v in candidates.values() if len(v)>1}
                                        if DIAGNOSTIC_DISABLE_GLOBAL_HISTORY_FILTER
                                        else set(known_company_names) | {normalize_company_key(v[1]) for v in candidates.values() if len(v)>1})
                raw_public_before=int(diagnostics.get('public_search',{}).get('raw_parsed_results',0))
                raw_paid_before=sum(int(v.get('raw_results',0)) for k,v in diagnostics.items() if k in ('serpapi','brave') and isinstance(v,dict))
                duplicates_before=int(diagnostics.get('_duplicate_search_results',0))
                pipeline_before=dict(diagnostics.get('search_pipeline',{}))
                search_rows=search_web(q,max_results=per_query_limit,diagnostics=diagnostics,session=search_session,search_mode=config.get('search_mode','免费优先（手动控制付费）'),exclude_domains=active_excluded_domains,exclude_company_names=active_excluded_names,paid_call_limit=20)
                raw_public_after=int(diagnostics.get('public_search',{}).get('raw_parsed_results',0))
                raw_paid_after=sum(int(v.get('raw_results',0)) for k,v in diagnostics.items() if k in ('serpapi','brave') and isinstance(v,dict))
                raw_search_results += max(0,raw_public_after-raw_public_before)+max(0,raw_paid_after-raw_paid_before)
                duplicates_skipped += max(0,int(diagnostics.get('_duplicate_search_results',0))-duplicates_before)
                query_history_drops=0; query_same_task_duplicates=0; query_reservation_drops=0
                web_filter_before=dict(diagnostics.get('search_web_filter',{}))
                for href,title in search_rows:
                    if self._stop_event.is_set():
                        interrupted_query=True
                        break
                    domain=root_domain(href)
                    if not domain: continue
                    if (not DIAGNOSTIC_DISABLE_GLOBAL_HISTORY_FILTER) and is_previously_collected(domain,title,known_domains,known_company_names):
                        query_history_drops += 1
                        duplicates_skipped += 1
                        record_registry_candidate(domain,title,href,q,status='previously_collected')
                        continue
                    if domain not in candidates:
                        if DIAGNOSTIC_DISABLE_GLOBAL_HISTORY_FILTER:
                            # Historical filtering is temporarily disabled. Keep same-task dedupe;
                            # save_lead()/persist_review_candidate() still persist all eligible data.
                            candidates[domain]=(href,title,q); query_added+=1
                        else:
                            reserved, reserve_reason = GLOBAL_DEDUP.reserve_candidate(
                                domain,title,href,query=q,industry=config.get('category',''),
                                source_url=href,task_id=task_id,country=config.get('country','中国'),
                                allow_collected_refresh=(registry_domain_key(domain) in refresh_domains or normalize_company_key(title) in refresh_names))
                            if not reserved:
                                query_reservation_drops += 1
                                duplicates_skipped += 1
                                if reserve_reason == 'confirmed_excluded': dedup_outcomes['confirmed_excluded'] += 1
                                elif reserve_reason == 'currently_reserved': dedup_outcomes['currently_reserved'] += 1
                                continue
                            if reserve_reason == 'retry_incomplete': dedup_outcomes['incomplete_retried'] += 1
                            elif reserve_reason == 'refresh_contacts': dedup_outcomes['contact_refresh'] += 1
                            candidates[domain]=(href,title,q); query_added+=1
                    else:
                        query_same_task_duplicates += 1
                metric_key=item['industry_code']
                metric=round_metrics.setdefault(metric_key,{'industry':item['industry'],'queries_done':0,'results_seen':0,'new_domains':0,'intent_results':{}})
                metric['queries_done']+=1
                metric['results_seen']+=query_added
                metric['new_domains']+=len(set(candidates)-before_domains)
                metric['intent_results'][item['intent']]=query_added
                record_query_performance(q,query_added)
                # Atomic checkpoint after every query: a crash may replay at most the current query.
                candidate_snapshot=[[domain,*value] for domain,value in candidates.items()]
                save_progress({'signature':signature,'base_signature':config.get('base_signature',signature),
                               'rotation_signature':config.get('rotation_signature',config.get('base_signature',signature)),
                               'keyword_cycle':int(config.get('keyword_cycle',0)),
                               'next_keyword_cycle':int(config.get('keyword_cycle',0)),
                               'plan_queries':[x['query'] for x in flat_queries],
                               'next_query_index':qi,'completed':False,
                               'round_metrics':round_metrics,'candidate_snapshot':candidate_snapshot,
                               'paid_calls_used':int(diagnostics.get('_paid_search_budget',{}).get('used',0)), 'task_id':task_id,
                               'updated_at':time.strftime('%Y-%m-%dT%H:%M:%S')})
                public_diag=diagnostics.get('public_search',{})
                tried=public_diag.get('engines_tried_this_query',[])
                engine_note='、'.join(tried[-3:]) if tried else '暂无引擎返回'
                pipeline_after=diagnostics.get('search_pipeline',{})
                parsed_delta=max(0,int(pipeline_after.get('html_parsed',0))-int(pipeline_before.get('html_parsed',0)))
                accepted_delta=max(0,int(pipeline_after.get('accepted_from_engines',0))-int(pipeline_before.get('accepted_from_engines',0)))
                filtered_delta=max(0,int(pipeline_after.get('social_or_directory',0))-int(pipeline_before.get('social_or_directory',0)))
                known_delta=max(0,int(pipeline_after.get('historical_or_known',0))-int(pipeline_before.get('historical_or_known',0)))
                dup_delta=max(0,int(pipeline_after.get('duplicate_domain_or_url',0))-int(pipeline_before.get('duplicate_domain_or_url',0)))
                web_filter_after=diagnostics.get('search_web_filter',{})
                web_dup_delta=max(0,int(web_filter_after.get('duplicate_or_history',0))-int(web_filter_before.get('duplicate_or_history',0)))
                web_filter_delta=max(0,int(web_filter_after.get('social_or_directory',0))-int(web_filter_before.get('social_or_directory',0)))
                self._post_ui(self._append_log, f'搜索数据核对 [{qi}/{len(flat_queries)}]：HTML解析 {parsed_delta} 条；搜索层接受 {accepted_delta} 条；社交/目录过滤 {filtered_delta} 条；历史/已知过滤 {known_delta} 条；搜索层重复 {dup_delta} 条；二次筛选重复/历史 {web_dup_delta} 条、目录过滤 {web_filter_delta} 条；本查询返回 {len(search_rows)} 条；历史库拦截 {query_history_drops} 条；任务内重复 {query_same_task_duplicates} 条；全局预留拒绝 {query_reservation_drops} 条；新增候选 {query_added} 家。')
                self._post_ui(self._update_query_progress,qi,len(flat_queries),len(candidates),query_added,engine_note,duplicates_skipped)
                if query_budget_reached(qi,resume_at,config.get('query_budget',120)) and qi < len(flat_queries):
                    budget_exhausted=True
                    self._post_ui(lambda done=qi,budget=config.get('query_budget',120),total=len(flat_queries): self.status.set(f'本轮搜索查询预算已用完：已执行 {done-resume_at}/{budget} 条；剩余 {total-done} 条计划已保存，重新开始可继续。'))
                    break
                if interrupted_query or self._stop_event.is_set():
                    # Replay the current query on next launch if it was interrupted mid-stream.
                    save_progress({'signature':signature,'base_signature':config.get('base_signature',signature),
                                   'rotation_signature':config.get('rotation_signature',config.get('base_signature',signature)),
                                   'keyword_cycle':int(config.get('keyword_cycle',0)),
                                   'next_keyword_cycle':int(config.get('keyword_cycle',0)),
                                   'plan_queries':[x['query'] for x in flat_queries],
                                   'next_query_index':flat_index if interrupted_query else qi-1,'completed':False,
                                   'round_metrics':round_metrics,'candidate_snapshot':[[domain,*value] for domain,value in candidates.items()],
                                   'paid_calls_used':int(diagnostics.get('_paid_search_budget',{}).get('used',0)), 'task_id':task_id,
                                   'updated_at':time.strftime('%Y-%m-%dT%H:%M:%S')})
                    self._post_ui(lambda:self.status.set('任务已停止 · 搜索进度已保存；已采集企业数据不会丢失'))
                    return
            if self._stop_event.is_set():
                self._post_ui(lambda:self.status.set('任务已停止 · 已保存当前进度和数据'))
                return
            if not budget_exhausted:
                save_progress({'signature':signature,'base_signature':config.get('base_signature',signature),
                               'rotation_signature':config.get('rotation_signature',config.get('base_signature',signature)),
                               'keyword_cycle':int(config.get('keyword_cycle',0)),
                               'next_keyword_cycle':int(config.get('keyword_cycle',0))+1,
                               'plan_queries':[x['query'] for x in flat_queries],
                               'next_query_index':len(flat_queries),'completed':True,
                               'round_metrics':round_metrics,'candidate_snapshot':[[domain,*value] for domain,value in candidates.items()],
                               'paid_calls_used':int(diagnostics.get('_paid_search_budget',{}).get('used',0)), 'task_id':task_id,
                               'updated_at':time.strftime('%Y-%m-%dT%H:%M:%S')})
            # LinkedIn enrichment is optional: its failure must never abort the
            # primary manufacturer search or the website/contact verification stage.
            try:
                people_queries = build_task_people_queries(config)
                for pq in people_queries[:6]:
                    if not self._wait_for_task_permission(): return
                    self._post_ui(lambda q=pq: self.status.set(f'发现 LinkedIn 公开职业资料：{q[:75]}'))
                    for title, profile_url in search_people_web(pq, max_results=10, diagnostics=diagnostics, session=search_session, search_mode=config.get('search_mode','免费优先（手动控制付费）')):
                        key=profile_url.rstrip('/').lower()
                        email_match=EMAIL_RE.search(title)
                        wa_link_match=WA_RE.search(title)
                        wa_number_match=re.search(r'(?i)(?:whatsapp|wa\.me)[^0-9+]{0,12}(\+?\d[\d ()-]{7,}\d)',title)
                        if not any(x.get('profile_url','').rstrip('/').lower()==key for x in people_found):
                            people_found.append({'name_title':title,'profile_url':profile_url,'search_query':pq,'identity_status':'公开职业资料线索，姓名/职位/企业关联待核验','whatsapp':wa_link_match.group(0) if wa_link_match else (wa_number_match.group(1) if wa_number_match else ''),'email':email_match.group(0) if email_match else '','official_company_url':'待匹配','notes':'来自公开搜索索引的 LinkedIn 资料；未推断未公开联系方式，不绕过登录或访问限制。'})
                if people_found:
                    self._post_ui(self._extend_people_rows, people_found)
            except Exception as exc:
                diagnostics.setdefault('linkedin_people_search', {})['last_error'] = f'{type(exc).__name__}: {str(exc)[:180]}'
                self._post_ui(self._append_log, f'LinkedIn职业资料补充搜索失败，主采集继续：{type(exc).__name__}: {str(exc)[:180]}')

            # Company-page discovery uses only distinct manufacturer queries; no people
            # searches, women-contact searches, or duplicate keyword phrases are allowed.
            try:
                linkedin_company_queries=build_linkedin_company_queries(
                    queries, task_query_context, max_queries=3
                )
                for q in linkedin_company_queries:
                    if not self._wait_for_task_permission(): return
                    lq=f'site:linkedin.com/company ({q}) (manufacturer OR factory OR manufacturing OR exporter OR OEM OR ODM OR 制造商 OR 工厂 OR 出口商)'
                    self._post_ui(lambda q=lq: self.status.set(f'LinkedIn企业主页公开索引搜索：{q[:80]}'))
                    for title,url in search_linkedin_companies(lq,max_results=min(12,max(6,target)),diagnostics=diagnostics,session=search_session,search_mode=config.get('search_mode','免费优先（手动控制付费）'),paid_call_limit=20):
                        if url not in [x[1] for x in linkedin_candidates]: linkedin_candidates.append((title,url))
            except Exception as exc:
                diagnostics.setdefault('linkedin_company_search', {})['last_status'] = '补充搜索异常，主采集继续'
                diagnostics.setdefault('linkedin_company_search', {}).setdefault('last_failure_reasons', []).append(
                    f'{type(exc).__name__}: {str(exc)[:180]}'
                )
                self._post_ui(self._append_log, f'LinkedIn企业主页补充搜索失败，主采集继续：{type(exc).__name__}: {str(exc)[:180]}')
            candidate_limit=min(1000,max(300,target*10))
            all_candidate_items=list(candidates.values())
            items=balance_candidate_items(all_candidate_items,config.get('query_context',{}),candidate_limit)
            candidate_overflow=max(0,len(all_candidate_items)-len(items))
            if candidate_overflow:
                selected_ids={root_domain(x[0]) for x in items}
                for overflow_item in all_candidate_items:
                    if root_domain(overflow_item[0]) not in selected_ids:
                        record_registry_candidate(root_domain(overflow_item[0]),overflow_item[1],overflow_item[0],overflow_item[2],status='review',reason='本轮候选核验数量达到安全上限；该候选未核验，保留待后续任务处理')
                diagnostics['candidate_queue_overflow']=candidate_overflow
                self._post_ui(self._append_log, f'候选核验队列达到本轮上限：{candidate_overflow} 个候选未进入本轮核验，已登记为待后续处理；没有计入已核验企业。')
            self._post_ui(lambda n=len(items),q=len(flat_queries): self.status.set(f'搜索阶段完成：{q} 条查询；发现 {n} 个候选网站，开始核验官网与公开联系方式'))
            # Company-specific LinkedIn discovery supplements homepage social-link extraction.
            # It uses public search only, is bounded to 20 companies, and does not spend paid API quota.
            try:
                linkedin_candidates.extend(search_linkedin_for_company_candidates(items,diagnostics,search_session,limit=8))
            except Exception as exc:
                diagnostics.setdefault('linkedin_company_search', {})['site_enrichment_error'] = f'{type(exc).__name__}: {str(exc)[:180]}'
                self._post_ui(self._append_log, f'LinkedIn企业关联补充失败，官网核验继续：{type(exc).__name__}: {str(exc)[:180]}')
            total=len(items)
            def job(item,retry=False):
                # Match the website against the industry/product terms that produced its search result.
                source_query=item[2] if len(item)>2 else ''
                ctx=config.get('query_context',{}).get(source_query,{})
                return scan_site(item[0],ctx.get('industry',config['industry']),ctx.get('keywords',config['keywords']),config['country'],timeout=(5, 8) if retry else None,relevance_terms=ctx.get('relevance_terms'),cancel_event=self._stop_event)
            if items:
                inspected=0; stop_scanning=False
                ex=ThreadPoolExecutor(max_workers=config['workers'])
                try:
                    # Submit in small batches; once target is met, do not queue hundreds of unnecessary site requests.
                    for batch_start in range(0,len(items),config['workers']):
                        if not self._wait_for_task_permission(): return
                        batch=items[batch_start:batch_start+config['workers']]
                        futures={ex.submit(job,item):item for item in batch}
                        for f in as_completed(futures):
                            if f.cancelled():
                                continue
                            if not self._wait_for_task_permission():
                                if self._stop_event.is_set():
                                    for pending in futures:
                                        if not pending.running() and not pending.done(): pending.cancel()
                                else:
                                    for pending in futures: pending.cancel()
                                    return
                            item=futures[f]; inspected+=1
                            try:
                                r=f.result(); scanned+=1
                                # Save public WhatsApp evidence before any industry/manufacturer filter.
                                try: persist_whatsapp_discoveries(r)
                                except Exception as contact_exc:
                                    errors+=1
                                    r['notes']=(r.get('notes','')+f' WhatsApp线索独立保存失败：{type(contact_exc).__name__}: {str(contact_exc)[:180]}').strip()
                                if len(item)>3 and item[3]:
                                    r['source_urls']=list(dict.fromkeys(r.get('source_urls',[])+[item[3]]))
                                    r['notes']=(r.get('notes','')+' 该官网候选由公开企业目录页面发现；目录来源已保留，官网对应关系仍建议核对。').strip()
                            except Exception as exc:
                                errors+=1
                                reason=f'官网核验异常：{type(exc).__name__}: {str(exc)[:500]}'
                                record_registry_candidate(root_domain(item[0]),item[1],item[0],item[2],status='review',reason=reason)
                                ctx=config.get('query_context',{}).get(item[2],{})
                                unverified_sites += 1
                                persist_review_candidate(item,reason,context={**ctx,'country':config.get('country','中国')},status='核验异常/待重试',persist_lead=False)
                                continue
                            if self._stop_event.is_set() or str(r.get('status','')).startswith('任务已停止'):
                                # Contacts extracted before Stop have already been persisted
                                # by scan_site; do not classify an incomplete crawl.
                                continue
                            if str(r.get('status','')).startswith('访问受限'):
                                restricted_sites+=1
                                reason=r.get('notes') or r.get('status') or '官网访问受限，尚未完成核验'
                                record_registry_candidate(root_domain(item[0]),r.get('company_name') or item[1],item[0],item[2],status='review',reason=reason)
                                ctx=config.get('query_context',{}).get(item[2],{})
                                unverified_sites += 1
                                persist_review_candidate(item,reason,context={**ctx,'country':config.get('country','中国')},status='访问受限/待核验',persist_lead=False)
                                continue
                            if str(r.get('status','')).startswith('访问失败'):
                                failed_sites.append(item); net_fail+=1
                                reason=r.get('notes') or r.get('status') or '官网网络访问失败，等待重试'
                                record_registry_candidate(root_domain(item[0]),r.get('company_name') or item[1],item[0],item[2],status='failed',reason=reason)
                                ctx=config.get('query_context',{}).get(item[2],{})
                                unverified_sites += 1
                                persist_review_candidate(item,reason,context={**ctx,'country':config.get('country','中国')},status='网络失败/待重试',persist_lead=False)
                                self._post_ui(self._append_log, f"官网访问失败：{root_domain(item[0]) or item[0]}；{reason[:420]}")
                                self._post_ui(lambda i=inspected,n=total: self.status.set(f'官网访问失败 {i}/{n}；详细原因已写入任务日志并加入低并发重试队列'))
                                continue
                            ctx=config.get('query_context',{}).get(item[2],{})
                            if r.get('industry_relevance_status') != '匹配':
                                industry_mismatch += 1
                                reason='官网已出现明确制造/生产证据，但尚未找到本次目标行业的直接匹配词；保留为行业待复核候选，不计入已确认行业制造商。匹配词：'+('、'.join(r.get('industry_relevance_terms',[])[:8]) or '无')
                                if has_reviewable_factory_evidence(r) and is_displayable_company_name(r.get('company_name') or item[1]):
                                    pending=persist_review_candidate(item,reason,context={**ctx,'country':config.get('country','中国')},status='行业待复核/制造商候选')
                                    if pending:
                                        industry_review_candidates += 1
                                        pending['manufacturer_score']=int(r.get('manufacturer_score') or 0)
                                        pending['manufacturer_evidence']=str(r.get('manufacturer_evidence') or '')
                                        pending['whatsapp_links']=list(r.get('whatsapp_links') or [])
                                        pending['whatsapp_contacts']=list(r.get('whatsapp_contacts') or [])
                                        pending['quality_reason']=reason
                                        found.append(pending)
                                        self._post_ui(self.add_result,pending,len(found),target)
                                else:
                                    record_registry_candidate(root_domain(item[0]),r.get('company_name') or item[1],item[0],item[2],status='excluded',reason=reason)
                                continue
                            r['industry_category']=ctx.get('category',config['category'])
                            li=self._match_linkedin_company(r.get('company_name',''), linkedin_candidates)
                            if li:
                                r['linkedin_links']=list(dict.fromkeys(r.get('linkedin_links',[])+[li]))[:10]
                                r['notes']=(r.get('notes','')+' LinkedIn公开公司页已按名称相似度匹配；仍需人工核对公司对应关系。').strip()
                            has_public_contact=bool(r.get('emails') or r.get('whatsapp_links') or r.get('whatsapp_contacts'))
                            export_signal=int(r.get('operation_score') or 0)>=8
                            women_query=(ctx.get('search_intent')=='women_trade_contacts')
                            broad_trade_candidate=False
                            manufacturer_candidate=is_manufacturer_candidate(r,config['min_score'])
                            quality_status, quality_reason=assess(r)
                            if quality_status == 'excluded':
                                excluded += 1
                                record_registry_candidate(root_domain(item[0]),r.get('company_name',''),item[0],item[2],status='excluded')
                                continue
                            if not has_public_contact and quality_status in ('keep','review'):
                                pending_no_contact += 1
                            broad_discovery_candidate=is_broad_discovery_candidate(r)
                            if manufacturer_candidate or is_trade_contact_candidate(r,config['min_score']) or broad_discovery_candidate:
                                if not is_displayable_company_name(r.get('company_name','')):
                                    below += 1
                                    reason='官网未能提取有效企业名称；使用搜索结果标题保留待核验线索，不作为已确认制造商'
                                    record_registry_candidate(root_domain(item[0]),item[1],item[0],item[2],status='review',reason=reason)
                                    ctx=config.get('query_context',{}).get(item[2],{})
                                    pending=persist_review_candidate(item,reason,context={**ctx,'country':config.get('country','中国')},status='名称待核验')
                                    if pending:
                                        found.append(pending); self._post_ui(self.add_result,pending,len(found),target)
                                    continue
                                if broad_trade_candidate and not manufacturer_candidate:
                                    quality_status='review'; quality_reason='存在外贸/出口信号及公开联系方式，但官网未能证明其为制造商'
                                if not manufacturer_candidate:
                                    quality_status='review'
                                    quality_reason='扩大搜索发现范围：存在制造/产品/出口或公开商务联系方式线索，尚未达到已确认制造商标准；保留待人工核验'
                                r['quality_status']=quality_status; r['quality_reason']=quality_reason
                                r['quality_category']='制造商候选' if (manufacturer_candidate and quality_status=='keep') else '潜在供应商/待人工核验'
                                if manufacturer_candidate and not has_public_contact:
                                    r['notes']=(r.get('notes','')+'；已确认制造商候选，但官网暂未公开商务联系方式；保留企业记录，联系方式后续单独补充').strip('；')
                                if women_query:
                                    r['gender_status']='女性外贸联系人候选（待人工核验）'
                                    r['decision_maker_evidence']=(r.get('decision_maker_evidence','')+'；由女性外贸职位搜索词发现，女性身份及个人联系方式归属必须人工核验').strip('；')
                                if not manufacturer_candidate:
                                    r['notes']=(r.get('notes','')+'；扩大候选发现：该记录仅为潜在供应商/联系人线索，不代表已确认制造商；邮箱与 WhatsApp 仅保留有明确公开来源的值。').strip()
                                domain=root_domain(item[0])
                                engines=diagnostics.get('domain_engine_map',{}).get(domain,[]) or [diagnostics.get('result_engine_map',{}).get(item[0],'')]
                                engines=[x for x in engines if x]
                                if engines:
                                    for engine in engines:
                                        try: record_engine_qualification(DB_FILE,engine,True)
                                        except Exception: pass
                                    r['notes']=(r.get('notes','')+f'；搜索来源引擎：{", ".join(engines)}；原始搜索词：{item[2]}').strip()
                                try:
                                    save_lead(r)
                                except Exception as db_exc:
                                    errors+=1
                                    r['notes']=(r.get('notes','')+f' 数据库保存失败：{type(db_exc).__name__}: {str(db_exc)[:180]}；本条未计入成功入库结果。').strip()
                                    record_registry_candidate(domain,r.get('company_name',''),r.get('company_website',''),item[2],status='failed',reason='主数据库保存失败：'+type(db_exc).__name__)
                                    continue
                                found.append(r)
                                self._post_ui(self.add_result,r,len(found),target)
                                if len(found)>=target:
                                    stop_scanning=True
                                    # Finish collecting this already-submitted batch so no in-flight
                                    # result is abandoned; only later batches are not submitted.
                                    for pending in futures:
                                        if pending is not f and not pending.running() and not pending.done(): pending.cancel()
                            else:
                                below += 1
                                # Industry-word matches alone are not supplier/manufacturer proof.
                                # Keep the URL in the candidate registry for diagnostics/retry, but
                                # do not pollute the visible result list or the main lead database.
                                reason=(f'官网虽命中部分行业词，但未达到制造商/工厂证据门槛 '
                                        f'（制造商评分 {r.get("manufacturer_score", 0)}）；仅保留候选诊断，不进入企业结果。')
                                record_registry_candidate(root_domain(item[0]), r.get('company_name') or item[1], item[0], item[2],
                                    status='review', reason=reason)
                            self._post_ui(lambda i=inspected,n=total,f=len(found): self.status.set(f'核验候选官网 {i}/{n}；已通过 {f}'))
                        if stop_scanning:
                            break
                finally:
                    ex.shutdown(wait=True, cancel_futures=True)
            # Retry network failures once with lower concurrency and a longer timeout.
            if failed_sites and len(found) < target:
                try:
                    retry_items=failed_sites[:max(0, target-len(found))]
                    for retry_start in range(0, len(retry_items), 2):
                        if not self._wait_for_task_permission(): break
                        retry_batch=retry_items[retry_start:retry_start+2]
                        retry_ex=ThreadPoolExecutor(max_workers=2)
                        try:
                            retry_futures={retry_ex.submit(job,item,True):item for item in retry_batch}
                            for f in as_completed(retry_futures):
                                if not self._wait_for_task_permission():
                                    for pending in retry_futures: pending.cancel()
                                    break
                                item=retry_futures[f]
                                try:
                                    r=f.result(); retry_scanned+=1
                                    try: persist_whatsapp_discoveries(r)
                                    except Exception as contact_exc:
                                        errors+=1
                                        r['notes']=(r.get('notes','')+f' WhatsApp线索独立保存失败：{type(contact_exc).__name__}: {str(contact_exc)[:180]}').strip()
                                except Exception as exc:
                                    errors+=1
                                    reason=f'官网重试异常：{type(exc).__name__}: {str(exc)[:500]}'
                                    record_registry_candidate(root_domain(item[0]),item[1],item[0],item[2],status='failed',reason=reason)
                                    ctx=config.get('query_context',{}).get(item[2],{})
                                    unverified_sites += 1
                                    persist_review_candidate(item,reason,context={**ctx,'country':config.get('country','中国')},status='重试失败/待核验',persist_lead=False)
                                    continue
                                if str(r.get('status','')).startswith(('访问失败','访问受限')):
                                    errors+=1
                                    failure_status='review' if str(r.get('status','')).startswith('访问受限') else 'failed'
                                    reason=r.get('notes') or r.get('status')
                                    self._post_ui(self._append_log, f"官网低并发重试仍失败：{root_domain(item[0]) or item[0]}；{reason[:420]}")
                                    record_registry_candidate(root_domain(item[0]),r.get('company_name') or item[1],item[0],item[2],status=failure_status,reason=reason)
                                    ctx=config.get('query_context',{}).get(item[2],{})
                                    unverified_sites += 1
                                    persist_review_candidate(item,reason,context={**ctx,'country':config.get('country','中国')},status='重试后仍不可访问/待核验',persist_lead=False)
                                    continue
                                retry_ctx=config.get('query_context',{}).get(item[2],{})
                                if r.get('industry_relevance_status') != '匹配':
                                    industry_mismatch += 1
                                    reason='重试后官网仍有制造/生产证据，但未找到本次目标行业直接匹配词；保留为行业待复核候选。'
                                    if has_reviewable_factory_evidence(r) and is_displayable_company_name(r.get('company_name') or item[1]):
                                        pending=persist_review_candidate(item,reason,context={**retry_ctx,'country':config.get('country','中国')},status='行业待复核/制造商候选')
                                        if pending:
                                            industry_review_candidates += 1
                                            pending['manufacturer_score']=int(r.get('manufacturer_score') or 0)
                                            pending['manufacturer_evidence']=str(r.get('manufacturer_evidence') or '')
                                            pending['whatsapp_links']=list(r.get('whatsapp_links') or [])
                                            pending['whatsapp_contacts']=list(r.get('whatsapp_contacts') or [])
                                            pending['quality_reason']=reason
                                            found.append(pending)
                                            self._post_ui(self.add_result,pending,len(found),target)
                                    else:
                                        record_registry_candidate(root_domain(item[0]),r.get('company_name') or item[1],item[0],item[2],status='excluded',reason=reason)
                                    continue
                                r['industry_category']=retry_ctx.get('category',config['category'])
                                has_public_contact=bool(r.get('emails') or r.get('whatsapp_links') or r.get('whatsapp_contacts'))
                                export_signal=int(r.get('operation_score') or 0)>=8
                                ctx=config.get('query_context',{}).get(item[2],{})
                                women_query=(ctx.get('search_intent')=='women_trade_contacts')
                                broad_trade_candidate=False
                                manufacturer_candidate=is_manufacturer_candidate(r,config['min_score'])
                                quality_status, quality_reason=assess(r)
                                if quality_status == 'excluded':
                                    excluded += 1
                                    record_registry_candidate(root_domain(item[0]),r.get('company_name',''),item[0],item[2],status='excluded')
                                    continue
                                if not has_public_contact and quality_status in ('keep','review'):
                                    pending_no_contact += 1
                                broad_discovery_candidate=is_broad_discovery_candidate(r)
                                if manufacturer_candidate or is_trade_contact_candidate(r,config['min_score']) or broad_discovery_candidate:
                                    if broad_trade_candidate and not manufacturer_candidate:
                                        quality_status='review'; quality_reason='存在外贸/出口信号及公开联系方式，但官网未能证明其为制造商'
                                    if not manufacturer_candidate:
                                        quality_status='review'
                                        quality_reason='扩大搜索发现范围：存在制造/产品/出口或公开商务联系方式线索，尚未达到已确认制造商标准；保留待人工核验'
                                    r['quality_status']=quality_status; r['quality_reason']=quality_reason
                                    r['quality_category']='制造商候选' if (manufacturer_candidate and quality_status=='keep') else '潜在供应商/待人工核验'
                                    if manufacturer_candidate and not has_public_contact:
                                        r['notes']=(r.get('notes','')+'；已确认制造商候选，但官网暂未公开商务联系方式；保留企业记录，联系方式后续单独补充').strip('；')
                                    if women_query:
                                        r['gender_status']='女性外贸联系人候选（待人工核验）'
                                        r['decision_maker_evidence']=(r.get('decision_maker_evidence','')+'；由女性外贸职位搜索词发现，女性身份及个人联系方式归属必须人工核验').strip('；')
                                    if not manufacturer_candidate:
                                        r['notes']=(r.get('notes','')+'；扩大候选发现：该记录仅为潜在供应商/联系人线索，不代表已确认制造商；邮箱与 WhatsApp 仅保留有明确公开来源的值。').strip()
                                    domain=root_domain(item[0])
                                    engines=diagnostics.get('domain_engine_map',{}).get(domain,[]) or [diagnostics.get('result_engine_map',{}).get(item[0],'')]
                                    engines=[x for x in engines if x]
                                    if engines:
                                        for engine in engines:
                                            try: record_engine_qualification(DB_FILE,engine,True)
                                            except Exception: pass
                                        r['notes']=(r.get('notes','')+f'；搜索来源引擎：{", ".join(engines)}；原始搜索词：{item[2]}').strip()
                                    try:
                                        save_lead(r)
                                    except Exception as db_exc:
                                        errors+=1
                                        r['notes']=(r.get('notes','')+f' 数据库保存失败：{type(db_exc).__name__}: {str(db_exc)[:180]}；本条未计入成功入库结果。').strip()
                                        record_registry_candidate(root_domain(item[0]),r.get('company_name',''),r.get('company_website',''),item[2],status='failed',reason='主数据库保存失败：'+type(db_exc).__name__)
                                        continue
                                    found.append(r)
                                    self._post_ui(self.add_result,r,len(found),target)
                                else:
                                    below += 1
                                    reason=(f'重试后官网仍未达到制造商/工厂证据门槛 '
                                            f'（制造商评分 {r.get("manufacturer_score", 0)}）；仅保留候选诊断，不进入企业主库。')
                                    record_registry_candidate(root_domain(item[0]), r.get('company_name') or item[1], item[0], item[2],
                                        status='review', reason=reason)
                        finally:
                            retry_ex.shutdown(wait=not self._stop_event.is_set(), cancel_futures=True)
                finally:
                    pass
            # Merge worker results on the Tk thread; the worker must not replace
            # the UI's shared row model while queued Treeview updates are running.
            self._post_ui(self._merge_worker_rows, found)
            valid_manufacturers=sum(1 for x in found if x.get('quality_status')=='keep')
            pending_review=sum(1 for x in found if x.get('quality_status')=='review')
            self._post_ui(self._update_summary_stats,raw_search_results,len(candidates),valid_manufacturers,pending_review,excluded,duplicates_skipped,len(linkedin_candidates),len(found))
            if not candidates:
                provider_status=diagnostics.get('provider_orchestration',{}).get('status','')
                serp=diagnostics.get('serpapi',{}); brave=diagnostics.get('brave',{})
                detail='；'.join(x for x in [f"SerpApi：{serp.get('last_error','')}",f"Brave：{brave.get('last_error','')}"] if x and not x.endswith('：'))
                free_status=diagnostics.get('public_search',{})
                free_detail='；'.join(f"{name}：{state.get('status','未知')}" for name,state in free_status.items() if isinstance(state,dict) and name in ('Bing','Qwant'))
                msg='未发现官网候选：'+(provider_status or '搜索引擎未返回可用候选。')
                if free_detail: msg+='；免费搜索诊断：'+free_detail
                if detail: msg+=' '+detail
                msg+=' 可查看网络诊断；免费搜索优先运行；不会自动消耗付费额度，只有手动切换到付费优先才调用 API。'
            elif not found: msg=f'搜索候选 {len(candidates)} 家；首次核验 {scanned} 家，失败网站重试 {retry_scanned} 次；行业证据不足 {industry_mismatch} 家（明确工厂证据待复核 {industry_review_candidates} 家）；网站未能核验 {unverified_sites} 家；有效制造商 0 家；待复核（缺少公开联系方式）{pending_no_contact} 家；排除无关 {excluded} 家；其他未达到收录条件 {below} 家；异常 {errors} 个。当前没有通过行业相关性核验的企业，请检查行业词库或稍后重试。'
            else:
                if DIAGNOSTIC_DISABLE_GLOBAL_HISTORY_FILTER:
                    duplicate_summary = f'本任务内重复搜索结果合并 {duplicates_skipped} 次（不跳过历史企业）'
                else:
                    duplicate_summary = f'历史重复/已完成记录跳过 {duplicates_skipped} 次（未完成候选重试 {dedup_outcomes["incomplete_retried"]} 次，已采集企业联系方式补采 {dedup_outcomes["contact_refresh"]} 次，确认排除 {dedup_outcomes["confirmed_excluded"]} 次，并发任务已预留 {dedup_outcomes["currently_reserved"]} 次）'
                msg=f'完成：原始去重后搜索候选 {len(candidates)} 家；首次核验 {scanned} 家，失败网站重试 {retry_scanned} 次；有效制造商 {valid_manufacturers} 家；待人工复核 {pending_review} 家（其中无公开联系方式 {pending_no_contact} 家）；行业证据不足 {industry_mismatch} 家（明确工厂证据待复核 {industry_review_candidates} 家）；网站未能核验 {unverified_sites} 家（只留在候选诊断库，不计入企业结果）；排除无关 {excluded} 家；本次新增企业 {len(found)} 家；{duplicate_summary}。LinkedIn公开公司页候选 {len(linkedin_candidates)} 个；低分 {below} 个，网络失败 {net_fail} 个，访问受限 {restricted_sites} 个，异常 {errors} 个。历史数据已保存。'
            if budget_exhausted:
                remaining=max(0,len(flat_queries)-(resume_at+int(config.get('query_budget',120))))
                msg += f'；本轮达到 {config.get("query_budget",120)} 条搜索查询预算，剩余 {remaining} 条计划已保存；再次开始采集可继续'
            msg += f'；LinkedIn公开职业资料线索 {len(people_found)} 条（姓名、职位、企业关联及联系方式按公开来源核验）'
            if DIAGNOSTIC_DISABLE_GLOBAL_HISTORY_FILTER:
                msg += f'；本任务内重复搜索结果跳过 {duplicates_skipped} 次'
                msg += '；历史重复跳过已关闭；历史库继续保存，本次不因历史企业记录而拦截采集'
            else:
                msg += f'；历史已采集企业/官网自动跳过 {duplicates_skipped} 次'
            paid_used=int(diagnostics.get('_paid_search_budget',{}).get('used',0))
            paid_month=diagnostics.get('_paid_search_budget',{}).get('monthly_used','未知')
            msg += f'；本任务付费搜索 {paid_used}/20 次（SerpApi + Brave 合计）；本月累计 {paid_month}/100 次'
            li_diag=diagnostics.get('linkedin_company_search',{})
            msg += f"；LinkedIn企业主页搜索 {li_diag.get('queries',0)} 次，成功 {li_diag.get('successes',0)} 次，失败 {li_diag.get('failures',0)} 次，命中 {li_diag.get('results',len(linkedin_candidates))} 条；{li_diag.get('last_status','未执行')}"
            if li_diag.get('last_failure_reasons'):
                msg += '；LinkedIn失败原因：' + '；'.join(li_diag['last_failure_reasons'][:3])
            self._post_ui(lambda msg=msg:self.status.set(msg))
        except Exception as e:
            msg=f'采集异常：{type(e).__name__}: {e}'
            paid_used=int(diagnostics.get('_paid_search_budget',{}).get('used',0))
            paid_month=diagnostics.get('_paid_search_budget',{}).get('monthly_used','未知')
            msg += f'；本任务付费搜索 {paid_used}/20 次（SerpApi + Brave 合计）；本月累计 {paid_month}/100 次'
            li_diag=diagnostics.get('linkedin_company_search',{})
            msg += f"；LinkedIn企业主页搜索 {li_diag.get('queries',0)} 次，成功 {li_diag.get('successes',0)} 次，失败 {li_diag.get('failures',0)} 次，命中 {li_diag.get('results',len(linkedin_candidates))} 条；{li_diag.get('last_status','未执行')}"
            if li_diag.get('last_failure_reasons'):
                msg += '；LinkedIn失败原因：' + '；'.join(li_diag['last_failure_reasons'][:3])
            self._post_ui(lambda msg=msg:self.status.set(msg))
            self._post_ui(lambda msg=msg:messagebox.showerror('采集失败',msg))
        finally:
            self._post_ui(self._finish_task_ui)

    def _finish_task_ui(self):
        self._task_active=False
        if getattr(self, 'current_task_id', ''):
            try: history_store.finish_task(HISTORY_ARCHIVE_FILE, self.current_task_id, '已完成/已停止')
            except Exception as exc: self._append_log(f'历史归档状态同步失败：{type(exc).__name__}: {exc}')
        for name,state in (('run_btn','normal'),('pause_btn','disabled'),('resume_btn','disabled'),('stop_btn','disabled')):
            widget=self.__dict__.get(name)
            if widget is not None: widget.config(state=state)
        if self.__dict__.get('search_mode_box') is not None: self.search_mode_box.config(state='readonly')

    def import_history_xlsx(self):
        path = filedialog.askopenfilename(title='选择历史采集 Excel', filetypes=[('Excel 文件','*.xlsx')])
        if not path:
            return
        try:
            result = import_legacy_xlsx_to_database(path)
            imported_rows = result.get('rows', [])
            groups = {}
            for row in imported_rows:
                key = (row.get('industry_category') or '历史导入/未分类', row.get('industry') or '历史导入/未分类', row.get('country') or '未注明')
                groups.setdefault(key, []).append(row)
            archived = 0
            for (category, industry, country), records in groups.items():
                tid = 'xlsx-' + uuid.uuid4().hex
                history_store.create_task(HISTORY_ARCHIVE_FILE, tid, category, industry, country, '历史 Excel 导入', '历史导入')
                for row in records:
                    archived += int(history_store.record_lead(HISTORY_ARCHIVE_FILE, tid, row))
                history_store.finish_task(HISTORY_ARCHIVE_FILE, tid, '导入归档完成')
            messagebox.showinfo('历史资料导入完成',
                f"新增企业：{result['imported']} 家\n更新已有企业：{result['updated']} 家\n跳过（缺少公司名称或官网）：{result['skipped']} 条\n历史归档快照：{archived} 条\n\n历史数据已按行业分类保存；当前任务结果不会混入历史企业。")
            self.stats_text.set(f"历史 Excel 已导入永久企业库，并按行业同步归档 {archived} 条；当前任务结果保持独立。")
        except Exception as exc:
            messagebox.showerror('导入失败', f'{type(exc).__name__}: {exc}')

    def verify_urls(self):
        win=tk.Toplevel(self); win.title('批量核验官网'); win.geometry('760x500')
        txt=tk.Text(win,wrap='word'); txt.pack(fill='both',expand=True,padx=10,pady=10); txt.insert('1.0','# 每行一个官网 URL\n')
        def go():
            urls=[normalize_url(x.strip()) for x in txt.get('1.0','end').splitlines() if x.strip() and not x.strip().startswith('#')]
            if not urls:
                messagebox.showwarning('没有网址','请每行粘贴一个官网网址，例如 https://example.com')
                return
            # Read every widget value before starting the worker thread.
            config={'industry':self.sub_var.get(),'keywords':self.kw.get().strip(),'country':{'中国':'China','美国':'United States','德国':'Germany','英国':'United Kingdom','全球':'Worldwide'}.get(self.country.get().strip(),self.country.get().strip()),'category':self.cat_var.get()}
            try: config['workers']=max(1,min(8,int(self.parallel.get())))
            except (ValueError,TypeError): config['workers']=4
            archive_task_id = uuid.uuid4().hex
            config['_archive_task_id'] = archive_task_id
            try:
                history_store.create_task(HISTORY_ARCHIVE_FILE, archive_task_id, config.get('category',''), config.get('industry',''), config.get('country',''), config.get('keywords',''), '网址核验')
            except Exception as exc:
                messagebox.showerror('历史归档初始化失败', f'{type(exc).__name__}: {exc}', parent=win)
                return
            self.current_task_id = archive_task_id
            self.rows=[]; self._rebuild_row_domain_index()
            for item in self.tree.get_children(''): self.tree.delete(item)
            self.results_tabs.tab(0, text='采集结果（0）')
            win.destroy(); self.run_btn.config(state='disabled'); self.status.set('正在核验粘贴的网址...')
            threading.Thread(target=self.worker_verify,args=(urls,config),daemon=True).start()
        ttk.Button(win,text='开始核验',command=go).pack(pady=8)

    def worker_verify(self,urls,config):
        archive_task_id = config.get('_archive_task_id', '')
        _ACTIVE_COLLECTION_TASK.task_id = archive_task_id
        _ACTIVE_COLLECTION_TASK.meta = {'category': config.get('category',''), 'industry': config.get('industry',''), 'country': config.get('country',''), 'keywords': config.get('keywords','')}
        self.current_task_id = archive_task_id
        new=[]; urls=list(dict.fromkeys(urls)); errors=0
        stop_event=getattr(self,'_stop_event',None)
        if stop_event is None: stop_event=threading.Event()
        try:
            workers=max(1,int(config.get('workers',2) or 2))
            pool=ThreadPoolExecutor(max_workers=workers)
            try:
                for batch_start in range(0,len(urls),workers):
                    if stop_event.is_set():
                        break
                    batch=urls[batch_start:batch_start+workers]
                    futures={pool.submit(scan_site,u,config['industry'],config['keywords'],config['country'],cancel_event=stop_event):u for u in batch}
                    for i,f in enumerate(as_completed(futures),batch_start+1):
                        if stop_event.is_set():
                            for pending in futures: pending.cancel()
                            break
                        try:
                            r=f.result()
                        except Exception:
                            errors+=1; continue
                        r['industry_category']=config['category']
                        # Save explicitly evidenced WhatsApp before any status/quality decision.
                        try:
                            persist_whatsapp_discoveries(r)
                        except Exception as contact_exc:
                            errors+=1
                            r['notes']=(r.get('notes','')+f' WhatsApp线索独立保存失败：{type(contact_exc).__name__}: {str(contact_exc)[:180]}').strip()
                        status=str(r.get('status',''))
                        if status.startswith('任务已停止'):
                            continue
                        if not status.startswith(('访问失败','访问受限')):
                            new.append(r)
                            try: save_lead(r)
                            except Exception as db_exc:
                                errors+=1; r['notes']=(r.get('notes','')+f' 数据库保存失败：{type(db_exc).__name__}').strip()
                        self._post_ui(self.add_result,r,i,len(urls))
                        self._post_ui(lambda i=i,n=len(urls):self.status.set(f'核验 {i}/{n}'))
            finally:
                pool.shutdown(wait=not stop_event.is_set(), cancel_futures=True)
            self._post_ui(self._merge_worker_rows, new)
            msg=(f'已停止：已核验 {len(new)} 条；异常 {errors} 条。' if stop_event.is_set()
                 else f'完成：核验 {len(new)} 条；异常 {errors} 条。')
            self._post_ui(lambda msg=msg:self.status.set(msg))
        except Exception as e:
            msg=f'网址核验异常：{type(e).__name__}: {e}'
            self._post_ui(lambda msg=msg:self.status.set(msg))
            self._post_ui(lambda msg=msg:messagebox.showerror('核验失败',msg))
        finally:
            self._post_ui(self._finish_task_ui)

    def _merge_worker_rows(self, items):
        """Merge worker-produced records on the Tk thread, preserving old rows."""
        by_domain={root_domain(x.get('company_website','')):x for x in self.rows if root_domain(x.get('company_website',''))}
        no_domain=[x for x in self.rows if not root_domain(x.get('company_website',''))]
        for item in items or []:
            domain=root_domain(item.get('company_website',''))
            if domain:
                previous=by_domain.get(domain)
                if previous:
                    merged=dict(previous)
                    previous_quality=merged.get('quality_status')
                    for key,value in item.items():
                        if key in ('manufacturer_score','factory_authenticity_score','operation_score','export_capability_score','contact_evidence_score'):
                            merged[key]=max(int(merged.get(key) or 0),int(value or 0))
                        elif key=='quality_status' and previous_quality=='keep' and value!='keep':
                            continue
                        elif key=='quality_reason' and previous_quality=='keep':
                            continue
                        elif value not in (None, '', [], {}, 0):
                            if isinstance(value,list) and isinstance(merged.get(key),list):
                                merged[key]=list(dict.fromkeys(merged[key]+value))
                            elif isinstance(value,dict) and isinstance(merged.get(key),dict):
                                combined=dict(merged[key]); combined.update(value); merged[key]=combined
                            else: merged[key]=value
                    item=merged
                by_domain[domain]=item
            elif item not in no_domain: no_domain.append(item)
        self.rows=list(by_domain.values())+no_domain
        self._rebuild_row_domain_index()

    def _extend_people_rows(self, items):
        known={str(x.get('profile_url','')).rstrip('/').lower() for x in self.people_rows}
        for item in items or []:
            key=str(item.get('profile_url','')).rstrip('/').lower()
            if key and key not in known:
                self.people_rows.append(item); known.add(key)

    def _update_summary_stats(self, raw_search_results=0, raw_candidates=0, valid=0, pending=0, excluded=0, duplicates=0, linkedin_hits=0, final_independent=0):
        self._last_raw_search_results=int(raw_search_results or 0)
        self._last_raw_candidates=int(raw_candidates or 0)
        self._last_excluded_count=int(excluded or 0)
        self._last_duplicates_skipped=int(duplicates or 0)
        self._last_linkedin_hits=int(linkedin_hits or 0)
        self._last_final_independent=int(final_independent or 0)
        self._refresh_whatsapp_discovery_totals()
        wa_numbers=self._contact_totals['whatsapp']
        wa_links=self._contact_totals['wa_links']
        public_phones=self._contact_totals['phones']
        dedup_stats=GLOBAL_DEDUP.stats()
        self.stats_text.set(
            f'本次原始搜索结果：{self._last_raw_search_results} 条\n'
            f'本次去重后候选企业：{self._last_raw_candidates} 家\n'
            f'本次待人工核验：{int(pending)} 家；有效制造商：{int(valid)} 家；排除企业：{self._last_excluded_count} 家\n'
            f'重复搜索结果/企业：{self._last_duplicates_skipped} 条；最终独立入库企业：{self._last_final_independent} 家\n'
            f'数据库历史企业记录：{len(self.rows)} 家；LinkedIn公开企业主页命中：{self._last_linkedin_hits} 条\n'
            f'全局去重库：{dedup_stats["total"]} 家；已确认永久去重：{dedup_stats["collected"]} 家；待核验/失败/排除：{dedup_stats["review"] + dedup_stats["failed"] + dedup_stats["excluded"]} 家\n'
            f'企业结果中的 WhatsApp 号码：{wa_numbers} 个；链接：{wa_links} 条；普通电话：{public_phones} 个\n'
            f'独立 WhatsApp 线索库：号码 {self._contact_totals.get("discovery_numbers",0)} 个；链接 {self._contact_totals.get("discovery_links",0)} 条'
        )

    def add_result(self,r,i,total):
        # Keep the in-memory export model synchronized with rows inserted into the
        # Treeview. Previously the UI showed live results while self.rows stayed
        # empty until the worker finished, so clicking Export displayed
        # "请先采集或核验" despite visible records.
        domain = root_domain(r.get('company_website',''))
        old_row = None
        if domain:
            index = self._row_domain_index.get(domain)
            if index is not None and 0 <= index < len(self.rows):
                old_row = self.rows[index]
                merged=dict(old_row)
                previous_quality=merged.get('quality_status')
                for key,value in r.items():
                    if key in ('manufacturer_score','factory_authenticity_score','operation_score','export_capability_score','contact_evidence_score'):
                        merged[key]=max(int(merged.get(key) or 0),int(value or 0))
                    elif key=='quality_status' and previous_quality=='keep' and value!='keep':
                        continue
                    elif key=='quality_reason' and previous_quality=='keep':
                        continue
                    elif value not in (None, '', [], {}, 0):
                        if isinstance(value,list) and isinstance(merged.get(key),list):
                            merged[key]=list(dict.fromkeys(merged[key]+value))
                        elif isinstance(value,dict) and isinstance(merged.get(key),dict):
                            combined=dict(merged[key]); combined.update(value); merged[key]=combined
                        else:
                            merged[key]=value
                r=merged
                self.rows[index] = r
            else:
                self._row_domain_index[domain] = len(self.rows)
                self.rows.append(r)
        elif r not in self.rows:
            self.rows.append(r)
        else:
            old_row = r
        # Classify each newly acquired or restored row immediately for visible feedback.
        if not r.get('quality_status'):
            quality_status, quality_reason=assess(r)
            r['quality_status']=quality_status
            r['quality_category']=('制造商候选' if quality_status=='keep' else ('无关/隔离' if quality_status=='excluded' else '待人工复核'))
            r['quality_reason']=quality_reason
        elif r.get('quality_status')=='excluded':
            r['quality_category']='无关/隔离'
        self._adjust_cached_row_metrics(old_row, -1)
        self._adjust_cached_row_metrics(r, 1)
        display_status=r.get('quality_category') or r.get('status','')
        display_notes=r.get('notes','')
        if r.get('quality_warning'):
            display_notes=(display_notes+'；数据质量提醒：'+r['quality_warning']).strip('；')
        values=(r.get('company_name',''),r.get('company_website',''),r.get('company_address','') or '未获取',r.get('industry',''),r.get('factory_authenticity_score',0),r.get('export_capability_score',0),r.get('contact_evidence_score',0),'\n'.join(r.get('whatsapp_contacts',[])[:6]) or '未发现','\n'.join(r.get('whatsapp_links',[])[:6]) or '未发现','\n'.join(r.get('emails',[])[:5]) or '未发现','\n'.join(f"{d.get('role_label','')} / {d.get('email_score',0)}分" for d in r.get('email_details',[])[:5]) or '未发现','\n'.join(r.get('phone_candidates',[])[:6]) or '未发现','\n'.join(r.get('linkedin_links',[])[:4]) or '未发现',r.get('gender_status','未知/未核实'),display_status,display_notes)
        iid=root_domain(r.get('company_website','')) or str(i)
        if self.tree.exists(iid):
            self.tree.item(iid,values=values)
        else:
            self.tree.insert('','end',iid=iid,values=values)
        if hasattr(self, 'results_tabs'):
            self.results_tabs.tab(0, text=f'采集结果（{len(self.tree.get_children(""))}）')
        if hasattr(self, 'count_label'):
            self.count_label.configure(text=f'企业总记录：{len(self.rows)} 家   |   有效制造商：{self._row_counts["keep"]} 家   |   待复核：{self._row_counts["review"]} 家')
        if hasattr(self, 'stats_text'):
            self._refresh_whatsapp_discovery_totals()
            wa_numbers=self._contact_totals['whatsapp']
            wa_links=self._contact_totals['wa_links']
            public_phones=self._contact_totals['phones']
            self.stats_text.set(
                f'本次去重后搜索候选：{self._last_raw_candidates} 家\n'
                f'企业数据库当前记录：{len(self.rows)} 家\n'
                f'有效制造商：{self._row_counts["keep"]} 家；待人工复核：{self._row_counts["review"]} 家；排除无关：{self._last_excluded_count} 家\n'
                f'{"本任务内重复搜索结果合并" if DIAGNOSTIC_DISABLE_GLOBAL_HISTORY_FILTER else "历史重复跳过"}：{self._last_duplicates_skipped} 次；LinkedIn公开企业主页命中：{self._last_linkedin_hits} 条\n'
                f'企业结果中的 WhatsApp 号码：{wa_numbers} 个；链接：{wa_links} 条；普通电话：{public_phones} 个\n'
                f'独立 WhatsApp 线索库：号码 {self._contact_totals.get("discovery_numbers",0)} 个；链接 {self._contact_totals.get("discovery_links",0)} 条\n'
                '说明：普通电话不会自动认定为 WhatsApp。'
            )

    def show_whatsapp_discoveries(self):
        """Show the independent WhatsApp ledger, including contacts from unqualified sites."""
        win=tk.Toplevel(self)
        win.title('独立 WhatsApp 公开线索')
        win.geometry('1120x620')
        frame=tk.Frame(win); frame.pack(fill='both',expand=True,padx=10,pady=10)
        cols=('name','domain','type','value','source','evidence','last_seen')
        tree=ttk.Treeview(frame,columns=cols,show='headings')
        labels={'name':'企业/页面名称','domain':'域名','type':'类型','value':'WhatsApp号码/链接','source':'证据来源网页','evidence':'证据说明','last_seen':'最近发现'}
        widths={'name':170,'domain':150,'type':125,'value':210,'source':250,'evidence':180,'last_seen':135}
        for col in cols:
            tree.heading(col,text=labels[col]); tree.column(col,width=widths[col],minwidth=80,stretch=True)
        y=ttk.Scrollbar(frame,orient='vertical',command=tree.yview); x=ttk.Scrollbar(frame,orient='horizontal',command=tree.xview)
        tree.configure(yscrollcommand=y.set,xscrollcommand=x.set)
        tree.pack(side='left',fill='both',expand=True); y.pack(side='right',fill='y'); x.pack(side='bottom',fill='x')
        try:
            con=sqlite3.connect(DB_FILE,timeout=10)
            try:
                rows=con.execute("SELECT company_name,domain,whatsapp_type,whatsapp_value,source_url,evidence,last_seen FROM whatsapp_discoveries ORDER BY last_seen DESC").fetchall()
            finally: con.close()
            for row in rows: tree.insert('','end',values=row)
            self._refresh_whatsapp_discovery_totals()
            self.status.set(f'独立 WhatsApp 线索库：显示 {len(rows)} 条；号码和链接均保留来源证据')
        except sqlite3.Error as exc:
            messagebox.showerror('读取 WhatsApp 线索失败',str(exc),parent=win)

    def export_whatsapp_discoveries_csv(self):
        """Export every explicitly evidenced WhatsApp discovery, including unqualified sites."""
        path=filedialog.asksaveasfilename(title='导出独立 WhatsApp 线索 CSV',defaultextension='.csv',filetypes=[('CSV','*.csv')],initialfile='外贸达人_WhatsApp独立线索.csv')
        if not path: return
        try:
            con=sqlite3.connect(DB_FILE,timeout=30)
            try:
                rows=con.execute('''SELECT company_name,domain,website,country,industry,whatsapp_type,whatsapp_value,source_url,evidence,first_seen,last_seen,status
                    FROM whatsapp_discoveries ORDER BY last_seen DESC''').fetchall()
            finally: con.close()
            fields=['企业名称/页面标题','网站域名','官网','目标国家','任务行业','联系方式类型','WhatsApp号码/链接','证据来源页面','证据说明','首次发现','最近发现','状态']
            with open(path,'w',encoding='utf-8-sig',newline='') as f:
                w=csv.writer(f); w.writerow(fields); w.writerows([[safe_spreadsheet_cell(v) for v in row] for row in rows])
            messagebox.showinfo('导出成功',f'独立 WhatsApp 线索已导出：{len(rows)} 条\n来源证据已一并保留。\n{path}')
        except Exception as exc:
            messagebox.showerror('导出失败',str(exc))


    def show_people(self):
        win=tk.Toplevel(self); win.title('女性外贸商务人员公开职业资料候选'); win.geometry('1120x560')
        ttk.Label(win,text='此列表仅保留搜索结果标题中明确出现邮箱或 WhatsApp 联系方式的公开职业资料候选；女性身份、职位和联系方式归属仍需人工核验。',wraplength=1080).pack(anchor='w',padx=10,pady=8)
        cols=('title','profile','query','identity','wa','email','company','notes')
        tree=ttk.Treeview(win,columns=cols,show='headings')
        labels={'title':'搜索结果标题','profile':'LinkedIn 公开资料链接','query':'搜索依据','identity':'身份核验状态','wa':'WhatsApp','email':'公开邮箱','company':'企业官网匹配','notes':'说明'}
        widths={'title':210,'profile':230,'query':230,'identity':160,'wa':150,'email':190,'company':130,'notes':240}
        for c in cols: tree.heading(c,text=labels[c]); tree.column(c,width=widths[c],stretch=True)
        ys=ttk.Scrollbar(win,orient='vertical',command=tree.yview); tree.configure(yscrollcommand=ys.set)
        tree.pack(side='left',fill='both',expand=True,padx=(10,0),pady=(0,10)); ys.pack(side='right',fill='y',padx=(0,10),pady=(0,10))
        for r in self.people_rows:
            tree.insert('','end',values=(r.get('name_title',''),r.get('profile_url',''),r.get('search_query',''),r.get('identity_status','待核实'),r.get('whatsapp',''),r.get('email',''),r.get('official_company_url','待匹配'),r.get('notes','')))
        if not self.people_rows: self.status.set('尚无公开个人职业线索；请启用女性外贸联系人搜索后开始采集。')

    def export_people_csv(self):
        if not self.people_rows: messagebox.showinfo('暂无个人线索','请启用女性外贸联系人搜索并运行自动采集。'); return
        path=filedialog.asksaveasfilename(title='导出公开个人职业线索 CSV',defaultextension='.csv',filetypes=[('CSV','*.csv')],initialfile='外贸达人_公开个人职业线索.csv')
        if not path:return
        fields=['搜索结果标题','公开职业资料链接','公开WhatsApp','公开邮箱','来源搜索词','身份核验状态']
        try:
            with open(path,'w',encoding='utf-8-sig',newline='') as f:
                w=csv.writer(f); w.writerow(fields)
                for r in self.people_rows:
                    wa=r.get('whatsapp','')
                    email=r.get('email','')
                    if not isinstance(email,str) or not clean_email_candidate(email): email=''
                    w.writerow([safe_spreadsheet_cell(v) for v in [r.get('name_title',''),r.get('profile_url',''),wa,email,r.get('search_query',''),r.get('identity_status','待人工核验')]])
            messagebox.showinfo('导出成功','公开个人职业资料候选及来源已保存：\n'+path)
        except Exception as e: messagebox.showerror('导出失败',str(e))

    @staticmethod
    def _simple_export_row(r):
        """Export complete, company-bound business contact and provenance fields."""
        company = r.get('company_name') or r.get('name_title') or r.get('page_title') or ''
        wa_links=[]
        for link in r.get('whatsapp_links',[]) or []:
            link=str(link).strip()
            if re.search(r'(?:wa\.me/|whatsapp\.com/)',link,re.I):
                normalized=normalize_whatsapp_url(link)
                if normalized and whatsapp_url_has_eligible_number(normalized, country=r.get('country') or '中国') and normalized not in wa_links: wa_links.append(normalized)
        wa_numbers=[]
        for number in r.get('whatsapp_contacts',[]) or []:
            value=normalize_whatsapp_number_display(number, country=r.get('country') or '中国')
            if value and value not in wa_numbers: wa_numbers.append(value)
        phones=[]
        wa_digits={re.sub(r'\D','',x) for x in wa_numbers}
        for link in wa_links:
            match=re.search(r'(?:wa\.me/|[?&]phone=)([+\d]+)',link,re.I)
            if match: wa_digits.add(re.sub(r'\D','',match.group(1)))
        for number in r.get('phone_candidates',[]) or []:
            value=clean_phone_candidate(str(number),'')
            digits=re.sub(r'\D','',str(number))
            if value and digits not in wa_digits and value not in phones: phones.append(value)
        emails=[]
        for item in r.get('emails',[]) or []:
            value=clean_email_candidate(str(item))
            if value and value not in emails: emails.append(value)
        sources=list(dict.fromkeys(str(x) for x in (r.get('source_urls') or []) if str(x).startswith(('http://','https://'))))
        linkedin=list(dict.fromkeys(str(x) for x in (r.get('linkedin_links') or []) if str(x).startswith(('http://','https://'))))
        evidence=r.get('contact_evidence') or {}
        wa_number_sources=list(dict.fromkeys(str((evidence.get('whatsapp_contacts') or {}).get(x,'')) for x in wa_numbers if (evidence.get('whatsapp_contacts') or {}).get(x,'')))
        wa_link_sources=list(dict.fromkeys(str((evidence.get('whatsapp_links') or {}).get(x,'')) for x in wa_links if (evidence.get('whatsapp_links') or {}).get(x,'')))
        return [safe_spreadsheet_cell(x) for x in [
            company, r.get('company_website',''), r.get('company_address',''), r.get('address_source_url',''),
            '; '.join(wa_numbers), '; '.join(wa_number_sources), '; '.join(wa_links), '; '.join(wa_link_sources),
            '; '.join(emails), '; '.join(phones), '; '.join(linkedin), '; '.join(sources),
            r.get('status',''), r.get('quality_category') or r.get('quality_status',''), r.get('notes',''), r.get('collected_at','')]]

    @staticmethod
    def _load_quality_quarantine():
        try:
            with open(QUALITY_QUARANTINE_FILE,encoding='utf-8') as f:
                value=json.load(f)
            return value if isinstance(value,list) else []
        except Exception:
            return []

    def _save_quality_quarantine(self):
        temp=QUALITY_QUARANTINE_FILE+'.tmp'
        with open(temp,'w',encoding='utf-8') as f:
            json.dump(self.quality_quarantine,f,ensure_ascii=False,indent=2)
        os.replace(temp,QUALITY_QUARANTINE_FILE)

    def _append_quality_quarantine(self, items):
        # Use the complete record fingerprint, not only company name/domain;
        # otherwise multiple distinct duplicate rows from one company would be lost.
        known={json.dumps(x,ensure_ascii=False,sort_keys=True,default=str) for x in self.quality_quarantine}
        for item in items:
            fingerprint=json.dumps(item,ensure_ascii=False,sort_keys=True,default=str)
            if fingerprint not in known:
                self.quality_quarantine.append(item); known.add(fingerprint)
        self._save_quality_quarantine()

    def apply_quality_filter(self):
        if not self.rows:
            messagebox.showinfo('暂无结果','请先采集或核验。'); return
        self._quality_original_rows=list(self.rows)
        accepted, quarantine, stats=clean_and_dedupe(self.rows)
        self.rows=accepted
        self._rebuild_row_domain_index()
        self._append_quality_quarantine(quarantine)
        self.quality_review=[r for r in accepted if r.get('quality_status')=='review']
        for item in self.tree.get_children(): self.tree.delete(item)
        for i,r in enumerate(reversed(self.rows),1): self.add_result(r,i,len(self.rows))
        self.status.set(f"筛选完成：保留 {stats['accepted']} 条（其中待复核 {stats['review']}），排除/重复隔离 {stats['quarantined']} 条")
        messagebox.showinfo('自动筛选与去重完成',
            f"原始记录：{stats['input']} 条\n可保留候选：{stats['accepted']} 条\n待人工复核：{stats['review']} 条\n排除/重复隔离：{stats['quarantined']} 条\n合并重复企业：{stats['duplicate_rows_merged']} 条\n邮箱格式异常：{stats['invalid_emails']} 个\n邮箱域名不匹配提醒：{stats['email_domain_conflicts']} 条\n\n原始数据未删除，可在‘查看隔离/恢复’中恢复。")

    def show_quality_quarantine(self):
        win=tk.Toplevel(self); win.title('隔离记录 / 重复记录（可恢复）'); win.geometry('900x520'); win.transient(self)
        ttk.Label(win,text=f'隔离记录：{len(self.quality_quarantine)} 条。这里只做隔离，不永久删除。').pack(anchor='w',padx=12,pady=8)
        cols=('name','status','reason'); tree=ttk.Treeview(win,columns=cols,show='headings')
        for c,t,w in [('name','企业/记录名称',360),('status','处理状态',130),('reason','隔离原因',360)]: tree.heading(c,text=t); tree.column(c,width=w)
        tree.pack(fill='both',expand=True,padx=12,pady=6)
        for i,item in enumerate(self.quality_quarantine):
            r=item.get('record',{}); name=r.get('company_name') or r.get('工厂/公司名称') or r.get('name_title') or ''
            tree.insert('','end',iid=str(i),values=(name,item.get('quality_status',''),item.get('quality_reason','')))
        def restore_selected():
            chosen=tree.selection()
            if not chosen: messagebox.showinfo('请选择记录','先选择需要恢复的记录。',parent=win); return
            indexes=sorted((int(x) for x in chosen),reverse=True)
            for idx in indexes:
                item=self.quality_quarantine.pop(idx); self.rows.append(item.get('record',{}))
            self._rebuild_row_domain_index()
            self._save_quality_quarantine()
            for item in tree.get_children(): tree.delete(item)
            for i,item in enumerate(self.quality_quarantine):
                r=item.get('record',{}); tree.insert('','end',iid=str(i),values=(r.get('company_name') or r.get('工厂/公司名称') or r.get('name_title') or '',item.get('quality_status',''),item.get('quality_reason','')))
            for item in self.tree.get_children(): self.tree.delete(item)
            for i,r in enumerate(reversed(self.rows),1): self.add_result(r,i,len(self.rows))
            self.status.set(f'已恢复 {len(indexes)} 条记录；恢复的数据仍可再次筛选')
        ttk.Button(win,text='恢复选中记录',command=restore_selected).pack(anchor='e',padx=12,pady=8)

    def _ensure_rows_for_export(self):
        """Exports are scoped strictly to the current task; history is exported from the archive viewer."""
        if not self.rows:
            messagebox.showinfo('当前任务没有结果', '当前任务结果为空。历史数据请从“历史记录（按行业）”中选择任务查看和导出。')
            return False
        return True

    def export_rows(self):
        self._ensure_rows_for_export()
        fields=['公司名称','官方网站','公司地址','地址来源网址','WhatsApp号码（明确标注）','WhatsApp号码证据网址','WhatsApp联系链接','WhatsApp链接证据网址','公开邮箱','公开电话（非WhatsApp）','LinkedIn企业主页','采集来源网址','访问/核验状态','制造商分类','核验说明','采集时间']
        # Only records with positive manufacturer signals enter the simple export.
        # Review/excluded/duplicate records remain in the app for later restoration.
        if not self.rows:
            return fields, []
        accepted, quarantine, stats=clean_and_dedupe(self.rows)
        if self.__dict__.get('quality_quarantine') is not None and quarantine:
            self._append_quality_quarantine(quarantine)
        exportable=[r for r in accepted if r.get('quality_status') in ('keep','review')]
        self.quality_review=[r for r in accepted if r.get('quality_status')=='review']
        return fields, [self._simple_export_row(r) for r in exportable]

    @staticmethod
    def _compact_export_row(r):
        """Create the requested concise contact sheet while retaining evidence in SQLite."""
        company=str(r.get('company_name') or r.get('name_title') or r.get('page_title') or '')
        website=str(r.get('company_website') or '')
        wa_values=[]
        for value in (r.get('whatsapp_contacts') or []):
            cleaned=normalize_whatsapp_number_display(value, country=r.get('country') or '中国')
            if cleaned and cleaned not in wa_values: wa_values.append(cleaned)
        for value in (r.get('whatsapp_links') or []):
            normalized=normalize_whatsapp_url(str(value))
            if normalized and whatsapp_url_has_eligible_number(normalized, country=r.get('country') or '中国') and normalized not in wa_values: wa_values.append(normalized)
        phones=[]
        for value in (r.get('phone_candidates') or []):
            cleaned=clean_phone_candidate(str(value),'')
            if cleaned and cleaned not in phones: phones.append(cleaned)
        emails=[]
        for value in (r.get('emails') or []):
            cleaned=clean_email_candidate(str(value))
            if cleaned and cleaned not in emails: emails.append(cleaned)
        evidence=r.get('contact_evidence') or {}
        email_sources=evidence.get('emails') or {}
        verified=[]
        details=r.get('email_details') or []
        for detail in details:
            if not isinstance(detail,dict): continue
            email=clean_email_candidate(str(detail.get('email') or ''))
            source=str(detail.get('public_source_url') or email_sources.get(email,'') or '')
            if email and source.startswith(('http://','https://')):
                entry=f'{email}（来源：{source}）'
                if entry not in verified: verified.append(entry)
        if not verified:
            for email in emails:
                source=str(email_sources.get(email,'') or '')
                if source.startswith(('http://','https://')):
                    verified.append(f'{email}（来源：{source}）')
        return [safe_spreadsheet_cell(x) for x in [company,website,'；'.join(wa_values),'；'.join(phones),'; '.join(emails),'；'.join(verified)]]

    def compact_export_rows(self):
        self._ensure_rows_for_export()
        fields=['公司名称','官方网站','WhatsApp联系方式（明确链接/标注号码）','公开商务电话（非WhatsApp）','公开邮箱','有来源依据的商务邮箱（含来源网址）']
        accepted,quarantine,_=clean_and_dedupe(self.rows or [])
        if self.__dict__.get('quality_quarantine') is not None and quarantine:
            self._append_quality_quarantine(quarantine)
        exportable=[r for r in accepted if r.get('quality_status') in ('keep','review')]
        return fields,[self._compact_export_row(r) for r in exportable]

    def export_compact_csv(self):
        if not self._ensure_rows_for_export():
            messagebox.showinfo('暂无结果','请先采集或核验。'); return
        path=filedialog.asksaveasfilename(title='导出简洁商务联系表 CSV',defaultextension='.csv',filetypes=[('CSV','*.csv')],initialfile='外贸达人_简洁商务联系表.csv')
        if not path: return
        fields,rows=self.compact_export_rows()
        if not rows:
            messagebox.showinfo('暂无可导出记录','当前没有有效制造商或待复核企业记录。'); return
        try:
            with open(path,'w',encoding='utf-8-sig',newline='') as f:
                writer=csv.writer(f); writer.writerow(fields); writer.writerows(rows)
            messagebox.showinfo('导出成功','简洁商务联系表已保存；详细来源证据仍保存在软件数据库中：\n'+path)
        except Exception as exc:
            messagebox.showerror('导出失败',f'{type(exc).__name__}: {exc}')

    def export_compact_xlsx(self):
        if not self._ensure_rows_for_export():
            messagebox.showinfo('暂无结果','请先采集或核验。'); return
        try: import openpyxl
        except ImportError:
            messagebox.showerror('缺少依赖','请运行启动文件自动安装依赖。'); return
        path=filedialog.asksaveasfilename(title='导出简洁商务联系表 Excel',defaultextension='.xlsx',filetypes=[('Excel','*.xlsx')],initialfile='外贸达人_简洁商务联系表.xlsx')
        if not path: return
        fields,rows=self.compact_export_rows()
        if not rows:
            messagebox.showinfo('暂无可导出记录','当前没有有效制造商或待复核企业记录。'); return
        try:
            wb=openpyxl.Workbook(); ws=wb.active; ws.title='简洁商务联系表'; ws.append(fields)
            for row in rows: ws.append(row)
            ws.freeze_panes='A2'; ws.auto_filter.ref=ws.dimensions; ws.sheet_view.showGridLines=False
            for col,width in {'A':30,'B':40,'C':42,'D':28,'E':38,'F':70}.items(): ws.column_dimensions[col].width=width
            for cell in ws[1]:
                cell.font=openpyxl.styles.Font(name='Microsoft YaHei',bold=True,color='FFFFFF')
                cell.fill=openpyxl.styles.PatternFill('solid',fgColor='1F4E78')
                cell.alignment=openpyxl.styles.Alignment(horizontal='center',vertical='center',wrap_text=True)
            for row in ws.iter_rows(min_row=2):
                for cell in row:
                    cell.alignment=openpyxl.styles.Alignment(vertical='top',wrap_text=True)
                    if isinstance(cell.value,str) and cell.value.startswith(('http://','https://')):
                        cell.hyperlink=cell.value; cell.style='Hyperlink'
            wb.save(path)
            messagebox.showinfo('导出成功','简洁商务联系表 Excel 已保存；详细来源证据仍保存在软件数据库中：\n'+path)
        except Exception as exc:
            messagebox.showerror('导出失败',f'{type(exc).__name__}: {exc}')

    def export_csv(self):
        if not self._ensure_rows_for_export(): messagebox.showinfo('暂无结果','请先采集或核验。'); return
        path=filedialog.asksaveasfilename(title='导出完整公司与商务联系资料 CSV',defaultextension='.csv',filetypes=[('CSV','*.csv')],initialfile='外贸达人_完整公司与联系人.csv')
        if not path:return
        fields,rows=self.export_rows()
        if not rows:
            messagebox.showinfo('暂无合格制造商','当前没有可导出的企业记录。请先采集或查看隔离记录。'); return
        try:
            with open(path,'w',encoding='utf-8-sig',newline='') as f:
                w=csv.writer(f); w.writerow(fields); w.writerows(rows)
            messagebox.showinfo('导出成功','完整公司与商务联系资料已保存，包含官网、地址、WhatsApp、邮箱、电话及来源：\n'+path)
        except Exception as e: messagebox.showerror('导出失败',str(e))

    def export_xlsx(self):
        if not self._ensure_rows_for_export(): messagebox.showinfo('暂无结果','请先采集或核验。'); return
        try: import openpyxl
        except ImportError: messagebox.showerror('缺少依赖','请运行启动文件自动安装依赖。'); return
        path=filedialog.asksaveasfilename(title='导出完整公司与商务联系资料 Excel',defaultextension='.xlsx',filetypes=[('Excel','*.xlsx')],initialfile='外贸达人_完整公司与联系人.xlsx')
        if not path:return
        fields,rows=self.export_rows()
        if not rows:
            messagebox.showinfo('暂无合格制造商','当前没有可导出的企业记录。请先采集或查看隔离记录。'); return
        wb=openpyxl.Workbook(); ws=wb.active; ws.title='公司与商务联系资料'; ws.append(fields)
        for r in rows: ws.append(r)
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
        from openpyxl.utils import get_column_letter
        header_fill=PatternFill('solid',fgColor='1F4E78')
        header_font=Font(name='Microsoft YaHei',bold=True,color='FFFFFF',size=10)
        body_font=Font(name='Microsoft YaHei',size=10,color='1F2937')
        thin=Side(style='hair',color='D9E2F3')
        for cell in ws[1]:
            cell.fill=header_fill; cell.font=header_font
            cell.alignment=Alignment(horizontal='center',vertical='center',wrap_text=True)
            cell.border=Border(bottom=Side(style='medium',color='5B9BD5'))
        ws.row_dimensions[1].height=32
        for row_idx in range(2,ws.max_row+1):
            ws.row_dimensions[row_idx].height=48
            for cell in ws[row_idx]:
                cell.font=body_font; cell.alignment=Alignment(vertical='top',wrap_text=True)
                cell.border=Border(bottom=thin)
                if isinstance(cell.value,str) and cell.value.startswith(('https://','http://')):
                    cell.hyperlink=cell.value; cell.style='Hyperlink'
        ws.freeze_panes='A2'; ws.auto_filter.ref=ws.dimensions
        ws.sheet_view.showGridLines=False
        widths={'A':30,'B':38,'C':38,'D':38,'E':24,'F':42,'G':38,'H':42,'I':32,'J':23,'K':36,'L':48,'M':22,'N':18,'O':48,'P':22}
        for col,width in widths.items(): ws.column_dimensions[col].width=width
        ws.sheet_properties.pageSetUpPr.fitToPage=True
        ws.page_setup.fitToWidth=1; ws.page_setup.fitToHeight=0; ws.page_setup.orientation='landscape'
        ws.print_title_rows='1:1'
        try:
            wb.save(path)
        except Exception as exc:
            messagebox.showerror('导出失败',f'{type(exc).__name__}: {exc}')
            return
        messagebox.showinfo('导出成功','Excel 已按公司资料列宽、自动换行、筛选、冻结表头和超链接格式导出：\n'+path)

    def open_history_archive_folder(self):
        """Open the folder containing the single canonical history archive file."""
        try:
            if os.name == 'nt':
                os.startfile(USER_DATA_DIR)
            else:
                import subprocess
                subprocess.Popen(['xdg-open', USER_DATA_DIR])
        except Exception as exc:
            messagebox.showerror('无法打开归档文件夹', f'历史归档文件位置：\n{HISTORY_ARCHIVE_FILE}\n\n{type(exc).__name__}: {exc}')

    def show_history_archive(self):
        win=tk.Toplevel(self); win.title('历史采集归档（按行业分类）'); win.geometry('1120x650'); win.transient(self)
        ttk.Label(win,text=f'历史记录独立保存在一个归档数据库文件中：{HISTORY_ARCHIVE_FILE}',wraplength=1050).pack(anchor='w',padx=12,pady=8)
        bar=ttk.Frame(win); bar.pack(fill='x',padx=12,pady=5)
        ttk.Label(bar,text='行业大类：').pack(side='left')
        categories=['全部行业'] + history_store.list_categories(HISTORY_ARCHIVE_FILE)
        cat_var=tk.StringVar(value='全部行业')
        cat_box=ttk.Combobox(bar,textvariable=cat_var,values=categories,state='readonly',width=28); cat_box.pack(side='left',padx=6)
        ttk.Button(bar,text='打开归档文件夹',command=self.open_history_archive_folder).pack(side='right',padx=4)
        tasks=ttk.Treeview(win,columns=('date','category','industry','country','type','count','status'),show='headings',height=8)
        for c,t,w in [('date','任务时间',145),('category','行业大类',130),('industry','细分行业',180),('country','目标国家',100),('type','任务类型',90),('count','记录数',70),('status','状态',110)]:
            tasks.heading(c,text=t); tasks.column(c,width=w,anchor='w')
        tasks.pack(fill='x',padx=12,pady=5)
        ttk.Label(win,text='所选任务企业记录：').pack(anchor='w',padx=12)
        cols=('company','website','industry','country','quality','whatsapp','email')
        leads=ttk.Treeview(win,columns=cols,show='headings')
        for c,t,w in [('company','企业名称',190),('website','官网',220),('industry','细分行业',140),('country','目标国家',90),('quality','分类状态',110),('whatsapp','WhatsApp',150),('email','公开邮箱',180)]:
            leads.heading(c,text=t); leads.column(c,width=w,anchor='w')
        leads.pack(fill='both',expand=True,padx=12,pady=5)
        task_map={}
        def refresh_tasks(*_):
            for item in tasks.get_children(): tasks.delete(item)
            task_map.clear()
            for rec in history_store.list_tasks(HISTORY_ARCHIVE_FILE,cat_var.get()):
                tid,created,category,industry,country,kind,count,status=rec
                iid=tasks.insert('','end',values=(created,category,industry,country,kind,count,status))
                task_map[iid]=tid
            for item in leads.get_children(): leads.delete(item)
        def show_task(_event=None):
            selected=tasks.selection()
            if not selected: return
            for item in leads.get_children(): leads.delete(item)
            for idx,row in enumerate(history_store.list_task_leads(HISTORY_ARCHIVE_FILE,task_map[selected[0]])):
                wa='; '.join((row.get('whatsapp_contacts') or []) + (row.get('whatsapp_links') or []))
                email='; '.join(row.get('emails') or [])
                leads.insert('','end',values=(row.get('company_name',''),row.get('company_website',''),row.get('industry',''),row.get('country',''),row.get('quality_category') or row.get('quality_status',''),wa,email))
        cat_box.bind('<<ComboboxSelected>>',refresh_tasks); tasks.bind('<<TreeviewSelect>>',show_task)
        refresh_tasks()

    def clear(self):
        if messagebox.askyesno('确认','清空当前结果？'):
            self.rows=[]; self.people_rows=[]; self.current_task_id=''
            self._rebuild_row_domain_index()
            for item in self.tree.get_children(): self.tree.delete(item)
            self.status.set('已清空当前任务显示；历史归档和企业数据库均未删除')
            if hasattr(self, 'stats_text'): self.stats_text.set('当前任务结果为空。历史记录仍保存在独立归档文件中。')

def run_application():
    try:
        App().mainloop()
    except Exception:
        import traceback
        log_path=os.path.join(USER_DATA_DIR, 'factorylead_error.log')
        detail=traceback.format_exc()
        try:
            from pathlib import Path
            Path(log_path).write_text(detail,encoding='utf-8')
        except Exception: pass
        try:
            import tkinter.messagebox as _mb
            _mb.showerror('外贸达人启动失败',f'程序启动失败，详细错误已写入：\n{log_path}\n\n{detail[-1800:]}')
        except Exception: pass
        raise

if __name__=='__main__': run_application()
