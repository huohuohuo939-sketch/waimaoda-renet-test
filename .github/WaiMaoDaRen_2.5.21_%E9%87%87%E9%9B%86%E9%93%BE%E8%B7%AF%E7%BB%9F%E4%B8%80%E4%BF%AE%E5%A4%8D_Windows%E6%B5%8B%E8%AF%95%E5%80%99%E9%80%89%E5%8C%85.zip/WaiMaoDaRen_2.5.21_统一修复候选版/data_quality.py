# -*- coding: utf-8 -*-
"""Conservative manufacturer lead classification, contact cleaning and reversible deduplication."""
import re
from urllib.parse import urlparse, parse_qs
try:
    import phonenumbers
except ImportError:
    phonenumbers = None

EMAIL_RE = re.compile(r'^[A-Z0-9.!#$%&\'*+/=?^_`{|}~-]+@[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?(?:\.[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?)+$', re.I)
NOISE = {
    '招聘/职位': re.compile(r'招聘|职位|人才网|招聘网|job\b|career\b|vacancy|sales manager\s*:|international sales representative|sales representative|export sales manager|business development representative|国际业务员|外贸业务员', re.I),
    '新闻/媒体/文章': re.compile(r'\b(news|times|businessline|blog|press release|history month|forum|wiki|directory)\b|新闻|资讯|媒体|博客|论坛|百科|黄页|高考|出路|women.s history month', re.I),
    '营销/软件/服务商': re.compile(r'\b(digital|marketing|crm|software|agency|consulting|advertising)\b|电子商务|电商平台|广告公司|营销公司|软件公司|咨询公司|培训机构', re.I),
    '旅游/酒店/本地导览': re.compile(r'\b(tourism|tourist guide|travel agency|hotel|resort|tours? guide|vacation rental)\b|旅游|旅行社|导游|酒店|度假村|景区|旅游指南', re.I),
    '资讯/无障碍/目录门户': re.compile(r'accessibility\s+(?:guide|directory|portal)|barrier[- ]free|accessible\s+(?:travel|tourism|living)|business\s+directory|supplier\s+directory|news\s+portal|资讯门户|新闻门户|行业资讯平台|企业黄页|供应商目录|无障碍生活|无障碍旅游|无障碍资讯|無障礙生活|無障礙旅遊|無障礙資訊|景点介绍|餐厅指南|活动资讯', re.I),
}
# Strong terms indicate a manufacturing candidate; weak terms alone only send a row to review.
MAKER_STRONG = re.compile(r'\b(manufacturer|manufacturers|manufacturing|factory|factories|production plant|producer|oem|odm|machinery manufacturer|equipment manufacturer|mining machinery)\b|制造商|制造厂|生产厂|工厂|生产基地|生产企业', re.I)
MAKER_MEDIUM = re.compile(r'\b(machinery|machine|equipment|industrial|production|plant|crusher|processing|mining)\b|机械|设备|矿山|矿机|加工|制造', re.I)
DISTRIBUTOR = re.compile(r'\b(distributor|dealer|trading company|supplier|reseller)\b|经销商|代理商|贸易公司|供应商', re.I)
FREE_EMAIL = {'gmail.com','yahoo.com','outlook.com','hotmail.com','163.com','126.com','qq.com','foxmail.com','vip.163.com'}


def _list(v):
    if isinstance(v, str): return [v] if v.strip() else []
    return [str(x).strip() for x in (v or []) if str(x).strip()]


def _emails(values):
    out=[]
    for raw in values:
        for item in re.split(r'[;,\s]+', str(raw or '')):
            e=item.strip().strip('<>()[]{}.,;:').lower()
            if not e or not EMAIL_RE.fullmatch(e): continue
            local,domain=e.rsplit('@',1)
            suffix=domain.rsplit('.',1)[-1]
            if domain in {'example.com','example.org','example.net','test.com','invalid','yourdomain.com','company.com','sentry.io','wixpress.com'}: continue
            if domain.endswith(('.example','.test','.invalid','.localhost','.sentry.io','.wixpress.com')): continue
            if suffix in {'png','jpg','jpeg','gif','svg','webp','avif','ico','bmp','tif','tiff','pdf','woff','woff2','css','js','map'}: continue
            if local.endswith(('.png','.jpg','.jpeg','.gif','.svg','.webp','.avif','.ico','.bmp','.tif','.tiff','.pdf','.woff','.woff2','.css','.js')): continue
            if e not in out: out.append(e)
    return out


def _valid_explicit_wa_digits(digits, allow_compact=True, country='中国'):
    """Validate explicit WhatsApp link numbers without tying phone country to factory country."""
    raw=str(digits or '').strip()
    digits=re.sub(r'\D','',raw)
    if digits.startswith('00'):
        digits=digits[2:]
    if not 9 <= len(digits) <= 15 or digits.startswith(('400','800')):
        return False
    if allow_compact and not raw.startswith(('+','00')) and str(country or '').strip() in {'中国','China','CN','中国大陆'}:
        if len(digits)==11 and digits.startswith('1'):
            return False
        if digits.startswith('86'):
            national=digits[2:]
            if not (len(national)==11 and national.startswith('1') and national[1] in '3456789'):
                return False
    if phonenumbers is not None:
        try:
            parsed=phonenumbers.parse('+'+digits,None)
            if not phonenumbers.is_valid_number(parsed): return False
            allowed={phonenumbers.PhoneNumberType.MOBILE,
                     phonenumbers.PhoneNumberType.FIXED_LINE_OR_MOBILE,
                     phonenumbers.PhoneNumberType.FIXED_LINE,
                     phonenumbers.PhoneNumberType.VOIP}
            return phonenumbers.number_type(parsed) in allowed
        except phonenumbers.NumberParseException:
            return False
    if digits.startswith('86'):
        national=digits[2:]
        return len(national)==11 and national.startswith('1') and national[1] in '3456789'
    return 9 <= len(digits) <= 15


def _wa(values, allow_number=False, country='中国'):
    """Normalize explicit WhatsApp links only; never turn an ordinary phone into WA."""
    out=[]
    for raw in values:
        s=str(raw or '').strip()
        if not s: continue
        try:
            p=urlparse(s if '://' in s else 'https://' + s)
            host=(p.hostname or '').lower()
            if host == 'wa.me':
                path=p.path.strip('/')
                if path.lower().startswith(('message/','invite/')):
                    link='https://wa.me/'+path
                    if link not in out: out.append(link)
                    continue
                candidate=path.split('/')[0]
            elif host == 'whatsapp.com' or host.endswith('.whatsapp.com'):
                if host == 'chat.whatsapp.com' or re.match(r'^/(?:channel|invite)/',p.path,re.I):
                    link='https://'+host+p.path.rstrip('/')
                    if link not in out: out.append(link)
                    continue
                candidate=(parse_qs(p.query).get('phone') or [''])[0]
            else:
                continue
        except Exception:
            continue
        digits=re.sub(r'\D','',candidate)
        if digits.startswith('00'):
            digits=digits[2:]
        if digits and _valid_explicit_wa_digits('+'+digits, country=country):
            link='https://wa.me/'+digits
            if link not in out: out.append(link)
    return out


def _clean_phones(values):
    out=[]
    for raw in values:
        for part in re.split(r'[;\n|]+',str(raw or '')):
            value=part.strip()
            if not value or re.search(r'\b20\d{2}[-/.年]\d{1,2}[-/.月]\d{1,2}',value):
                continue
            digits=re.sub(r'\D','',value)
            if 7 <= len(digits) <= 15 and re.fullmatch(r'[+\d() .\-/extEXT分机号#]+',value):
                if value not in out: out.append(value)
    return out


def _domain(row):
    u=str(row.get('company_website') or row.get('website') or '').strip()
    if not u: return ''
    try:
        p=urlparse(u if '://' in u else 'https://'+u)
        host=(p.hostname or '').lower()
        return host[4:] if host.startswith('www.') else host
    except Exception: return ''


def _name_key(name):
    s=str(name or '').lower()
    s=re.sub(r'\b(limited|ltd|co\.?|company|inc\.?|corp\.?|corporation|group)\b',' ',s)
    return re.sub(r'[^a-z0-9\u4e00-\u9fff]+','',s)


def assess(row):
    name=str(row.get('company_name') or row.get('工厂/公司名称') or row.get('name_title') or row.get('page_title') or '').strip()
    industry=str(row.get('industry') or row.get('industry_category') or row.get('行业') or '')
    page_title=str(row.get('page_title') or row.get('website_title') or '')
    site_type=str(row.get('site_type') or row.get('business_type') or '')
    evidence=' '.join([name, industry, page_title, site_type, str(row.get('manufacturer_evidence') or '')])
    for reason, pat in NOISE.items():
        if pat.search(name) or pat.search(page_title) or pat.search(site_type): return 'excluded', reason
    if MAKER_STRONG.search(evidence): return 'keep', '出现明确制造/工厂/OEM证据，列为制造商候选，仍需官网核实'
    if MAKER_MEDIUM.search(evidence): return 'review', '出现行业或产品词，但尚无明确生产制造证据'
    if DISTRIBUTOR.search(evidence): return 'review', '可能为供应商/经销商/贸易商，需确认是否自有工厂'
    return 'review', '缺少明确制造商证据，暂存待人工复核'


def clean_and_dedupe(rows):
    """Return (accepted, quarantine, stats). Never discard contacts when merging duplicate entities."""
    accepted=[]; quarantine=[]; groups={}
    stats={'input':len(rows),'excluded':0,'review':0,'duplicate_rows_merged':0,'invalid_emails':0,'email_domain_conflicts':0,'mixed_email_domains':0,'phone_values_not_whatsapp':0}
    for index, original in enumerate(rows):
        r=dict(original)
        name=str(r.get('company_name') or r.get('工厂/公司名称') or r.get('name_title') or r.get('page_title') or '').strip()
        status,reason=assess(r)
        if status=='excluded':
            stats['excluded']+=1; quarantine.append({'record':r,'quality_status':'excluded','quality_reason':reason}); continue
        if status=='review': stats['review']+=1
        r['company_name']=name
        # Explicit WA URLs and explicitly labelled WA contact fields only.
        wa_links=_list(r.get('whatsapp_links'))
        wa_contacts=[]
        for raw_wa in _list(r.get('whatsapp_contacts')):
            raw_text=str(raw_wa).strip(); digits=re.sub(r'\D','',raw_text)
            if _valid_explicit_wa_digits(raw_text, allow_compact=True, country=str(r.get('country') or r.get('目标国家') or '中国')):
                normalized='+'+(digits[2:] if raw_text.startswith('00') and digits.startswith('00') else digits)
                if normalized not in wa_contacts: wa_contacts.append(normalized)
        wa_links += _list(r.get('联系方式'))
        r['whatsapp_contacts']=wa_contacts
        r['whatsapp_links']=list(dict.fromkeys(_wa(wa_links, country=str(r.get('country') or r.get('目标国家') or '中国'))))
        raw_emails=_list(r.get('emails'))+_list(r.get('邮箱'))
        valid=_emails(raw_emails); stats['invalid_emails'] += max(0,len(raw_emails)-len(valid))
        r['emails']=valid
        raw_contact_values=[]
        for contact_value in _list(r.get('联系方式')):
            for contact_part in re.split(r'[;\n|]+',contact_value):
                contact_part=contact_part.strip()
                if contact_part and not re.search(r'(?:wa\.me/|whatsapp\.com/)',contact_part,re.I):
                    raw_contact_values.append(contact_part)
        phones=_clean_phones(_list(r.get('phone_candidates'))+raw_contact_values)
        r['phone_candidates']=phones
        stats['phone_values_not_whatsapp'] += len(phones)
        domain=_domain(r)
        email_domains={e.rsplit('@',1)[1] for e in valid}
        if len(email_domains)>1:
            r['quality_warning']='同一记录含多个邮箱域名，需逐个核验邮箱归属'; stats['mixed_email_domains']+=1
        if domain and any(edomain != domain and not edomain.endswith('.'+domain) and edomain not in FREE_EMAIL for edomain in email_domains):
            r['quality_warning']='邮箱域名与官网域名不一致，需核验归属'; stats['email_domain_conflicts']+=1
        key=('domain:'+domain) if domain else ('name:'+_name_key(name) if len(_name_key(name))>=4 else 'row:'+str(index))
        if key in groups:
            primary=groups[key]
            primary['emails']=list(dict.fromkeys(primary.get('emails',[])+valid))
            primary['whatsapp_links']=list(dict.fromkeys(primary.get('whatsapp_links',[])+r['whatsapp_links']))
            primary['whatsapp_contacts']=list(dict.fromkeys(_list(primary.get('whatsapp_contacts'))+_list(r.get('whatsapp_contacts'))))
            primary['source_urls']=list(dict.fromkeys(_list(primary.get('source_urls'))+_list(r.get('source_urls'))))
            primary['phone_candidates']=list(dict.fromkeys(_list(primary.get('phone_candidates'))+phones))
            primary['linkedin_links']=list(dict.fromkeys(_list(primary.get('linkedin_links'))+_list(r.get('linkedin_links'))))
            # Address is merged only inside the same domain/name dedupe group; never copy
            # an address from a different company record.
            if not primary.get('company_address') and r.get('company_address'):
                primary['company_address']=r.get('company_address')
                primary['address_source_url']=r.get('address_source_url','')
            for field in ('contact_evidence','email_details'):
                left=primary.get(field) or ({} if field=='contact_evidence' else [])
                right=r.get(field) or ({} if field=='contact_evidence' else [])
                if field=='contact_evidence' and isinstance(left,dict) and isinstance(right,dict):
                    for kind,mapping in right.items():
                        if isinstance(mapping,dict): left.setdefault(kind,{}).update({k:v for k,v in mapping.items() if k not in left.get(kind,{})})
                    primary[field]=left
                elif field=='email_details' and isinstance(left,list) and isinstance(right,list):
                    seen_email={str(x.get('email','')).lower() for x in left if isinstance(x,dict)}
                    primary[field]=left+[x for x in right if isinstance(x,dict) and str(x.get('email','')).lower() not in seen_email]
            warnings=list(dict.fromkeys(x for x in [primary.get('quality_warning'),r.get('quality_warning')] if x))
            if warnings: primary['quality_warning']='；'.join(warnings)
            primary['notes']=(str(primary.get('notes') or '')+'；合并重复记录：'+name).strip('；')
            stats['duplicate_rows_merged']+=1
            quarantine.append({'record':r,'quality_status':'duplicate_merged','quality_reason':'已合并到主记录 '+str(primary.get('company_name') or name)})
            continue
        r['quality_status']=status; r['quality_category']='制造商候选' if status=='keep' else '待人工复核'; r['quality_reason']=reason
        groups[key]=r
    accepted=list(groups.values())
    def rank(r):
        status=0 if r.get('quality_status')=='keep' else 1
        contact=int(bool(r.get('emails')))+int(bool(r.get('whatsapp_links')))
        score=int(r.get('factory_authenticity_score') or r.get('manufacturer_score') or 0)
        return (status,-score,-contact,str(r.get('company_name','')).casefold())
    accepted.sort(key=rank)
    stats['accepted']=len(accepted); stats['quarantined']=len(quarantine); stats['manufacturer_candidates']=sum(r.get('quality_status')=='keep' for r in accepted); stats['review_kept']=sum(r.get('quality_status')=='review' for r in accepted)
    return accepted,quarantine,stats
