﻿@echo off
setlocal EnableExtensions
chcp 65001 >nul
set "APP_DIR=%~dp0"
set "REQ_FILE=%APP_DIR%requirements.txt"
set "APP_FILE=%APP_DIR%app.py"
set "DATA_ROOT=%LOCALAPPDATA%\WaiMaoDaRen"
if not defined LOCALAPPDATA set "DATA_ROOT=%USERPROFILE%\AppData\Local\WaiMaoDaRen"
if not exist "%DATA_ROOT%" mkdir "%DATA_ROOT%" 2>nul
set "LOG_DIR=%DATA_ROOT%\startup_logs"
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%" 2>nul
set "LOG_FILE=%LOG_DIR%\startup_latest.log"
title WaiMaoDaRen 2.5.21 Unified Pipeline Repair Candidate
echo ============================================================
echo WaiMaoDaRen 2.5.21 Unified Pipeline Repair Candidate Launcher
echo Startup log: "%LOG_FILE%"
echo ============================================================
call :MAIN
set "RC=%ERRORLEVEL%"
if "%RC%"=="0" goto SUCCESS
echo.
echo [ERROR] Startup failed. Details are shown above and saved in:
echo "%LOG_FILE%"
goto FINISH
:SUCCESS
echo.
echo [INFO] Application closed normally.
:FINISH
echo.
echo Press any key to close this window...
pause >nul
exit /b %RC%

:MAIN
>"%LOG_FILE%" echo WaiMaoDaRen 2.5.21 Unified Pipeline Repair Candidate startup log
>>"%LOG_FILE%" echo Date: %DATE% %TIME%
>>"%LOG_FILE%" echo App folder: %APP_DIR%
echo [INFO] Checking application files...
if exist "%REQ_FILE%" goto CHECK_APP
 echo [ERROR] requirements.txt not found: "%REQ_FILE%"
>>"%LOG_FILE%" echo ERROR: requirements.txt not found
exit /b 2
:CHECK_APP
if exist "%APP_FILE%" goto DETECT_PYTHON
echo [ERROR] app.py not found: "%APP_FILE%"
>>"%LOG_FILE%" echo ERROR: app.py not found
exit /b 2
:DETECT_PYTHON
echo [INFO] Detecting Python 3.10 or newer...
set "PYTHON_CMD="
where py >nul 2>nul
if errorlevel 1 goto CHECK_PYTHON_COMMAND
set "PYTHON_CMD=py -3"
:CHECK_PYTHON_COMMAND
if defined PYTHON_CMD goto PYTHON_FOUND
where python >nul 2>nul
if errorlevel 1 goto NO_PYTHON
set "PYTHON_CMD=python"
:PYTHON_FOUND
%PYTHON_CMD% -c "import sys; print('Python:',sys.version); raise SystemExit(0 if sys.version_info >= (3,10) else 1)"
if errorlevel 1 goto BAD_PYTHON
set "PY_TAG="
for /f "delims=" %%V in ('%PYTHON_CMD% -c "import sys; print(str(sys.version_info.major)+str(sys.version_info.minor))"') do set "PY_TAG=%%V"
if defined PY_TAG goto PYTHON_TAG_FOUND
echo [ERROR] Could not determine Python version.
>>"%LOG_FILE%" echo ERROR: Could not determine Python version
exit /b 1
:PYTHON_TAG_FOUND
set "VENV_DIR=%DATA_ROOT%\venv_py%PY_TAG%"
set "VENV_PY=%VENV_DIR%\Scripts\python.exe"
echo [INFO] Using isolated environment: "%VENV_DIR%"
if exist "%VENV_PY%" goto VENV_READY
echo [INFO] Creating Python environment. First launch only.
%PYTHON_CMD% -m venv "%VENV_DIR%"
if errorlevel 1 goto VENV_FAIL
:VENV_READY
"%VENV_PY%" -c "import sys; print('Environment Python:',sys.version); raise SystemExit(0 if sys.version_info >= (3,10) else 1)"
if errorlevel 1 goto INVALID_VENV
"%VENV_PY%" -c "import requests, bs4, openpyxl, truststore, phonenumbers" >nul 2>nul
if not errorlevel 1 goto DEPS_READY
echo [INFO] Installing missing dependencies. This is normally needed only once.
echo [INFO] If installation fails, check internet access and retry.
"%VENV_PY%" -m pip install --disable-pip-version-check -r "%REQ_FILE%"
if errorlevel 1 goto DEPS_FAIL
:DEPS_READY
echo [INFO] Starting application...
>>"%LOG_FILE%" echo Starting app.py
"%VENV_PY%" "%APP_FILE%" >>"%LOG_FILE%" 2>&1
set "APP_RC=%ERRORLEVEL%"
if "%APP_RC%"=="0" exit /b 0
echo [ERROR] Application returned exit code %APP_RC%.
echo [INFO] Application error details follow.
type "%LOG_FILE%"
exit /b %APP_RC%
:NO_PYTHON
echo [ERROR] Python was not found. Install Python 3.11 or 3.12 64-bit.
>>"%LOG_FILE%" echo ERROR: Python launcher not found
exit /b 1
:BAD_PYTHON
echo [ERROR] Python 3.10 or newer is required.
>>"%LOG_FILE%" echo ERROR: Python version is older than 3.10
exit /b 1
:VENV_FAIL
echo [ERROR] Could not create the Python environment.
>>"%LOG_FILE%" echo ERROR: python -m venv failed
exit /b 1
:INVALID_VENV
echo [ERROR] The isolated Python environment is invalid.
>>"%LOG_FILE%" echo ERROR: isolated Python environment invalid
exit /b 1
:DEPS_FAIL
echo [ERROR] Dependency installation failed. Check internet access.
>>"%LOG_FILE%" echo ERROR: dependency installation failed
exit /b 1
