# 2.5.15 集中修复记录

- 历史跳过暂停与历史记录写入分离：继续使用正式 `global_dedup.db`，不再切换 `global_dedup_diagnostic.db`。
- WhatsApp 专项队列按直接 WhatsApp URL 去重；普通官网仍按根域名去重。
- 直接 WhatsApp URL 在专项扫描函数中直接保存，不作为企业官网抓取；无效 WhatsApp 路径不保存。
- 直接 WhatsApp 入口与搜索摘要线索的保存统计单独记录。
- 进度/汇总文字明确区分任务内重复结果合并与历史重复跳过。
- 主官网扫描、失败重试、手动网址核验及 WhatsApp 专项扫描改为可取消的线程池关闭方式。
- 失败网站重试数量限制为当前目标缺口，防止超过用户设定数量。
- 修复 Windows EXE 构建脚本残留的旧版本号。

## 自动化验证

- `python -m unittest discover -s tests -q`：118 项通过。
- `python -m compileall -q .`：通过。
- 测试覆盖离线模拟与回归逻辑，不等于真实搜索引擎/API/目标网站采集验收。

## 尚未完成的外部验收

- 当前执行环境没有可用外网 DNS/HTTP，不能验证真实 Bing、DuckDuckGo、SerpApi、Brave 或目标网站。
- 当前没有安装可运行的 Chromium 浏览器二进制，不能声称支持或验证 JavaScript 动态页面渲染；目前仍以静态 HTML、页面内脚本/JSON、搜索摘要和公开链接提取为主。
- 尚未进行用户 Windows 10 实机 GUI、网络和多小时稳定性测试。
