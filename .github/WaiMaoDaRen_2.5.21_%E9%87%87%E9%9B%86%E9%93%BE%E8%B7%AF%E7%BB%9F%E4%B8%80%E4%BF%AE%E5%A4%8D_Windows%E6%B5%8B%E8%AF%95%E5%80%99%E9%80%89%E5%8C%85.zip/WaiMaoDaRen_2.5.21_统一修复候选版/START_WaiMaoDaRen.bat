@echo off
chcp 65001 >nul
call "%~dp0run_factorylead.bat"
exit /b %ERRORLEVEL%
