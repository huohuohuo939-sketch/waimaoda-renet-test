"""Industry-classified, append-only collection history archive.

The live leads database remains the master contact/evidence store. This archive
keeps per-task snapshots so a company found in several industries/tasks remains
traceable without mixing historical rows into the current task view.
"""
import json
import os
import sqlite3
import time
import hashlib


def connect(path):
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    con = sqlite3.connect(path, timeout=30)
    con.execute('PRAGMA busy_timeout=30000')
    con.execute('PRAGMA journal_mode=DELETE')
    con.execute('PRAGMA synchronous=FULL')
    return con


def _backup_before_schema_change(path):
    """Create one SQLite backup before changing an existing archive schema."""
    backup_path = path + '.pre_category_sync.bak'
    if os.path.exists(backup_path) or not os.path.isfile(path):
        return backup_path if os.path.exists(backup_path) else ''
    src = sqlite3.connect(path, timeout=30)
    dst = sqlite3.connect(backup_path, timeout=30)
    try:
        src.backup(dst)
        dst.commit()
    finally:
        dst.close()
        src.close()
    return backup_path


def _ensure_task_leads_schema(con, path):
    """Upgrade older archive schemas while preserving every stored row."""
    info = con.execute('PRAGMA table_info(task_leads)').fetchall()
    if not info:
        con.execute('''CREATE TABLE task_leads (
            task_id TEXT NOT NULL, domain TEXT NOT NULL, company_name TEXT NOT NULL DEFAULT '',
            website TEXT NOT NULL DEFAULT '', category TEXT NOT NULL DEFAULT '', industry TEXT NOT NULL DEFAULT '',
            country TEXT NOT NULL DEFAULT '', quality_status TEXT NOT NULL DEFAULT 'review',
            collected_at TEXT NOT NULL DEFAULT '', record_json TEXT NOT NULL,
            PRIMARY KEY(task_id, domain, category, industry),
            FOREIGN KEY(task_id) REFERENCES tasks(task_id))''')
        return
    pk = [row[1] for row in sorted((r for r in info if r[5]), key=lambda r: r[5])]
    required = {'task_id','domain','company_name','website','category','industry','country','quality_status','collected_at','record_json'}
    present = {row[1] for row in info}
    if required.issubset(present) and pk == ['task_id','domain','category','industry']:
        return
    _backup_before_schema_change(path)
    con.execute('DROP TABLE IF EXISTS task_leads_new')
    con.execute('''CREATE TABLE task_leads_new (
        task_id TEXT NOT NULL, domain TEXT NOT NULL, company_name TEXT NOT NULL DEFAULT '',
        website TEXT NOT NULL DEFAULT '', category TEXT NOT NULL DEFAULT '', industry TEXT NOT NULL DEFAULT '',
        country TEXT NOT NULL DEFAULT '', quality_status TEXT NOT NULL DEFAULT 'review',
        collected_at TEXT NOT NULL DEFAULT '', record_json TEXT NOT NULL,
        PRIMARY KEY(task_id, domain, category, industry),
        FOREIGN KEY(task_id) REFERENCES tasks(task_id))''')
    defaults = {
        'company_name': "''", 'website': "''", 'category': "''", 'industry': "''",
        'country': "''", 'quality_status': "'review'", 'collected_at': "''",
        'record_json': "'{}'"
    }
    select_cols = ['task_id','domain'] + [x if x in present else f'{defaults[x]} AS {x}' for x in defaults]
    con.execute('INSERT OR REPLACE INTO task_leads_new (' + ','.join(['task_id','domain'] + list(defaults)) + ') SELECT ' + ','.join(select_cols) + ' FROM task_leads')
    con.execute('DROP TABLE task_leads')
    con.execute('ALTER TABLE task_leads_new RENAME TO task_leads')


def init(path):
    con = connect(path)
    try:
        con.execute('''CREATE TABLE IF NOT EXISTS tasks (
            task_id TEXT PRIMARY KEY, created_at TEXT NOT NULL, finished_at TEXT NOT NULL DEFAULT '',
            category TEXT NOT NULL DEFAULT '', industry TEXT NOT NULL DEFAULT '', country TEXT NOT NULL DEFAULT '',
            keywords TEXT NOT NULL DEFAULT '', task_type TEXT NOT NULL DEFAULT '采集',
            record_count INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT '进行中')''')
        _ensure_task_leads_schema(con, path)
        con.execute('CREATE INDEX IF NOT EXISTS idx_history_industry ON task_leads(category,industry,country)')
        con.execute('CREATE INDEX IF NOT EXISTS idx_history_task ON task_leads(task_id)')
        con.commit()
    finally:
        con.close()


def create_task(path, task_id, category, industry, country, keywords, task_type='采集'):
    init(path)
    now = time.strftime('%Y-%m-%d %H:%M:%S')
    con = connect(path)
    try:
        con.execute('''INSERT OR IGNORE INTO tasks(task_id,created_at,category,industry,country,keywords,task_type,status)
                       VALUES(?,?,?,?,?,?,?,'进行中')''',
                    (task_id, now, category or '', industry or '', country or '', keywords or '', task_type))
        con.commit()
    finally:
        con.close()


def record_lead(path, task_id, row):
    if not task_id:
        return False
    init(path)
    domain = str(row.get('company_website') or row.get('website') or '').strip().lower()
    if not domain:
        return False
    from urllib.parse import urlparse
    host = urlparse(domain if '://' in domain else 'https://' + domain).hostname or domain
    host = host.lower().removeprefix('www.')
    con = connect(path)
    try:
        task = con.execute('SELECT category,industry,country FROM tasks WHERE task_id=?', (task_id,)).fetchone()
        task_category, task_industry, task_country = task or ('', '', '')
        category = str(row.get('industry_category') or row.get('category') or task_category or '')
        industry = str(row.get('industry') or task_industry or '')
        country = str(row.get('country') or task_country or '')
        snapshot = dict(row)
        snapshot['industry_category'] = category
        snapshot['industry'] = industry
        snapshot['country'] = country
        snapshot['collection_task_id'] = task_id
        payload = json.dumps(snapshot, ensure_ascii=False, sort_keys=True, default=str)
        con.execute('''INSERT INTO task_leads(task_id,domain,company_name,website,category,industry,country,quality_status,collected_at,record_json)
                       VALUES(?,?,?,?,?,?,?,?,?,?)
                       ON CONFLICT(task_id,domain,category,industry) DO UPDATE SET
                       company_name=excluded.company_name,website=excluded.website,category=excluded.category,
                       industry=excluded.industry,country=excluded.country,quality_status=excluded.quality_status,
                       collected_at=excluded.collected_at,record_json=excluded.record_json''',
                    (task_id, host, str(snapshot.get('company_name') or ''), str(snapshot.get('company_website') or snapshot.get('website') or ''),
                     category, industry, country, str(snapshot.get('quality_status') or 'review'),
                     str(snapshot.get('collected_at') or time.strftime('%Y-%m-%d %H:%M:%S')), payload))
        con.execute("""UPDATE tasks SET category=CASE WHEN category='' THEN ? ELSE category END,
                     industry=CASE WHEN industry='' THEN ? ELSE industry END,
                     country=CASE WHEN country='' THEN ? ELSE country END,
                     record_count=(SELECT COUNT(*) FROM task_leads WHERE task_id=?) WHERE task_id=?""",
                    (category, industry, country, task_id, task_id))
        con.commit()
        return True
    finally:
        con.close()


def finish_task(path, task_id, status='已完成'):
    if not task_id:
        return
    init(path)
    con = connect(path)
    try:
        con.execute('UPDATE tasks SET finished_at=?,status=?,record_count=(SELECT COUNT(*) FROM task_leads WHERE task_id=?) WHERE task_id=?',
                    (time.strftime('%Y-%m-%d %H:%M:%S'), status, task_id, task_id))
        con.commit()
    finally:
        con.close()


def migrate_master_once(path, master_db):
    """Non-destructive one-time import of existing leads, grouped by industry/country."""
    if not os.path.isfile(master_db):
        return {'imported': 0, 'groups': 0}
    init(path)
    con = connect(path)
    try:
        done = con.execute("SELECT 1 FROM tasks WHERE task_id='legacy-master-migration-v2'").fetchone()
        if done:
            return {'imported': 0, 'groups': 0, 'already_migrated': True}
    finally:
        con.close()
    src = sqlite3.connect(master_db, timeout=30)
    try:
        cols = {x[1] for x in src.execute('PRAGMA table_info(leads)')}
        needed = {'domain','company_name','website','category','industry','country'}
        if not needed.issubset(cols):
            return {'imported': 0, 'groups': 0, 'error': 'master schema incomplete'}
        rows = src.execute('SELECT * FROM leads').fetchall()
        names = [x[1] for x in src.execute('PRAGMA table_info(leads)')]
    finally:
        src.close()
    grouped = {}
    for values in rows:
        row = dict(zip(names, values))
        category = str(row.get('category') or '未分类')
        industry = str(row.get('industry') or '未分类')
        country = str(row.get('country') or '未注明')
        key = (category, industry, country)
        grouped.setdefault(key, []).append(row)
    imported = 0
    for key, records in grouped.items():
        category, industry, country = key
        task_id = 'legacy-' + hashlib.sha1(('|'.join(key)).encode('utf-8')).hexdigest()[:16]
        create_task(path, task_id, category, industry, country, '历史数据库迁移', '历史迁移')
        for row in records:
            def arr(name):
                try: return json.loads(row.get(name) or '[]')
                except Exception: return []
            def obj(name):
                try: return json.loads(row.get(name) or '{}')
                except Exception: return {}
            snapshot = {
                'company_name': row.get('company_name') or '', 'company_website': row.get('website') or '',
                'industry_category': category, 'industry': industry, 'country': country,
                'manufacturer_score': row.get('score') or 0, 'operation_score': row.get('operation_score') or 0,
                'manufacturer_evidence': row.get('evidence') or '', 'whatsapp_links': arr('whatsapp'),
                'emails': arr('emails'), 'phone_candidates': arr('phones'), 'linkedin_links': arr('linkedin'),
                'source_urls': arr('sources'), 'status': row.get('status') or '', 'notes': row.get('notes') or '',
                'collected_at': row.get('collected_at') or '', 'email_details': arr('email_details'),
                'whatsapp_contacts': arr('whatsapp_contacts'), 'contact_evidence': obj('contact_evidence'),
                'quality_status': row.get('quality_status') or 'review', 'quality_reason': row.get('quality_reason') or '',
                'history_origin': '历史主数据库迁移'
            }
            if record_lead(path, task_id, snapshot): imported += 1
        finish_task(path, task_id, '历史已归档')
    create_task(path, 'legacy-master-migration-v2', '系统', '历史数据迁移标记 v2', '', '', '系统标记')
    finish_task(path, 'legacy-master-migration-v2', '完成')
    return {'imported': imported, 'groups': len(grouped)}


def merge_archive_file(target_path, source_path):
    """Idempotently merge an older app-folder archive into the canonical user archive."""
    if not source_path or not os.path.isfile(source_path):
        return {'tasks': 0, 'records': 0}
    if os.path.abspath(target_path) == os.path.abspath(source_path):
        return {'tasks': 0, 'records': 0}
    init(target_path)
    init(source_path)
    src = connect(source_path)
    dst = connect(target_path)
    task_count = record_count = 0
    try:
        tasks = src.execute('SELECT task_id,created_at,finished_at,category,industry,country,keywords,task_type,record_count,status FROM tasks').fetchall()
        for row in tasks:
            cur = dst.execute('''INSERT OR IGNORE INTO tasks(task_id,created_at,finished_at,category,industry,country,keywords,task_type,record_count,status)
                                 VALUES(?,?,?,?,?,?,?,?,?,?)''', row)
            task_count += max(0, cur.rowcount)
        leads = src.execute('SELECT task_id,domain,company_name,website,category,industry,country,quality_status,collected_at,record_json FROM task_leads').fetchall()
        for row in leads:
            cur = dst.execute('''INSERT OR IGNORE INTO task_leads(task_id,domain,company_name,website,category,industry,country,quality_status,collected_at,record_json)
                                 VALUES(?,?,?,?,?,?,?,?,?,?)''', row)
            record_count += max(0, cur.rowcount)
        dst.execute('''UPDATE tasks SET record_count=(SELECT COUNT(*) FROM task_leads WHERE task_id=tasks.task_id)
                       WHERE task_id IN (SELECT task_id FROM task_leads)''')
        dst.commit()
    except Exception:
        dst.rollback()
        raise
    finally:
        src.close()
        dst.close()
    return {'tasks': task_count, 'records': record_count}


def list_categories(path):
    init(path)
    con = connect(path)
    try:
        return [r[0] for r in con.execute("SELECT category FROM (SELECT category FROM tasks WHERE category!='' AND task_type!='系统标记' UNION SELECT category FROM task_leads WHERE category!='') ORDER BY category")]
    finally:
        con.close()


def list_tasks(path, category='全部行业'):
    init(path)
    con = connect(path)
    try:
        sql = '''SELECT t.task_id,t.created_at,
                        COALESCE(NULLIF(GROUP_CONCAT(DISTINCT NULLIF(l.category,'')),''),t.category),
                        COALESCE(NULLIF(GROUP_CONCAT(DISTINCT NULLIF(l.industry,'')),''),t.industry),
                        COALESCE(NULLIF(GROUP_CONCAT(DISTINCT NULLIF(l.country,'')),''),t.country),t.task_type,COUNT(DISTINCT l.domain),t.status
                 FROM tasks t LEFT JOIN task_leads l ON l.task_id=t.task_id
                 WHERE t.task_id NOT IN ('legacy-master-migration-v1','legacy-master-migration-v2') '''
        args = []
        if category and category != '全部行业':
            sql += ' AND (t.category=? OR EXISTS (SELECT 1 FROM task_leads lf WHERE lf.task_id=t.task_id AND lf.category=?))'; args.extend([category, category])
        sql += ' GROUP BY t.task_id ORDER BY t.created_at DESC'
        return con.execute(sql, args).fetchall()
    finally:
        con.close()


def list_task_leads(path, task_id):
    init(path)
    con = connect(path)
    try:
        rows = con.execute('SELECT record_json FROM task_leads WHERE task_id=? ORDER BY company_name', (task_id,)).fetchall()
        out=[]
        for (raw,) in rows:
            try: out.append(json.loads(raw))
            except Exception: pass
        return out
    finally:
        con.close()
